"""Executable Phase-3 neural-code workflow for rapid maze learning.

The workflow consumes only frozen Phase-0/Phase-1 tables and the exact
selected/C paths recorded by Phase 0.  It estimates C-primary tree-depth code
in early (B) and late (C) Day-1 epochs, then applies physically separated
cross-subtree tests to the late epoch.  Its separately addressable H-NR1 branch
tests Day-2 reward introduction using C-primary node-94 visit templates,
matched pseudo-terminal controls, and a distributed-coordinate fallback.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
from math import comb
from pathlib import Path
from typing import Any, Mapping, Sequence

import h5py
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.kernel_approximation import RBFSampler
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .config import DT, REWARD_NODE
from .maze import NewMaze
from .rapid_learning_neural_codes import (
    RewardVisitSpec,
    assess_topology_support,
    balance_topology_masks,
    balanced_accuracy,
    classify_node94_interpretation,
    compute_pseudo_target_did,
    fixed_topology_folds,
    match_pseudo_terminal_controls,
    poisson_decoder_adapter,
    posthoc_interior_depth_folds,
    run_topology_fold_backends,
    select_reward_target_visits,
    topology_fold_masks,
)


@dataclass(frozen=True)
class Phase3Config:
    time_window_frames: int = 8
    min_c_per_min: float = 0.1
    min_frames_per_depth: int = 50
    rescue_min_frames_per_depth: int = 25
    min_visits_per_depth: int = 2
    min_common_depths: int = 5
    n_label_shuffles: int = 200
    seed: int = 2718
    min_cells: int = 10
    n_animal_bootstrap: int = 10000
    animal_ci_level: float = 0.95
    animal_inference_alpha: float = 0.05
    min_animals_inference: int = 5
    reward_n_bootstrap: int = 1000
    reward_min_distributed_nodes: int = 8
    reward_distributed_ridge_alpha: float = 10.0

    @property
    def count_window_samples(self) -> int:
        return int(self.time_window_frames) + 1

    @property
    def count_window_exposure_s(self) -> float:
        return float(self.count_window_samples) * float(DT)


@dataclass(frozen=True)
class EpochData:
    session_id: str
    epoch: str
    absolute_frames: np.ndarray
    counts_c: np.ndarray
    raw_c_at_frame: np.ndarray
    depth: np.ndarray
    run: np.ndarray
    spatial_cell: np.ndarray
    xy_behavior: np.ndarray
    visit_id: np.ndarray
    selected_row_index: np.ndarray


@dataclass(frozen=True)
class CommonDepthPlan:
    """Frozen support plan shared by every side of a paired decoder."""

    status: str
    support_tier: str
    selected_depths: tuple[int, ...]
    excluded_depths: tuple[int, ...]
    min_frames_per_depth: int


def _json_ready(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_epoch_boundaries(
    assigned_choices: pd.DataFrame,
    transitions: pd.DataFrame,
) -> pd.DataFrame:
    """Resolve Phase-1 B/C decisions to exact Phase-0 frame boundaries."""

    required_assigned = {
        "session_id",
        "animal_id",
        "cohort_group",
        "decision_id",
        "epoch",
        "abs_frame_start",
    }
    required_transitions = {
        "transition_id",
        "session_id",
        "abs_frame_start",
        "abs_frame_end",
    }
    missing = sorted(required_assigned.difference(assigned_choices.columns))
    if missing:
        raise KeyError(f"assigned choices missing columns: {missing}")
    missing = sorted(required_transitions.difference(transitions.columns))
    if missing:
        raise KeyError(f"transition table missing columns: {missing}")
    assigned = assigned_choices.drop_duplicates(
        ["session_id", "decision_id", "epoch"]
    ).copy()
    endpoints = transitions[
        ["session_id", "transition_id", "abs_frame_start", "abs_frame_end"]
    ].drop_duplicates(["session_id", "transition_id"])
    merged = assigned.merge(
        endpoints,
        left_on=["session_id", "decision_id"],
        right_on=["session_id", "transition_id"],
        how="left",
        suffixes=("_phase1", "_phase0"),
        validate="many_to_one",
    )
    rows: list[dict[str, Any]] = []
    for keys, group in merged.groupby(
        ["session_id", "animal_id", "cohort_group", "epoch"], sort=False
    ):
        session_id, animal_id, context, epoch = keys
        starts = pd.to_numeric(group["abs_frame_start_phase0"], errors="coerce")
        ends = pd.to_numeric(group["abs_frame_end"], errors="coerce")
        if starts.isna().any() or ends.isna().any():
            status = "unresolved_transition_frame_boundary"
            frame_start = frame_end = np.nan
        else:
            status = "ok"
            frame_start = float(starts.min())
            frame_end = float(ends.max())
        rows.append(
            {
                "session_id": str(session_id),
                "animal_id": str(animal_id),
                "cohort_group": str(context),
                "epoch": str(epoch),
                "frame_start": frame_start,
                "frame_end": frame_end,
                "n_assigned_decisions": int(group["decision_id"].nunique()),
                "status": status,
            }
        )
    return pd.DataFrame(rows)


def selected_explore_epoch_mask(
    selected: pd.DataFrame,
    transitions: pd.DataFrame,
    *,
    frame_start: float,
    frame_end: float,
) -> np.ndarray:
    """Select rows inside a frozen epoch and a Phase-0 explore interval."""

    if "frame" not in selected.columns:
        raise KeyError("selected table is missing frame")
    required = {"abs_frame_start", "abs_frame_end", "mode_label"}
    missing = sorted(required.difference(transitions.columns))
    if missing:
        raise KeyError(f"transition table missing columns: {missing}")
    frames = pd.to_numeric(selected["frame"], errors="coerce").to_numpy(dtype=float)
    epoch = (
        np.isfinite(frames)
        & (frames >= float(frame_start))
        & (frames <= float(frame_end))
    )
    explore = transitions.loc[
        transitions["mode_label"].astype(str).eq("explore")
    ].copy()
    explore = explore.loc[
        pd.to_numeric(explore["abs_frame_end"], errors="coerce").ge(float(frame_start))
        & pd.to_numeric(explore["abs_frame_start"], errors="coerce").le(
            float(frame_end)
        )
    ]
    intervals = (
        explore[["abs_frame_start", "abs_frame_end"]]
        .apply(pd.to_numeric, errors="coerce")
        .dropna()
        .sort_values("abs_frame_start")
    )
    in_explore = np.zeros(frames.size, dtype=bool)
    for start, end in intervals.to_numpy(dtype=float):
        in_explore |= (frames >= start) & (frames <= end)
    return epoch & in_explore


def selected_frame_geometry(
    selected: pd.DataFrame, maze: Any | None = None
) -> dict[str, np.ndarray]:
    """Map selected rows to maze cells/runs/depth with the verified axis convention."""

    maze = NewMaze(6) if maze is None else maze
    required = {"frame", "mass_bx", "mass_by", "mass_x", "mass_y", "speed", "head_dir"}
    missing = sorted(required.difference(selected.columns))
    if missing:
        raise KeyError(f"selected table missing geometry columns: {missing}")
    bx = pd.to_numeric(selected["mass_bx"], errors="coerce").to_numpy(dtype=float)
    by = pd.to_numeric(selected["mass_by"], errors="coerce").to_numpy(dtype=float)
    cells = np.full(len(selected), -1, dtype=int)
    finite = np.isfinite(bx) & np.isfinite(by)
    for index in np.flatnonzero(finite):
        # Project convention: ma.ce key is (mass_by, mass_bx).
        cells[index] = int(maze.ce.get((int(by[index]), int(bx[index])), -1))
    runs = np.full(len(selected), -1, dtype=int)
    valid_cell = (cells >= 0) & (cells < len(maze.rc))
    runs[valid_cell] = np.asarray(maze.rc, dtype=int)[cells[valid_cell]]
    run_depth = np.full(len(maze.ru), -1, dtype=int)
    run_depth[0] = 0
    for parent, children in enumerate(np.asarray(maze.ch, dtype=int)):
        if run_depth[parent] < 0:
            continue
        for child in children:
            if int(child) >= 0:
                run_depth[int(child)] = run_depth[parent] + 1
    depth = np.full(len(selected), -1, dtype=int)
    valid_run = (runs >= 0) & (runs < len(run_depth))
    depth[valid_run] = run_depth[runs[valid_run]]
    head = pd.to_numeric(selected["head_dir"], errors="coerce").to_numpy(dtype=float)
    xy = np.column_stack(
        [
            pd.to_numeric(selected["mass_x"], errors="coerce"),
            pd.to_numeric(selected["mass_y"], errors="coerce"),
            pd.to_numeric(selected["speed"], errors="coerce"),
            np.sin(head),
            np.cos(head),
        ]
    ).astype(float)
    for column in range(xy.shape[1]):
        bad = ~np.isfinite(xy[:, column])
        fill = float(np.nanmedian(xy[:, column])) if np.any(~bad) else 0.0
        xy[bad, column] = fill
    return {"cell": cells, "run": runs, "depth": depth, "xy_behavior": xy}


def contiguous_run_visits(frames: Sequence[int], runs: Sequence[int]) -> np.ndarray:
    """Assign visit IDs; selected-frame discontinuities start new visits."""

    frames = np.asarray(frames, dtype=int)
    runs = np.asarray(runs, dtype=int)
    if frames.ndim != 1 or runs.ndim != 1 or frames.size != runs.size:
        raise ValueError("frames and runs must be equal-length vectors")
    if frames.size == 0:
        return np.asarray([], dtype=int)
    boundary = np.ones(frames.size, dtype=bool)
    boundary[1:] = (runs[1:] != runs[:-1]) | (np.diff(frames) != 1)
    return np.cumsum(boundary).astype(int) - 1


def transition_run_visits(
    frames: Sequence[int],
    transitions: pd.DataFrame,
    maze: Any | None = None,
) -> np.ndarray:
    """Map selected frames to run visits defined on the full trajectory.

    This remains stable when low-speed rows are absent from ``selected_df``.
    A new visit starts when the full trajectory changes maze run, bout, or
    splitter clip.
    """

    maze = NewMaze(6) if maze is None else maze
    frames = np.asarray(frames, dtype=int)
    required = {
        "abs_frame_start",
        "abs_frame_end",
        "current_node",
        "bout",
        "clip_index",
    }
    missing = sorted(required.difference(transitions.columns))
    if missing:
        raise KeyError(f"transition table missing visit columns: {missing}")
    ordered = transitions.sort_values("abs_frame_start", kind="stable").reset_index(
        drop=True
    )
    if ordered.empty:
        return np.full(len(frames), -1, dtype=int)
    starts = pd.to_numeric(ordered["abs_frame_start"], errors="coerce").to_numpy(
        dtype=float
    )
    ends = pd.to_numeric(ordered["abs_frame_end"], errors="coerce").to_numpy(
        dtype=float
    )
    nodes = pd.to_numeric(ordered["current_node"], errors="coerce").to_numpy(
        dtype=float
    )
    transition_runs = np.full(len(ordered), -1, dtype=int)
    valid_nodes = np.isfinite(nodes) & (nodes >= 0) & (nodes < len(maze.rc))
    transition_runs[valid_nodes] = np.asarray(maze.rc, dtype=int)[
        nodes[valid_nodes].astype(int)
    ]
    bouts = (
        pd.to_numeric(ordered["bout"], errors="coerce").fillna(-1).to_numpy(dtype=int)
    )
    clips = (
        pd.to_numeric(ordered["clip_index"], errors="coerce")
        .fillna(-1)
        .to_numpy(dtype=int)
    )
    boundary = np.ones(len(ordered), dtype=bool)
    boundary[1:] = (
        (transition_runs[1:] != transition_runs[:-1])
        | (bouts[1:] != bouts[:-1])
        | (clips[1:] != clips[:-1])
    )
    transition_visits = np.cumsum(boundary).astype(int) - 1
    index = np.searchsorted(starts, frames, side="right") - 1
    safe = np.clip(index, 0, len(starts) - 1)
    valid = (
        (index >= 0)
        & (index < len(starts))
        & np.isfinite(starts[safe])
        & np.isfinite(ends[safe])
        & (frames >= starts[safe])
        & (frames <= ends[safe])
    )
    out = np.full(len(frames), -1, dtype=int)
    out[valid] = transition_visits[safe[valid]]
    return out


def load_c_count_windows(
    neural_file: str | Path,
    absolute_frames: Sequence[int],
    *,
    time_window_frames: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Load only C samples needed for inclusive trailing count windows."""

    path = Path(neural_file)
    frames = np.asarray(absolute_frames, dtype=int)
    if frames.ndim != 1 or frames.size == 0:
        raise ValueError("absolute_frames must be a nonempty vector")
    if np.any(frames < 0):
        raise ValueError("absolute_frames cannot be negative")
    lookback = int(time_window_frames)
    offsets = np.arange(lookback, -1, -1, dtype=int)
    required = frames[:, None] - offsets[None, :]
    required[required < 0] = 0
    unique = np.unique(required)
    with h5py.File(path, "r") as handle:
        if "C" not in handle or not isinstance(handle["C"], h5py.Dataset):
            raise ValueError(f"{path} does not contain a dense HDF5 C dataset")
        dataset = handle["C"]
        if dataset.ndim != 2 or int(unique[-1]) >= dataset.shape[0]:
            raise ValueError("requested frame is outside the frozen C dataset")
        loaded = np.asarray(dataset[unique, :], dtype=float)
        n_time, n_cells = map(int, dataset.shape)
    locations = np.searchsorted(unique, required)
    windows = loaded[locations]
    counts = np.sum(windows, axis=1)
    raw_at_frame = loaded[np.searchsorted(unique, frames)]
    return (
        counts,
        raw_at_frame,
        {
            "neural_file": str(path),
            "C_storage_orientation": "absolute_frame_by_cell",
            "C_n_time": n_time,
            "C_n_cells": n_cells,
            "n_requested_frames": int(frames.size),
            "n_unique_C_frames_loaded": int(unique.size),
            "count_window_lookback_frames": lookback,
            "count_window_nominal_samples": lookback + 1,
            "exposure_policy": "inclusive_sample_count",
        },
    )


def _xy_behavior_backend(
    train_x: np.ndarray,
    train_y: np.ndarray,
    test_x: np.ndarray,
    *,
    n_classes: int,
    metadata: Mapping[str, Any],
) -> np.ndarray:
    del n_classes
    seed = int(metadata.get("xy_backend_seed", metadata.get("seed", 0)))
    model = make_pipeline(
        StandardScaler(),
        RBFSampler(gamma=1.0, n_components=128, random_state=seed),
        LogisticRegression(C=1.0, max_iter=1000, random_state=seed),
    )
    model.fit(train_x, train_y)
    return np.asarray(model.predict(test_x), dtype=int)


def _activity_gate(
    raw_c: np.ndarray, *, min_c_per_min: float
) -> tuple[np.ndarray, np.ndarray]:
    minutes = max(float(raw_c.shape[0]) * float(DT) / 60.0, np.finfo(float).eps)
    rate = np.nansum(raw_c, axis=0) / minutes
    keep = (
        np.isfinite(rate)
        & (rate >= float(min_c_per_min))
        & (np.nanvar(raw_c, axis=0) > 0)
    )
    return keep, rate


def _chronological_visit_split(
    depth: np.ndarray,
    visits: np.ndarray,
    depths: Sequence[int],
) -> tuple[np.ndarray, np.ndarray]:
    train = np.zeros(depth.size, dtype=bool)
    test = np.zeros(depth.size, dtype=bool)
    for value in depths:
        indices = np.flatnonzero(depth == int(value))
        ordered_visits = list(dict.fromkeys(visits[indices].tolist()))
        for position, visit in enumerate(ordered_visits):
            target = train if position % 2 == 0 else test
            target |= (depth == int(value)) & (visits == visit)
    return train, test


def _split_support_status(
    depth: np.ndarray,
    visits: np.ndarray,
    train: np.ndarray,
    test: np.ndarray,
    depths: Sequence[int],
    *,
    min_frames: int,
    min_visits: int,
) -> tuple[str, list[dict[str, Any]]]:
    rows = []
    status = "ok"
    for split_name, mask in (("train", train), ("test", test)):
        for value in depths:
            selected = mask & (depth == int(value))
            n_frames = int(np.sum(selected))
            n_visits = int(np.unique(visits[selected]).size)
            rows.append(
                {
                    "split": split_name,
                    "depth": int(value),
                    "n_frames": n_frames,
                    "n_visits": n_visits,
                }
            )
            if n_visits < int(min_visits):
                status = "insufficient_visits_per_depth"
            elif n_frames < int(min_frames) and status == "ok":
                status = "insufficient_frames_per_depth"
    return status, rows


def _depths_text(depths: Sequence[int]) -> str:
    return "|".join(str(int(value)) for value in depths)


def _select_common_depth_plan(
    scopes: Sequence[tuple[str, str, np.ndarray, np.ndarray, np.ndarray]],
    config: Phase3Config,
    *,
    analysis: str,
) -> tuple[CommonDepthPlan, pd.DataFrame]:
    """Choose one deterministic depth set that passes every paired scope.

    ``scopes`` contains ``(epoch, split, depth, visit_id, mask)`` tuples.  A
    depth is eligible only when it meets the frame and visit floors in every
    scope.  The seven-depth primary is always attempted first; named common-
    depth rescues never lower the visit floor or split visits framewise.
    """

    all_depths = tuple(range(7))
    attempts = (
        ("primary_7depth", int(config.min_frames_per_depth), True),
        (
            "rescue_common_depth_primary_frames",
            int(config.min_frames_per_depth),
            False,
        ),
        (
            "rescue_7depth_frames",
            int(config.rescue_min_frames_per_depth),
            True,
        ),
        (
            "rescue_common_depth_rescue_frames",
            int(config.rescue_min_frames_per_depth),
            False,
        ),
    )
    audit_rows: list[dict[str, Any]] = []
    for attempt_index, (tier, min_frames, require_all) in enumerate(attempts):
        eligible: list[int] = []
        failures_by_depth: dict[int, list[str]] = {value: [] for value in all_depths}
        measurements: list[dict[str, Any]] = []
        for epoch_name, split_name, depth, visits, mask in scopes:
            for value in all_depths:
                selected = np.asarray(mask, dtype=bool) & (depth == int(value))
                n_frames = int(np.sum(selected))
                n_visits = int(np.unique(visits[selected]).size)
                if n_frames < int(min_frames):
                    failures_by_depth[value].append(
                        f"{epoch_name}:{split_name}:frames<{int(min_frames)}"
                    )
                if n_visits < int(config.min_visits_per_depth):
                    failures_by_depth[value].append(
                        f"{epoch_name}:{split_name}:visits<{int(config.min_visits_per_depth)}"
                    )
                measurements.append(
                    {
                        "analysis": analysis,
                        "attempt_index": int(attempt_index),
                        "support_tier": tier,
                        "epoch": str(epoch_name),
                        "split": str(split_name),
                        "depth": int(value),
                        "n_frames": n_frames,
                        "n_visits": n_visits,
                        "min_frames_gate": int(min_frames),
                        "min_visits_gate": int(config.min_visits_per_depth),
                    }
                )
        eligible = [value for value in all_depths if not failures_by_depth[value]]
        if require_all:
            selected_depths = all_depths if len(eligible) == len(all_depths) else ()
        else:
            selected_depths = (
                tuple(eligible)
                if len(eligible) >= int(config.min_common_depths)
                else ()
            )
        plan_status = f"ok_{tier}" if selected_depths else "attempt_failed"
        excluded_depths = tuple(
            value for value in all_depths if value not in set(selected_depths)
        )
        selected_text = _depths_text(selected_depths)
        excluded_text = _depths_text(excluded_depths)
        for row in measurements:
            value = int(row["depth"])
            if value in selected_depths:
                excluded_reason = ""
            elif failures_by_depth[value]:
                excluded_reason = "|".join(sorted(set(failures_by_depth[value])))
            else:
                excluded_reason = "excluded_by_seven_depth_requirement"
            row.update(
                {
                    "depth_eligible_all_scopes": bool(value in eligible),
                    "depth_selected": bool(value in selected_depths),
                    "excluded_reason": excluded_reason,
                    "plan_status": plan_status,
                    "selected_depths": selected_text,
                    "excluded_depths": excluded_text,
                    "n_selected_depths": int(len(selected_depths)),
                    "min_common_depths_gate": int(config.min_common_depths),
                }
            )
        audit_rows.extend(measurements)
        if selected_depths:
            return (
                CommonDepthPlan(
                    status=plan_status,
                    support_tier=tier,
                    selected_depths=tuple(int(value) for value in selected_depths),
                    excluded_depths=tuple(int(value) for value in excluded_depths),
                    min_frames_per_depth=int(min_frames),
                ),
                pd.DataFrame(audit_rows),
            )
    if audit_rows:
        for row in audit_rows[-len(scopes) * len(all_depths) :]:
            row["plan_status"] = "insufficient_common_depths"
    return (
        CommonDepthPlan(
            status="insufficient_common_depths",
            support_tier="unresolved",
            selected_depths=(),
            excluded_depths=all_depths,
            min_frames_per_depth=int(config.rescue_min_frames_per_depth),
        ),
        pd.DataFrame(audit_rows),
    )


def select_common_within_depth_plan(
    epoch_b: EpochData,
    epoch_c: EpochData,
    config: Phase3Config,
) -> tuple[CommonDepthPlan, pd.DataFrame]:
    """Select one depth set supported by B/C train and test visit blocks."""

    scopes = []
    for epoch in (epoch_b, epoch_c):
        train, test = _chronological_visit_split(
            epoch.depth, epoch.visit_id, tuple(range(7))
        )
        scopes.extend(
            [
                (epoch.epoch, "train", epoch.depth, epoch.visit_id, train),
                (epoch.epoch, "test", epoch.depth, epoch.visit_id, test),
            ]
        )
    return _select_common_depth_plan(scopes, config, analysis="paired_B_C")


def _select_cross_day_depth_plan(
    train_epoch: EpochData,
    test_epoch: EpochData,
    config: Phase3Config,
) -> tuple[CommonDepthPlan, pd.DataFrame]:
    scopes = [
        (
            train_epoch.epoch,
            "train_day1_C",
            train_epoch.depth,
            train_epoch.visit_id,
            np.ones(train_epoch.depth.size, dtype=bool),
        ),
        (
            test_epoch.epoch,
            "test_day2_pre",
            test_epoch.depth,
            test_epoch.visit_id,
            np.ones(test_epoch.depth.size, dtype=bool),
        ),
    ]
    return _select_common_depth_plan(scopes, config, analysis="day1C_to_day2_prereward")


def _shuffle_depth_accuracy(
    train_c: np.ndarray,
    train_depth: np.ndarray,
    test_c: np.ndarray,
    test_depth: np.ndarray,
    *,
    train_visit_id: np.ndarray,
    dt_eff: float,
    n_shuffle: int,
    seed: int,
) -> np.ndarray:
    unique = np.unique(np.concatenate([train_depth, test_depth]))
    encode = {int(value): index for index, value in enumerate(unique)}
    decode = {index: int(value) for value, index in encode.items()}
    train_visit_id = np.asarray(train_visit_id)
    if train_visit_id.shape != train_depth.shape:
        raise ValueError("train_visit_id must align with train_depth")
    visits = np.unique(train_visit_id)
    visit_labels = []
    for visit in visits:
        labels, counts = np.unique(
            train_depth[train_visit_id == visit], return_counts=True
        )
        visit_labels.append(int(labels[np.argmax(counts)]))
    visit_labels = np.asarray(visit_labels, dtype=int)
    rng = np.random.default_rng(int(seed))
    out = np.empty(max(1, int(n_shuffle)), dtype=float)
    metadata = {"dt": float(dt_eff), "prior_mode": "uniform"}
    for index in range(out.size):
        permuted = rng.permutation(visit_labels)
        label_by_visit = dict(zip(visits.tolist(), permuted.tolist()))
        shuffled_depth = np.asarray(
            [label_by_visit[value] for value in train_visit_id], dtype=int
        )
        y = np.asarray([encode[int(value)] for value in shuffled_depth], dtype=int)
        pred_encoded = poisson_decoder_adapter(
            train_c,
            y,
            test_c,
            n_classes=len(unique),
            metadata=metadata,
        )
        pred = np.asarray([decode.get(int(value), -1) for value in pred_encoded])
        out[index] = balanced_accuracy(test_depth, pred)
    return out


def _position_to_depth_prediction(
    train_c: np.ndarray,
    train_spatial: np.ndarray,
    train_depth: np.ndarray,
    test_c: np.ndarray,
    *,
    dt_eff: float,
) -> np.ndarray:
    spatial_values = np.unique(train_spatial)
    encode = {int(value): index for index, value in enumerate(spatial_values)}
    decode = {index: int(value) for value, index in encode.items()}
    y = np.asarray([encode[int(value)] for value in train_spatial], dtype=int)
    pred_encoded = poisson_decoder_adapter(
        train_c,
        y,
        test_c,
        n_classes=len(spatial_values),
        metadata={"dt": float(dt_eff), "prior_mode": "uniform"},
    )
    pred_spatial = np.asarray([decode.get(int(value), -1) for value in pred_encoded])
    mapping = {}
    for value in spatial_values:
        depths = train_depth[train_spatial == value]
        labels, counts = np.unique(depths, return_counts=True)
        mapping[int(value)] = int(labels[np.argmax(counts)])
    return np.asarray(
        [mapping.get(int(value), -1) for value in pred_spatial], dtype=int
    )


def within_epoch_training_cell_mask(
    epoch: EpochData,
    config: Phase3Config,
    *,
    depth_plan: CommonDepthPlan | None = None,
) -> np.ndarray | None:
    """Return a training-only cell gate for one B/C epoch."""

    depths = (
        tuple(range(7))
        if depth_plan is None
        else tuple(int(value) for value in depth_plan.selected_depths)
    )
    if not depths:
        return None
    train, test = _chronological_visit_split(epoch.depth, epoch.visit_id, depths)
    min_frames = (
        int(config.min_frames_per_depth)
        if depth_plan is None
        else int(depth_plan.min_frames_per_depth)
    )
    status, _ = _split_support_status(
        epoch.depth,
        epoch.visit_id,
        train,
        test,
        depths,
        min_frames=min_frames,
        min_visits=config.min_visits_per_depth,
    )
    if status != "ok" and depth_plan is None:
        min_frames = int(config.rescue_min_frames_per_depth)
        status, _ = _split_support_status(
            epoch.depth,
            epoch.visit_id,
            train,
            test,
            depths,
            min_frames=min_frames,
            min_visits=config.min_visits_per_depth,
        )
    if status != "ok":
        return None
    train, _ = balance_topology_masks(
        epoch.depth,
        train,
        test,
        depths,
        seed=config.seed + (0 if epoch.epoch == "B" else 1),
    )
    keep, _ = _activity_gate(
        epoch.raw_c_at_frame[train], min_c_per_min=config.min_c_per_min
    )
    return keep


def evaluate_within_epoch_depth_code(
    epoch: EpochData,
    config: Phase3Config,
    *,
    fixed_cell_mask: np.ndarray | None = None,
    depth_plan: CommonDepthPlan | None = None,
) -> tuple[dict[str, Any], pd.DataFrame, pd.DataFrame]:
    """Decode a frozen all-seven or paired common-depth support plan."""

    if depth_plan is None:
        depths = tuple(range(7))
        support_tier = "primary_7depth"
        min_frames = int(config.min_frames_per_depth)
    else:
        depths = tuple(int(value) for value in depth_plan.selected_depths)
        support_tier = str(depth_plan.support_tier)
        min_frames = int(depth_plan.min_frames_per_depth)
    if not depths:
        return (
            {
                "session_id": epoch.session_id,
                "epoch": epoch.epoch,
                "status": "insufficient_common_depths",
                "support_tier": "unresolved",
                "selected_depths": "",
                "excluded_depths": _depths_text(tuple(range(7))),
                "n_depth_classes": 0,
            },
            pd.DataFrame(),
            pd.DataFrame(),
        )
    train, test = _chronological_visit_split(epoch.depth, epoch.visit_id, depths)
    status, support_rows = _split_support_status(
        epoch.depth,
        epoch.visit_id,
        train,
        test,
        depths,
        min_frames=min_frames,
        min_visits=config.min_visits_per_depth,
    )
    if status != "ok" and depth_plan is None:
        min_frames = int(config.rescue_min_frames_per_depth)
        rescue_status, support_rows_rescue = _split_support_status(
            epoch.depth,
            epoch.visit_id,
            train,
            test,
            depths,
            min_frames=min_frames,
            min_visits=config.min_visits_per_depth,
        )
        for row in support_rows_rescue:
            row["support_tier"] = "rescue_7depth_frames"
        support_rows.extend(support_rows_rescue)
        if rescue_status == "ok":
            status = "ok"
            support_tier = "rescue_7depth_frames"
    for row in support_rows:
        row.setdefault("support_tier", support_tier)
        row.update(
            {
                "session_id": epoch.session_id,
                "epoch": epoch.epoch,
                "analysis": "within_epoch",
                "selected_depth": True,
                "selected_depths": _depths_text(depths),
                "excluded_depths": _depths_text(
                    tuple(value for value in range(7) if value not in set(depths))
                ),
                "n_depth_classes": int(len(depths)),
                "min_frames_gate": int(min_frames),
            }
        )
    if not status.startswith("ok"):
        return (
            {
                "session_id": epoch.session_id,
                "epoch": epoch.epoch,
                "status": status,
                "support_tier": "unresolved",
                "selected_depths": _depths_text(depths),
                "excluded_depths": _depths_text(
                    tuple(value for value in range(7) if value not in set(depths))
                ),
                "n_depth_classes": int(len(depths)),
            },
            pd.DataFrame(support_rows),
            pd.DataFrame(),
        )
    train, test = balance_topology_masks(
        epoch.depth,
        train,
        test,
        depths,
        seed=config.seed + (0 if epoch.epoch == "B" else 1),
    )
    # Freeze the activity gate from training data only; test activity never
    # decides which cells enter a held-out decoder.
    candidate_cells, rates = _activity_gate(
        epoch.raw_c_at_frame[train], min_c_per_min=config.min_c_per_min
    )
    if fixed_cell_mask is None:
        keep_cells = candidate_cells
        cell_gate_source = "balanced_training_frames_only"
    else:
        keep_cells = np.asarray(fixed_cell_mask, dtype=bool)
        if keep_cells.shape != candidate_cells.shape:
            raise ValueError("fixed_cell_mask does not align with C cells")
        cell_gate_source = "common_B_C_training_only_intersection"
    if int(np.sum(keep_cells)) < int(config.min_cells):
        return (
            {
                "session_id": epoch.session_id,
                "epoch": epoch.epoch,
                "status": "insufficient_C_cells_after_rate_gate",
                "n_cells": int(np.sum(keep_cells)),
                "support_tier": support_tier,
                "selected_depths": _depths_text(depths),
                "excluded_depths": _depths_text(
                    tuple(value for value in range(7) if value not in set(depths))
                ),
                "n_depth_classes": int(len(depths)),
            },
            pd.DataFrame(support_rows),
            pd.DataFrame(),
        )
    c = epoch.counts_c[:, keep_cells]
    encode = {int(value): index for index, value in enumerate(depths)}
    decode = {index: int(value) for value, index in encode.items()}
    topology_pred_encoded = poisson_decoder_adapter(
        c[train],
        np.asarray([encode[int(value)] for value in epoch.depth[train]]),
        c[test],
        n_classes=len(depths),
        metadata={"dt": config.count_window_exposure_s, "prior_mode": "uniform"},
    )
    topology_pred = np.asarray(
        [decode.get(int(value), -1) for value in topology_pred_encoded], dtype=int
    )
    position_pred = _position_to_depth_prediction(
        c[train],
        epoch.spatial_cell[train],
        epoch.depth[train],
        c[test],
        dt_eff=config.count_window_exposure_s,
    )
    xy_pred = _xy_behavior_backend(
        epoch.xy_behavior[train],
        epoch.depth[train],
        epoch.xy_behavior[test],
        n_classes=len(depths),
        metadata={"seed": config.seed},
    )
    shuffle = _shuffle_depth_accuracy(
        c[train],
        epoch.depth[train],
        c[test],
        epoch.depth[test],
        train_visit_id=epoch.visit_id[train],
        dt_eff=config.count_window_exposure_s,
        n_shuffle=config.n_label_shuffles,
        seed=config.seed + (11 if epoch.epoch == "B" else 19),
    )
    true = epoch.depth[test]
    values = {
        "session_id": epoch.session_id,
        "epoch": epoch.epoch,
        "status": f"ok_{support_tier}",
        "support_tier": support_tier,
        "selected_depths": _depths_text(depths),
        "excluded_depths": _depths_text(
            tuple(value for value in range(7) if value not in set(depths))
        ),
        "n_depth_classes": int(len(depths)),
        "min_frames_gate": int(min_frames),
        "n_train_frames": int(np.sum(train)),
        "n_test_frames": int(np.sum(test)),
        "n_cells_input": int(epoch.counts_c.shape[1]),
        "n_cells_after_rate_gate": int(np.sum(keep_cells)),
        "cell_rate_gate_source": cell_gate_source,
        "min_C_rate_per_min": float(config.min_c_per_min),
        "topology_balanced_accuracy": balanced_accuracy(true, topology_pred),
        "position_to_depth_balanced_accuracy": balanced_accuracy(true, position_pred),
        "xy_behavior_balanced_accuracy": balanced_accuracy(true, xy_pred),
        "shuffle_mean_balanced_accuracy": float(np.mean(shuffle)),
        "shuffle_q95_balanced_accuracy": float(np.quantile(shuffle, 0.95)),
        "n_label_shuffles": int(shuffle.size),
        "rate_min": float(np.nanmin(rates[keep_cells])),
        "rate_median": float(np.nanmedian(rates[keep_cells])),
    }
    predictions = pd.DataFrame(
        {
            "session_id": epoch.session_id,
            "epoch": epoch.epoch,
            "analysis": "within_epoch",
            "absolute_frame": epoch.absolute_frames[test],
            "selected_row_index": epoch.selected_row_index[test],
            "true_depth": true,
            "topology_predicted_depth": topology_pred,
            "position_to_depth_prediction": position_pred,
            "xy_behavior_prediction": xy_pred,
        }
    )
    return values, pd.DataFrame(support_rows), predictions


def evaluate_cross_day_depth_transfer(
    train_epoch: EpochData,
    test_epoch: EpochData,
    config: Phase3Config,
) -> tuple[dict[str, Any], pd.DataFrame, pd.DataFrame]:
    """Train on late Day-1 C and test pre-reward Day-2 exploration."""

    depth_plan, support = _select_cross_day_depth_plan(train_epoch, test_epoch, config)
    support["session_id"] = train_epoch.session_id
    support["test_session_id"] = test_epoch.session_id
    if not depth_plan.status.startswith("ok"):
        return (
            {
                "session_id": train_epoch.session_id,
                "test_session_id": test_epoch.session_id,
                "status": depth_plan.status,
                "support_tier": "unresolved",
                "selected_depths": "",
                "excluded_depths": _depths_text(depth_plan.excluded_depths),
                "n_depth_classes": 0,
            },
            support,
            pd.DataFrame(),
        )
    depths = tuple(int(value) for value in depth_plan.selected_depths)
    support_tier = str(depth_plan.support_tier)

    rng = np.random.default_rng(config.seed + 401)

    def balance(depth: np.ndarray) -> np.ndarray:
        count = min(int(np.sum(depth == value)) for value in depths)
        mask = np.zeros(len(depth), dtype=bool)
        for value in depths:
            candidates = np.flatnonzero(depth == value)
            mask[rng.choice(candidates, size=count, replace=False)] = True
        return mask

    train = balance(train_epoch.depth)
    test = balance(test_epoch.depth)
    keep_cells, rates = _activity_gate(
        train_epoch.raw_c_at_frame[train], min_c_per_min=config.min_c_per_min
    )
    if train_epoch.counts_c.shape[1] != test_epoch.counts_c.shape[1]:
        raise ValueError("joint-basis Day1/Day2 C cell counts do not match")
    if int(np.sum(keep_cells)) < int(config.min_cells):
        return (
            {
                "session_id": train_epoch.session_id,
                "test_session_id": test_epoch.session_id,
                "status": "insufficient_C_cells_after_day1_training_gate",
                "n_cells_after_rate_gate": int(np.sum(keep_cells)),
                "support_tier": support_tier,
                "selected_depths": _depths_text(depths),
                "excluded_depths": _depths_text(depth_plan.excluded_depths),
                "n_depth_classes": int(len(depths)),
            },
            support,
            pd.DataFrame(),
        )
    train_c = train_epoch.counts_c[:, keep_cells]
    test_c = test_epoch.counts_c[:, keep_cells]
    encode = {int(value): index for index, value in enumerate(depths)}
    decode = {index: int(value) for value, index in encode.items()}
    topology_pred_encoded = poisson_decoder_adapter(
        train_c[train],
        np.asarray([encode[int(value)] for value in train_epoch.depth[train]]),
        test_c[test],
        n_classes=len(depths),
        metadata={"dt": config.count_window_exposure_s, "prior_mode": "uniform"},
    )
    topology_pred = np.asarray(
        [decode.get(int(value), -1) for value in topology_pred_encoded], dtype=int
    )
    position_pred = _position_to_depth_prediction(
        train_c[train],
        train_epoch.spatial_cell[train],
        train_epoch.depth[train],
        test_c[test],
        dt_eff=config.count_window_exposure_s,
    )
    xy_pred = _xy_behavior_backend(
        train_epoch.xy_behavior[train],
        train_epoch.depth[train],
        test_epoch.xy_behavior[test],
        n_classes=len(depths),
        metadata={"seed": config.seed + 403},
    )
    shuffle = _shuffle_depth_accuracy(
        train_c[train],
        train_epoch.depth[train],
        test_c[test],
        test_epoch.depth[test],
        train_visit_id=train_epoch.visit_id[train],
        dt_eff=config.count_window_exposure_s,
        n_shuffle=config.n_label_shuffles,
        seed=config.seed + 409,
    )
    true = test_epoch.depth[test]
    topology_accuracy = balanced_accuracy(true, topology_pred)
    position_accuracy = balanced_accuracy(true, position_pred)
    xy_accuracy = balanced_accuracy(true, xy_pred)
    shuffle_q95 = float(np.quantile(shuffle, 0.95))
    result = {
        "session_id": train_epoch.session_id,
        "test_session_id": test_epoch.session_id,
        "status": f"ok_{support_tier}",
        "support_tier": support_tier,
        "selected_depths": _depths_text(depths),
        "excluded_depths": _depths_text(depth_plan.excluded_depths),
        "n_depth_classes": int(len(depths)),
        "min_frames_gate": int(depth_plan.min_frames_per_depth),
        "n_train_frames": int(np.sum(train)),
        "n_test_frames": int(np.sum(test)),
        "n_cells_after_rate_gate": int(np.sum(keep_cells)),
        "cell_rate_gate_source": "day1_C_balanced_training_frames_only",
        "topology_balanced_accuracy": topology_accuracy,
        "position_to_depth_balanced_accuracy": position_accuracy,
        "xy_behavior_balanced_accuracy": xy_accuracy,
        "shuffle_mean_balanced_accuracy": float(np.mean(shuffle)),
        "shuffle_q95_balanced_accuracy": shuffle_q95,
        "topology_minus_position": topology_accuracy - position_accuracy,
        "topology_minus_xy_behavior": topology_accuracy - xy_accuracy,
        "topology_minus_shuffle_q95": topology_accuracy - shuffle_q95,
        "rate_min": float(np.nanmin(rates[keep_cells])),
        "rate_median": float(np.nanmedian(rates[keep_cells])),
    }
    predictions = pd.DataFrame(
        {
            "session_id": train_epoch.session_id,
            "test_session_id": test_epoch.session_id,
            "analysis": "day1C_to_day2_prereward",
            "absolute_frame": test_epoch.absolute_frames[test],
            "selected_row_index": test_epoch.selected_row_index[test],
            "true_depth": true,
            "topology_predicted_depth": topology_pred,
            "position_to_depth_prediction": position_pred,
            "xy_behavior_prediction": xy_pred,
        }
    )
    return result, support, predictions


def _build_epoch_data(
    session_id: str,
    epoch: str,
    selected: pd.DataFrame,
    transitions: pd.DataFrame,
    boundary: pd.Series,
    neural_file: str,
    config: Phase3Config,
) -> tuple[EpochData, dict[str, Any]]:
    mask = selected_explore_epoch_mask(
        selected,
        transitions,
        frame_start=float(boundary["frame_start"]),
        frame_end=float(boundary["frame_end"]),
    )
    geometry = selected_frame_geometry(selected)
    mask &= geometry["cell"] >= 0
    rows = np.flatnonzero(mask)
    if rows.size == 0:
        raise ValueError("no selected explore C-supported rows in epoch")
    frames = selected.iloc[rows]["frame"].to_numpy(dtype=int)
    counts, raw, c_audit = load_c_count_windows(
        neural_file,
        frames,
        time_window_frames=config.time_window_frames,
    )
    runs = geometry["run"][rows]
    visit_columns = {
        "abs_frame_start",
        "abs_frame_end",
        "current_node",
        "bout",
        "clip_index",
    }
    visits = (
        transition_run_visits(frames, transitions)
        if visit_columns.issubset(transitions.columns)
        else contiguous_run_visits(frames, runs)
    )
    if np.any(visits < 0):
        raise ValueError(
            "selected epoch frames could not be mapped to full-trajectory visits"
        )
    data = EpochData(
        session_id=str(session_id),
        epoch=str(epoch),
        absolute_frames=frames,
        counts_c=counts,
        raw_c_at_frame=raw,
        depth=geometry["depth"][rows],
        run=runs,
        spatial_cell=geometry["cell"][rows],
        xy_behavior=geometry["xy_behavior"][rows],
        visit_id=visits,
        selected_row_index=rows,
    )
    return data, {**c_audit, "n_epoch_rows": int(rows.size)}


def _cross_subtree_late(
    epoch: EpochData,
    config: Phase3Config,
    *,
    folds: Sequence[Any] | None = None,
    analysis_label: str = "cross_subtree",
    support_only_label: str | None = None,
    audit_all_frame_attempts: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    result_rows = []
    support_rows = []
    prediction_rows = []
    selected_folds = tuple(fixed_topology_folds() if folds is None else folds)
    scope_fields = (
        {}
        if support_only_label is None
        else {
            "support_only_label": str(support_only_label),
            "claim_tier": "support_only_posthoc_setup_rescue",
            "fixed_global_depths": "2|3|4|5",
            "n_depth_classes": 4,
        }
    )
    for fold_index, fold in enumerate(selected_folds):
        train, test = topology_fold_masks(epoch.run, fold)
        primary_support = assess_topology_support(
            epoch.depth,
            epoch.visit_id,
            train,
            test,
            fold,
            min_frames_per_depth=config.min_frames_per_depth,
            min_visits_per_depth=config.min_visits_per_depth,
        )
        support = primary_support
        support_attempts = [
            (
                "frames_primary_threshold",
                int(config.min_frames_per_depth),
                primary_support,
            )
        ]
        used_min_frames = config.min_frames_per_depth
        if not support.supported:
            rescue_support = assess_topology_support(
                epoch.depth,
                epoch.visit_id,
                train,
                test,
                fold,
                min_frames_per_depth=config.rescue_min_frames_per_depth,
                min_visits_per_depth=config.min_visits_per_depth,
            )
            support_attempts.append(
                (
                    "frames_rescue_threshold",
                    int(config.rescue_min_frames_per_depth),
                    rescue_support,
                )
            )
            if rescue_support.supported:
                support = rescue_support
                used_min_frames = config.rescue_min_frames_per_depth
        attempts_to_export = (
            support_attempts
            if audit_all_frame_attempts
            else [("selected_attempt", int(used_min_frames), support)]
        )
        for attempt_name, attempt_min_frames, attempt_support in attempts_to_export:
            for split, frame_counts, visit_counts in (
                (
                    "train",
                    attempt_support.train_frames_by_depth,
                    attempt_support.train_visits_by_depth,
                ),
                (
                    "test",
                    attempt_support.test_frames_by_depth,
                    attempt_support.test_visits_by_depth,
                ),
            ):
                visits_map = dict(visit_counts)
                for value, n_frames in frame_counts:
                    row = {
                        "session_id": epoch.session_id,
                        "epoch": epoch.epoch,
                        "analysis": analysis_label,
                        "fold_name": fold.name,
                        "fold_tier": fold.tier,
                        "split": split,
                        "depth": int(value),
                        "n_frames": int(n_frames),
                        "n_visits": int(visits_map[int(value)]),
                        "support_status": attempt_support.status,
                        "min_frames_gate_used": int(attempt_min_frames),
                    }
                    if audit_all_frame_attempts:
                        row.update(
                            {
                                "support_attempt": attempt_name,
                                "min_visits_gate": int(config.min_visits_per_depth),
                                "attempt_selected_for_decoder": bool(
                                    attempt_support is support and support.supported
                                ),
                            }
                        )
                    row.update(scope_fields)
                    support_rows.append(row)
        shuffle_values = np.asarray([], dtype=float)
        c = epoch.counts_c
        n_cells_after_gate = np.nan
        rate_min = np.nan
        rate_median = np.nan
        if support.supported:
            balanced_train, balanced_test = balance_topology_masks(
                epoch.depth,
                train,
                test,
                fold.global_depths,
                seed=config.seed + fold_index,
            )
            keep_cells, rates = _activity_gate(
                epoch.raw_c_at_frame[balanced_train],
                min_c_per_min=config.min_c_per_min,
            )
            n_cells_after_gate = int(np.sum(keep_cells))
            if n_cells_after_gate < int(config.min_cells):
                result_rows.append(
                    {
                        "session_id": epoch.session_id,
                        "epoch": epoch.epoch,
                        "fold_name": fold.name,
                        "fold_tier": fold.tier,
                        "train_root": fold.train_root,
                        "test_root": fold.test_root,
                        "centroid_distance": fold.centroid_distance,
                        "minimum_cell_distance": fold.minimum_cell_distance,
                        "min_frames_gate_used": int(used_min_frames),
                        "support_status": support.status,
                        "status": "insufficient_C_cells_after_training_rate_gate",
                        "n_cells_input": int(epoch.counts_c.shape[1]),
                        "n_cells_after_rate_gate": n_cells_after_gate,
                        "cell_rate_gate_source": "balanced_training_subtree_frames_only",
                        "classification": "cell_support_unresolved",
                        **scope_fields,
                    }
                )
                continue
            c = epoch.counts_c[:, keep_cells]
            rate_min = float(np.nanmin(rates[keep_cells]))
            rate_median = float(np.nanmedian(rates[keep_cells]))
            shuffle_values = _shuffle_depth_accuracy(
                c[balanced_train],
                epoch.depth[balanced_train],
                c[balanced_test],
                epoch.depth[balanced_test],
                train_visit_id=epoch.visit_id[balanced_train],
                dt_eff=config.count_window_exposure_s,
                n_shuffle=config.n_label_shuffles,
                seed=config.seed + 101 + fold_index,
            )
        comparison, audit = run_topology_fold_backends(
            c,
            epoch.depth,
            epoch.spatial_cell,
            epoch.xy_behavior,
            epoch.run,
            epoch.visit_id,
            fold,
            topology_backend=poisson_decoder_adapter,
            position_backend=poisson_decoder_adapter,
            xy_behavior_backend=_xy_behavior_backend,
            shuffle_accuracies=shuffle_values,
            min_frames_per_depth=used_min_frames,
            min_visits_per_depth=config.min_visits_per_depth,
            balance_seed=config.seed + fold_index,
            metadata={
                "dt": config.count_window_exposure_s,
                "prior_mode": "uniform",
                "seed": config.seed + fold_index,
            },
        )
        result_rows.append(
            {
                "session_id": epoch.session_id,
                "epoch": epoch.epoch,
                "fold_tier": fold.tier,
                "train_root": fold.train_root,
                "test_root": fold.test_root,
                "centroid_distance": fold.centroid_distance,
                "minimum_cell_distance": fold.minimum_cell_distance,
                "min_frames_gate_used": int(used_min_frames),
                "status": comparison.support_status,
                "n_cells_input": int(epoch.counts_c.shape[1]),
                "n_cells_after_rate_gate": n_cells_after_gate,
                "cell_rate_gate_source": (
                    "balanced_training_subtree_frames_only"
                    if support.supported
                    else "not_applied_geometry_support_unresolved"
                ),
                "rate_min": rate_min,
                "rate_median": rate_median,
                **scope_fields,
                **asdict(comparison),
            }
        )
        if "true_depth" in audit:
            test_relative = np.asarray(audit["test_frame_indices"], dtype=int)
            prediction_rows.append(
                pd.DataFrame(
                    {
                        "session_id": epoch.session_id,
                        "epoch": epoch.epoch,
                        "analysis": analysis_label,
                        "fold_name": fold.name,
                        "absolute_frame": epoch.absolute_frames[test_relative],
                        "selected_row_index": epoch.selected_row_index[test_relative],
                        "true_depth": audit["true_depth"],
                        "topology_predicted_depth": audit["topology_prediction"],
                        "position_to_depth_prediction": audit[
                            "position_to_depth_prediction"
                        ],
                        "xy_behavior_prediction": audit["xy_behavior_prediction"],
                        **scope_fields,
                    }
                )
            )
    return (
        pd.DataFrame(result_rows),
        pd.DataFrame(support_rows),
        pd.concat(prediction_rows, ignore_index=True)
        if prediction_rows
        else pd.DataFrame(),
    )


def build_reward_visit_support_audit(
    inventory: pd.DataFrame,
    transitions: pd.DataFrame,
    *,
    spec: RewardVisitSpec = RewardVisitSpec(),
) -> pd.DataFrame:
    """Separately runnable node-94 support audit; no neural DiD is implied."""

    maze = NewMaze(6)
    terminal_start = 2 ** int(maze.le) - 1
    rows = []
    required_transition_columns = {
        "pair_id",
        "next_node",
        "transition_duration_seconds",
        "day_index",
        "maze_seconds_start",
        "maze_seconds_end",
        "n_selected_rows_transition",
        "transition_id",
    }
    missing_transition_columns = sorted(
        required_transition_columns.difference(transitions.columns)
    )
    for pair in inventory.itertuples(index=False):
        reward_learning_day = pd.to_numeric(
            pd.Series([getattr(pair, "reward_learning_day_index", np.nan)]),
            errors="coerce",
        ).iloc[0]
        reward_day2_eligible = bool(
            np.isfinite(reward_learning_day) and int(reward_learning_day) == 2
        )
        if not reward_day2_eligible:
            rows.append(
                {
                    "pair_id": str(pair.pair_id),
                    "animal_id": str(pair.animal_id),
                    "cohort_group": str(pair.cohort_group),
                    "target_node": int(REWARD_NODE),
                    "reward_learning_day_index": reward_learning_day,
                    "reward_day2_intro_eligible": False,
                    "visit_support_status": "reward_learning_day1_requires_separate_within_day_branch",
                    "n_pre_eligible": np.nan,
                    "n_post_primary_eligible": np.nan,
                    "n_post_rescue_eligible": np.nan,
                    "first_reward_excluded_from_post": True,
                    "neural_did_status": "not_estimated_visit_level_C_template_branch_pending",
                    "interpretation_cap": "support audit only; not evidence for reward coding",
                }
            )
            continue
        if missing_transition_columns:
            rows.append(
                {
                    "pair_id": str(pair.pair_id),
                    "animal_id": str(pair.animal_id),
                    "cohort_group": str(pair.cohort_group),
                    "target_node": int(REWARD_NODE),
                    "reward_learning_day_index": reward_learning_day,
                    "reward_day2_intro_eligible": True,
                    "visit_support_status": "missing_phase0_reward_visit_columns",
                    "missing_transition_columns": "|".join(missing_transition_columns),
                    "n_pre_eligible": np.nan,
                    "n_post_primary_eligible": np.nan,
                    "n_post_rescue_eligible": np.nan,
                    "first_reward_excluded_from_post": True,
                    "neural_did_status": "not_estimated_visit_level_C_template_branch_pending",
                    "interpretation_cap": "support audit only; not evidence for reward coding",
                }
            )
            continue
        pair_transitions = transitions.loc[
            transitions["pair_id"].astype(str).eq(str(pair.pair_id))
        ]
        next_node = pd.to_numeric(pair_transitions["next_node"], errors="coerce")
        visits = pair_transitions.loc[
            next_node.ge(terminal_start) & next_node.lt(len(maze.ru))
        ].copy()
        visit_rows = []
        for event in visits.itertuples(index=False):
            node = int(event.next_node)
            run_cells = np.asarray(maze.ru[node], dtype=int)
            orientation = (
                "horizontal"
                if np.ptp(np.asarray(maze.xc)[run_cells])
                >= np.ptp(np.asarray(maze.yc)[run_cells])
                else "vertical"
            )
            duration = max(
                float(event.transition_duration_seconds), np.finfo(float).eps
            )
            visit_rows.append(
                {
                    "node": node,
                    "day": f"day{int(event.day_index)}",
                    "visit_id": str(event.transition_id),
                    "start_time_s": float(event.maze_seconds_start),
                    "end_time_s": float(event.maze_seconds_end),
                    "n_c_frames": int(event.n_selected_rows_transition),
                    "orientation": orientation,
                    "approach_speed": 1.0 / duration,
                    "dwell_s": duration,
                }
            )
        visit_table = pd.DataFrame(visit_rows)
        reward_time = pd.to_numeric(
            pd.Series([getattr(pair, "day2_first_reward_maze_seconds", np.nan)]),
            errors="coerce",
        ).iloc[0]
        if visit_table.empty or not np.isfinite(reward_time):
            support_status = "visit_or_reward_support_unresolved"
            support = None
        else:
            support = select_reward_target_visits(
                visit_table,
                float(reward_time),
                target_node=REWARD_NODE,
                spec=spec,
            )
            support_status = support.status
        rows.append(
            {
                "pair_id": str(pair.pair_id),
                "animal_id": str(pair.animal_id),
                "cohort_group": str(pair.cohort_group),
                "target_node": int(REWARD_NODE),
                "reward_learning_day_index": reward_learning_day,
                "reward_day2_intro_eligible": True,
                "visit_support_status": support_status,
                "n_pre_eligible": np.nan if support is None else support.n_pre_eligible,
                "n_post_primary_eligible": np.nan
                if support is None
                else support.n_post_primary_eligible,
                "n_post_rescue_eligible": np.nan
                if support is None
                else support.n_post_rescue_eligible,
                "first_reward_excluded_from_post": True,
                "neural_did_status": "not_estimated_visit_level_C_template_branch_pending",
                "interpretation_cap": "support audit only; not evidence for reward coding",
            }
        )
    return pd.DataFrame(rows)


def exact_two_sided_sign_p(values: Sequence[float]) -> tuple[float, int, int, int]:
    """Return an exact two-sided sign-test p-value, excluding exact ties."""

    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    positive = int(np.sum(array > 0))
    negative = int(np.sum(array < 0))
    n_nonzero = positive + negative
    if n_nonzero == 0:
        return np.nan, 0, positive, negative
    lower_tail = min(positive, negative)
    probability = sum(comb(n_nonzero, value) for value in range(lower_tail + 1))
    p_value = min(1.0, 2.0 * float(probability) / float(2**n_nonzero))
    return p_value, n_nonzero, positive, negative


def _bootstrap_mean_ci(
    values: Sequence[float],
    *,
    n_bootstrap: int,
    ci_level: float,
    seed: int,
) -> tuple[float, float]:
    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return np.nan, np.nan
    if int(n_bootstrap) <= 0:
        raise ValueError("n_animal_bootstrap must be positive")
    if not 0.0 < float(ci_level) < 1.0:
        raise ValueError("animal_ci_level must be between zero and one")
    if array.size == 1:
        value = float(array[0])
        return value, value
    rng = np.random.default_rng(int(seed))
    sampled = array[
        rng.integers(0, array.size, size=(int(n_bootstrap), int(array.size)))
    ]
    means = np.mean(sampled, axis=1)
    tail = (1.0 - float(ci_level)) / 2.0
    return tuple(float(value) for value in np.quantile(means, [tail, 1.0 - tail]))


def _inference_seed(base_seed: int, *parts: str) -> int:
    payload = "|".join([str(int(base_seed)), *(str(part) for part in parts)])
    return int.from_bytes(sha256(payload.encode("utf-8")).digest()[:4], "little")


def build_animal_inference_summaries(
    early_late_gain: pd.DataFrame,
    cross_subtree: pd.DataFrame,
    day1c_to_day2: pd.DataFrame,
    config: Phase3Config = Phase3Config(),
) -> dict[str, pd.DataFrame]:
    """Build animal-level Phase-3 estimands, inference, and context diagnostics.

    Decoder outputs are treated as frozen source values.  Sessions/folds are
    averaged within animal before uncertainty is estimated, so the inferential
    unit is always the animal.
    """

    source_records: list[dict[str, Any]] = []
    coverage: dict[tuple[str, str, str, str], dict[str, int]] = {}
    context_coverage: dict[tuple[str, str, str, str, str], dict[str, int]] = {}
    specifications: list[tuple[str, str, str, str]] = []

    def add_specification(
        frame: pd.DataFrame,
        *,
        hypothesis_id: str,
        estimand: str,
        fold_tier: str,
        analysis_scope: str,
        values: pd.Series,
        supported: pd.Series,
    ) -> None:
        key = (hypothesis_id, estimand, fold_tier, analysis_scope)
        specifications.append(key)
        candidate_count = int(len(frame))
        supported_mask = supported.reindex(frame.index, fill_value=False).astype(bool)
        numeric = pd.to_numeric(values.reindex(frame.index), errors="coerce")
        animal = (
            frame.get("animal_id", pd.Series("", index=frame.index))
            .fillna("")
            .astype(str)
        )
        context = (
            frame.get("cohort_group", pd.Series("unknown", index=frame.index))
            .fillna("unknown")
            .astype(str)
            .replace("nan", "unknown")
        )
        valid_animal = animal.str.len().gt(0) & animal.ne("nan")
        finite = numeric.notna() & np.isfinite(numeric.to_numpy(dtype=float))
        usable = supported_mask & finite & valid_animal
        coverage[key] = {
            "n_candidate_source_rows": candidate_count,
            "n_supported_source_rows": int(supported_mask.sum()),
            "n_finite_source_rows": int(usable.sum()),
            "n_excluded_source_rows": int(candidate_count - usable.sum()),
        }
        for context_value in sorted(context.unique().tolist()):
            in_context = context.eq(context_value)
            context_coverage[(*key, str(context_value))] = {
                "n_candidate_source_rows": int(in_context.sum()),
                "n_supported_source_rows": int((in_context & supported_mask).sum()),
                "n_finite_source_rows": int((in_context & usable).sum()),
                "n_excluded_source_rows": int(
                    in_context.sum() - (in_context & usable).sum()
                ),
            }
        for index in frame.index[usable]:
            source_unit = str(frame.loc[index].get("session_id", ""))
            test_session = str(frame.loc[index].get("test_session_id", ""))
            fold_name = str(frame.loc[index].get("fold_name", ""))
            source_records.append(
                {
                    "hypothesis_id": hypothesis_id,
                    "estimand": estimand,
                    "fold_tier": fold_tier,
                    "analysis_scope": analysis_scope,
                    "animal_id": animal.loc[index],
                    "cohort_group": context.loc[index],
                    "source_unit": "|".join(
                        value
                        for value in (source_unit, test_session, fold_name)
                        if value and value != "nan"
                    ),
                    "effect_value": float(numeric.loc[index]),
                }
            )

    gain = early_late_gain.copy()
    gain_specs = {
        "topology_gain_C_minus_B": (
            "topology_balanced_accuracy_C",
            "topology_balanced_accuracy_B",
        ),
        "topology_minus_position_gain_C_minus_B": (
            "topology_balanced_accuracy_C",
            "position_to_depth_balanced_accuracy_C",
            "topology_balanced_accuracy_B",
            "position_to_depth_balanced_accuracy_B",
        ),
        "topology_minus_xy_gain_C_minus_B": (
            "topology_balanced_accuracy_C",
            "xy_behavior_balanced_accuracy_C",
            "topology_balanced_accuracy_B",
            "xy_behavior_balanced_accuracy_B",
        ),
        "topology_minus_shuffle_gain_C_minus_B": (
            "topology_balanced_accuracy_C",
            "shuffle_q95_balanced_accuracy_C",
            "topology_balanced_accuracy_B",
            "shuffle_q95_balanced_accuracy_B",
        ),
    }
    for estimand, columns in gain_specs.items():
        if len(columns) == 2 and set(columns).issubset(gain.columns):
            values = pd.to_numeric(gain[columns[0]], errors="coerce") - pd.to_numeric(
                gain[columns[1]], errors="coerce"
            )
        elif len(columns) == 4 and set(columns).issubset(gain.columns):
            values = (
                pd.to_numeric(gain[columns[0]], errors="coerce")
                - pd.to_numeric(gain[columns[1]], errors="coerce")
                - pd.to_numeric(gain[columns[2]], errors="coerce")
                + pd.to_numeric(gain[columns[3]], errors="coerce")
            )
        else:
            values = pd.Series(np.nan, index=gain.index)
        add_specification(
            gain,
            hypothesis_id="H-NS1A",
            estimand=estimand,
            fold_tier="not_applicable",
            analysis_scope="paired_B_vs_C",
            values=values,
            supported=pd.Series(True, index=gain.index),
        )

    cross = cross_subtree.copy()
    for tier in ("primary", "rescue"):
        if "fold_tier" in cross:
            tier_frame = cross.loc[cross["fold_tier"].astype(str).eq(tier)].copy()
        else:
            tier_frame = cross.iloc[0:0].copy()
        status = tier_frame.get("status", pd.Series("", index=tier_frame.index)).astype(
            str
        )
        supported = status.str.startswith("ok")
        for estimand in (
            "topology_minus_position",
            "topology_minus_xy_behavior",
            "topology_minus_shuffle_q95",
        ):
            values = (
                pd.to_numeric(tier_frame[estimand], errors="coerce")
                if estimand in tier_frame
                else pd.Series(np.nan, index=tier_frame.index)
            )
            add_specification(
                tier_frame,
                hypothesis_id="H-NS1B",
                estimand=estimand,
                fold_tier=tier,
                analysis_scope=f"cross_subtree_{tier}_folds",
                values=values,
                supported=supported,
            )

    transfer = day1c_to_day2.copy()
    transfer_status = transfer.get(
        "status", pd.Series("", index=transfer.index)
    ).astype(str)
    transfer_supported = transfer_status.str.startswith("ok")
    transfer_specs = {
        "topology_minus_position": "position_to_depth_balanced_accuracy",
        "topology_minus_xy_behavior": "xy_behavior_balanced_accuracy",
        "topology_minus_shuffle_q95": "shuffle_q95_balanced_accuracy",
    }
    for estimand, comparator in transfer_specs.items():
        if {"topology_balanced_accuracy", comparator}.issubset(transfer.columns):
            values = pd.to_numeric(
                transfer["topology_balanced_accuracy"], errors="coerce"
            ) - pd.to_numeric(transfer[comparator], errors="coerce")
        else:
            values = pd.Series(np.nan, index=transfer.index)
        add_specification(
            transfer,
            hypothesis_id="H-NS2",
            estimand=estimand,
            fold_tier="not_applicable",
            analysis_scope="day1C_to_day2_prereward",
            values=values,
            supported=transfer_supported,
        )

    source_columns = [
        "hypothesis_id",
        "estimand",
        "fold_tier",
        "analysis_scope",
        "animal_id",
        "cohort_group",
        "source_unit",
        "effect_value",
    ]
    source = pd.DataFrame(source_records, columns=source_columns)
    animal_rows: list[dict[str, Any]] = []
    if not source.empty:
        grouping = ["hypothesis_id", "estimand", "fold_tier", "analysis_scope"]
        for (*keys, animal_id), group in source.groupby(
            [*grouping, "animal_id"], sort=False
        ):
            contexts = sorted(group["cohort_group"].astype(str).unique().tolist())
            animal_rows.append(
                {
                    **dict(zip(grouping, keys)),
                    "animal_id": str(animal_id),
                    "cohort_group": (
                        contexts[0] if len(contexts) == 1 else "mixed_context"
                    ),
                    "context_set": "|".join(contexts),
                    "n_contexts": int(len(contexts)),
                    "n_source_rows": int(len(group)),
                    "n_source_units": int(group["source_unit"].nunique()),
                    "effect_value": float(group["effect_value"].mean()),
                    "animal_aggregation": "mean_across_supported_sessions_or_folds",
                }
            )
    animal = pd.DataFrame(animal_rows)

    summary_rows: list[dict[str, Any]] = []
    for key in specifications:
        hypothesis_id, estimand, fold_tier, analysis_scope = key
        if animal.empty:
            group = pd.DataFrame()
        else:
            group = animal.loc[
                animal["hypothesis_id"].eq(hypothesis_id)
                & animal["estimand"].eq(estimand)
                & animal["fold_tier"].eq(fold_tier)
                & animal["analysis_scope"].eq(analysis_scope)
            ]
        values = (
            group["effect_value"].to_numpy(dtype=float)
            if len(group)
            else np.asarray([], dtype=float)
        )
        source_rows_per_animal = (
            group["n_source_rows"].to_numpy(dtype=int)
            if len(group)
            else np.asarray([], dtype=int)
        )
        expected_source_rows = (
            4
            if hypothesis_id == "H-NS1B" and fold_tier == "primary"
            else (2 if hypothesis_id == "H-NS1B" and fold_tier == "rescue" else 1)
        )
        n_complete_animals = int(np.sum(source_rows_per_animal >= expected_source_rows))
        n_animals = int(values.size)
        effect = float(np.mean(values)) if n_animals else np.nan
        median = float(np.median(values)) if n_animals else np.nan
        ci_low, ci_high = _bootstrap_mean_ci(
            values,
            n_bootstrap=config.n_animal_bootstrap,
            ci_level=config.animal_ci_level,
            seed=_inference_seed(config.seed, *key),
        )
        p_value, n_nonzero, n_positive, n_negative = exact_two_sided_sign_p(values)
        n_zero = int(n_animals - n_nonzero)
        effect_direction = (
            ("positive" if effect > 0 else ("negative" if effect < 0 else "zero"))
            if np.isfinite(effect)
            else "unresolved"
        )
        positive_supported = bool(
            np.isfinite(ci_low)
            and ci_low > 0
            and np.isfinite(p_value)
            and p_value <= float(config.animal_inference_alpha)
        )
        negative_supported = bool(
            np.isfinite(ci_high)
            and ci_high < 0
            and np.isfinite(p_value)
            and p_value <= float(config.animal_inference_alpha)
        )
        if n_animals == 0:
            classification = "support_unresolved"
            inference_direction = "unresolved"
            claim_cap = "no animal-level claim; no supported finite animals"
        elif n_animals < int(config.min_animals_inference):
            classification = (
                f"underpowered_rescue_n_lt_{int(config.min_animals_inference)}"
                if fold_tier == "rescue"
                else f"underpowered_n_lt_{int(config.min_animals_inference)}"
            )
            inference_direction = "uncertain"
            claim_cap = (
                "rescue-fold descriptive estimate only; minimum n not met and no primary cross-subtree claim"
                if fold_tier == "rescue"
                else "descriptive animal-level estimate only; minimum n not met"
            )
        elif fold_tier == "rescue":
            classification = "rescue_scope_descriptive_only"
            inference_direction = "uncertain"
            claim_cap = "rescue-fold diagnostic only; no primary cross-subtree claim"
        elif hypothesis_id == "H-NS1B" and n_complete_animals < n_animals:
            classification = "partial_primary_fold_support"
            inference_direction = "uncertain"
            claim_cap = "descriptive primary-fold estimate only; at least one animal lacks all four frozen primary directions"
        elif positive_supported:
            classification = "supported_positive"
            inference_direction = "positive_supported"
            claim_cap = "positive animal-level evidence within the frozen scope; not a causal or mechanistic claim"
        elif negative_supported:
            classification = "supported_negative"
            inference_direction = "negative_supported"
            claim_cap = "negative animal-level evidence within the frozen scope; not a causal or mechanistic claim"
        else:
            classification = "adequate_n_not_directionally_supported"
            inference_direction = "uncertain"
            claim_cap = "no directional animal-level claim; interval or exact sign test is not decisive"
        contexts = {}
        if len(group):
            for context in sorted(
                source.loc[
                    source["hypothesis_id"].eq(hypothesis_id)
                    & source["estimand"].eq(estimand)
                    & source["fold_tier"].eq(fold_tier)
                    & source["analysis_scope"].eq(analysis_scope),
                    "cohort_group",
                ].unique()
            ):
                contexts[str(context)] = int(
                    source.loc[
                        source["hypothesis_id"].eq(hypothesis_id)
                        & source["estimand"].eq(estimand)
                        & source["fold_tier"].eq(fold_tier)
                        & source["analysis_scope"].eq(analysis_scope)
                        & source["cohort_group"].eq(context),
                        "animal_id",
                    ].nunique()
                )
        summary_rows.append(
            {
                "hypothesis_id": hypothesis_id,
                "estimand": estimand,
                "fold_tier": fold_tier,
                "analysis_scope": analysis_scope,
                "effect_mean": effect,
                "effect_median": median,
                "ci_low": ci_low,
                "ci_high": ci_high,
                "ci_level": float(config.animal_ci_level),
                "bootstrap_method": (
                    "paired_animal_bootstrap_mean_difference"
                    if hypothesis_id == "H-NS1A"
                    else "one_sample_animal_bootstrap_mean_margin"
                ),
                "n_bootstrap": int(config.n_animal_bootstrap),
                "exact_p_value": p_value,
                "p_value_method": "exact_two_sided_sign_test",
                "p_adjustment": "none",
                "multiplicity_scope": "predeclared Phase3 estimands; hypothesis status requires all required margins",
                "n_animals": n_animals,
                "n_nonzero_animals": n_nonzero,
                "n_positive_animals": n_positive,
                "n_negative_animals": n_negative,
                "n_zero_animals": n_zero,
                "expected_source_rows_per_animal": int(expected_source_rows),
                "n_animals_complete_source_support": n_complete_animals,
                "complete_source_support_fraction": (
                    float(n_complete_animals / n_animals) if n_animals else np.nan
                ),
                "min_source_rows_per_animal": (
                    int(np.min(source_rows_per_animal))
                    if source_rows_per_animal.size
                    else 0
                ),
                "median_source_rows_per_animal": (
                    float(np.median(source_rows_per_animal))
                    if source_rows_per_animal.size
                    else np.nan
                ),
                "max_source_rows_per_animal": (
                    int(np.max(source_rows_per_animal))
                    if source_rows_per_animal.size
                    else 0
                ),
                "effect_direction": effect_direction,
                "inference_direction": inference_direction,
                "support_classification": classification,
                "min_animals_inference": int(config.min_animals_inference),
                "context_counts": "|".join(
                    f"{context}:{count}" for context, count in contexts.items()
                ),
                "n_contexts": int(len(contexts)),
                **coverage[key],
                "claim_cap": claim_cap,
            }
        )
    summary = pd.DataFrame(summary_rows)

    context_rows: list[dict[str, Any]] = []
    context_grouping = [
        "hypothesis_id",
        "estimand",
        "fold_tier",
        "analysis_scope",
        "cohort_group",
    ]
    if not source.empty:
        per_animal_context = source.groupby(
            [*context_grouping, "animal_id"], as_index=False
        ).agg(
            effect_value=("effect_value", "mean"),
            n_source_rows=("effect_value", "size"),
        )
    else:
        per_animal_context = pd.DataFrame(
            columns=[*context_grouping, "animal_id", "effect_value", "n_source_rows"]
        )
    for key, context_counts in context_coverage.items():
        hypothesis_id, estimand, fold_tier, analysis_scope, cohort_group = key
        group = per_animal_context.loc[
            per_animal_context["hypothesis_id"].eq(hypothesis_id)
            & per_animal_context["estimand"].eq(estimand)
            & per_animal_context["fold_tier"].eq(fold_tier)
            & per_animal_context["analysis_scope"].eq(analysis_scope)
            & per_animal_context["cohort_group"].eq(cohort_group)
        ]
        values = group["effect_value"].to_numpy(dtype=float)
        n_context_animals = int(len(group))
        if n_context_animals == 0:
            context_classification = "context_support_unresolved"
        elif n_context_animals < int(config.min_animals_inference):
            context_classification = f"underpowered_context_diagnostic_n_lt_{int(config.min_animals_inference)}"
        else:
            context_classification = (
                "descriptive_context_diagnostic_no_separate_confirmatory_test"
            )
        context_rows.append(
            {
                "hypothesis_id": hypothesis_id,
                "estimand": estimand,
                "fold_tier": fold_tier,
                "analysis_scope": analysis_scope,
                "cohort_group": cohort_group,
                "n_animals": n_context_animals,
                "n_source_rows": int(group["n_source_rows"].sum()),
                "effect_mean": float(np.mean(values)) if values.size else np.nan,
                "effect_median": float(np.median(values)) if values.size else np.nan,
                "effect_min": float(np.min(values)) if values.size else np.nan,
                "effect_max": float(np.max(values)) if values.size else np.nan,
                "n_positive_animals": int(np.sum(values > 0)),
                "n_negative_animals": int(np.sum(values < 0)),
                "n_zero_animals": int(np.sum(values == 0)),
                **context_counts,
                "context_classification": context_classification,
                "claim_cap": "context diagnostic only; no context-specific confirmatory claim",
            }
        )
    context = pd.DataFrame(context_rows)
    return {
        "phase3_animal_level_estimands.csv": animal,
        "phase3_animal_inference_summary.csv": summary,
        "phase3_animal_context_diagnostics.csv": context,
    }


def _hypothesis_inference_status(
    summary: pd.DataFrame,
    hypothesis_id: str,
) -> tuple[str, int, str]:
    required = {
        "H-NS1A": {
            "topology_gain_C_minus_B",
            "topology_minus_position_gain_C_minus_B",
            "topology_minus_xy_gain_C_minus_B",
            "topology_minus_shuffle_gain_C_minus_B",
        },
        "H-NS1B": {
            "topology_minus_position",
            "topology_minus_xy_behavior",
            "topology_minus_shuffle_q95",
        },
        "H-NS2": {
            "topology_minus_position",
            "topology_minus_xy_behavior",
            "topology_minus_shuffle_q95",
        },
    }[hypothesis_id]
    rows = summary.loc[summary["hypothesis_id"].astype(str).eq(hypothesis_id)].copy()
    if hypothesis_id == "H-NS1B":
        primary = rows.loc[rows["fold_tier"].astype(str).eq("primary")]
        rescue = rows.loc[rows["fold_tier"].astype(str).eq("rescue")]
        rows = primary
        if rows["n_animals"].max() == 0 and rescue["n_animals"].max() > 0:
            return (
                "animal_level_rescue_scope_only",
                int(rescue["n_animals"].max()),
                "rescue folds are descriptive only; no primary cross-subtree claim",
            )
    if rows.empty or not required.issubset(set(rows["estimand"].astype(str))):
        return (
            "animal_level_support_unresolved",
            0,
            "required animal-level estimands are missing",
        )
    rows = rows.loc[rows["estimand"].astype(str).isin(required)]
    n_animals = int(rows["n_animals"].min())
    classifications = set(rows["support_classification"].astype(str))
    if n_animals == 0 or "support_unresolved" in classifications:
        return "animal_level_support_unresolved", n_animals, "no animal-level claim"
    if any(value.startswith("underpowered") for value in classifications):
        return (
            "animal_level_inference_underpowered",
            n_animals,
            "descriptive estimates only; minimum animal count not met",
        )
    if classifications == {"supported_positive"}:
        return (
            "animal_level_positive_supported",
            n_animals,
            "all required estimands are positive within the frozen scope; no causal or mechanistic claim",
        )
    return (
        "animal_level_estimated_not_fully_supported",
        n_animals,
        "hypothesis-level claim capped because not all required estimands are directionally supported",
    )


def _boolean_mask(values: pd.Series) -> pd.Series:
    return values.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def _reward_hypothesis_status(
    animal_status: pd.DataFrame,
    did_scores: pd.DataFrame,
    distributed_scores: pd.DataFrame,
) -> dict[str, Any]:
    """Summarize H-NR1 evidence without treating pipeline ``ok`` as support."""

    status = animal_status.copy()
    did = did_scores.copy()
    distributed = distributed_scores.copy()
    for frame in (status, did, distributed):
        if "animal_id" not in frame:
            frame["animal_id"] = pd.Series(dtype=str)
        else:
            frame["animal_id"] = frame["animal_id"].astype(str)
    final = (
        status.loc[status["analysis_variant"].astype(str).eq("final")].copy()
        if {"analysis_variant", "animal_id"}.issubset(status.columns)
        else pd.DataFrame()
    )
    day2_eligible = final.loc[
        ~final.get("status", pd.Series("", index=final.index))
        .astype(str)
        .eq("reward_learning_day1_requires_separate_within_day_branch")
    ]
    c_ready = day2_eligible.loc[
        ~day2_eligible.get("status", pd.Series("", index=day2_eligible.index))
        .astype(str)
        .eq("C_reward_cross_day_not_ready")
    ]

    target_did = did.copy()
    if "is_target_node" in target_did:
        target_did = target_did.loc[_boolean_mask(target_did["is_target_node"])]
    else:
        target_did = target_did.iloc[0:0]
    target_did = target_did.loc[
        target_did.get("status", pd.Series("", index=target_did.index))
        .astype(str)
        .eq("ok")
        & pd.to_numeric(
            target_did.get(
                "pseudo_target_did", pd.Series(np.nan, index=target_did.index)
            ),
            errors="coerce",
        ).notna()
    ]
    explore_estimable_ids = set(
        target_did.loc[
            target_did.get("analysis_variant", pd.Series("", index=target_did.index))
            .astype(str)
            .eq("explore_only"),
            "animal_id",
        ]
    )
    outcome_estimable_ids = set(
        target_did.loc[
            target_did.get("analysis_variant", pd.Series("", index=target_did.index))
            .astype(str)
            .eq("outcome_inclusive"),
            "animal_id",
        ]
    )

    target_coordinate = distributed.copy()
    if "is_reward_anchor" in target_coordinate:
        target_coordinate = target_coordinate.loc[
            _boolean_mask(target_coordinate["is_reward_anchor"])
        ]
    else:
        target_coordinate = target_coordinate.iloc[0:0]
    coordinate_finite = (
        pd.to_numeric(
            target_coordinate.get(
                "delta_post_minus_pre", pd.Series(np.nan, index=target_coordinate.index)
            ),
            errors="coerce",
        ).notna()
        & pd.to_numeric(
            target_coordinate.get(
                "post_loono_spearman", pd.Series(np.nan, index=target_coordinate.index)
            ),
            errors="coerce",
        ).notna()
        & pd.to_numeric(
            target_coordinate.get(
                "rank_percentile_descending",
                pd.Series(np.nan, index=target_coordinate.index),
            ),
            errors="coerce",
        ).notna()
    )
    target_coordinate = target_coordinate.loc[coordinate_finite]
    distributed_estimable_ids = set(
        target_coordinate.get("animal_id", pd.Series(dtype=str))
    )

    explore_rows = status.loc[
        status.get("analysis_variant", pd.Series("", index=status.index))
        .astype(str)
        .eq("explore_only")
    ]
    explore_supported_ids = set(
        explore_rows.loc[
            explore_rows.get("interpretation", pd.Series("", index=explore_rows.index))
            .astype(str)
            .eq("reward_location_specific_code")
            & _boolean_mask(
                explore_rows.get(
                    "target_change_supported",
                    pd.Series(False, index=explore_rows.index),
                )
            )
            & explore_rows["animal_id"].isin(explore_estimable_ids),
            "animal_id",
        ]
    )
    outcome_rows = status.loc[
        status.get("analysis_variant", pd.Series("", index=status.index))
        .astype(str)
        .eq("outcome_inclusive")
    ]
    outcome_supported_ids = set(
        outcome_rows.loc[
            outcome_rows.get("interpretation", pd.Series("", index=outcome_rows.index))
            .astype(str)
            .eq("reward_consumption_state")
            & _boolean_mask(
                outcome_rows.get(
                    "target_change_supported",
                    pd.Series(False, index=outcome_rows.index),
                )
            )
            & outcome_rows["animal_id"].isin(outcome_estimable_ids),
            "animal_id",
        ]
    )
    distributed_supported_math = target_coordinate.loc[
        pd.to_numeric(
            target_coordinate.get(
                "delta_post_minus_pre", pd.Series(np.nan, index=target_coordinate.index)
            ),
            errors="coerce",
        ).gt(0)
        & pd.to_numeric(
            target_coordinate.get(
                "post_loono_spearman", pd.Series(np.nan, index=target_coordinate.index)
            ),
            errors="coerce",
        ).gt(0)
        & pd.to_numeric(
            target_coordinate.get(
                "rank_percentile_descending",
                pd.Series(np.nan, index=target_coordinate.index),
            ),
            errors="coerce",
        ).le(0.10)
    ]
    final_distributed_ids = set(
        final.loc[
            final.get("interpretation", pd.Series("", index=final.index))
            .astype(str)
            .eq("distributed_reward_coordinate_code")
            & _boolean_mask(
                final.get(
                    "distributed_reward_supported", pd.Series(False, index=final.index)
                )
            ),
            "animal_id",
        ]
    )
    distributed_supported_ids = (
        set(distributed_supported_math["animal_id"]) & final_distributed_ids
    )
    estimable_ids = (
        explore_estimable_ids | outcome_estimable_ids | distributed_estimable_ids
    )
    supported_ids = (
        explore_supported_ids | outcome_supported_ids | distributed_supported_ids
    )
    if explore_supported_ids:
        hypothesis_status = "animal_level_explore_location_specific_support"
        cap = (
            "one or more animals meet the explore-only node-94 specificity criterion; "
            "no pooled/group-level, causal, or mechanistic claim"
        )
    elif distributed_supported_ids or outcome_supported_ids:
        hypothesis_status = "animal_level_alternative_reward_code_support"
        cap = (
            "support occurs only in the outcome-inclusive sensitivity and/or distributed "
            "fallback; no explore-only location-specific, pooled/group-level, causal, or mechanistic claim"
        )
    elif estimable_ids:
        hypothesis_status = "animal_level_reward_specific_not_supported"
        cap = (
            "reward neural metrics were estimable but no animal met a prespecified reward-specific "
            "criterion; this is not an equivalence or group-level null result"
        )
    else:
        hypothesis_status = "animal_level_support_unresolved"
        cap = "no reward-code inference; no animal had an estimable H-NR1 neural metric"
    return {
        "status": hypothesis_status,
        "n": int(len(estimable_ids)),
        "n_day2_reward_intro_animals": int(day2_eligible["animal_id"].nunique())
        if "animal_id" in day2_eligible
        else 0,
        "n_C_ready_animals": int(c_ready["animal_id"].nunique())
        if "animal_id" in c_ready
        else 0,
        "n_explore_estimable": int(len(explore_estimable_ids)),
        "n_outcome_estimable": int(len(outcome_estimable_ids)),
        "n_distributed_estimable": int(len(distributed_estimable_ids)),
        "n_any_estimable": int(len(estimable_ids)),
        "n_explore_location_specific_supported": int(len(explore_supported_ids)),
        "n_outcome_target_specific_supported": int(len(outcome_supported_ids)),
        "n_distributed_reward_coordinate_supported": int(
            len(distributed_supported_ids)
        ),
        "n_any_supported": int(len(supported_ids)),
        "supported_animal_ids": "|".join(sorted(supported_ids)),
        "interpretation_cap": cap,
    }


def _safe_correlation(left: np.ndarray, right: np.ndarray) -> float:
    left = np.asarray(left, dtype=float)
    right = np.asarray(right, dtype=float)
    keep = np.isfinite(left) & np.isfinite(right)
    if int(np.sum(keep)) < 3:
        return np.nan
    left = left[keep]
    right = right[keep]
    if np.std(left) <= 0 or np.std(right) <= 0:
        return np.nan
    return float(np.corrcoef(left, right)[0, 1])


def _terminal_orientation(maze: Any, node: int) -> str:
    cells = np.asarray(maze.ru[int(node)], dtype=int)
    x_range = np.ptp(np.asarray(maze.xc, dtype=float)[cells])
    y_range = np.ptp(np.asarray(maze.yc, dtype=float)[cells])
    return "horizontal" if x_range >= y_range else "vertical"


def _load_reward_day_visits(
    meta: pd.Series,
    transitions: pd.DataFrame,
    *,
    day_index: int,
) -> tuple[pd.DataFrame, dict[str, np.ndarray], dict[str, Any]]:
    """Build terminal-visit metadata and exact selected absolute-frame lists."""

    prefix = f"day{int(day_index)}"
    maze = NewMaze(6)
    session_id = str(meta[f"session_{prefix}"])
    selected_path = Path(str(meta[f"{prefix}_selected_data_path"]))
    neural_file = Path(str(meta[f"{prefix}_neural_file"]))
    selected = pd.read_csv(selected_path)
    required_selected = {"frame", "speed"}
    missing = sorted(required_selected.difference(selected.columns))
    if missing:
        raise KeyError(f"{session_id} selected table missing columns: {missing}")
    frame_values = pd.to_numeric(selected["frame"], errors="coerce").to_numpy(
        dtype=float
    )
    if not np.all(np.isfinite(frame_values)) or np.any(np.diff(frame_values) < 0):
        raise ValueError(f"{session_id} selected frames are invalid or nonmonotonic")
    frames = frame_values.astype(int)
    session_transitions = transitions.loc[
        transitions["session_id"].astype(str).eq(session_id)
    ].copy()
    next_node = pd.to_numeric(session_transitions["next_node"], errors="coerce")
    terminal_start = 2 ** int(maze.le) - 1
    session_transitions = session_transitions.loc[
        next_node.ge(terminal_start) & next_node.lt(len(maze.ru))
    ].copy()
    rows: list[dict[str, Any]] = []
    frame_map: dict[str, np.ndarray] = {}
    for event in session_transitions.itertuples(index=False):
        start = int(event.abs_frame_start)
        end = int(event.abs_frame_end)
        lo = int(np.searchsorted(frames, start, side="left"))
        hi = int(np.searchsorted(frames, end, side="right"))
        visit_frames = frames[lo:hi]
        visit_id = str(event.transition_id)
        frame_map[visit_id] = visit_frames
        speed = pd.to_numeric(selected.iloc[lo:hi]["speed"], errors="coerce").to_numpy(
            dtype=float
        )
        rows.append(
            {
                "pair_id": str(meta["pair_id"]),
                "animal_id": str(meta["animal_id"]),
                "cohort_group": str(meta["cohort_group"]),
                "session_id": session_id,
                "day": prefix,
                "day_index": int(day_index),
                "visit_id": visit_id,
                "node": int(event.next_node),
                "mode_label": str(event.mode_label),
                "start_time_s": float(event.maze_seconds_start),
                "end_time_s": float(event.maze_seconds_end),
                "abs_frame_start": start,
                "abs_frame_end": end,
                "n_c_frames": int(visit_frames.size),
                "phase0_n_selected_rows": int(event.n_selected_rows_transition),
                "selected_frame_count_matches_phase0": bool(
                    visit_frames.size == int(event.n_selected_rows_transition)
                ),
                "orientation": _terminal_orientation(maze, int(event.next_node)),
                "approach_speed": float(np.nanmean(speed))
                if np.any(np.isfinite(speed))
                else np.nan,
                "dwell_s": float(event.transition_duration_seconds),
            }
        )
    visit_table = pd.DataFrame(rows)
    nonempty_frames = [value for value in frame_map.values() if value.size]
    if not nonempty_frames:
        return (
            visit_table,
            {},
            {
                "session_id": session_id,
                "status": "no_terminal_visit_selected_frames",
                "selected_data_path": str(selected_path),
                "neural_file": str(neural_file),
            },
        )
    with h5py.File(neural_file, "r") as handle:
        if "C" not in handle or not isinstance(handle["C"], h5py.Dataset):
            raise ValueError(f"{neural_file} does not contain a dense HDF5 C dataset")
        dataset = handle["C"]
        last_frame = max(int(value[-1]) for value in nonempty_frames)
        if dataset.ndim != 2 or last_frame >= int(dataset.shape[0]):
            raise ValueError(f"{session_id} visit frames are outside the C dataset")
        c_n_time, c_n_cells = map(int, dataset.shape)
    return (
        visit_table,
        frame_map,
        {
            "session_id": session_id,
            "status": "ok",
            "selected_data_path": str(selected_path),
            "neural_file": str(neural_file),
            "C_storage_orientation": "absolute_frame_by_cell",
            "C_n_time": c_n_time,
            "C_n_cells": c_n_cells,
            "n_terminal_visits": int(len(visit_table)),
            "n_visits_with_C_frames": int(len(nonempty_frames)),
            "n_unique_C_frames_available": int(
                np.unique(np.concatenate(nonempty_frames)).size
            ),
            "C_loading_policy": "metadata_only_then_selected_visit_streaming",
        },
    )


def _mean_C_for_frames(dataset: h5py.Dataset, frames: np.ndarray) -> np.ndarray:
    """Stream contiguous frame runs instead of slow HDF5 point selection."""

    frames = np.unique(np.asarray(frames, dtype=int))
    if frames.size == 0:
        raise ValueError("cannot average an empty visit")
    breaks = np.flatnonzero(np.diff(frames) != 1) + 1
    chunks = np.split(frames, breaks)
    total = np.zeros(int(dataset.shape[1]), dtype=float)
    count = 0
    for chunk in chunks:
        values = np.asarray(dataset[int(chunk[0]) : int(chunk[-1]) + 1, :], dtype=float)
        total += np.sum(values, axis=0)
        count += int(values.shape[0])
    return total / max(1, count)


def _load_requested_reward_vectors(
    requested_visit_ids: Sequence[str],
    visits: pd.DataFrame,
    frame_map: Mapping[str, np.ndarray],
    neural_file_by_session: Mapping[str, str | Path],
) -> tuple[dict[str, np.ndarray], pd.DataFrame]:
    requested = {str(value) for value in requested_visit_ids}
    rows = visits.loc[visits["visit_id"].astype(str).isin(requested)].copy()
    vectors: dict[str, np.ndarray] = {}
    audits = []
    for session_id, group in rows.groupby("session_id", sort=False):
        neural_file = Path(neural_file_by_session[str(session_id)])
        n_frames = 0
        with h5py.File(neural_file, "r") as handle:
            dataset = handle["C"]
            for visit_id in group["visit_id"].astype(str):
                frames = np.asarray(frame_map.get(visit_id, []), dtype=int)
                if frames.size == 0:
                    continue
                vectors[visit_id] = _mean_C_for_frames(dataset, frames)
                n_frames += int(frames.size)
        audits.append(
            {
                "session_id": str(session_id),
                "neural_file": str(neural_file),
                "n_requested_visits": int(group["visit_id"].nunique()),
                "n_loaded_visits": int(
                    sum(value in vectors for value in group["visit_id"].astype(str))
                ),
                "n_C_frames_streamed": int(n_frames),
                "C_loading_policy": "contiguous_run_streaming_selected_visits_only",
            }
        )
    return vectors, pd.DataFrame(audits)


def _select_reward_variant(
    visits: pd.DataFrame,
    first_reward_time: float,
    *,
    variant: str,
    spec: RewardVisitSpec,
) -> tuple[pd.DataFrame, Any, Any]:
    """Freeze explore-only primary or outcome-inclusive sensitivity visits."""

    outcome_support = select_reward_target_visits(
        visits, first_reward_time, target_node=REWARD_NODE, spec=spec
    )
    if variant == "outcome_inclusive":
        variant_visits = visits.copy()
        support = outcome_support
    elif variant == "explore_only":
        variant_visits = visits.loc[
            visits["mode_label"].astype(str).eq("explore")
        ].copy()
        # Retain the actual first-reward visit solely so the helper resolves and
        # excludes it; it is never selected as an explore post-reward template.
        reward_id = outcome_support.first_reward_visit_id
        if reward_id is not None:
            reward_row = visits.loc[visits["visit_id"].astype(str).eq(str(reward_id))]
            variant_visits = pd.concat(
                [variant_visits, reward_row], ignore_index=True
            ).drop_duplicates("visit_id")
        support = select_reward_target_visits(
            variant_visits, first_reward_time, target_node=REWARD_NODE, spec=spec
        )
    else:
        raise ValueError("reward variant must be explore_only or outcome_inclusive")
    match = match_pseudo_terminal_controls(
        variant_visits,
        support,
        first_reward_time,
        spec=spec,
    )
    return variant_visits, support, match


def _reward_cell_gate(
    visit_ids: Sequence[str],
    visits: pd.DataFrame,
    vectors: Mapping[str, np.ndarray],
    *,
    min_c_per_min: float,
) -> tuple[np.ndarray, np.ndarray]:
    selected = visits.loc[
        visits["visit_id"].astype(str).isin([str(value) for value in visit_ids])
    ]
    selected = selected.loc[selected["visit_id"].astype(str).isin(vectors)]
    if selected.empty:
        return np.asarray([], dtype=bool), np.asarray([], dtype=float)
    ids = selected["visit_id"].astype(str).tolist()
    n_frames = selected["n_c_frames"].to_numpy(dtype=float)
    matrix = np.vstack([vectors[value] for value in ids])
    exposure_minutes = max(
        float(np.sum(n_frames)) * float(DT) / 60.0, np.finfo(float).eps
    )
    rates = np.sum(matrix * n_frames[:, None], axis=0) / exposure_minutes
    keep = (
        np.isfinite(rates)
        & (rates >= float(min_c_per_min))
        & (np.nanvar(matrix, axis=0) > 0)
    )
    return keep, rates


def _reward_role_map(support: Any, match: Any) -> dict[str, tuple[int, str]]:
    roles: dict[str, tuple[int, str]] = {}
    for visit_id in support.pre_visit_ids:
        roles[str(visit_id)] = (int(REWARD_NODE), "pre")
    for visit_id in support.post_visit_ids:
        roles[str(visit_id)] = (int(REWARD_NODE), "post")
    for node, epochs in match.per_node_visit_ids.items():
        for epoch in ("pre", "post"):
            for visit_id in epochs[epoch]:
                roles[str(visit_id)] = (int(node), epoch)
    return roles


def _score_reward_templates(
    *,
    animal_id: str,
    variant: str,
    visits: pd.DataFrame,
    vectors: Mapping[str, np.ndarray],
    support: Any,
    match: Any,
    config: Phase3Config,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Compute visit-level own-template minus best-competitor margins."""

    role_map = _reward_role_map(support, match)
    pre_ids = [visit_id for visit_id, (_, epoch) in role_map.items() if epoch == "pre"]
    keep_cells, rates = _reward_cell_gate(
        pre_ids, visits, vectors, min_c_per_min=config.min_c_per_min
    )
    if keep_cells.size == 0 or int(np.sum(keep_cells)) < int(config.min_cells):
        return (
            pd.DataFrame(),
            pd.DataFrame(),
            {
                "status": "insufficient_C_cells_after_pre_visit_rate_gate",
                "n_cells_after_rate_gate": int(np.sum(keep_cells))
                if keep_cells.size
                else 0,
            },
        )
    grouped: dict[tuple[int, str], list[str]] = {}
    for visit_id, key in role_map.items():
        if visit_id in vectors:
            grouped.setdefault(key, []).append(visit_id)
    templates = {
        key: np.mean(np.vstack([vectors[value][keep_cells] for value in ids]), axis=0)
        for key, ids in grouped.items()
    }
    template_rows = []
    cell_indices = np.flatnonzero(keep_cells)
    for (node, epoch), template in templates.items():
        for cell_index, value in zip(cell_indices, template, strict=True):
            template_rows.append(
                {
                    "animal_id": animal_id,
                    "analysis_variant": variant,
                    "node": int(node),
                    "epoch": epoch,
                    "cell_index": int(cell_index),
                    "template_C": float(value),
                    "n_visits": int(len(grouped[(node, epoch)])),
                }
            )
    score_rows = []
    for (node, epoch), ids in grouped.items():
        competitors = {
            other_node: template
            for (other_node, other_epoch), template in templates.items()
            if other_epoch == epoch and other_node != node
        }
        for visit_id in ids:
            own_other = [value for value in ids if value != visit_id]
            if not own_other or not competitors:
                continue
            visit_vector = vectors[visit_id][keep_cells]
            own_template = np.mean(
                np.vstack([vectors[value][keep_cells] for value in own_other]), axis=0
            )
            own_similarity = _safe_correlation(visit_vector, own_template)
            competitor_values = [
                _safe_correlation(visit_vector, template)
                for template in competitors.values()
            ]
            finite_competitors = [
                value for value in competitor_values if np.isfinite(value)
            ]
            best_competitor = max(finite_competitors) if finite_competitors else np.nan
            score_rows.append(
                {
                    "animal_id": animal_id,
                    "analysis_variant": variant,
                    "visit_id": visit_id,
                    "node": int(node),
                    "epoch": epoch,
                    "score": (
                        float(own_similarity - best_competitor)
                        if np.isfinite(own_similarity) and np.isfinite(best_competitor)
                        else np.nan
                    ),
                    "own_template_correlation": own_similarity,
                    "best_competitor_correlation": best_competitor,
                    "n_competitor_nodes": int(len(finite_competitors)),
                }
            )
    return (
        pd.DataFrame(score_rows),
        pd.DataFrame(template_rows),
        {
            "status": "ok",
            "n_cells_input": int(keep_cells.size),
            "n_cells_after_rate_gate": int(np.sum(keep_cells)),
            "cell_rate_gate_source": "selected_Day1_pre_visits_only",
            "rate_min": float(np.nanmin(rates[keep_cells])),
            "rate_median": float(np.nanmedian(rates[keep_cells])),
        },
    )


def _bootstrap_target_did(
    scores: pd.DataFrame,
    controls: Sequence[int],
    *,
    n_bootstrap: int,
    seed: int,
) -> dict[str, Any]:
    values: dict[tuple[int, str], np.ndarray] = {}
    for (node, epoch), group in scores.groupby(["node", "epoch"], sort=False):
        finite = (
            pd.to_numeric(group["score"], errors="coerce")
            .dropna()
            .to_numpy(dtype=float)
        )
        if finite.size:
            values[(int(node), str(epoch))] = finite
    nodes = [int(REWARD_NODE), *[int(value) for value in controls]]
    if any((node, epoch) not in values for node in nodes for epoch in ("pre", "post")):
        return {
            "bootstrap_status": "missing_node_epoch_visit_scores",
            "target_did_ci_low": np.nan,
            "target_did_ci_high": np.nan,
            "target_did_bootstrap_p_positive": np.nan,
        }
    rng = np.random.default_rng(int(seed))
    boot = np.empty(max(1, int(n_bootstrap)), dtype=float)
    for index in range(boot.size):
        delta = {}
        for node in nodes:
            means = {}
            for epoch in ("pre", "post"):
                sample = values[(node, epoch)]
                means[epoch] = float(
                    np.mean(rng.choice(sample, size=sample.size, replace=True))
                )
            delta[node] = means["post"] - means["pre"]
        boot[index] = delta[int(REWARD_NODE)] - np.median(
            [delta[node] for node in nodes if node != int(REWARD_NODE)]
        )
    return {
        "bootstrap_status": "ok",
        "n_bootstrap": int(boot.size),
        "target_did_ci_low": float(np.quantile(boot, 0.025)),
        "target_did_ci_high": float(np.quantile(boot, 0.975)),
        "target_did_bootstrap_p_positive": float(np.mean(boot > 0)),
    }


def _tree_distance(parents: np.ndarray, node: int, anchor: int) -> int:
    def ancestors(value: int) -> list[int]:
        out = []
        while value >= 0:
            out.append(int(value))
            value = int(parents[value])
        return out

    left = ancestors(int(node))
    right = ancestors(int(anchor))
    right_depth = {value: index for index, value in enumerate(right)}
    for left_index, value in enumerate(left):
        if value in right_depth:
            return int(left_index + right_depth[value])
    raise ValueError("maze tree nodes do not share a root")


def _loono_coordinate_score(x: np.ndarray, y: np.ndarray, *, alpha: float) -> float:
    if x.shape[0] < 4 or np.unique(y).size < 3:
        return np.nan
    prediction = np.empty(x.shape[0], dtype=float)
    for index in range(x.shape[0]):
        train = np.ones(x.shape[0], dtype=bool)
        train[index] = False
        model = make_pipeline(StandardScaler(), Ridge(alpha=float(alpha)))
        model.fit(x[train], y[train])
        prediction[index] = float(model.predict(x[[index]])[0])
    result = stats.spearmanr(y, prediction)
    return float(result.statistic) if np.isfinite(result.statistic) else np.nan


def _distributed_visit_selection(
    visits: pd.DataFrame,
    *,
    first_reward_time: float,
    first_reward_visit_id: Any,
    spec: RewardVisitSpec,
) -> dict[tuple[int, str], list[str]]:
    explore = visits.loc[
        visits["mode_label"].astype(str).eq("explore")
        & (visits["n_c_frames"].astype(int) >= int(spec.min_frames_per_visit))
    ].copy()
    selected: dict[tuple[int, str], list[str]] = {}
    for node, group in explore.groupby("node", sort=True):
        pre = group.loc[group["day"].astype(str).eq("day1")].sort_values("start_time_s")
        post = group.loc[
            group["day"].astype(str).eq("day2")
            & (group["start_time_s"].astype(float) > float(first_reward_time))
            & (
                group["start_time_s"].astype(float)
                <= float(first_reward_time) + float(spec.rescue_post_window_s)
            )
            & ~group["visit_id"].astype(str).eq(str(first_reward_visit_id))
        ].sort_values("start_time_s")
        count = min(int(spec.k_visits), len(pre), len(post))
        if count < 2:
            continue
        selected[(int(node), "pre")] = pre.tail(count)["visit_id"].astype(str).tolist()
        selected[(int(node), "post")] = (
            post.head(count)["visit_id"].astype(str).tolist()
        )
    return selected


def _distributed_reward_coordinate(
    *,
    animal_id: str,
    visits: pd.DataFrame,
    vectors: Mapping[str, np.ndarray],
    selected: Mapping[tuple[int, str], Sequence[str]],
    config: Phase3Config,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Fallback: rank node 94 as an anchor for a distributed distance code."""

    candidate_nodes = {node for node, epoch in selected if epoch == "pre"} & {
        node for node, epoch in selected if epoch == "post"
    }
    nodes = sorted(
        node
        for node in candidate_nodes
        if all(
            str(value) in vectors
            for epoch in ("pre", "post")
            for value in selected[(node, epoch)]
        )
    )
    if len(nodes) < int(config.reward_min_distributed_nodes):
        return pd.DataFrame(), {
            "distributed_status": "insufficient_nodes_for_distributed_coordinate",
            "n_distributed_nodes": int(len(nodes)),
            "distributed_reward_supported": False,
        }
    pre_ids = [value for node in nodes for value in selected[(node, "pre")]]
    keep_cells, _ = _reward_cell_gate(
        pre_ids, visits, vectors, min_c_per_min=config.min_c_per_min
    )
    if keep_cells.size == 0 or int(np.sum(keep_cells)) < int(config.min_cells):
        return pd.DataFrame(), {
            "distributed_status": "insufficient_cells_for_distributed_coordinate",
            "n_distributed_nodes": int(len(nodes)),
            "distributed_reward_supported": False,
        }
    templates = {}
    for epoch in ("pre", "post"):
        templates[epoch] = np.vstack(
            [
                np.mean(
                    np.vstack(
                        [
                            vectors[value][keep_cells]
                            for value in selected[(node, epoch)]
                        ]
                    ),
                    axis=0,
                )
                for node in nodes
            ]
        )
    # The gate is frozen on pre-reward activity.  Rare non-finite post values
    # are therefore imputed from the pre-template cell median rather than
    # using post data to redefine the eligible-cell set.
    pre_fill = np.nanmedian(templates["pre"], axis=0)
    pre_fill[~np.isfinite(pre_fill)] = 0.0
    n_nonfinite_pre = int(np.sum(~np.isfinite(templates["pre"])))
    n_nonfinite_post = int(np.sum(~np.isfinite(templates["post"])))
    for epoch in ("pre", "post"):
        bad = ~np.isfinite(templates[epoch])
        if np.any(bad):
            templates[epoch] = np.where(bad, pre_fill[None, :], templates[epoch])
    maze = NewMaze(6)
    terminal_nodes = list(range(2 ** int(maze.le) - 1, len(maze.ru)))
    rows = []
    for anchor in terminal_nodes:
        distance = np.asarray(
            [
                _tree_distance(np.asarray(maze.pa, dtype=int), node, anchor)
                for node in nodes
            ],
            dtype=float,
        )
        pre_score = _loono_coordinate_score(
            templates["pre"], distance, alpha=config.reward_distributed_ridge_alpha
        )
        post_score = _loono_coordinate_score(
            templates["post"], distance, alpha=config.reward_distributed_ridge_alpha
        )
        rows.append(
            {
                "animal_id": animal_id,
                "anchor_node": int(anchor),
                "is_reward_anchor": bool(anchor == int(REWARD_NODE)),
                "pre_loono_spearman": pre_score,
                "post_loono_spearman": post_score,
                "delta_post_minus_pre": post_score - pre_score,
                "n_nodes": int(len(nodes)),
                "n_cells": int(np.sum(keep_cells)),
                "n_nonfinite_pre_imputed": n_nonfinite_pre,
                "n_nonfinite_post_imputed": n_nonfinite_post,
                "nonfinite_policy": "pre_template_cell_median",
                "status": "ok",
            }
        )
    result = pd.DataFrame(rows)
    finite = result["delta_post_minus_pre"].replace([np.inf, -np.inf], np.nan).dropna()
    if finite.empty:
        return result, {
            "distributed_status": "distributed_coordinate_scores_nonfinite",
            "n_distributed_nodes": int(len(nodes)),
            "distributed_reward_supported": False,
        }
    ordered = result.sort_values(
        ["delta_post_minus_pre", "anchor_node"], ascending=[False, True]
    )
    ordered["rank_descending"] = np.arange(1, len(ordered) + 1)
    rank_map = ordered.set_index("anchor_node")["rank_descending"]
    result["rank_descending"] = result["anchor_node"].map(rank_map)
    result["rank_percentile_descending"] = (result["rank_descending"] - 1) / max(
        1, len(result) - 1
    )
    target = result.loc[result["is_reward_anchor"]].iloc[0]
    supported = bool(
        np.isfinite(target["delta_post_minus_pre"])
        and float(target["delta_post_minus_pre"]) > 0
        and np.isfinite(target["post_loono_spearman"])
        and float(target["post_loono_spearman"]) > 0
        and float(target["rank_percentile_descending"]) <= 0.10
    )
    return result, {
        "distributed_status": "ok" if supported else "no_exceptional_reward_anchor",
        "n_distributed_nodes": int(len(nodes)),
        "distributed_reward_supported": supported,
        "reward_anchor_pre_spearman": float(target["pre_loono_spearman"]),
        "reward_anchor_post_spearman": float(target["post_loono_spearman"]),
        "reward_anchor_delta": float(target["delta_post_minus_pre"]),
        "reward_anchor_rank_percentile": float(target["rank_percentile_descending"]),
    }


def run_reward_code_branch(
    inventory: pd.DataFrame,
    transitions: pd.DataFrame,
    *,
    config: Phase3Config,
    spec: RewardVisitSpec = RewardVisitSpec(),
) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    """Run H-NR1 for Day-2 reward introduction with a fixed claim ladder."""

    visit_audits = []
    template_audits = []
    score_audits = []
    match_audits = []
    did_audits = []
    status_rows = []
    distributed_audits = []
    c_load_audits = []
    exclusions: list[dict[str, Any]] = []
    for pair_index, meta in inventory.iterrows():
        animal_id = str(meta["animal_id"])
        pair_id = str(meta["pair_id"])
        reward_day = pd.to_numeric(
            pd.Series([meta.get("reward_learning_day_index")]), errors="coerce"
        ).iloc[0]
        if not np.isfinite(reward_day) or int(reward_day) != 2:
            status_rows.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "cohort_group": str(meta["cohort_group"]),
                    "analysis_variant": "final",
                    "status": "reward_learning_day1_requires_separate_within_day_branch",
                    "interpretation": "not_applicable_to_Day2_reward_introduction",
                }
            )
            continue
        ready = str(meta.get("C_reward_cross_day_ready", "False")).lower() == "true"
        aligned = all(
            str(meta.get(f"day{day}_C_frame_alignment_ok", "False")).lower() == "true"
            for day in (1, 2)
        )
        shared_basis = (
            str(meta.get("shared_component_basis", "False")).lower() == "true"
        )
        if not (ready and aligned and shared_basis):
            reason = str(
                meta.get(
                    "C_reward_cross_day_exclusion_reason",
                    "C_reward_cross_day_not_ready",
                )
            )
            status_rows.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "cohort_group": str(meta["cohort_group"]),
                    "analysis_variant": "final",
                    "status": "C_reward_cross_day_not_ready",
                    "reason": reason,
                    "interpretation": "node94_support_unresolved",
                }
            )
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "stage": "reward_C_gate",
                    "reason": reason,
                }
            )
            continue
        first_reward_time = pd.to_numeric(
            pd.Series([meta.get("day2_first_reward_maze_seconds")]), errors="coerce"
        ).iloc[0]
        if not np.isfinite(first_reward_time):
            status_rows.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "cohort_group": str(meta["cohort_group"]),
                    "analysis_variant": "final",
                    "status": "first_reward_time_unresolved",
                    "interpretation": "node94_support_unresolved",
                }
            )
            continue
        try:
            day1_visits, day1_frames, day1_load = _load_reward_day_visits(
                meta, transitions, day_index=1
            )
            day2_visits, day2_frames, day2_load = _load_reward_day_visits(
                meta, transitions, day_index=2
            )
            if day1_load.get("C_n_cells") != day2_load.get("C_n_cells"):
                raise ValueError(
                    "Day1/Day2 C component counts differ despite shared-basis gate"
                )
            visits = pd.concat([day1_visits, day2_visits], ignore_index=True)
            frame_map = {**day1_frames, **day2_frames}
            neural_file_by_session = {
                str(meta["session_day1"]): str(meta["day1_neural_file"]),
                str(meta["session_day2"]): str(meta["day2_neural_file"]),
            }
            for audit in (day1_load, day2_load):
                c_load_audits.append(
                    {"pair_id": pair_id, "animal_id": animal_id, **audit}
                )
        except Exception as exc:
            reason = f"{type(exc).__name__}:{exc}"
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "stage": "reward_visit_C_load",
                    "reason": reason,
                }
            )
            status_rows.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "cohort_group": str(meta["cohort_group"]),
                    "analysis_variant": "final",
                    "status": "reward_visit_C_load_failed",
                    "reason": reason,
                    "interpretation": "node94_support_unresolved",
                }
            )
            continue

        variant_status: dict[str, dict[str, Any]] = {}
        outcome_support = select_reward_target_visits(
            visits, float(first_reward_time), target_node=REWARD_NODE, spec=spec
        )
        selections: dict[str, tuple[pd.DataFrame, Any, Any]] = {}
        requested_ids: set[str] = set()
        for variant in ("explore_only", "outcome_inclusive"):
            selection = _select_reward_variant(
                visits, float(first_reward_time), variant=variant, spec=spec
            )
            selections[variant] = selection
            _, support, match = selection
            if support.supported and match.supported:
                requested_ids.update(_reward_role_map(support, match))
        vectors, vector_load = _load_requested_reward_vectors(
            sorted(requested_ids),
            visits,
            frame_map,
            neural_file_by_session,
        )
        if not vector_load.empty:
            vector_load["pair_id"] = pair_id
            vector_load["animal_id"] = animal_id
            c_load_audits.extend(vector_load.to_dict("records"))
        for variant_index, variant in enumerate(("explore_only", "outcome_inclusive")):
            variant_visits, support, match = selections[variant]
            role_map = (
                _reward_role_map(support, match)
                if support.supported and match.supported
                else {}
            )
            visit_copy = visits.copy()
            visit_copy["analysis_variant"] = variant
            visit_copy["selected_role"] = (
                visit_copy["visit_id"]
                .astype(str)
                .map(
                    {
                        key: ("target_" if node == int(REWARD_NODE) else "control_")
                        + epoch
                        for key, (node, epoch) in role_map.items()
                    }
                )
                .fillna("not_selected")
            )
            visit_copy["is_first_reward_visit"] = (
                visit_copy["visit_id"]
                .astype(str)
                .eq(str(outcome_support.first_reward_visit_id))
            )
            visit_copy["first_reward_excluded_from_post"] = True
            visit_audits.append(visit_copy)
            match_audits.append(
                {
                    "pair_id": pair_id,
                    "animal_id": animal_id,
                    "cohort_group": str(meta["cohort_group"]),
                    "analysis_variant": variant,
                    "target_support_status": support.status,
                    "first_reward_visit_id": support.first_reward_visit_id,
                    "first_reward_excluded_from_post": True,
                    "target_pre_visit_ids": json.dumps(list(support.pre_visit_ids)),
                    "target_post_visit_ids": json.dumps(list(support.post_visit_ids)),
                    "n_pre_eligible": int(support.n_pre_eligible),
                    "n_post_primary_eligible": int(support.n_post_primary_eligible),
                    "n_post_rescue_eligible": int(support.n_post_rescue_eligible),
                    "post_window_s_used": support.post_window_s_used,
                    "control_match_status": match.status,
                    "matched_nodes": json.dumps(list(match.matched_nodes)),
                    "caliper_fraction_used": match.caliper_fraction_used,
                    "orientation_matched": match.orientation_matched,
                    "per_node_visit_ids": json.dumps(
                        _json_ready(match.per_node_visit_ids), sort_keys=True
                    ),
                }
            )
            combined_support = support.status if not support.supported else match.status
            base_status = {
                "pair_id": pair_id,
                "animal_id": animal_id,
                "cohort_group": str(meta["cohort_group"]),
                "analysis_variant": variant,
                "target_support_status": support.status,
                "control_match_status": match.status,
                "support_status": combined_support,
                "first_reward_excluded_from_post": True,
                "n_controls": int(len(match.matched_nodes)),
            }
            if not (support.supported and match.supported):
                interpretation = classify_node94_interpretation(
                    support_status=combined_support,
                    target_change_supported=False,
                    target_rank_percentile=None,
                )
                base_status.update(
                    {
                        "status": "location_specific_support_unresolved",
                        "target_change_supported": False,
                        "interpretation": interpretation,
                    }
                )
                status_rows.append(base_status)
                variant_status[variant] = base_status
                continue
            scores, templates, score_meta = _score_reward_templates(
                animal_id=animal_id,
                variant=variant,
                visits=variant_visits,
                vectors=vectors,
                support=support,
                match=match,
                config=config,
            )
            if not scores.empty:
                scores["pair_id"] = pair_id
                scores["cohort_group"] = str(meta["cohort_group"])
                score_audits.append(scores)
            if not templates.empty:
                templates["pair_id"] = pair_id
                templates["cohort_group"] = str(meta["cohort_group"])
                template_audits.append(templates)
            if score_meta["status"] != "ok" or scores.empty:
                base_status.update(
                    {
                        "status": score_meta["status"],
                        "target_change_supported": False,
                        "interpretation": "node94_support_unresolved",
                        **score_meta,
                    }
                )
                status_rows.append(base_status)
                variant_status[variant] = base_status
                continue
            did = compute_pseudo_target_did(
                scores,
                controls_by_animal={animal_id: match.matched_nodes},
                target_node=REWARD_NODE,
                min_controls=spec.min_controls,
            )
            did["pair_id"] = pair_id
            did["cohort_group"] = str(meta["cohort_group"])
            did["analysis_variant"] = variant
            did_audits.append(did)
            target_rows = (
                did.loc[did.get("is_target_node", False).eq(True)]
                if "is_target_node" in did
                else pd.DataFrame()
            )
            if target_rows.empty or str(target_rows.iloc[0]["status"]) != "ok":
                base_status.update(
                    {
                        "status": "target_DiD_unresolved",
                        "target_change_supported": False,
                        "interpretation": "node94_support_unresolved",
                        **score_meta,
                    }
                )
                status_rows.append(base_status)
                variant_status[variant] = base_status
                continue
            target = target_rows.iloc[0]
            uncertainty = _bootstrap_target_did(
                scores,
                match.matched_nodes,
                n_bootstrap=config.reward_n_bootstrap,
                seed=config.seed + 1000 * pair_index + variant_index,
            )
            target_supported = bool(
                np.isfinite(target["pseudo_target_did"])
                and float(target["pseudo_target_did"]) > 0
                and uncertainty.get("bootstrap_status") == "ok"
                and float(uncertainty["target_did_ci_low"]) > 0
            )
            rank = float(target["rank_percentile_descending"])
            interpretation = classify_node94_interpretation(
                support_status=combined_support,
                target_change_supported=target_supported,
                target_rank_percentile=rank,
                explore_only_supported=bool(
                    variant == "explore_only" and target_supported
                ),
                outcome_inclusive_supported=bool(
                    variant == "outcome_inclusive" and target_supported
                ),
            )
            base_status.update(
                {
                    "status": "ok",
                    "target_pseudo_DiD": float(target["pseudo_target_did"]),
                    "target_rank_percentile": rank,
                    "target_change_supported": target_supported,
                    "interpretation": interpretation,
                    **score_meta,
                    **uncertainty,
                }
            )
            status_rows.append(base_status)
            variant_status[variant] = base_status

        explore_claim = variant_status.get("explore_only", {}).get("interpretation")
        outcome_claim = variant_status.get("outcome_inclusive", {}).get(
            "interpretation"
        )
        location_specific = explore_claim == "reward_location_specific_code"
        distributed_table = pd.DataFrame()
        distributed_meta = {
            "distributed_status": "not_needed_location_specific_supported",
            "distributed_reward_supported": False,
        }
        if not location_specific:
            distributed_selection = _distributed_visit_selection(
                visits,
                first_reward_time=float(first_reward_time),
                first_reward_visit_id=outcome_support.first_reward_visit_id,
                spec=spec,
            )
            distributed_nodes = {
                node for node, epoch in distributed_selection if epoch == "pre"
            } & {node for node, epoch in distributed_selection if epoch == "post"}
            distributed_ids = (
                {value for ids in distributed_selection.values() for value in ids}
                if len(distributed_nodes) >= int(config.reward_min_distributed_nodes)
                else set()
            )
            missing_ids = sorted(distributed_ids.difference(vectors))
            if missing_ids:
                extra_vectors, extra_load = _load_requested_reward_vectors(
                    missing_ids,
                    visits,
                    frame_map,
                    neural_file_by_session,
                )
                vectors.update(extra_vectors)
                if not extra_load.empty:
                    extra_load["pair_id"] = pair_id
                    extra_load["animal_id"] = animal_id
                    extra_load["load_stage"] = "distributed_fallback"
                    c_load_audits.extend(extra_load.to_dict("records"))
            distributed_table, distributed_meta = _distributed_reward_coordinate(
                animal_id=animal_id,
                visits=visits,
                vectors=vectors,
                selected=distributed_selection,
                config=config,
            )
            if not distributed_table.empty:
                distributed_table["pair_id"] = pair_id
                distributed_table["cohort_group"] = str(meta["cohort_group"])
                distributed_audits.append(distributed_table)
        if location_specific:
            final_interpretation = "reward_location_specific_code"
        elif bool(distributed_meta.get("distributed_reward_supported", False)):
            final_interpretation = "distributed_reward_coordinate_code"
        elif outcome_claim == "reward_consumption_state":
            final_interpretation = "reward_consumption_state"
        elif (
            explore_claim == "generic_terminal_reorganization"
            or outcome_claim == "generic_terminal_reorganization"
        ):
            final_interpretation = "generic_terminal_reorganization"
        elif all(
            value.get("status") == "location_specific_support_unresolved"
            for value in variant_status.values()
        ):
            final_interpretation = "node94_support_unresolved"
        else:
            final_interpretation = "no_supported_reward_specific_code"
        status_rows.append(
            {
                "pair_id": pair_id,
                "animal_id": animal_id,
                "cohort_group": str(meta["cohort_group"]),
                "analysis_variant": "final",
                "status": "ok"
                if final_interpretation != "node94_support_unresolved"
                else "support_unresolved",
                "interpretation": final_interpretation,
                "explore_only_interpretation": explore_claim,
                "outcome_inclusive_interpretation": outcome_claim,
                **distributed_meta,
            }
        )
    tables = {
        "phase3_node94_visit_audit.csv": pd.concat(visit_audits, ignore_index=True)
        if visit_audits
        else pd.DataFrame(),
        "phase3_node94_template_audit.csv": pd.concat(
            template_audits, ignore_index=True
        )
        if template_audits
        else pd.DataFrame(),
        "phase3_node94_visit_scores.csv": pd.concat(score_audits, ignore_index=True)
        if score_audits
        else pd.DataFrame(),
        "phase3_node94_match_audit.csv": pd.DataFrame(match_audits),
        "phase3_node94_did_scores.csv": pd.concat(did_audits, ignore_index=True)
        if did_audits
        else pd.DataFrame(),
        "phase3_node94_animal_status.csv": pd.DataFrame(status_rows),
        "phase3_node94_branch_status.csv": pd.DataFrame(status_rows),
        "phase3_distributed_reward_coordinate.csv": pd.concat(
            distributed_audits, ignore_index=True
        )
        if distributed_audits
        else pd.DataFrame(),
        "phase3_reward_C_load_audit.csv": pd.DataFrame(c_load_audits),
    }
    return tables, exclusions


def _write_tables(out_dir: Path, tables: Mapping[str, pd.DataFrame]) -> dict[str, Any]:
    outputs = {}
    for name, table in tables.items():
        path = out_dir / name
        if table.empty and table.columns.empty:
            # A header-only CSV remains machine-readable and explicitly empty;
            # pandas cannot read a zero-byte artifact back for an audit.
            table = pd.DataFrame({"empty_table_reason": pd.Series(dtype=str)})
        table.to_csv(path, index=False)
        outputs[name] = {
            "path": str(path),
            "n_rows": int(len(table)),
            "sha256": _sha256(path),
        }
    return outputs


def _resolve_phase1_assigned_choices(phase1_dir: Path) -> tuple[Path, str]:
    """Prefer the all-neighbor structural epochs over child-entry diagnostics."""

    primary = phase1_dir / "all_neighbor_primary_structure_assigned_choices.csv"
    if primary.exists():
        return primary, "primary_all_neighbor_variable_outdegree"
    fallback = phase1_dir / "structure_assigned_choices.csv"
    if fallback.exists():
        return fallback, "child_entry_diagnostic_fallback"
    return primary, "missing"


def run_phase3(
    *,
    phase0_dir: str | Path,
    phase1_dir: str | Path,
    out_dir: str | Path,
    config: Phase3Config = Phase3Config(),
    branch: str = "structure",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Run Phase 3 from frozen tables and exact Phase-0 C provenance."""

    phase0_dir = Path(phase0_dir).resolve()
    phase1_dir = Path(phase1_dir).resolve()
    out_dir = Path(out_dir).resolve()
    if branch not in {"structure", "reward", "all"}:
        raise ValueError("branch must be structure, reward, or all")
    if out_dir.exists() and any(out_dir.iterdir()) and not overwrite:
        raise FileExistsError(
            f"refusing to overwrite nonempty output directory: {out_dir}"
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    inventory_path = phase0_dir / "rapid_learning_session_inventory.csv"
    transitions_path = phase0_dir / "rapid_learning_transition_support.csv"
    inventory = pd.read_csv(inventory_path, low_memory=False)
    transitions = pd.read_csv(transitions_path, low_memory=False)
    tables: dict[str, pd.DataFrame] = {}
    exclusions: list[dict[str, Any]] = []
    assigned_path, assigned_analysis_role = _resolve_phase1_assigned_choices(phase1_dir)

    if branch in {"structure", "all"}:
        if not assigned_path.exists():
            raise FileNotFoundError(
                f"Phase-1 assigned B/C artifact is required: {assigned_path}"
            )
        assigned = pd.read_csv(assigned_path, low_memory=False)
        boundaries = build_epoch_boundaries(assigned, transitions)
        tables["phase3_epoch_boundaries.csv"] = boundaries
        within_results = []
        within_support = []
        within_predictions = []
        cross_results = []
        cross_support = []
        cross_predictions = []
        posthoc_cross_results = []
        posthoc_cross_support = []
        posthoc_cross_predictions = []
        transfer_results = []
        transfer_support = []
        transfer_predictions = []
        common_depth_audits = []
        c_load_audit = []
        metadata = inventory.set_index("session_day1", drop=False)
        for session_id, session_bounds in boundaries.groupby("session_id", sort=False):
            if session_id not in metadata.index:
                exclusions.append(
                    {
                        "session_id": session_id,
                        "stage": "inventory",
                        "reason": "missing_session_inventory",
                    }
                )
                continue
            meta = metadata.loc[session_id]
            if isinstance(meta, pd.DataFrame):
                meta = meta.iloc[0]
            ready = (
                str(meta.get("C_structure_within_session_ready", "False")).lower()
                == "true"
            )
            aligned = (
                str(meta.get("day1_C_frame_alignment_ok", "False")).lower() == "true"
            )
            if not ready or not aligned:
                exclusions.append(
                    {
                        "session_id": session_id,
                        "stage": "phase0_C_gate",
                        "reason": str(
                            meta.get(
                                "C_structure_within_session_exclusion_reason",
                                "C_not_ready",
                            )
                        ),
                    }
                )
                continue
            selected_path = Path(str(meta["day1_selected_data_path"]))
            neural_file = str(meta["day1_neural_file"])
            try:
                selected = pd.read_csv(selected_path)
                session_transitions = transitions.loc[
                    transitions["session_id"].astype(str).eq(str(session_id))
                ]
                epoch_data = {}
                for boundary in session_bounds.itertuples(index=False):
                    if str(boundary.status) != "ok":
                        raise ValueError(f"{boundary.epoch}:{boundary.status}")
                    data, audit = _build_epoch_data(
                        str(session_id),
                        str(boundary.epoch),
                        selected,
                        session_transitions,
                        pd.Series(boundary._asdict()),
                        neural_file,
                        config,
                    )
                    epoch_data[str(boundary.epoch)] = data
                    c_load_audit.append(
                        {
                            "session_id": str(session_id),
                            "epoch": str(boundary.epoch),
                            "selected_data_path": str(selected_path),
                            "neural_file": neural_file,
                            "neural_source": str(meta.get("day1_neural_source", "")),
                            **audit,
                        }
                    )
                common_cell_mask = None
                common_cell_status = "not_available"
                common_depth_plan = None
                if {"B", "C"}.issubset(epoch_data):
                    common_depth_plan, depth_audit = select_common_within_depth_plan(
                        epoch_data["B"], epoch_data["C"], config
                    )
                    depth_audit["session_id"] = str(session_id)
                    depth_audit["animal_id"] = str(meta["animal_id"])
                    depth_audit["cohort_group"] = str(meta["cohort_group"])
                    common_depth_audits.append(depth_audit)
                    mask_b = within_epoch_training_cell_mask(
                        epoch_data["B"], config, depth_plan=common_depth_plan
                    )
                    mask_c = within_epoch_training_cell_mask(
                        epoch_data["C"], config, depth_plan=common_depth_plan
                    )
                    if mask_b is not None and mask_c is not None:
                        common_cell_mask = mask_b & mask_c
                        common_cell_status = (
                            "ok"
                            if int(np.sum(common_cell_mask)) >= int(config.min_cells)
                            else "insufficient_common_B_C_cells"
                        )
                    elif common_depth_plan.status.startswith("ok"):
                        common_cell_mask = np.zeros(
                            epoch_data["B"].counts_c.shape[1], dtype=bool
                        )
                        common_cell_status = "common_depth_cell_gate_unresolved"
                for epoch_name, data in epoch_data.items():
                    fixed_mask = (
                        common_cell_mask if common_cell_mask is not None else None
                    )
                    result, support, predictions = evaluate_within_epoch_depth_code(
                        data,
                        config,
                        fixed_cell_mask=fixed_mask,
                        depth_plan=(
                            common_depth_plan if epoch_name in {"B", "C"} else None
                        ),
                    )
                    result.update(
                        {
                            "animal_id": str(meta["animal_id"]),
                            "cohort_group": str(meta["cohort_group"]),
                            "common_B_C_cell_status": common_cell_status,
                            "common_depth_plan_status": (
                                common_depth_plan.status
                                if common_depth_plan is not None
                                else "not_available"
                            ),
                            "n_common_B_C_cells": (
                                int(np.sum(common_cell_mask))
                                if common_cell_mask is not None
                                else np.nan
                            ),
                        }
                    )
                    within_results.append(result)
                    if len(support):
                        within_support.append(support)
                    if len(predictions):
                        within_predictions.append(predictions)
                if "C" in epoch_data:
                    result, support, predictions = _cross_subtree_late(
                        epoch_data["C"], config
                    )
                    if len(result):
                        result["animal_id"] = str(meta["animal_id"])
                        result["cohort_group"] = str(meta["cohort_group"])
                        cross_results.append(result)
                    if len(support):
                        cross_support.append(support)
                    if len(predictions):
                        cross_predictions.append(predictions)
                    (
                        posthoc_result,
                        posthoc_support,
                        posthoc_predictions,
                    ) = _cross_subtree_late(
                        epoch_data["C"],
                        config,
                        folds=posthoc_interior_depth_folds(),
                        analysis_label=("posthoc_support_rescue_interior_depths_2_5"),
                        support_only_label=(
                            "posthoc_support_rescue_interior_depths_2_5"
                        ),
                        audit_all_frame_attempts=True,
                    )
                    if len(posthoc_result):
                        posthoc_result["animal_id"] = str(meta["animal_id"])
                        posthoc_result["cohort_group"] = str(meta["cohort_group"])
                        posthoc_cross_results.append(posthoc_result)
                    if len(posthoc_support):
                        posthoc_cross_support.append(posthoc_support)
                    if len(posthoc_predictions):
                        posthoc_cross_predictions.append(posthoc_predictions)
                    context = str(meta["cohort_group"])
                    cross_day_ready = (
                        str(meta.get("C_structure_cross_day_ready", "False")).lower()
                        == "true"
                    )
                    if (
                        context
                        in {
                            "unrewarded_no_water",
                            "unrewarded_dry_waterport",
                        }
                        and cross_day_ready
                    ):
                        day2_session = str(meta["session_day2"])
                        first_reward = pd.to_numeric(
                            pd.Series(
                                [meta.get("day2_first_reward_abs_frame", np.nan)]
                            ),
                            errors="coerce",
                        ).iloc[0]
                        day2_transitions = transitions.loc[
                            transitions["session_id"].astype(str).eq(day2_session)
                        ].copy()
                        if not np.isfinite(first_reward) or day2_transitions.empty:
                            transfer_results.append(
                                {
                                    "session_id": str(session_id),
                                    "test_session_id": day2_session,
                                    "animal_id": str(meta["animal_id"]),
                                    "cohort_group": context,
                                    "status": "missing_day2_prereward_boundary",
                                }
                            )
                        else:
                            try:
                                day2_selected = pd.read_csv(
                                    Path(str(meta["day2_selected_data_path"]))
                                )
                                start = float(
                                    pd.to_numeric(
                                        day2_transitions["abs_frame_start"],
                                        errors="coerce",
                                    ).min()
                                )
                                day2_epoch, day2_audit = _build_epoch_data(
                                    day2_session,
                                    "D2_pre_reward",
                                    day2_selected,
                                    day2_transitions,
                                    pd.Series(
                                        {
                                            "frame_start": start,
                                            "frame_end": float(first_reward) - 1.0,
                                        }
                                    ),
                                    str(meta["day2_neural_file"]),
                                    config,
                                )
                                (
                                    transfer,
                                    transfer_gate,
                                    transfer_pred,
                                ) = evaluate_cross_day_depth_transfer(
                                    epoch_data["C"], day2_epoch, config
                                )
                                transfer.update(
                                    {
                                        "animal_id": str(meta["animal_id"]),
                                        "cohort_group": context,
                                        "first_reward_abs_frame": float(first_reward),
                                    }
                                )
                                transfer_results.append(transfer)
                                if len(transfer_gate):
                                    transfer_support.append(transfer_gate)
                                if len(transfer_pred):
                                    transfer_predictions.append(transfer_pred)
                                c_load_audit.append(
                                    {
                                        "session_id": day2_session,
                                        "epoch": "D2_pre_reward",
                                        "selected_data_path": str(
                                            meta["day2_selected_data_path"]
                                        ),
                                        "neural_file": str(meta["day2_neural_file"]),
                                        "neural_source": str(
                                            meta.get("day2_neural_source", "")
                                        ),
                                        **day2_audit,
                                    }
                                )
                            except Exception as exc:
                                transfer_results.append(
                                    {
                                        "session_id": str(session_id),
                                        "test_session_id": day2_session,
                                        "animal_id": str(meta["animal_id"]),
                                        "cohort_group": context,
                                        "status": f"{type(exc).__name__}:{exc}",
                                    }
                                )
            except Exception as exc:
                exclusions.append(
                    {
                        "session_id": str(session_id),
                        "stage": "structure_runner",
                        "reason": f"{type(exc).__name__}:{exc}",
                    }
                )
        within_df = pd.DataFrame(within_results)
        tables["phase3_within_epoch_depth_results.csv"] = within_df
        if not within_df.empty and {"B", "C"}.issubset(set(within_df["epoch"])):
            metrics = [
                "topology_balanced_accuracy",
                "position_to_depth_balanced_accuracy",
                "xy_behavior_balanced_accuracy",
                "shuffle_q95_balanced_accuracy",
            ]
            complete = within_df.loc[
                within_df["status"].astype(str).str.startswith("ok")
            ]
            paired_metadata = [
                "selected_depths",
                "excluded_depths",
                "n_depth_classes",
                "support_tier",
                "common_depth_plan_status",
                "n_common_B_C_cells",
            ]
            pivot_index = [
                "session_id",
                "animal_id",
                "cohort_group",
                *[column for column in paired_metadata if column in complete.columns],
            ]
            if complete.empty or not set(metrics).issubset(complete.columns):
                wide = pd.DataFrame()
            else:
                wide = complete.pivot(
                    index=pivot_index,
                    columns="epoch",
                    values=metrics,
                )
                wide.columns = [f"{metric}_{epoch}" for metric, epoch in wide.columns]
                wide = wide.reset_index()
            required_pair = [
                "topology_balanced_accuracy_B",
                "topology_balanced_accuracy_C",
            ]
            if set(required_pair).issubset(wide.columns):
                wide = wide.dropna(subset=required_pair).reset_index(drop=True)
            else:
                wide = pd.DataFrame()
            for metric in metrics:
                if f"{metric}_B" in wide and f"{metric}_C" in wide:
                    wide[f"delta_{metric}_C_minus_B"] = (
                        wide[f"{metric}_C"] - wide[f"{metric}_B"]
                    )
            if {
                "topology_balanced_accuracy_B",
                "topology_balanced_accuracy_C",
            }.issubset(wide.columns):
                wide["topology_gain_C_minus_B"] = (
                    wide["topology_balanced_accuracy_C"]
                    - wide["topology_balanced_accuracy_B"]
                )
            for label, comparator in (
                ("position", "position_to_depth_balanced_accuracy"),
                ("xy", "xy_behavior_balanced_accuracy"),
                ("shuffle", "shuffle_q95_balanced_accuracy"),
            ):
                required = {
                    "topology_balanced_accuracy_B",
                    "topology_balanced_accuracy_C",
                    f"{comparator}_B",
                    f"{comparator}_C",
                }
                if required.issubset(wide.columns):
                    wide[f"topology_minus_{label}_gain_C_minus_B"] = (
                        wide["topology_balanced_accuracy_C"]
                        - wide[f"{comparator}_C"]
                        - wide["topology_balanced_accuracy_B"]
                        + wide[f"{comparator}_B"]
                    )
        else:
            wide = pd.DataFrame()
        tables["phase3_early_late_depth_gain.csv"] = wide
        tables["phase3_within_epoch_support.csv"] = (
            pd.concat(within_support, ignore_index=True)
            if within_support
            else pd.DataFrame()
        )
        tables["phase3_common_depth_rescue_audit.csv"] = (
            pd.concat(common_depth_audits, ignore_index=True)
            if common_depth_audits
            else pd.DataFrame()
        )
        tables["phase3_cross_subtree_results.csv"] = (
            pd.concat(cross_results, ignore_index=True)
            if cross_results
            else pd.DataFrame()
        )
        tables["phase3_cross_subtree_support.csv"] = (
            pd.concat(cross_support, ignore_index=True)
            if cross_support
            else pd.DataFrame()
        )
        tables["phase3_cross_subtree_posthoc_interior_depths_2_5_results.csv"] = (
            pd.concat(posthoc_cross_results, ignore_index=True)
            if posthoc_cross_results
            else pd.DataFrame()
        )
        tables["phase3_cross_subtree_posthoc_interior_depths_2_5_support.csv"] = (
            pd.concat(posthoc_cross_support, ignore_index=True)
            if posthoc_cross_support
            else pd.DataFrame()
        )
        tables["phase3_cross_subtree_posthoc_interior_depths_2_5_predictions.csv"] = (
            pd.concat(posthoc_cross_predictions, ignore_index=True)
            if posthoc_cross_predictions
            else pd.DataFrame()
        )
        tables["phase3_day1C_to_day2_prereward_results.csv"] = pd.DataFrame(
            transfer_results
        )
        tables["phase3_day1C_to_day2_prereward_support.csv"] = (
            pd.concat(transfer_support, ignore_index=True)
            if transfer_support
            else pd.DataFrame()
        )
        tables["phase3_prediction_audit.csv"] = (
            pd.concat(
                [
                    *(within_predictions or []),
                    *(cross_predictions or []),
                    *(transfer_predictions or []),
                ],
                ignore_index=True,
            )
            if (within_predictions or cross_predictions or transfer_predictions)
            else pd.DataFrame()
        )
        tables["phase3_C_load_audit.csv"] = pd.DataFrame(c_load_audit)
        inference_tables = build_animal_inference_summaries(
            tables["phase3_early_late_depth_gain.csv"],
            tables["phase3_cross_subtree_results.csv"],
            tables["phase3_day1C_to_day2_prereward_results.csv"],
            config,
        )
        tables.update(inference_tables)

    if branch in {"reward", "all"}:
        reward_tables, reward_exclusions = run_reward_code_branch(
            inventory,
            transitions,
            config=config,
        )
        tables.update(reward_tables)
        exclusions.extend(reward_exclusions)

    status_rows: list[dict[str, Any]] = []
    if branch in {"structure", "all"}:
        inference_summary = tables.get(
            "phase3_animal_inference_summary.csv", pd.DataFrame()
        )
        ns1a_status, ns1a_n, ns1a_cap = _hypothesis_inference_status(
            inference_summary, "H-NS1A"
        )
        ns1b_status, ns1b_n, ns1b_cap = _hypothesis_inference_status(
            inference_summary, "H-NS1B"
        )
        ns2_status, ns2_n, ns2_cap = _hypothesis_inference_status(
            inference_summary, "H-NS2"
        )
        status_rows.extend(
            [
                {
                    "hypothesis_id": "H-NS1A",
                    "hypothesis": "C-based tree-depth accessibility increases from exposure-matched early B to late C exploration.",
                    "status": ns1a_status,
                    "n": ns1a_n,
                    "interpretation_cap": ns1a_cap,
                },
                {
                    "hypothesis_id": "H-NS1B",
                    "hypothesis": "Late C depth code generalizes across physically distant equivalent subtrees beyond position and behavior comparators.",
                    "status": ns1b_status,
                    "n": ns1b_n,
                    "interpretation_cap": ns1b_cap,
                },
                {
                    "hypothesis_id": "H-NS2",
                    "hypothesis": "Day-1 structural code transfers to pre-reward Day-2 search.",
                    "status": ns2_status,
                    "n": ns2_n,
                    "interpretation_cap": ns2_cap,
                },
            ]
        )
    if branch in {"reward", "all"}:
        reward_summary = _reward_hypothesis_status(
            tables.get("phase3_node94_animal_status.csv", pd.DataFrame()),
            tables.get("phase3_node94_did_scores.csv", pd.DataFrame()),
            tables.get("phase3_distributed_reward_coordinate.csv", pd.DataFrame()),
        )
        status_rows.append(
            {
                "hypothesis_id": "H-NR1",
                "hypothesis": "Post-discovery neural change at node 94 exceeds matched terminal-node and trajectory controls.",
                **reward_summary,
            }
        )
    tables["hypothesis_status.csv"] = pd.DataFrame(status_rows)

    tables["phase3_exclusions.csv"] = pd.DataFrame(exclusions)
    outputs = _write_tables(out_dir, tables)
    inputs = {}
    for path in (inventory_path, transitions_path):
        inputs[path.name] = {"path": str(path), "sha256": _sha256(path)}
    if assigned_path.exists():
        inputs[assigned_path.name] = {
            "path": str(assigned_path),
            "sha256": _sha256(assigned_path),
        }
    manifest = {
        "phase": "rapid_learning_structure_reward_phase3_neural_codes",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "branch": branch,
        "config": asdict(config),
        "signal_contract": "C-primary; S is not used",
        "representation": "tree_depth7 from selected mass_by,mass_bx -> maze cell -> run depth",
        "epoch_contract": "Phase1 B/C decisions resolved through Phase0 transition frame boundaries; explore intervals only",
        "phase1_assigned_choice_role": assigned_analysis_role,
        "phase1_assigned_choice_file": str(assigned_path),
        "matching_contract": "within-session Day1 uses one component basis; Day1-to-Day2 transfer runs only when Phase0 verifies the maintained joint-deconvolution identity basis and equal C components",
        "topology_folds": [asdict(fold) for fold in fixed_topology_folds()],
        "posthoc_cross_subtree_support_rescue_contract": {
            "label": "posthoc_support_rescue_interior_depths_2_5",
            "claim_tier": "support_only_posthoc_setup_rescue",
            "folds": [asdict(fold) for fold in posthoc_interior_depth_folds()],
            "depths": [2, 3, 4, 5],
            "min_visits_per_depth_per_side": int(config.min_visits_per_depth),
            "frame_gate_order": [
                int(config.min_frames_per_depth),
                int(config.rescue_min_frames_per_depth),
            ],
            "comparator_contract": (
                "topology, position, XY, and visit-label shuffle use the exact "
                "same balanced four-depth train/test frames"
            ),
            "primary_preserved": (
                "phase3_cross_subtree_results.csv remains the original all-depth "
                "six-fold audit and this rescue never enters primary inference"
            ),
        },
        "position_comparator": "maintained C-based Poisson decoder; predicted training-cell mapped to depth",
        "xy_behavior_comparator": "fixed RBF features plus multinomial logistic regression",
        "shuffle_policy": "training depth labels permuted across balanced frames",
        "cell_rate_gate_contract": "B and C use the intersection of per-epoch training-only C gates for early-late comparability; cross-subtree folds retain fold-training-only gates",
        "depth_support_contract": (
            "seven-depth primary attempted first; named deterministic rescue uses "
            f"at least {config.min_common_depths} depths meeting the unchanged "
            f"{config.min_visits_per_depth}-visit floor in every compared scope; "
            "paired B/C epochs use the exact same selected depths and common "
            "training-only cell intersection"
        ),
        "visit_contract": "run visits are defined on full Phase0 transitions, not selected-frame continuity",
        "shuffle_contract": "depth labels are permuted at the full-trajectory visit level",
        "animal_inference_contract": {
            "unit": "animal",
            "within_animal_aggregation": "mean across supported sessions or folds before inference",
            "H_NS1A": "paired B-vs-C topology gain and paired comparator-adjusted gains",
            "H_NS1B": "one-sample cross-subtree margins; primary and rescue folds reported separately",
            "H_NS2": "one-sample Day1-C to Day2-pre-reward comparator margins",
            "ci": f"{config.animal_ci_level:.3f} animal bootstrap CI with {config.n_animal_bootstrap} resamples",
            "p_value": "exact two-sided sign test with zero ties excluded",
            "multiplicity": "no p-value adjustment; estimands are predeclared and hypothesis status requires all required margins",
            "min_animals": int(config.min_animals_inference),
            "context_policy": "cohort diagnostics are descriptive and not separately confirmatory",
        },
        "reward_branch_contract": (
            "Day2 reward introduction only; latent/dry cohorts; C-primary visit templates; "
            "first reward excluded; explore-only primary and outcome-inclusive sensitivity"
        ),
        "reward_branch_cap": "associative visit-template analysis; no causal or single-cell place-field claim",
        "reward_score": "leave-one-visit-out own-template correlation minus best matched-node template correlation",
        "reward_fallback": "leave-one-node-out distributed graph-distance coordinate with node94 anchor ranked against all terminal anchors",
        "inputs": inputs,
        "outputs": outputs,
    }
    manifest_path = out_dir / "phase3_manifest.json"
    manifest_path.write_text(
        json.dumps(_json_ready(manifest), indent=2), encoding="utf-8"
    )
    return manifest


__all__ = [
    "CommonDepthPlan",
    "EpochData",
    "Phase3Config",
    "build_animal_inference_summaries",
    "build_epoch_boundaries",
    "build_reward_visit_support_audit",
    "contiguous_run_visits",
    "transition_run_visits",
    "evaluate_within_epoch_depth_code",
    "exact_two_sided_sign_p",
    "load_c_count_windows",
    "run_reward_code_branch",
    "run_phase3",
    "select_common_within_depth_plan",
    "within_epoch_training_cell_mask",
    "selected_explore_epoch_mask",
    "selected_frame_geometry",
]
