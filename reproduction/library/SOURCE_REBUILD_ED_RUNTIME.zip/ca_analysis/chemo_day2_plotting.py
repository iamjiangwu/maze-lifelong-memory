from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .chemo_day2_compare import ComparisonConfig


GROUP_COLORS = {
    "ChemoUBIday2": "#c0392b",
    "AllUnrewardedDay2": "#1f77b4",
}


def _color_for(group: str) -> str:
    return GROUP_COLORS.get(str(group), "#4d4d4d")


def _ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save(fig: plt.Figure, out: Path) -> str:
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return str(out)


def _plot_cumulative(
    curve_group: pd.DataFrame,
    config: ComparisonConfig,
    event_type: str,
    title: str,
    t_break: float,
    out_path: Path,
) -> str:
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    sub = curve_group.loc[curve_group["event_type"] == str(event_type)].copy()
    for group, ss in sub.groupby("group"):
        s = ss.sort_values("maze_seconds")
        x = pd.to_numeric(s["maze_seconds"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(s["cum_mean"], errors="coerce").to_numpy(dtype=float)
        lo = pd.to_numeric(s["cum_ci_low"], errors="coerce").to_numpy(dtype=float)
        hi = pd.to_numeric(s["cum_ci_high"], errors="coerce").to_numpy(dtype=float)
        c = _color_for(str(group))
        ax.plot(x, y, color=c, lw=2.0, label=str(group))
        ax.fill_between(x, lo, hi, color=c, alpha=0.2, linewidth=0.0)
    if np.isfinite(t_break):
        ax.axvline(float(t_break), color="k", ls="--", lw=1.3, label=f"t_break={t_break:.0f}s")
    ax.set_title(title)
    ax.set_xlabel("Maze time (s)")
    ax.set_ylabel("Cumulative count")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=9)
    return _save(fig, out_path)


def _plot_early_equivalence(
    early_rate_table: pd.DataFrame,
    ratio_reward: pd.DataFrame,
    ratio_long: pd.DataFrame,
    config: ComparisonConfig,
    out_path: Path,
) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.2))
    if early_rate_table is None or early_rate_table.empty or not {"event_type", "session", "group", "early_rate"}.issubset(
        set(early_rate_table.columns)
    ):
        for ax in axes:
            ax.text(0.5, 0.5, "No early-rate data", ha="center", va="center", transform=ax.transAxes)
            ax.set_axis_off()
        return _save(fig, out_path)
    for i, et in enumerate(["reward", "long_path_reward"]):
        ax = axes[i]
        sub = early_rate_table.loc[
            (early_rate_table["event_type"] == et) & (early_rate_table["session"] != "__ratio__")
        ].copy()
        for group, ss in sub.groupby("group"):
            x = np.full(len(ss), 0 if group == config.group_a_name else 1, dtype=float)
            x = x + np.random.default_rng(0).normal(0, 0.05, len(ss))
            y = pd.to_numeric(ss["early_rate"], errors="coerce").to_numpy(dtype=float)
            ax.scatter(x, y, s=24, alpha=0.8, color=_color_for(str(group)), label=str(group))
        ax.set_xticks([0, 1], [config.group_a_name, config.group_b_name], rotation=20, ha="right")
        ax.set_ylabel("Early rate (events/s)")
        ax.set_title("Reward rate" if et == "reward" else "Long-path rate")
        ax.grid(alpha=0.25)
    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        axes[0].legend(handles[:2], labels[:2], frameon=False, fontsize=8)

    ax = axes[2]
    used_gap = False
    for name, df in [("reward", ratio_reward), ("long_path_reward", ratio_long)]:
        if df is None or df.empty:
            continue
        c = "#2e7d32" if name == "reward" else "#ef6c00"
        if {"maze_seconds", "gap_mean", "gap_ci_low", "gap_ci_high"}.issubset(set(df.columns)):
            s = df.sort_values("maze_seconds")
            x = pd.to_numeric(s["maze_seconds"], errors="coerce").to_numpy(dtype=float)
            y = pd.to_numeric(s["gap_mean"], errors="coerce").to_numpy(dtype=float)
            lo = pd.to_numeric(s["gap_ci_low"], errors="coerce").to_numpy(dtype=float)
            hi = pd.to_numeric(s["gap_ci_high"], errors="coerce").to_numpy(dtype=float)
            ax.plot(x, y, color=c, lw=2, label=name)
            ax.fill_between(x, lo, hi, color=c, alpha=0.18, linewidth=0.0)
            used_gap = True
        elif {"time_bin_start", "ratio_mean", "ratio_ci_low", "ratio_ci_high"}.issubset(set(df.columns)):
            s = df.sort_values("time_bin_start")
            x = pd.to_numeric(s["time_bin_start"], errors="coerce").to_numpy(dtype=float)
            y = pd.to_numeric(s["ratio_mean"], errors="coerce").to_numpy(dtype=float)
            lo = pd.to_numeric(s["ratio_ci_low"], errors="coerce").to_numpy(dtype=float)
            hi = pd.to_numeric(s["ratio_ci_high"], errors="coerce").to_numpy(dtype=float)
            ax.plot(x, y, color=c, lw=2, label=name)
            ax.fill_between(x, lo, hi, color=c, alpha=0.18, linewidth=0.0)
    if used_gap:
        ax.axhline(0.0, color="k", ls=":", lw=1.2)
        ax.set_title("Cumulative gap CI (A-B)")
        ax.set_xlabel("Maze time (s)")
        ax.set_ylabel("Cumulative gap")
    else:
        ax.axhline(config.equivalence_low, color="k", ls=":", lw=1.2)
        ax.axhline(config.equivalence_high, color="k", ls=":", lw=1.2)
        ax.set_title("A/B rate ratio CI")
        ax.set_xlabel("Maze time bin start (s)")
        ax.set_ylabel("Ratio")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=8)
    return _save(fig, out_path)


def _plot_growth_models(
    curve_group: pd.DataFrame,
    growth_overlay: pd.DataFrame,
    event_type: str,
    title: str,
    out_path: Path,
) -> str:
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    req_obs = {"event_type", "group", "maze_seconds", "cum_mean"}
    req_ol = {"event_type", "group", "model", "maze_seconds", "pred_cum"}
    if curve_group is None or curve_group.empty or not req_obs.issubset(set(curve_group.columns)):
        ax.text(0.5, 0.5, "No cumulative curve data", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
        return _save(fig, out_path)
    obs = curve_group.loc[curve_group["event_type"] == str(event_type)].copy()
    if growth_overlay is not None and (not growth_overlay.empty) and req_ol.issubset(set(growth_overlay.columns)):
        ol = growth_overlay.loc[growth_overlay["event_type"] == str(event_type)].copy()
    else:
        ol = pd.DataFrame()
    for group, ss in obs.groupby("group"):
        s = ss.sort_values("maze_seconds")
        x = pd.to_numeric(s["maze_seconds"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(s["cum_mean"], errors="coerce").to_numpy(dtype=float)
        c = _color_for(str(group))
        ax.plot(x, y, color=c, lw=2.4, label=f"{group} observed")
    ls_map = {"linear": "-", "exponential": "--", "power_law": ":"}
    if not ol.empty and {"group", "model", "maze_seconds", "pred_cum"}.issubset(set(ol.columns)):
        for (group, model), ss in ol.groupby(["group", "model"]):
            s = ss.sort_values("maze_seconds")
            x = pd.to_numeric(s["maze_seconds"], errors="coerce").to_numpy(dtype=float)
            y = pd.to_numeric(s["pred_cum"], errors="coerce").to_numpy(dtype=float)
            ax.plot(
                x,
                y,
                color=_color_for(str(group)),
                ls=ls_map.get(str(model), "-."),
                lw=1.3,
                alpha=0.8,
                label=f"{group} {model}",
            )
    ax.set_title(title)
    ax.set_xlabel("Maze time (s)")
    ax.set_ylabel("Cumulative count")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=7, ncol=2)
    return _save(fig, out_path)


def _plot_conversion_curve(conversion_curve: pd.DataFrame, out_path: Path) -> str:
    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    req = {"group", "time_bin_start", "conversion_mean", "conversion_ci_low", "conversion_ci_high"}
    if conversion_curve is None or conversion_curve.empty or not req.issubset(set(conversion_curve.columns)):
        ax.text(0.5, 0.5, "No conversion data", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
        return _save(fig, out_path)
    for group, ss in conversion_curve.groupby("group"):
        s = ss.sort_values("time_bin_start")
        x = pd.to_numeric(s["time_bin_start"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(s["conversion_mean"], errors="coerce").to_numpy(dtype=float)
        lo = pd.to_numeric(s["conversion_ci_low"], errors="coerce").to_numpy(dtype=float)
        hi = pd.to_numeric(s["conversion_ci_high"], errors="coerce").to_numpy(dtype=float)
        c = _color_for(str(group))
        ax.plot(x, y, color=c, lw=2, label=str(group))
        ax.fill_between(x, lo, hi, color=c, alpha=0.2, linewidth=0)
    ax.set_title("Reward per long-path conversion over time")
    ax.set_xlabel("Maze time bin start (s)")
    ax.set_ylabel("Reward / long-path")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=8)
    return _save(fig, out_path)


def _plot_mode_fractions(mode_curve: pd.DataFrame, out_path: Path) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 4.2), sharex=True)
    req = {"group", "metric", "time_bin_start", "mean", "ci_low", "ci_high"}
    if mode_curve is None or mode_curve.empty or not req.issubset(set(mode_curve.columns)):
        for ax in axes:
            ax.text(0.5, 0.5, "No mode-fraction data", ha="center", va="center", transform=ax.transAxes)
            ax.set_axis_off()
        return _save(fig, out_path)
    map_title = {"mode_leave": "Leave", "mode_drink": "Drink", "mode_explore": "Explore"}
    for ax, metric in zip(axes, ["mode_leave", "mode_drink", "mode_explore"]):
        sub = mode_curve.loc[mode_curve["metric"] == metric].copy()
        for group, ss in sub.groupby("group"):
            s = ss.sort_values("time_bin_start")
            x = pd.to_numeric(s["time_bin_start"], errors="coerce").to_numpy(dtype=float)
            y = pd.to_numeric(s["mean"], errors="coerce").to_numpy(dtype=float)
            lo = pd.to_numeric(s["ci_low"], errors="coerce").to_numpy(dtype=float)
            hi = pd.to_numeric(s["ci_high"], errors="coerce").to_numpy(dtype=float)
            c = _color_for(str(group))
            ax.plot(x, y, color=c, lw=2, label=str(group))
            ax.fill_between(x, lo, hi, color=c, alpha=0.2, linewidth=0)
        ax.set_title(map_title[metric])
        ax.set_xlabel("Maze time bin start (s)")
        ax.set_ylim(-0.03, 1.03)
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Fraction of mode time")
    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        axes[0].legend(handles[:2], labels[:2], frameon=False, fontsize=8)
    return _save(fig, out_path)


def _plot_mechanism_forest(mechanism_table: pd.DataFrame, out_path: Path) -> str:
    if mechanism_table is None or mechanism_table.empty or not {"rank_score", "delta_of_deltas", "ci_low", "ci_high", "metric"}.issubset(
        set(mechanism_table.columns)
    ):
        fig, ax = plt.subplots(figsize=(8.6, 4.6))
        ax.text(0.5, 0.5, "No mechanism table", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
        return _save(fig, out_path)
    top = mechanism_table.sort_values("rank_score", ascending=False).head(12).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8.6, max(4.5, 0.44 * len(top) + 1.2)))
    y = np.arange(len(top))
    x = pd.to_numeric(top["delta_of_deltas"], errors="coerce").to_numpy(dtype=float)
    lo = pd.to_numeric(top["ci_low"], errors="coerce").to_numpy(dtype=float)
    hi = pd.to_numeric(top["ci_high"], errors="coerce").to_numpy(dtype=float)
    err = np.vstack([x - lo, hi - x])
    ax.errorbar(x, y, xerr=err, fmt="o", color="#2f2f2f", ecolor="#666666", capsize=2)
    ax.axvline(0, color="k", lw=1.2, ls="--")
    ax.set_yticks(y, top["metric"].tolist())
    ax.set_xlabel("Delta-of-deltas (group A minus group B)")
    ax.set_title("Mechanism effect ranking")
    ax.grid(alpha=0.2, axis="x")
    return _save(fig, out_path)


def _plot_policy_choice_panels(session_metric_table: pd.DataFrame, config: ComparisonConfig, out_path: Path) -> str:
    fig, axes = plt.subplots(2, 3, figsize=(12.5, 7.2))
    metrics = [
        "outer_inner_preference",
        "bias_in_left",
        "bias_in_right",
        "bias_out_left",
        "bias_out_right",
    ]
    groups = [config.group_a_name, config.group_b_name]
    for ax, metric in zip(axes.ravel(), metrics):
        for gi, g in enumerate(groups):
            sub = session_metric_table.loc[session_metric_table["group"] == g]
            y_pre = pd.to_numeric(sub.get(f"{metric}_pre", np.nan), errors="coerce").to_numpy(dtype=float)
            y_post = pd.to_numeric(sub.get(f"{metric}_post", np.nan), errors="coerce").to_numpy(dtype=float)
            y_pre = y_pre[np.isfinite(y_pre)]
            y_post = y_post[np.isfinite(y_post)]
            if y_pre.size:
                ax.scatter(np.full(y_pre.size, gi * 2 + 0), y_pre, color=_color_for(g), alpha=0.45, s=18)
                ax.plot([gi * 2 - 0.15, gi * 2 + 0.15], [np.nanmedian(y_pre), np.nanmedian(y_pre)], color="k", lw=2)
            if y_post.size:
                ax.scatter(np.full(y_post.size, gi * 2 + 1), y_post, color=_color_for(g), alpha=0.9, s=22)
                ax.plot([gi * 2 + 0.85, gi * 2 + 1.15], [np.nanmedian(y_post), np.nanmedian(y_post)], color="k", lw=2)
        ax.set_xticks([0, 1, 2, 3], [f"{groups[0]} pre", f"{groups[0]} post", f"{groups[1]} pre", f"{groups[1]} post"], rotation=20, ha="right")
        ax.set_title(metric)
        ax.grid(alpha=0.2)
    axes.ravel()[-1].axis("off")
    fig.suptitle("Policy and choice metrics (pre vs post breakpoint)", y=1.02)
    return _save(fig, out_path)


def _plot_qc(validation_table: pd.DataFrame, regen_qc: pd.DataFrame, session_qc: pd.DataFrame, out_path: Path) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))
    if not validation_table.empty:
        ax = axes[0]
        vals = {
            "day2_port2_ok": int(np.sum(validation_table["day2_reward_ok"] == True)),  # noqa: E712
            "day1_no_reward_ok": int(np.sum(validation_table["day1_no_reward_ok"] == True)),  # noqa: E712
            "total_sessions": int(len(validation_table)),
        }
        ax.bar(range(len(vals)), list(vals.values()), color=["#4caf50", "#2196f3", "#9e9e9e"])
        ax.set_xticks(range(len(vals)), list(vals.keys()), rotation=20, ha="right")
        ax.set_title("Session context checks")
    if not regen_qc.empty:
        ax = axes[1]
        vals = {
            "regen_attempted": int(np.sum(regen_qc["attempted_regen"] == True)),  # noqa: E712
            "regen_ok": int(np.sum(regen_qc["regen_ok"] == True)),  # noqa: E712
            "regen_fail": int(np.sum(regen_qc["attempted_regen"] == True) - np.sum(regen_qc["regen_ok"] == True)),  # noqa: E712
        }
        ax.bar(range(len(vals)), list(vals.values()), color=["#ffb300", "#43a047", "#e53935"])
        ax.set_xticks(range(len(vals)), list(vals.keys()), rotation=20, ha="right")
        ax.set_title("Selected-data regeneration")
    if not session_qc.empty:
        ax = axes[2]
        vals = {
            "loaded": int(np.sum(session_qc["load_ok"] == True)),  # noqa: E712
            "load_failed": int(np.sum(session_qc["load_ok"] == False)),  # noqa: E712
        }
        ax.bar(range(len(vals)), list(vals.values()), color=["#2e7d32", "#d32f2f"])
        ax.set_xticks(range(len(vals)), list(vals.keys()), rotation=20, ha="right")
        ax.set_title("Trajectory inclusion")
    for ax in axes:
        ax.grid(alpha=0.2, axis="y")
    fig.suptitle("QC inclusion and missingness")
    return _save(fig, out_path)


def export_summary_figures(
    result: dict[str, Any],
    config: ComparisonConfig,
    fig_dir: str | Path,
) -> dict[str, str]:
    fig_dir = _ensure_dir(fig_dir)
    t_break = float(result.get("breakpoint", {}).get("t_break", np.nan))
    curve_group = result.get("curve_group", pd.DataFrame())
    growth_overlay = result.get("growth_overlay", pd.DataFrame())

    manifest: dict[str, str] = {}
    manifest["fig01_cumulative_rewards_with_breakpoint"] = _plot_cumulative(
        curve_group,
        config,
        "reward",
        "Cumulative rewards with breakpoint",
        t_break,
        fig_dir / "fig01_cumulative_rewards_with_breakpoint.png",
    )
    manifest["fig02_cumulative_long_paths_rewardnode94_with_breakpoint"] = _plot_cumulative(
        curve_group,
        config,
        "long_path_reward",
        "Cumulative long-path rewards to node 94",
        t_break,
        fig_dir / "fig02_cumulative_long_paths_rewardnode94_with_breakpoint.png",
    )
    manifest["fig03_early_equivalence_rates"] = _plot_early_equivalence(
        result.get("early_rate_table", pd.DataFrame()),
        result.get("ratio_reward", pd.DataFrame()),
        result.get("ratio_long", pd.DataFrame()),
        config,
        fig_dir / "fig03_early_equivalence_rates.png",
    )
    manifest["fig04_growth_model_comparison_rewards"] = _plot_growth_models(
        curve_group,
        growth_overlay,
        "reward",
        "Growth-model comparison: rewards",
        fig_dir / "fig04_growth_model_comparison_rewards.png",
    )
    manifest["fig05_growth_model_comparison_longpaths"] = _plot_growth_models(
        curve_group,
        growth_overlay,
        "long_path_reward",
        "Growth-model comparison: long paths",
        fig_dir / "fig05_growth_model_comparison_longpaths.png",
    )
    manifest["fig06_reward_per_longpath_conversion_over_time"] = _plot_conversion_curve(
        result.get("conversion_curve", pd.DataFrame()),
        fig_dir / "fig06_reward_per_longpath_conversion_over_time.png",
    )
    manifest["fig07_mode_fraction_trajectories"] = _plot_mode_fractions(
        result.get("mode_curve", pd.DataFrame()),
        fig_dir / "fig07_mode_fraction_trajectories.png",
    )
    manifest["fig08_mechanism_effect_rank_forest"] = _plot_mechanism_forest(
        result.get("mechanism_table", pd.DataFrame()),
        fig_dir / "fig08_mechanism_effect_rank_forest.png",
    )
    manifest["fig09_policy_and_choice_panels"] = _plot_policy_choice_panels(
        result.get("session_metric_table", pd.DataFrame()),
        config,
        fig_dir / "fig09_policy_and_choice_panels.png",
    )
    manifest["fig10_qc_inclusion_and_missingness"] = _plot_qc(
        result.get("validation_table", pd.DataFrame()),
        result.get("regen_qc", pd.DataFrame()),
        result.get("session_qc", pd.DataFrame()),
        fig_dir / "fig10_qc_inclusion_and_missingness.png",
    )
    return manifest


__all__ = ["export_summary_figures"]
