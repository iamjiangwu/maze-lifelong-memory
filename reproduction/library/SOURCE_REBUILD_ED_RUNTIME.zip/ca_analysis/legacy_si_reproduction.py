from __future__ import annotations

import math
import os
from pathlib import Path
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .behavior import default_behavior_groups_260113
from .group_series_plotting_utils import compute_group_series_averages, summarize_group_series_curve
from .io import load_behav_neural
from .maze import NewMaze
from .mode_analysis import MODE_DRINK, MODE_EXPLORE, MODE_LEAVE, split_mode_clips
from .similarity import pivot_window_spatial_information_fast
from .trajectory import LoadTraj


LEGACY_METHOD = "interpolate_then_average"
LEGACY_MIN_TIME_POLICY = "scaled_nonoverlap"
LEGACY_SPATIAL_BINS = "15x15"


def _truthy(value) -> bool:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    text = str(value).strip().lower()
    return text in {"1", "true", "yes", "y", "t"}


def normalize_group_name(name: str) -> str:
    text = str(name).strip()
    normalized = text.replace(" ", "")
    if normalized.startswith("RewardedDay1"):
        return "Rewarded Day1"
    if normalized.startswith("UnrewardedDay1"):
        return "Unrewarded Day1"
    return text


def load_legacy_group_audit(path: str | Path) -> tuple[pd.DataFrame, dict[str, list[str]]]:
    audit = pd.read_csv(path).copy()
    audit["group_norm"] = audit["group"].map(normalize_group_name)
    audit["included_bool"] = audit["included"].map(_truthy)
    groups: dict[str, list[str]] = {}
    for group_name, sub in audit.loc[audit["included_bool"]].groupby("group_norm", sort=True):
        groups[str(group_name)] = [str(v) for v in sub["session_id"].tolist()]
    return audit, groups


def load_current_day1_groups() -> dict[str, list[str]]:
    groups = default_behavior_groups_260113()
    out: dict[str, list[str]] = {}
    for key in ("RewardedDay1", "UnrewardedDay1"):
        if key not in groups:
            continue
        norm = normalize_group_name(key)
        out.setdefault(norm, [])
        out[norm].extend([str(v) for v in groups[key]])
    for key in list(out.keys()):
        deduped = []
        seen = set()
        for session_id in out[key]:
            if session_id in seen:
                continue
            seen.add(session_id)
            deduped.append(session_id)
        out[key] = deduped
    return out


def scaled_nonoverlap_min_time_sec(
    n_selected_rows: int,
    window_steps: int,
    *,
    base_min_time_sec: float = 5.0,
) -> float:
    n_rows = max(int(n_selected_rows), 0)
    window_steps = max(int(window_steps), 1)
    n_nonoverlap_windows = max(1, int(math.floor(float(n_rows) / float(window_steps))))
    return float(base_min_time_sec) / float(n_nonoverlap_windows)


def label_selected_frames_by_mode(tr, ma_obj, frame_selected, *, include_reward_mode: bool):
    if tr is None:
        raise RuntimeError("Missing trajectory object from load_behav_neural; cannot compute mode clips.")
    clips = np.asarray(split_mode_clips(tr, ma_obj, include_reward=bool(include_reward_mode)), dtype=int)
    if clips.size == 0:
        raise RuntimeError("No mode clips were produced for trajectory.")
    if clips.ndim != 2 or clips.shape[1] < 4:
        raise RuntimeError("Invalid SplitModeClips output shape.")

    frame_selected = np.asarray(frame_selected, dtype=int)
    if frame_selected.size == 0:
        raise RuntimeError("No selected frames available for mode labeling.")

    order = np.argsort(frame_selected)
    frame_sorted = frame_selected[order]
    mode_sorted = np.full(frame_sorted.shape, -1, dtype=np.int8)

    no = getattr(tr, "no", [])
    fr = np.asarray(getattr(tr, "fr", []), dtype=int)
    n_invalid_segments = 0
    n_overlap_assignments = 0
    n_transition_points = 0

    for clip in clips:
        bout = int(clip[0])
        start = int(clip[1])
        nstep = int(clip[2])
        mode = int(clip[3])
        if bout < 0 or bout >= len(no):
            n_invalid_segments += 1
            continue
        bout_arr = np.asarray(no[bout])
        if bout_arr.ndim != 2 or bout_arr.shape[1] < 2 or nstep <= 0:
            n_invalid_segments += 1
            continue
        frame_offset = int(fr[bout, 0]) if fr.ndim == 2 and fr.shape[1] >= 1 and bout < fr.shape[0] else 0
        bout_frames = bout_arr[:, 1].astype(int, copy=False) + frame_offset
        i0 = max(0, int(start))
        i1 = min(int(start) + int(nstep), int(bout_frames.size - 1))
        if i1 <= i0:
            continue
        n_transition_points += int(i1 - i0)
        for i in range(i0, i1):
            a = int(bout_frames[i])
            z = int(bout_frames[i + 1])
            if z <= a:
                continue
            l = int(np.searchsorted(frame_sorted, a, side="left"))
            r = int(np.searchsorted(frame_sorted, z, side="left"))
            if r <= l:
                continue
            prev = mode_sorted[l:r]
            n_overlap_assignments += int(np.sum(prev != -1))
            mode_sorted[l:r] = np.int8(mode)

    mode_selected = np.full(frame_selected.shape, -1, dtype=np.int8)
    mode_selected[order] = mode_sorted
    mode_counts = {
        "leave": int(np.sum(mode_selected == int(MODE_LEAVE))),
        "drink": int(np.sum(mode_selected == int(MODE_DRINK))),
        "explore": int(np.sum(mode_selected == int(MODE_EXPLORE))),
        "unknown": int(np.sum(mode_selected < 0)),
    }
    mode_meta = {
        "n_clips": int(clips.shape[0]),
        "n_transition_points": int(n_transition_points),
        "n_overlap_assignments": int(n_overlap_assignments),
        "n_invalid_segments": int(n_invalid_segments),
    }
    return mode_selected, mode_counts, mode_meta


def _drop_nan_rows_using_c(df: pd.DataFrame, c) -> tuple[pd.DataFrame, int]:
    n_drop_nan = 0
    if c is not None:
        nan_idx = np.where(np.isnan(c.T))[0]
        if nan_idx.size:
            keep = ~df["frame"].isin(nan_idx)
            n_drop_nan = int((~keep).sum())
            df = df.loc[keep].reset_index(drop=True)
    return df, n_drop_nan


def load_single_session_subset(
    session_id: str,
    *,
    is_unrewarded: bool,
    ma_obj,
    behav_wd,
    neural_wd,
    mode_filter: str = "explore",
):
    tr, df, _, c_raw, c, s_arr, _ = load_behav_neural(
        session_id,
        behav_wd=behav_wd,
        neural_wd=neural_wd,
    )
    if tr is None:
        if not os.environ.get("CA_TRAJ_EXTRA_ROOT"):
            candidate_root = Path(behav_wd) / "github_clean_repo"
            if candidate_root.exists():
                os.environ["CA_TRAJ_EXTRA_ROOT"] = str(candidate_root)
        try:
            tr = LoadTraj(f"{session_id}-tf")
        except Exception:
            tr = None
    if s_arr is None:
        raise RuntimeError("missing_S")
    if c is None and c_raw is None:
        raise RuntimeError(f"Missing C/C_raw matrix for session '{session_id}'.")
    if "frame" not in df.columns:
        raise RuntimeError(f"Session '{session_id}' selected_df missing 'frame'.")
    if not {"mass_x", "mass_y"}.issubset(df.columns):
        raise RuntimeError(f"Session '{session_id}' selected_df missing mass_x/mass_y.")
    if "maze_time" not in df.columns:
        raise RuntimeError(f"Session '{session_id}' selected_df missing 'maze_time'.")

    n_rows_in = int(len(df))
    df, n_drop_nan = _drop_nan_rows_using_c(df, c)

    frame = df["frame"].to_numpy(dtype=int)
    c_src = c if c is not None else c_raw
    fmax = min(int(s_arr.shape[1]), int(c_src.shape[1]))
    good = (frame >= 0) & (frame < fmax)
    n_drop_oob = int((~good).sum())
    df = df.loc[good].reset_index(drop=True)
    frame = df["frame"].to_numpy(dtype=int)

    sp_sel = s_arr.T[frame]
    rc_full = c.T if c is not None else c_raw.T
    if frame.size and frame.max() >= rc_full.shape[0] and frame.max() < rc_full.shape[1]:
        rc_full = rc_full.T
    rc_sel = rc_full[frame]

    n_neurons = min(int(sp_sel.shape[1]), int(rc_sel.shape[1]))
    sp_sel = sp_sel[:, :n_neurons]
    rc_sel = rc_sel[:, :n_neurons]

    include_reward_mode = not bool(is_unrewarded)
    mode_selected = np.full(frame.shape, -1, dtype=np.int8)
    mode_counts = {"leave": 0, "drink": 0, "explore": 0, "unknown": int(frame.size)}
    mode_meta = {
        "n_clips": 0,
        "n_transition_points": 0,
        "n_overlap_assignments": 0,
        "n_invalid_segments": 0,
    }
    if mode_filter == "explore":
        mode_selected, mode_counts, mode_meta = label_selected_frames_by_mode(
            tr,
            ma_obj,
            frame,
            include_reward_mode=include_reward_mode,
        )
        mask = mode_selected == int(MODE_EXPLORE)
        if int(np.sum(mask)) == 0:
            raise RuntimeError("No explore-mode rows after interval-expanded mode labeling.")
    elif mode_filter == "all":
        mask = np.ones(frame.shape, dtype=bool)
    else:
        raise ValueError("mode_filter must be 'explore' or 'all'.")

    df_use = df.loc[mask].reset_index(drop=True)
    sp_use = sp_sel[mask]
    rc_use = rc_sel[mask]
    pos_use = df_use[["mass_x", "mass_y"]].to_numpy(dtype=float)

    meta = {
        "session_id": str(session_id),
        "is_unrewarded": bool(is_unrewarded),
        "mode_filter": str(mode_filter),
        "include_reward_mode": bool(include_reward_mode),
        "n_rows_in": n_rows_in,
        "n_rows_after_nan_drop": int(len(frame)),
        "n_rows_dropped_nan": int(n_drop_nan),
        "n_rows_dropped_oob": int(n_drop_oob),
        "mode_parser": "ca_analysis.mode_analysis.split_mode_clips (interval-expanded to selected_df frames)",
        "mode_counts_selected_rows": mode_counts,
        "mode_labeling_meta": mode_meta,
        "n_rows_with_known_mode": int(mode_counts["leave"] + mode_counts["drink"] + mode_counts["explore"]),
        "explore_fraction_selected_rows": (
            float(mode_counts["explore"] / len(frame)) if len(frame) else np.nan
        ),
        "n_rows_after_mode_filter": int(len(df_use)),
        "n_neurons_final": int(n_neurons),
        "timebase": "step windows mapped to maze_time",
        "continuity_assumption": "selected_df is speed-thresholded (>2 cm/s) and may be discontinuous",
    }
    return sp_use, rc_use, df_use, pos_use, meta


def _selected_df_for_label_mode(df_use: pd.DataFrame, label_mode: str) -> pd.DataFrame:
    if label_mode == "positions":
        drop_cols = [c for c in ("mass_bx", "mass_by") if c in df_use.columns]
        if drop_cols:
            return df_use.drop(columns=drop_cols)
        return df_use
    if label_mode == "maze_bins":
        return df_use
    raise ValueError("label_mode must be 'positions' or 'maze_bins'.")


def compute_session_si_stepcurve(
    sp_use,
    rc_use,
    df_use: pd.DataFrame,
    pos_use,
    *,
    dt: float = 0.04,
    window_steps: int = 4000,
    stride_steps: int = 1000,
    n_bins_x: int = 15,
    n_bins_y: int = 15,
    min_spikes_per_min: float = 0.5,
    prior_mode: str = "empirical",
    min_time_policy: str = LEGACY_MIN_TIME_POLICY,
    base_min_time_per_bin_sec: float = 5.0,
    fixed_min_time_per_bin_sec: float | None = None,
    rate_source: str = "spike",
    label_mode: str = "positions",
    maze_id: int | None = 6,
):
    n_rows = int(len(df_use))
    if n_rows < int(window_steps):
        return {"ok": False, "reason": f"insufficient_rows_for_window: {n_rows} < {int(window_steps)}"}

    if min_time_policy == "scaled_nonoverlap":
        min_time_per_bin_sec = scaled_nonoverlap_min_time_sec(
            n_rows,
            int(window_steps),
            base_min_time_sec=base_min_time_per_bin_sec,
        )
    elif min_time_policy == "fixed":
        if fixed_min_time_per_bin_sec is None:
            min_time_per_bin_sec = float(base_min_time_per_bin_sec)
        else:
            min_time_per_bin_sec = float(fixed_min_time_per_bin_sec)
    else:
        raise ValueError("min_time_policy must be 'scaled_nonoverlap' or 'fixed'.")

    df_for_labels = _selected_df_for_label_mode(df_use, label_mode)
    piv = pivot_window_spatial_information_fast(
        sp_use,
        rc_use,
        df_for_labels,
        pos_use,
        n_bins_x=n_bins_x,
        n_bins_y=n_bins_y,
        dt=dt,
        time_window=0,
        win_len_sec=float(window_steps) * float(dt),
        pivot_step_sec=float(stride_steps) * float(dt),
        pivot_time_axis="selected",
        prior_mode=prior_mode,
        min_time_per_bin_sec=min_time_per_bin_sec,
        min_spikes_per_min=min_spikes_per_min,
        rate_source=rate_source,
        maze_id=maze_id,
    )
    n_windows = int(len(piv["pivot_bounds"]))
    if n_windows == 0:
        return {"ok": False, "reason": "no_valid_windows_after_pivot"}

    si_mean = np.asarray(piv["si_mean"], dtype=float)
    si_std = np.asarray(piv["si_std"], dtype=float)
    window_index = np.arange(n_windows, dtype=int)
    step_mid_rel = window_index.astype(float) * float(stride_steps)
    maze_t = pd.to_numeric(df_use["maze_time"], errors="coerce").to_numpy(dtype=float)
    maze_center = np.full(n_windows, np.nan, dtype=float)
    for i, (s, e) in enumerate(piv["pivot_bounds"]):
        s0 = int(s)
        e0 = int(e)
        if s0 < 0 or e0 <= s0 or e0 > maze_t.size:
            continue
        seg = maze_t[s0:e0]
        seg = seg[np.isfinite(seg)]
        if seg.size:
            maze_center[i] = float(np.nanmedian(seg))
    finite = np.flatnonzero(np.isfinite(maze_center))
    if finite.size == 0:
        return {"ok": False, "reason": "no_finite_maze_time_centers"}
    maze_time_rel = maze_center - float(maze_center[finite[0]])

    return {
        "ok": True,
        "pivot_result": piv,
        "si_mean": si_mean,
        "si_std": si_std,
        "window_index": window_index,
        "step_mid_rel": step_mid_rel,
        "maze_time_rel": maze_time_rel,
        "pivot_bounds": piv["pivot_bounds"],
        "n_windows": n_windows,
        "n_neurons": int(len(piv["kept_neuron_ids"])),
        "min_time_per_bin_sec_used": float(min_time_per_bin_sec),
        "min_time_policy": str(min_time_policy),
        "label_mode": str(label_mode),
        "label_source": str(piv.get("meta", {}).get("label_source", "")),
    }


def compute_session_si_timecurve(
    sp_use,
    rc_use,
    df_use: pd.DataFrame,
    pos_use,
    *,
    dt: float = 0.04,
    window_sec: float = 20 * 60.0,
    step_sec: float = 5 * 60.0,
    n_bins_x: int = 15,
    n_bins_y: int = 15,
    min_spikes_per_min: float = 0.0,
    prior_mode: str = "empirical",
    min_time_policy: str = LEGACY_MIN_TIME_POLICY,
    base_min_time_per_bin_sec: float = 5.0,
    fixed_min_time_per_bin_sec: float | None = None,
    rate_source: str = "spike",
    label_mode: str = "maze_bins",
    pivot_time_axis: str = "maze",
    support_mode: str = "window",
    common_support_frac: float = 1.0,
    maze_id: int | None = 6,
):
    df_for_labels = _selected_df_for_label_mode(df_use, label_mode)
    piv = pivot_window_spatial_information_fast(
        sp_use,
        rc_use,
        df_for_labels,
        pos_use,
        n_bins_x=n_bins_x,
        n_bins_y=n_bins_y,
        dt=dt,
        time_window=0,
        win_len_sec=float(window_sec),
        pivot_step_sec=float(step_sec),
        pivot_time_axis=str(pivot_time_axis),
        prior_mode=prior_mode,
        min_time_per_bin_sec=(
            float(fixed_min_time_per_bin_sec)
            if (str(min_time_policy) == "fixed" and fixed_min_time_per_bin_sec is not None)
            else float(base_min_time_per_bin_sec)
        ),
        min_time_policy=str(min_time_policy),
        min_spikes_per_min=min_spikes_per_min,
        rate_source=rate_source,
        support_mode=support_mode,
        common_support_frac=float(common_support_frac),
        maze_id=maze_id,
    )
    pivot_times = np.asarray(piv.get("pivot_times", np.array([])), dtype=float)
    si_mean = np.asarray(piv.get("si_mean", np.array([])), dtype=float)
    si_std = np.asarray(piv.get("si_std", np.array([])), dtype=float)
    if pivot_times.size == 0:
        return {"ok": False, "reason": "no_valid_windows_after_pivot"}
    finite = np.flatnonzero(np.isfinite(pivot_times))
    if finite.size == 0:
        return {"ok": False, "reason": "no_finite_pivot_times"}
    t_rel = pivot_times - float(pivot_times[finite[0]])
    return {
        "ok": True,
        "pivot_result": piv,
        "si_mean": si_mean,
        "si_std": si_std,
        "maze_time_rel": t_rel,
        "n_windows": int(pivot_times.size),
        "n_neurons": int(len(piv.get("kept_neuron_ids", []))),
        "label_mode": str(label_mode),
        "label_source": str(piv.get("meta", {}).get("label_source", "")),
        "min_time_per_bin_sec_used": float(
            piv.get("meta", {}).get(
                "effective_min_time_per_bin_sec",
                fixed_min_time_per_bin_sec if fixed_min_time_per_bin_sec is not None else base_min_time_per_bin_sec,
            )
        ),
        "min_time_policy": str(piv.get("meta", {}).get("min_time_policy", min_time_policy)),
    }


def compute_group_session_curves(
    group_to_sessions: dict[str, list[str]],
    *,
    behav_wd,
    neural_wd,
    ma_obj=None,
    mode_filter: str = "explore",
    dt: float = 0.04,
    window_steps: int = 4000,
    stride_steps: int = 1000,
    window_sec: float | None = None,
    step_sec: float | None = None,
    pivot_style: str = "step",
    n_bins_x: int = 15,
    n_bins_y: int = 15,
    min_spikes_per_min: float = 0.5,
    prior_mode: str = "empirical",
    min_time_policy: str = LEGACY_MIN_TIME_POLICY,
    base_min_time_per_bin_sec: float = 5.0,
    fixed_min_time_per_bin_sec: float | None = None,
    rate_source: str = "spike",
    label_mode: str = "positions",
    pivot_time_axis: str = "maze",
    support_mode: str = "window",
    common_support_frac: float = 1.0,
    maze_id: int | None = 6,
    log_fn=None,
    session_subset_cache: dict | None = None,
):
    if ma_obj is None:
        ma_obj = NewMaze(int(maze_id) if maze_id is not None else 6)

    session_curves: dict[str, list[dict]] = {}
    excluded_rows: list[dict] = []
    summary_rows: list[dict] = []

    for group_name, sessions in group_to_sessions.items():
        group_norm = normalize_group_name(group_name)
        is_unrewarded = group_norm == "Unrewarded Day1"
        session_curves[group_norm] = []
        requested = int(len(sessions))
        for session_id in sessions:
            sid = str(session_id)
            try:
                if log_fn is not None:
                    log_fn(f"  loading {group_norm} :: {sid}")
                subset_key = (sid, bool(is_unrewarded), str(mode_filter))
                if session_subset_cache is not None and subset_key in session_subset_cache:
                    sp_use, rc_use, df_use, pos_use, load_meta = session_subset_cache[subset_key]
                else:
                    sp_use, rc_use, df_use, pos_use, load_meta = load_single_session_subset(
                        sid,
                        is_unrewarded=is_unrewarded,
                        ma_obj=ma_obj,
                        behav_wd=behav_wd,
                        neural_wd=neural_wd,
                        mode_filter=mode_filter,
                    )
                    if session_subset_cache is not None:
                        session_subset_cache[subset_key] = (sp_use, rc_use, df_use, pos_use, load_meta)
                if pivot_style == "step":
                    sess = compute_session_si_stepcurve(
                        sp_use,
                        rc_use,
                        df_use,
                        pos_use,
                        dt=dt,
                        window_steps=window_steps,
                        stride_steps=stride_steps,
                        n_bins_x=n_bins_x,
                        n_bins_y=n_bins_y,
                        min_spikes_per_min=min_spikes_per_min,
                        prior_mode=prior_mode,
                        min_time_policy=min_time_policy,
                        base_min_time_per_bin_sec=base_min_time_per_bin_sec,
                        fixed_min_time_per_bin_sec=fixed_min_time_per_bin_sec,
                        rate_source=rate_source,
                        label_mode=label_mode,
                        maze_id=maze_id,
                    )
                elif pivot_style == "time":
                    if window_sec is None or step_sec is None:
                        raise ValueError("window_sec and step_sec are required for pivot_style='time'.")
                    sess = compute_session_si_timecurve(
                        sp_use,
                        rc_use,
                        df_use,
                        pos_use,
                        dt=dt,
                        window_sec=window_sec,
                        step_sec=step_sec,
                        n_bins_x=n_bins_x,
                        n_bins_y=n_bins_y,
                        min_spikes_per_min=min_spikes_per_min,
                        prior_mode=prior_mode,
                        min_time_policy=min_time_policy,
                        base_min_time_per_bin_sec=base_min_time_per_bin_sec,
                        fixed_min_time_per_bin_sec=fixed_min_time_per_bin_sec,
                        rate_source=rate_source,
                        label_mode=label_mode,
                        pivot_time_axis=pivot_time_axis,
                        support_mode=support_mode,
                        common_support_frac=common_support_frac,
                        maze_id=maze_id,
                    )
                else:
                    raise ValueError("pivot_style must be 'step' or 'time'.")
                if not bool(sess.get("ok", False)):
                    raise RuntimeError(str(sess.get("reason", "unknown_curve_failure")))
                session_curves[group_norm].append(
                    {
                        "session_id": sid,
                        "si_mean": np.asarray(sess["si_mean"], dtype=float),
                        "si_std": np.asarray(sess["si_std"], dtype=float),
                        "maze_time_rel": np.asarray(sess["maze_time_rel"], dtype=float),
                        "n_windows": int(sess["n_windows"]),
                        "n_neurons": int(sess["n_neurons"]),
                        "load_meta": load_meta,
                        "min_time_per_bin_sec_used": float(sess.get("min_time_per_bin_sec_used", np.nan)),
                        "min_time_policy": str(sess.get("min_time_policy", min_time_policy)),
                        "label_mode": str(sess.get("label_mode", label_mode)),
                        "label_source": str(sess.get("label_source", "")),
                    }
                )
                if log_fn is not None:
                    log_fn(
                        f"  included {group_norm} :: {sid} "
                        f"(windows={int(sess['n_windows'])}, neurons={int(sess['n_neurons'])})"
                    )
            except Exception as exc:
                if log_fn is not None:
                    log_fn(f"  excluded {group_norm} :: {sid} :: {exc}")
                excluded_rows.append(
                    {
                        "group": group_norm,
                        "session_id": sid,
                        "reason": str(exc),
                        "is_unrewarded": bool(is_unrewarded),
                        "mode_filter": str(mode_filter),
                        "label_mode": str(label_mode),
                    }
                )

        included = int(len(session_curves[group_norm]))
        summary_rows.append(
            {
                "group": group_norm,
                "requested_sessions": requested,
                "included_sessions": included,
                "excluded_sessions": requested - included,
                "is_unrewarded": bool(is_unrewarded),
                "mode_filter": str(mode_filter),
                "label_mode": str(label_mode),
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    excluded_df = pd.DataFrame(excluded_rows)
    alignment_report = {
        "session_matching_source": "input_group_mapping",
        "representation_space": (
            "2D raw position (mass_x, mass_y; 15x15)"
            if label_mode == "positions"
            else "2D maze-binned position (mass_bx, mass_by; 15x15)"
        ),
        "timebase": (
            "maze_time mapped from per-window medians" if pivot_style == "step" else f"{pivot_time_axis} pivot axis"
        ),
        "continuity_assumption": "selected_df is speed-thresholded (>2 cm/s) and may be discontinuous",
        "summary_by_group": summary_df.to_dict(orient="records"),
        "excluded_sessions": excluded_df.to_dict(orient="records"),
    }
    return {
        "session_curves": session_curves,
        "summary_df": summary_df,
        "excluded_df": excluded_df,
        "alignment_report": alignment_report,
    }


def interpolate_then_average_group_curves(
    session_curves: dict[str, list[dict]],
    *,
    grid_dt_sec: float,
    min_support_count: int = 3,
):
    rows: list[dict] = []
    summary_rows: list[dict] = []
    group_tables: dict[str, pd.DataFrame] = {}

    for group_name, curves in session_curves.items():
        usable = []
        for curve in curves:
            t = pd.to_numeric(np.asarray(curve.get("maze_time_rel", np.array([]))), errors="coerce").astype(float)
            y = pd.to_numeric(np.asarray(curve.get("si_mean", np.array([]))), errors="coerce").astype(float)
            mask = np.isfinite(t) & np.isfinite(y)
            t = t[mask]
            y = y[mask]
            if t.size < 2:
                continue
            order = np.argsort(t)
            t = t[order]
            y = y[order]
            uniq, idx = np.unique(t, return_index=True)
            t = uniq
            y = y[idx]
            if t.size < 2:
                continue
            usable.append((curve["session_id"], t, y))

        if not usable:
            group_tables[group_name] = pd.DataFrame(
                columns=["group", "maze_time_rel_sec", "maze_time_rel_min", "mean_si", "sem_si", "n"]
            )
            summary_rows.append(
                {
                    "group": str(group_name),
                    "n_sessions_used": 0,
                    "n_curve_points": 0,
                    "slope_all": np.nan,
                }
            )
            continue

        t0 = min(float(t[0]) for _, t, _ in usable)
        t1 = max(float(t[-1]) for _, t, _ in usable)
        grid = np.arange(float(t0), float(t1) + float(grid_dt_sec) + 1e-9, float(grid_dt_sec), dtype=float)
        mat = np.full((len(usable), grid.size), np.nan, dtype=float)
        for row_i, (_, t, y) in enumerate(usable):
            mat[row_i] = np.interp(grid, t, y, left=np.nan, right=np.nan)
        n = np.sum(np.isfinite(mat), axis=0).astype(int)
        with np.errstate(invalid="ignore", divide="ignore"):
            mean_si = np.nanmean(mat, axis=0)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                sem_si = np.nanstd(mat, axis=0, ddof=1) / np.sqrt(np.maximum(n, 1))
        sem_si[n <= 1] = 0.0
        support_mask = n >= int(min_support_count)
        mean_masked = np.where(support_mask, mean_si, np.nan)
        sem_masked = np.where(support_mask, sem_si, np.nan)
        group_df = pd.DataFrame(
            {
                "group": str(group_name),
                "maze_time_rel_sec": grid,
                "maze_time_rel_min": grid / 60.0,
                "mean_si": mean_masked,
                "sem_si": sem_masked,
                "n": n.astype(int),
            }
        )
        supported_df = group_df.loc[support_mask].reset_index(drop=True)
        group_tables[group_name] = supported_df
        rows.extend(supported_df.to_dict(orient="records"))
        finite_mean = np.isfinite(supported_df["mean_si"].to_numpy(dtype=float))
        if supported_df.empty or not np.any(finite_mean):
            slope = np.nan
        else:
            x = supported_df.loc[finite_mean, "maze_time_rel_sec"].to_numpy(dtype=float)
            y = supported_df.loc[finite_mean, "mean_si"].to_numpy(dtype=float)
            x_center = x - float(np.mean(x))
            denom = float(np.sum(x_center**2))
            slope = np.nan if denom <= 0 else float(np.sum(x_center * (y - float(np.mean(y)))) / denom)
        summary_rows.append(
            {
                "group": str(group_name),
                "n_sessions_used": int(len(usable)),
                "n_curve_points": int(len(supported_df)),
                "slope_all": slope,
            }
        )

    curves_df = pd.DataFrame(rows)
    summary_df = pd.DataFrame(summary_rows)
    return {
        "curves_df": curves_df,
        "summary_df": summary_df,
        "group_tables": group_tables,
    }


def support_aware_group_summary(
    session_curves: dict[str, list[dict]],
    *,
    grid_dt_sec: float,
    min_support_frac: float = 0.5,
    min_support_count: int = 3,
    max_time_sec: float | None = 120 * 60.0,
):
    curve_rows = []
    summary_rows = []
    for group_name, curves in session_curves.items():
        loaded = {
            str(group_name): {
                str(curve["session_id"]): {
                    "t": np.asarray(curve["maze_time_rel"], dtype=float),
                    "y": np.asarray(curve["si_mean"], dtype=float),
                }
                for curve in curves
            }
        }
        stats = compute_group_series_averages(
            loaded,
            series_getter=lambda obj: (obj["t"], obj["y"]),
            window="union",
            how="mean",
            error="sem",
            grid_dt=float(grid_dt_sec),
        )
        curve_stats = stats.get(str(group_name), {})
        summary = summarize_group_series_curve(
            curve_stats,
            n_subjects_total=int(len(curves)),
            min_support_frac=float(min_support_frac),
            min_support_count=int(min_support_count),
            max_time=max_time_sec,
        )
        t_grid = np.asarray(curve_stats.get("t_grid", np.array([])), dtype=float)
        center = np.asarray(curve_stats.get("center", np.array([])), dtype=float)
        err = np.asarray(curve_stats.get("error", np.array([])), dtype=float)
        n = np.asarray(curve_stats.get("n", np.array([])), dtype=float)
        support_required = int(summary["support_count_required"])
        support_ok = np.isfinite(n) & (n >= float(support_required))
        within_horizon = support_ok.copy()
        if max_time_sec is not None and np.isfinite(max_time_sec):
            within_horizon &= np.isfinite(t_grid) & (t_grid <= float(max_time_sec))
        curve_rows.append(
            pd.DataFrame(
                {
                    "group": str(group_name),
                    "maze_time_rel_sec": t_grid,
                    "maze_time_rel_min": t_grid / 60.0,
                    "mean_si": center,
                    "sem_si": err,
                    "n": n,
                    "support_ok": support_ok,
                    "within_support_horizon": within_horizon,
                    "support_count_required": int(support_required),
                }
            )
        )
        summary_rows.append({"group": str(group_name), **summary})
    return {
        "curves_df": pd.concat(curve_rows, ignore_index=True) if curve_rows else pd.DataFrame(),
        "summary_df": pd.DataFrame(summary_rows),
    }


def add_legacy_export_columns(
    curves_df: pd.DataFrame,
    summary_df: pd.DataFrame,
    *,
    config_label: str,
    window_steps: int,
    stride_steps: int,
    method: str = LEGACY_METHOD,
    min_time_policy: str = LEGACY_MIN_TIME_POLICY,
    spatial_bins: str = LEGACY_SPATIAL_BINS,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    curves_out = curves_df.copy()
    if not curves_out.empty:
        curves_out.insert(0, "config", str(config_label))
        curves_out["method"] = str(method)
        curves_out["window_steps"] = int(window_steps)
        curves_out["stride_steps"] = int(stride_steps)
        curves_out["spatial_bins"] = str(spatial_bins)
        curves_out["min_time_policy"] = str(min_time_policy)
        curves_out = curves_out[
            [
                "config",
                "group",
                "maze_time_rel_sec",
                "maze_time_rel_min",
                "mean_si",
                "sem_si",
                "n",
                "method",
                "window_steps",
                "stride_steps",
                "spatial_bins",
                "min_time_policy",
            ]
        ]
    summary_out = summary_df.copy()
    if not summary_out.empty:
        summary_out.insert(0, "config", str(config_label))
        summary_out = summary_out[
            ["config", "group", "n_sessions_used", "n_curve_points", "slope_all"]
        ]
    return curves_out, summary_out


def plot_legacy_group_curves(
    curves_df: pd.DataFrame,
    *,
    out_path: str | Path,
    config_order: tuple[str, ...] = ("w4000_s1000", "w8000_s1000"),
) -> None:
    if curves_df.empty:
        raise ValueError("curves_df is empty.")
    fig, axes = plt.subplots(len(config_order), 1, figsize=(12, 11), sharex=False)
    if len(config_order) == 1:
        axes = [axes]
    colors = {"Rewarded Day1": "tab:blue", "Unrewarded Day1": "tab:green"}
    for ax, config_label in zip(axes, config_order):
        sub = curves_df.loc[curves_df["config"] == str(config_label)].copy()
        for group_name in ("Rewarded Day1", "Unrewarded Day1"):
            grp = sub.loc[sub["group"] == group_name].copy()
            if grp.empty:
                continue
            x = grp["maze_time_rel_min"].to_numpy(dtype=float)
            y = grp["mean_si"].to_numpy(dtype=float)
            se = grp["sem_si"].to_numpy(dtype=float)
            ax.plot(x, y, label=group_name, color=colors[group_name], linewidth=2.0)
            ax.fill_between(x, y - se, y + se, color=colors[group_name], alpha=0.20)
        ax.set_title(f"{config_label} | {LEGACY_METHOD} | {LEGACY_MIN_TIME_POLICY} min_time")
        ax.set_xlabel("Mapped maze-time (min)")
        ax.set_ylabel("Mean SI (bits/spike)")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="upper left")
    fig.tight_layout()
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
