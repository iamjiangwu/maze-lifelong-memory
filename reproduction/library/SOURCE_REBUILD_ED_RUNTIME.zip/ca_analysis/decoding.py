import numpy as np

from .config import DT, N_BINS_X, N_BINS_Y
from .spatial import discretize_positions, build_count_matrix
from .similarity import compute_tuning_and_prior


def pick_matched_ids(cimap, n_train, n_test):
    if cimap is None:
        k = min(int(n_train), int(n_test))
        return np.arange(k, dtype=int), np.arange(k, dtype=int)
    pairs = np.asarray(cimap, dtype=int)
    # MATLAB maps are 1-based; 0 means mismatch.
    if pairs.size and pairs.min() >= 0:
        pairs = pairs - 1
    good = (
        (pairs[:, 0] >= 0)
        & (pairs[:, 1] >= 0)
        & (pairs[:, 0] < int(n_test))
        & (pairs[:, 1] < int(n_train))
    )
    pairs = pairs[good]
    test_ids = pairs[:, 0].astype(int)
    train_ids = pairs[:, 1].astype(int)
    return train_ids, test_ids


def poisson_decode_train_test(
    counts_train_tn,
    labels_train,
    counts_test_tn,
    *,
    n_bins,
    dt=DT,
    min_time=0.0,
    prior_mode='empirical',
    return_posterior=True,
    batch_size=None,
):
    Xtr = np.asarray(counts_train_tn, dtype=float)
    ytr = np.asarray(labels_train, dtype=int)
    Xte = np.asarray(counts_test_tn, dtype=float)
    if Xtr.ndim != 2 or Xte.ndim != 2:
        raise ValueError('counts must be 2D (T x N)')
    if Xtr.shape[1] != Xte.shape[1]:
        raise ValueError('train/test neuron dimensions must match')
    lam, prior = compute_tuning_and_prior(
        Xtr,
        ytr,
        n_bins=int(n_bins),
        dt=float(dt),
        min_time=float(min_time),
        decode_head='none',
    )
    prior_mode = str(prior_mode).lower()
    if prior_mode in ('empirical', 'occupancy'):
        decode_prior = np.asarray(prior, dtype=float)
    elif prior_mode in ('uniform', 'uniform_occupied', 'flat'):
        occupied = np.asarray(prior, dtype=float) > 0
        decode_prior = np.zeros_like(prior, dtype=float)
        if np.any(occupied):
            decode_prior[occupied] = 1.0 / float(np.sum(occupied))
    else:
        raise ValueError("prior_mode must be 'empirical' or 'uniform'.")
    # lam is in events/sec, while counts are per-bin events.
    # For Poisson decoding use expected counts = lam * dt.
    log_rate = np.log(lam + 1e-12)
    log_offset = (-float(dt) * np.sum(lam, axis=1) + np.log(decode_prior + 1e-12)).astype(float)
    if return_posterior:
        log_post = (log_rate @ Xte.T) + log_offset[:, None]
        pred = np.argmax(log_post, axis=0).astype(int)
    else:
        pred = np.empty(Xte.shape[0], dtype=int)
        if Xte.shape[0] > 0:
            bs = int(batch_size) if batch_size is not None else Xte.shape[0]
            if bs <= 0:
                bs = Xte.shape[0]
            for start in range(0, Xte.shape[0], bs):
                stop = min(start + bs, Xte.shape[0])
                log_post_chunk = (log_rate @ Xte[start:stop].T) + log_offset[:, None]
                pred[start:stop] = np.argmax(log_post_chunk, axis=0).astype(int)
    out = {
        'pred': pred,
        'lam': lam,
        'prior': decode_prior,
        'empirical_prior': prior,
        'prior_mode': prior_mode,
    }
    if return_posterior:
        out['posterior_log'] = log_post
    return out


def prepare_decoding_inputs(
    spike_counts,
    raw_counts,
    selected_df,
    positions,
    *,
    n_bins_x=N_BINS_X,
    n_bins_y=N_BINS_Y,
    time_window=0,
    neuron_ids=None,
):
    pos = np.asarray(positions, dtype=float)
    labels, x_edges, y_edges = discretize_positions(pos, n_bins_x=n_bins_x, n_bins_y=n_bins_y)
    frames = np.arange(len(labels), dtype=int)
    Q = build_count_matrix(
        np.asarray(spike_counts, dtype=float),
        np.asarray(raw_counts, dtype=float),
        selected_df,
        frames=frames,
        time_window=int(time_window),
        neuron_ids=neuron_ids,
    )
    counts_tn = Q.T
    return {
        'labels': labels,
        'counts_tn': counts_tn,
        'x_edges': x_edges,
        'y_edges': y_edges,
        'n_bins': int(n_bins_x * n_bins_y),
        'n_bins_x': int(n_bins_x),
        'n_bins_y': int(n_bins_y),
    }


def evaluate_decoding_errors(
    pred_labels,
    true_labels,
    *,
    n_bins_x=N_BINS_X,
    n_bins_y=N_BINS_Y,
    distance_flat=None,
    near_threshold=None,
    return_confusion=False,
):
    pred = np.asarray(pred_labels, dtype=int)
    true = np.asarray(true_labels, dtype=int)
    m = min(pred.size, true.size)
    pred = pred[:m]
    true = true[:m]

    px = pred % int(n_bins_x)
    py = pred // int(n_bins_x)
    tx = true % int(n_bins_x)
    ty = true // int(n_bins_x)

    dx = px - tx
    dy = py - ty
    euclid = np.sqrt(dx.astype(float) ** 2 + dy.astype(float) ** 2)
    abs_bin_err = np.abs(dx) + np.abs(dy)

    heat = np.full((int(n_bins_y), int(n_bins_x)), np.nan, dtype=float)
    for y in range(int(n_bins_y)):
        for x in range(int(n_bins_x)):
            mask = (tx == x) & (ty == y)
            if np.any(mask):
                heat[y, x] = float(np.nanmean(euclid[mask]))

    out = {
        'euclidean_error': euclid,
        'abs_bin_error': abs_bin_err.astype(float),
        'error_heatmap': heat,
        'median_euclidean_error': float(np.nanmedian(euclid)) if euclid.size else np.nan,
        'mean_euclidean_error': float(np.nanmean(euclid)) if euclid.size else np.nan,
    }
    if return_confusion:
        n_classes = int(n_bins_x) * int(n_bins_y)
        cm = confusion_matrix_int(true, pred, n_classes=n_classes)
        diag = np.diag(cm).astype(float)
        row_sum = cm.sum(axis=1).astype(float)
        diag_frac = np.divide(
            diag,
            row_sum,
            out=np.full(diag.shape, np.nan, dtype=float),
            where=row_sum > 0,
        )
        out["confusion_matrix"] = cm
        out["confusion_diag"] = diag
        out["confusion_diag_fraction"] = diag_frac
        out["mean_confusion_diag_fraction"] = float(np.nanmean(diag_frac)) if diag_frac.size else np.nan

    if distance_flat is not None:
        dist = np.asarray(distance_flat, dtype=float).ravel()
        n_classes = int(n_bins_x) * int(n_bins_y)
        if dist.size != n_classes:
            raise ValueError(
                f"distance_flat must have length {n_classes} for a {int(n_bins_x)}x{int(n_bins_y)} grid; got {dist.size}."
            )
        true_dist = dist[true] if true.size else np.asarray([], dtype=float)
        pred_dist = dist[pred] if pred.size else np.asarray([], dtype=float)
        out["distance_error"] = pred_dist - true_dist
        out["mean_distance_error"] = float(np.nanmean(out["distance_error"])) if true.size else np.nan
        if near_threshold is not None:
            near_threshold = float(near_threshold)
            near_mask = np.isfinite(true_dist) & (true_dist <= near_threshold)
            far_mask = np.isfinite(true_dist) & (true_dist > near_threshold)
            out["near_reward_mean_error"] = float(np.nanmean(euclid[near_mask])) if np.any(near_mask) else np.nan
            out["far_reward_mean_error"] = float(np.nanmean(euclid[far_mask])) if np.any(far_mask) else np.nan
            out["near_reward_mean_distance_error"] = (
                float(np.nanmean(out["distance_error"][near_mask])) if np.any(near_mask) else np.nan
            )
            out["far_reward_mean_distance_error"] = (
                float(np.nanmean(out["distance_error"][far_mask])) if np.any(far_mask) else np.nan
            )
            out["near_reward_accuracy"] = float(np.mean(pred[near_mask] == true[near_mask])) if np.any(near_mask) else np.nan
            out["far_reward_accuracy"] = float(np.mean(pred[far_mask] == true[far_mask])) if np.any(far_mask) else np.nan
            out["attraction_index"] = (
                float(np.nanmean(true_dist - pred_dist)) if np.any(np.isfinite(true_dist) & np.isfinite(pred_dist)) else np.nan
            )
            if return_confusion:
                out["near_reward_mean_diag_fraction"] = (
                    float(np.nanmean(out["confusion_diag_fraction"][dist <= near_threshold]))
                    if np.any(np.isfinite(dist) & (dist <= near_threshold))
                    else np.nan
                )
                out["far_reward_mean_diag_fraction"] = (
                    float(np.nanmean(out["confusion_diag_fraction"][dist > near_threshold]))
                    if np.any(np.isfinite(dist) & (dist > near_threshold))
                    else np.nan
                )
    return out


def label_shuffle_null(
    counts_train_tn,
    labels_train,
    counts_test_tn,
    labels_test,
    *,
    n_bins,
    dt=DT,
    n_repeats=200,
    random_state=0,
):
    Xtr = np.asarray(counts_train_tn, dtype=float)
    ytr = np.asarray(labels_train, dtype=int)
    Xte = np.asarray(counts_test_tn, dtype=float)
    yte = np.asarray(labels_test, dtype=int)
    rng = np.random.RandomState(int(random_state))

    out = np.full(int(n_repeats), np.nan, dtype=float)
    for i in range(int(n_repeats)):
        yperm = rng.permutation(ytr)
        res = poisson_decode_train_test(Xtr, yperm, Xte, n_bins=n_bins, dt=dt)
        pred = res['pred']
        m = min(pred.size, yte.size)
        out[i] = float(np.mean(pred[:m] == yte[:m])) if m else np.nan
    return out


def pair_shuffle_null(
    counts_train_tn,
    labels_train,
    counts_test_tn,
    labels_test,
    *,
    n_bins,
    dt=DT,
    n_repeats=200,
    random_state=0,
):
    Xtr = np.asarray(counts_train_tn, dtype=float)
    ytr = np.asarray(labels_train, dtype=int)
    Xte = np.asarray(counts_test_tn, dtype=float)
    yte = np.asarray(labels_test, dtype=int)
    rng = np.random.RandomState(int(random_state))
    out = np.full(int(n_repeats), np.nan, dtype=float)
    for i in range(int(n_repeats)):
        perm = rng.permutation(Xte.shape[1])
        res = poisson_decode_train_test(Xtr, ytr, Xte[:, perm], n_bins=n_bins, dt=dt)
        pred = res['pred']
        m = min(pred.size, yte.size)
        out[i] = float(np.mean(pred[:m] == yte[:m])) if m else np.nan
    return out


def coarse_partition_from_positions(positions, *, n_bins_x=N_BINS_X, n_bins_y=N_BINS_Y, scheme='quadrant'):
    pos = np.asarray(positions, dtype=float)
    labels, _, _ = discretize_positions(pos, n_bins_x=n_bins_x, n_bins_y=n_bins_y)
    ix = labels % int(n_bins_x)
    iy = labels // int(n_bins_x)

    if scheme == 'quadrant':
        xm = int(n_bins_x) // 2
        ym = int(n_bins_y) // 2
        part = np.zeros_like(labels, dtype=int)
        part[(ix >= xm) & (iy < ym)] = 1
        part[(ix < xm) & (iy >= ym)] = 2
        part[(ix >= xm) & (iy >= ym)] = 3
        names = ['Q1_UL', 'Q2_UR', 'Q3_LL', 'Q4_LR']
    elif scheme == 'left_right':
        xm = int(n_bins_x) // 2
        part = (ix >= xm).astype(int)
        names = ['left', 'right']
    elif scheme == 'up_down':
        ym = int(n_bins_y) // 2
        part = (iy >= ym).astype(int)
        names = ['up', 'down']
    else:
        raise ValueError("scheme must be 'quadrant'|'left_right'|'up_down'")
    return part, names


def confusion_matrix_int(y_true, y_pred, n_classes):
    yt = np.asarray(y_true, dtype=int).ravel()
    yp = np.asarray(y_pred, dtype=int).ravel()
    m = min(yt.size, yp.size)
    yt = yt[:m]
    yp = yp[:m]
    cm = np.zeros((int(n_classes), int(n_classes)), dtype=int)
    good = (yt >= 0) & (yt < int(n_classes)) & (yp >= 0) & (yp < int(n_classes))
    yt = yt[good]
    yp = yp[good]
    np.add.at(cm, (yt, yp), 1)
    return cm


def poisson_decode_partition(
    counts_train_tn,
    partition_labels_train,
    counts_test_tn,
    partition_labels_test,
    *,
    dt=DT,
):
    ytr = np.asarray(partition_labels_train, dtype=int)
    yte = np.asarray(partition_labels_test, dtype=int)
    n_classes = int(np.max(np.concatenate([ytr, yte])) + 1) if ytr.size and yte.size else 0
    if n_classes <= 0:
        return {'pred': np.array([], dtype=int), 'accuracy': np.nan, 'confusion': np.zeros((0, 0), dtype=int)}
    res = poisson_decode_train_test(
        np.asarray(counts_train_tn, dtype=float),
        ytr,
        np.asarray(counts_test_tn, dtype=float),
        n_bins=n_classes,
        dt=dt,
    )
    pred = res['pred']
    m = min(pred.size, yte.size)
    acc = float(np.mean(pred[:m] == yte[:m])) if m else np.nan
    cm = confusion_matrix_int(yte[:m], pred[:m], n_classes=n_classes)
    return {'pred': pred, 'accuracy': acc, 'confusion': cm, 'n_classes': n_classes}
