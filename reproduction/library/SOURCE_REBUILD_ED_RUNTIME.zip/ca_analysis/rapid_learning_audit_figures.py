"""Missing-safe audit figures for the rapid-learning workflow.

Figure contract
---------------
Core conclusion
    These figures expose cohort support, transformation stages, estimator
    reliability, and decoder comparators.  They never classify a biological
    hypothesis.
Evidence chain
    Phase 0 shows cohort/readiness support; Phase 1 shows topology-score, null,
    and interpretation-limit diagnostics; Phase 2 shows the ELPC control ladder
    and reliability; Phase 3 shows decoder support/comparator margins and
    reward-branch status.
Archetype/backend/export
    Python/matplotlib quantitative audit grids, exported as PNG plus one tidy
    source-data CSV per figure and a JSON provenance manifest.
Review risks
    Missing or preliminary inputs must be shown explicitly, smoke outputs must
    not look confirmatory, and absent sensitivity analyses must not be silently
    replaced by nearby metrics.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt  # noqa: E402


DEFAULT_PROJECT_ROOT = Path("docs/rapid_learning_structure_reward_2026-07-15")

PALETTE = {
    "blue": "#4C78A8",
    "orange": "#F2A65A",
    "green": "#59A14F",
    "red": "#E15759",
    "purple": "#8F77B5",
    "gray": "#8C8C8C",
    "light_gray": "#D9D9D9",
}


@dataclass(frozen=True)
class AuditFigureRecord:
    figure_id: str
    png: str
    source_csv: str
    status: str
    source_dir: str
    source_tier: str
    panel_status: dict[str, str]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_csv(path: Path) -> tuple[pd.DataFrame, str]:
    if not path.exists():
        return pd.DataFrame(), "missing"
    try:
        table = pd.read_csv(path)
    except (OSError, pd.errors.EmptyDataError, pd.errors.ParserError) as exc:
        return pd.DataFrame(), f"unreadable:{type(exc).__name__}"
    return table, "ok" if len(table) else "empty"


def _source_tier(path: Path) -> str:
    lowered = path.name.lower()
    if "smoke" in lowered or "prelim" in lowered:
        return "preliminary_smoke"
    if path.exists() and any(path.glob("*.csv")):
        return "analysis_output"
    return "missing_or_pending"


def _resolve_phase_dir(
    root: Path,
    explicit: Path | None,
    preferred: str,
    fallbacks: Sequence[str],
) -> Path:
    if explicit is not None:
        return explicit.resolve()
    for name in (preferred, *fallbacks):
        candidate = root / name
        if candidate.exists() and any(candidate.glob("*.csv")):
            return candidate
    return root / preferred


def _style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.7,
            "legend.frameon": False,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )


def _new_grid(title: str, source_dir: Path) -> tuple[plt.Figure, np.ndarray]:
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.4), constrained_layout=True)
    tier = _source_tier(source_dir)
    fig.suptitle(
        f"AUDIT DIAGNOSTIC — {title}\nsource={source_dir.name}; tier={tier}",
        fontsize=10,
        fontweight="bold",
    )
    return fig, axes.ravel()


def _missing_panel(ax: plt.Axes, title: str, reason: str) -> None:
    ax.set_title(title, loc="left", fontweight="bold")
    ax.text(
        0.5,
        0.5,
        f"MISSING / PENDING\n{reason}",
        transform=ax.transAxes,
        ha="center",
        va="center",
        color="#555555",
        bbox={"boxstyle": "round,pad=0.5", "fc": "#F2F2F2", "ec": "#BDBDBD"},
    )
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def _status_frame(panel: str, status: str, note: str) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "panel": panel,
                "record_type": "panel_status",
                "status": status,
                "note": note,
            }
        ]
    )


def _with_panel(table: pd.DataFrame, panel: str, record_type: str) -> pd.DataFrame:
    copied = table.copy()
    copied.insert(0, "record_type", record_type)
    copied.insert(0, "panel", panel)
    return copied


def _write_source_csv(path: Path, pieces: Iterable[pd.DataFrame]) -> None:
    nonempty = [piece for piece in pieces if piece is not None and len(piece)]
    table = (
        pd.concat(nonempty, ignore_index=True, sort=False)
        if nonempty
        else _status_frame("all", "missing", "No source rows were available.")
    )
    table.to_csv(path, index=False)


def _save(fig: plt.Figure, path: Path) -> None:
    fig.savefig(path, dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def _cohort_colors(labels: Sequence[str]) -> dict[str, str]:
    colors = [PALETTE["blue"], PALETTE["orange"], PALETTE["green"], PALETTE["purple"]]
    return {
        label: colors[index % len(colors)]
        for index, label in enumerate(sorted(set(labels)))
    }


def _bool_series(values: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(values):
        return values.fillna(False)
    return values.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def _phase0_figure(source_dir: Path, out_dir: Path) -> AuditFigureRecord:
    inventory_path = source_dir / "rapid_learning_session_inventory.csv"
    support_path = source_dir / "rapid_learning_session_support.csv"
    inventory, inventory_status = _read_csv(inventory_path)
    support, support_status = _read_csv(support_path)
    fig, axes = _new_grid("Phase 0 cohort and support overview", source_dir)
    source_rows: list[pd.DataFrame] = []
    statuses: dict[str, str] = {}

    if inventory_status == "ok" and {"cohort_group", "pair_id"}.issubset(inventory):
        counts = (
            inventory.groupby("cohort_group", dropna=False)["pair_id"]
            .nunique()
            .rename("n_pairs")
            .reset_index()
        )
        colors = _cohort_colors(counts["cohort_group"].astype(str).tolist())
        axes[0].bar(
            counts["cohort_group"].astype(str),
            counts["n_pairs"],
            color=[colors[str(value)] for value in counts["cohort_group"]],
        )
        axes[0].set_ylabel("Day1↔Day2 pairs")
        axes[0].tick_params(axis="x", rotation=25)
        axes[0].set_title("A  Frozen cohort", loc="left", fontweight="bold")
        source_rows.append(_with_panel(counts, "A_cohort", "cohort_count"))
        statuses["A"] = "ok"
    else:
        _missing_panel(axes[0], "A  Frozen cohort", f"inventory {inventory_status}")
        source_rows.append(
            _status_frame("A_cohort", inventory_status, str(inventory_path))
        )
        statuses["A"] = inventory_status

    readiness = [
        "structure_behavior_ready",
        "ELPC_within_session_ready",
        "C_structure_cross_day_ready",
        "C_reward_within_session_ready",
    ]
    available_readiness = [column for column in readiness if column in inventory]
    if inventory_status == "ok" and available_readiness and "cohort_group" in inventory:
        rows = []
        for cohort, group in inventory.groupby("cohort_group", dropna=False):
            for column in available_readiness:
                rows.append(
                    {
                        "cohort_group": cohort,
                        "readiness": column,
                        "n_ready": int(_bool_series(group[column]).sum()),
                        "n_total": int(len(group)),
                    }
                )
        ready = pd.DataFrame(rows)
        ready["fraction_ready"] = ready["n_ready"] / ready["n_total"].replace(0, np.nan)
        pivot = ready.pivot(
            index="cohort_group", columns="readiness", values="fraction_ready"
        )
        pivot.plot(kind="bar", ax=axes[1], width=0.82, colormap="Blues")
        axes[1].set_ylim(0, 1.05)
        axes[1].set_ylabel("Fraction ready")
        axes[1].set_xlabel("")
        axes[1].tick_params(axis="x", rotation=25)
        axes[1].set_title(
            "B  Analysis-specific readiness", loc="left", fontweight="bold"
        )
        axes[1].legend(fontsize=5, title=None)
        source_rows.append(_with_panel(ready, "B_readiness", "readiness"))
        statuses["B"] = "ok"
    else:
        _missing_panel(
            axes[1], "B  Analysis-specific readiness", "readiness columns unavailable"
        )
        source_rows.append(
            _status_frame("B_readiness", "missing", "readiness columns unavailable")
        )
        statuses["B"] = "missing"

    day1_columns = [
        "day1_n_explore_primary_decisions",
        "day1_n_explore_primary_decisions_with_C_support",
    ]
    if inventory_status == "ok" and set(
        day1_columns + ["cohort_group", "animal_id"]
    ).issubset(inventory):
        long = inventory[["animal_id", "cohort_group", *day1_columns]].melt(
            id_vars=["animal_id", "cohort_group"], var_name="metric", value_name="count"
        )
        long["count"] = pd.to_numeric(long["count"], errors="coerce")
        x_labels = sorted(long["cohort_group"].astype(str).unique())
        offsets = {day1_columns[0]: -0.12, day1_columns[1]: 0.12}
        for metric, color in zip(day1_columns, [PALETTE["gray"], PALETTE["blue"]]):
            subset = long[long["metric"].eq(metric)]
            for index, cohort in enumerate(x_labels):
                values = subset.loc[
                    subset["cohort_group"].astype(str).eq(cohort), "count"
                ].dropna()
                axes[2].scatter(
                    np.full(len(values), index + offsets[metric]),
                    values,
                    s=14,
                    alpha=0.75,
                    color=color,
                    label=metric if index == 0 else None,
                )
        axes[2].set_xticks(range(len(x_labels)), x_labels, rotation=25)
        axes[2].set_ylabel("Eligible Day-1 decisions")
        axes[2].set_title(
            "C  Structure-decision support", loc="left", fontweight="bold"
        )
        axes[2].legend(fontsize=5)
        source_rows.append(_with_panel(long, "C_day1_support", "animal_support"))
        statuses["C"] = "ok"
    else:
        _missing_panel(
            axes[2],
            "C  Structure-decision support",
            "Day-1 support columns unavailable",
        )
        source_rows.append(
            _status_frame(
                "C_day1_support", "missing", "Day-1 support columns unavailable"
            )
        )
        statuses["C"] = "missing"

    day2_columns = [
        "n_pre_reward_explore_primary_decisions",
        "n_post_reward_primary_decisions_with_C_support",
    ]
    if support_status == "ok" and set(
        day2_columns + ["day_index", "cohort_group", "animal_id"]
    ).issubset(support):
        day2 = support.loc[pd.to_numeric(support["day_index"], errors="coerce").eq(2)]
        long = day2[["animal_id", "cohort_group", *day2_columns]].melt(
            id_vars=["animal_id", "cohort_group"], var_name="metric", value_name="count"
        )
        long["count"] = pd.to_numeric(long["count"], errors="coerce")
        x_labels = sorted(long["cohort_group"].astype(str).unique())
        offsets = {day2_columns[0]: -0.12, day2_columns[1]: 0.12}
        for metric, color in zip(day2_columns, [PALETTE["orange"], PALETTE["green"]]):
            subset = long[long["metric"].eq(metric)]
            for index, cohort in enumerate(x_labels):
                values = subset.loc[
                    subset["cohort_group"].astype(str).eq(cohort), "count"
                ].dropna()
                axes[3].scatter(
                    np.full(len(values), index + offsets[metric]),
                    values,
                    s=14,
                    alpha=0.75,
                    color=color,
                    label=metric if index == 0 else None,
                )
        axes[3].set_xticks(range(len(x_labels)), x_labels, rotation=25)
        axes[3].set_ylabel("Eligible Day-2 decisions")
        axes[3].set_title("D  Reward/search support", loc="left", fontweight="bold")
        axes[3].legend(fontsize=5)
        source_rows.append(_with_panel(long, "D_day2_support", "animal_support"))
        statuses["D"] = "ok"
    else:
        _missing_panel(
            axes[3], "D  Reward/search support", f"session support {support_status}"
        )
        source_rows.append(
            _status_frame("D_day2_support", support_status, str(support_path))
        )
        statuses["D"] = support_status

    png = out_dir / "phase0_cohort_support_audit.png"
    csv = out_dir / "phase0_cohort_support_audit_source_data.csv"
    _save(fig, png)
    _write_source_csv(csv, source_rows)
    overall = "ok" if all(value == "ok" for value in statuses.values()) else "partial"
    return AuditFigureRecord(
        "phase0",
        str(png),
        str(csv),
        overall,
        str(source_dir),
        _source_tier(source_dir),
        statuses,
    )


def _find_table(
    source_dir: Path, names: Sequence[str]
) -> tuple[pd.DataFrame, Path, str]:
    for name in names:
        path = source_dir / name
        table, status = _read_csv(path)
        if status in {"ok", "empty", "unreadable:ParserError"}:
            return table, path, status
    path = source_dir / names[0]
    return pd.DataFrame(), path, "missing"


def _phase1_figure(source_dir: Path, out_dir: Path) -> AuditFigureRecord:
    gain, gain_path, gain_status = _find_table(
        source_dir,
        [
            "all_neighbor_primary_structure_policy_gain.csv",
            "structure_policy_gain.csv",
        ],
    )
    per_epoch, per_epoch_path, per_epoch_status = _find_table(
        source_dir,
        [
            "all_neighbor_primary_structure_policy_per_animal_epoch.csv",
            "structure_policy_per_animal_epoch.csv",
        ],
    )
    null_delta, null_path, null_status = _find_table(
        source_dir,
        [
            "all_neighbor_primary_graph_policy_null_delta.csv",
            "all_neighbor_primary_null_delta.csv",
            "full_trajectory_null_delta.csv",
        ],
    )
    sensitivity, sensitivity_path, sensitivity_status = _find_table(
        source_dir,
        [
            "all_neighbor_primary_component_gain_diagnostic.csv",
            "structure_component_k_sensitivity.csv",
            "topology_component_k_sensitivity.csv",
            "structure_policy_sensitivity.csv",
        ],
    )
    mismatch, mismatch_path, mismatch_status = _find_table(
        source_dir,
        [
            "all_neighbor_primary_graph_policy_null_feature_audit.csv",
            "all_neighbor_primary_null_feature_audit.csv",
            "simulator_feature_mismatch.csv",
            "full_trajectory_null_feature_audit.csv",
            "simulator_feature_audit.csv",
        ],
    )
    fig, axes = _new_grid("Phase 1 topology-score and null audit", source_dir)
    source_rows: list[pd.DataFrame] = []
    statuses: dict[str, str] = {}

    required = {"animal_id", "cohort_group", "delta_psi"}
    if gain_status == "ok" and required.issubset(gain):
        work = gain[list(required)].copy()
        work["delta_psi"] = pd.to_numeric(work["delta_psi"], errors="coerce")
        cohorts = sorted(work["cohort_group"].astype(str).unique())
        colors = _cohort_colors(cohorts)
        rng = np.random.default_rng(712)
        for index, cohort in enumerate(cohorts):
            values = work.loc[
                work["cohort_group"].astype(str).eq(cohort), "delta_psi"
            ].dropna()
            axes[0].scatter(
                index + rng.uniform(-0.08, 0.08, len(values)),
                values,
                color=colors[cohort],
                s=18,
                alpha=0.85,
            )
        axes[0].axhline(0, color="black", lw=0.8, ls="--")
        axes[0].set_xticks(range(len(cohorts)), cohorts, rotation=25)
        axes[0].set_ylabel("Null-corrected ΔΨ (C−B)")
        axes[0].set_title(
            "A  Observed topology-score gain", loc="left", fontweight="bold"
        )
        source_rows.append(_with_panel(work, "A_observed_gain", "animal_gain"))
        statuses["A"] = "ok"
    else:
        _missing_panel(
            axes[0], "A  Observed topology-score gain", f"gain {gain_status}"
        )
        source_rows.append(
            _status_frame("A_observed_gain", gain_status, str(gain_path))
        )
        statuses["A"] = gain_status

    if per_epoch_status == "ok" and {"animal_id", "epoch", "psi_raw", "psi"}.issubset(
        per_epoch
    ):
        wide_raw = per_epoch.pivot(index="animal_id", columns="epoch", values="psi_raw")
        wide_corrected = per_epoch.pivot(
            index="animal_id", columns="epoch", values="psi"
        )
        if {"B", "C"}.issubset(wide_raw) and {"B", "C"}.issubset(wide_corrected):
            comparison = pd.DataFrame(
                {
                    "animal_id": wide_raw.index,
                    "raw_delta": wide_raw["C"] - wide_raw["B"],
                    "null_corrected_delta": wide_corrected["C"] - wide_corrected["B"],
                }
            ).reset_index(drop=True)
            axes[1].scatter(
                comparison["raw_delta"],
                comparison["null_corrected_delta"],
                color=PALETTE["blue"],
                s=18,
            )
            finite = comparison[["raw_delta", "null_corrected_delta"]].to_numpy(
                dtype=float
            )
            finite = finite[np.isfinite(finite)]
            if finite.size:
                lo, hi = float(np.min(finite)), float(np.max(finite))
                axes[1].plot([lo, hi], [lo, hi], color=PALETTE["gray"], ls="--", lw=0.8)
            n_null = pd.to_numeric(per_epoch.get("n_null"), errors="coerce").max()
            axes[1].set_title(
                f"B  Raw versus null-corrected gain (n_null≤{int(n_null) if np.isfinite(n_null) else 'NA'})",
                loc="left",
                fontweight="bold",
            )
            axes[1].set_xlabel("Raw ΔΨ")
            axes[1].set_ylabel("Null-corrected ΔΨ")
            source_rows.append(
                _with_panel(comparison, "B_null_correction", "animal_gain")
            )
            if null_status == "ok":
                source_rows.append(
                    _with_panel(null_delta, "B_null_correction", "null_delta")
                )
            statuses["B"] = "ok"
        else:
            _missing_panel(
                axes[1], "B  Raw versus null-corrected gain", "B/C epochs unavailable"
            )
            source_rows.append(
                _status_frame("B_null_correction", "missing", "B/C epochs unavailable")
            )
            statuses["B"] = "missing"
    else:
        _missing_panel(
            axes[1],
            "B  Raw versus null-corrected gain",
            f"per-epoch {per_epoch_status}",
        )
        source_rows.append(
            _status_frame("B_null_correction", per_epoch_status, str(per_epoch_path))
        )
        statuses["B"] = per_epoch_status

    if sensitivity_status == "ok":
        numeric = sensitivity.select_dtypes(include=[np.number]).columns.tolist()
        value = next(
            (
                column
                for column in [
                    "delta_psi",
                    "delta_psi_raw_C_minus_B",
                    "estimate",
                    "gain",
                ]
                if column in sensitivity
            ),
            None,
        )
        group = next(
            (
                column
                for column in [
                    "component",
                    "feature_set",
                    "topology_features",
                    "k",
                    "analysis",
                ]
                if column in sensitivity
            ),
            None,
        )
        if value and group:
            plot = sensitivity[[group, value]].copy()
            plot[value] = pd.to_numeric(plot[value], errors="coerce")
            grouped = plot.groupby(group, dropna=False)[value].median().reset_index()
            axes[2].bar(
                grouped[group].astype(str), grouped[value], color=PALETTE["purple"]
            )
            axes[2].axhline(0, color="black", lw=0.8, ls="--")
            axes[2].tick_params(axis="x", rotation=25)
            axes[2].set_ylabel(value)
            axes[2].set_title(
                "C  Component / K sensitivity", loc="left", fontweight="bold"
            )
            source_rows.append(_with_panel(sensitivity, "C_component_K", "sensitivity"))
            statuses["C"] = "ok"
        else:
            _missing_panel(
                axes[2],
                "C  Component / K sensitivity",
                f"unrecognized schema; numeric={numeric}",
            )
            source_rows.append(
                _status_frame(
                    "C_component_K", "schema_unresolved", str(sensitivity_path)
                )
            )
            statuses["C"] = "schema_unresolved"
    else:
        _missing_panel(
            axes[2], "C  Component / K sensitivity", "analysis not yet exported"
        )
        source_rows.append(
            _status_frame("C_component_K", sensitivity_status, str(sensitivity_path))
        )
        statuses["C"] = sensitivity_status

    if mismatch_status == "ok":
        feature = next(
            (
                column
                for column in ["feature", "metric", "variable"]
                if column in mismatch
            ),
            None,
        )
        observed = next(
            (
                column
                for column in ["observed", "observed_mean", "observed_value"]
                if column in mismatch
            ),
            None,
        )
        simulated = next(
            (
                column
                for column in ["simulated", "null_mean", "simulated_mean"]
                if column in mismatch
            ),
            None,
        )
        if feature and observed and simulated:
            plot = mismatch[[feature, observed, simulated]].copy()
            x = np.arange(len(plot))
            axes[3].bar(
                x - 0.18,
                plot[observed],
                width=0.36,
                color=PALETTE["blue"],
                label="observed",
            )
            axes[3].bar(
                x + 0.18,
                plot[simulated],
                width=0.36,
                color=PALETTE["gray"],
                label="simulated",
            )
            axes[3].set_xticks(x, plot[feature].astype(str), rotation=25)
            axes[3].legend(fontsize=6)
            axes[3].set_title(
                "D  Simulator feature fidelity", loc="left", fontweight="bold"
            )
            source_rows.append(
                _with_panel(mismatch, "D_simulator_fidelity", "feature_mismatch")
            )
            statuses["D"] = "ok"
        else:
            _missing_panel(
                axes[3], "D  Simulator feature fidelity", "unrecognized mismatch schema"
            )
            source_rows.append(
                _status_frame(
                    "D_simulator_fidelity", "schema_unresolved", str(mismatch_path)
                )
            )
            statuses["D"] = "schema_unresolved"
    else:
        _missing_panel(
            axes[3],
            "D  Simulator feature fidelity",
            "observed-vs-simulated feature audit pending",
        )
        source_rows.append(
            _status_frame("D_simulator_fidelity", mismatch_status, str(mismatch_path))
        )
        statuses["D"] = mismatch_status

    png = out_dir / "phase1_topology_null_audit.png"
    csv = out_dir / "phase1_topology_null_audit_source_data.csv"
    _save(fig, png)
    _write_source_csv(csv, source_rows)
    overall = "ok" if all(value == "ok" for value in statuses.values()) else "partial"
    return AuditFigureRecord(
        "phase1",
        str(png),
        str(csv),
        overall,
        str(source_dir),
        _source_tier(source_dir),
        statuses,
    )


def _panel_claim_cap(ax: plt.Axes, text: str) -> None:
    ax.text(
        0.99,
        0.02,
        text,
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=5.5,
        color="#555555",
        bbox={"boxstyle": "round,pad=0.25", "fc": "white", "ec": "#D9D9D9"},
    )


def _phase1_interpretation_diagnostics_figure(
    source_dir: Path, out_dir: Path
) -> AuditFigureRecord:
    """Expose Phase-1 interpretation limits without reclassifying hypotheses."""

    denominator, denominator_path, denominator_status = _find_table(
        source_dir, ["phase1_policy_denominator_floor_sensitivity.csv"]
    )
    frontier, frontier_path, frontier_status = _find_table(
        source_dir, ["phase1_global_frontier_support_diagnostic.csv"]
    )
    penalty, penalty_path, penalty_status = _find_table(
        source_dir, ["phase1_graph_policy_penalty_sensitivity.csv"]
    )
    rivals, rivals_path, rivals_status = _find_table(
        source_dir, ["phase1_h_s2_component_specificity.csv"]
    )
    fig, axes = _new_grid(
        "Phase 1 interpretation limits (diagnostic only; not confirmatory)", source_dir
    )
    source_rows: list[pd.DataFrame] = []
    statuses: dict[str, str] = {}
    scope_labels = {
        "pooled_reward_agnostic": "pooled reward-agnostic",
        "latent_dry_reward_free": "latent/dry reward-free",
    }

    denominator_required = {
        "metric",
        "opportunity_floor_per_node_epoch",
        "scope",
        "n_animals",
        "median_common_nodes",
    }
    if denominator_status == "ok" and denominator_required.issubset(denominator):
        work = denominator.copy()
        work["opportunity_floor_per_node_epoch"] = pd.to_numeric(
            work["opportunity_floor_per_node_epoch"], errors="coerce"
        )
        work["n_animals"] = pd.to_numeric(work["n_animals"], errors="coerce")
        work["median_common_nodes"] = pd.to_numeric(
            work["median_common_nodes"], errors="coerce"
        )
        metric_labels = {
            "P_BF_Lf_from_child_forward": "P_BF",
            "P_BS_Lo_from_child_outward_given_forward": "P_BS",
        }
        metric_colors = {"P_BF": PALETTE["blue"], "P_BS": PALETTE["purple"]}
        for (metric, scope), group in work.groupby(["metric", "scope"], sort=True):
            group = group.sort_values("opportunity_floor_per_node_epoch")
            metric_label = metric_labels.get(str(metric), str(metric))
            scope_label = scope_labels.get(str(scope), str(scope))
            axes[0].plot(
                group["opportunity_floor_per_node_epoch"],
                group["n_animals"],
                color=metric_colors.get(metric_label, PALETTE["gray"]),
                linestyle="-" if str(scope) == "pooled_reward_agnostic" else "--",
                marker="o" if metric_label == "P_BF" else "s",
                markersize=4,
                linewidth=1.2,
                label=f"{metric_label}; {scope_label}",
            )
        axes[0].set_xlabel("Minimum opportunities per node/epoch")
        axes[0].set_ylabel("Animals retained")
        axes[0].set_xticks(
            sorted(work["opportunity_floor_per_node_epoch"].dropna().unique())
        )
        axes[0].set_ylim(bottom=0)
        axes[0].legend(fontsize=5.5, ncol=2)
        axes[0].set_title("A  Denominator-floor support", loc="left", fontweight="bold")
        _panel_claim_cap(axes[0], "Support diagnostic only")
        work["claim_cap"] = (
            "diagnostic support sensitivity; changing denominator floors does not "
            "replace the prespecified primary analysis"
        )
        source_rows.append(
            _with_panel(work, "A_denominator_floor_support", "denominator_floor")
        )
        statuses["A"] = "ok"
    else:
        _missing_panel(
            axes[0],
            "A  Denominator-floor support",
            f"denominator sensitivity {denominator_status}",
        )
        source_rows.append(
            _status_frame(
                "A_denominator_floor_support",
                denominator_status,
                str(denominator_path),
            )
        )
        statuses["A"] = denominator_status

    frontier_required = {
        "scope",
        "epoch",
        "n_decisions",
        "frontier_discriminating_fraction",
    }
    if frontier_status == "ok" and frontier_required.issubset(frontier):
        work = frontier.copy()
        work["frontier_discriminating_fraction"] = pd.to_numeric(
            work["frontier_discriminating_fraction"], errors="coerce"
        )
        work["n_decisions"] = pd.to_numeric(work["n_decisions"], errors="coerce")
        epochs = [value for value in ["B", "C"] if value in set(work["epoch"])]
        scopes = [
            value
            for value in ["pooled_reward_agnostic", "latent_dry_reward_free"]
            if value in set(work["scope"])
        ]
        x = np.arange(len(epochs), dtype=float)
        width = 0.34
        for index, scope in enumerate(scopes):
            values = []
            counts = []
            for epoch in epochs:
                rows = work.loc[work["scope"].eq(scope) & work["epoch"].eq(epoch)]
                values.append(
                    float(rows["frontier_discriminating_fraction"].iloc[0])
                    if len(rows)
                    else np.nan
                )
                counts.append(int(rows["n_decisions"].iloc[0]) if len(rows) else 0)
            offset = (index - (len(scopes) - 1) / 2) * width
            bars = axes[1].bar(
                x + offset,
                values,
                width=width,
                color=[PALETTE["blue"], PALETTE["orange"]][index],
                label=scope_labels.get(scope, scope),
            )
            for bar, count in zip(bars, counts, strict=True):
                axes[1].text(
                    bar.get_x() + bar.get_width() / 2,
                    max(0.02, bar.get_height() - 0.08),
                    f"n={count}",
                    ha="center",
                    va="top",
                    rotation=90,
                    fontsize=5,
                    color="white" if bar.get_height() > 0.2 else "black",
                )
        axes[1].set_xticks(x, epochs)
        axes[1].set_ylim(0, 1.02)
        axes[1].set_xlabel("Structure epoch")
        axes[1].set_ylabel("Frontier-discriminating decisions")
        axes[1].set_title(
            "B  Dynamic-frontier support depletion", loc="left", fontweight="bold"
        )
        axes[1].legend(fontsize=5.5)
        _panel_claim_cap(axes[1], "Decision support, not effect evidence")
        work["claim_cap"] = (
            "diagnostic decision-level support; depleted frontier discrimination "
            "limits interpretation of the global secondary score"
        )
        source_rows.append(_with_panel(work, "B_frontier_support", "frontier_support"))
        statuses["B"] = "ok"
    else:
        _missing_panel(
            axes[1],
            "B  Dynamic-frontier support depletion",
            f"frontier diagnostic {frontier_status}",
        )
        source_rows.append(
            _status_frame("B_frontier_support", frontier_status, str(frontier_path))
        )
        statuses["B"] = frontier_status

    penalty_required = {
        "l2_penalty",
        "scope",
        "mean_raw_delta",
        "median_raw_delta",
        "claim_cap",
    }
    if penalty_status == "ok" and penalty_required.issubset(penalty):
        work = penalty.copy()
        for column in ["l2_penalty", "mean_raw_delta", "median_raw_delta"]:
            work[column] = pd.to_numeric(work[column], errors="coerce")
        colors = {
            "pooled_reward_agnostic": PALETTE["blue"],
            "latent_dry_reward_free": PALETTE["orange"],
        }
        for scope, group in work.groupby("scope", sort=True):
            group = group.sort_values("l2_penalty")
            label = scope_labels.get(str(scope), str(scope))
            axes[2].plot(
                group["l2_penalty"],
                group["median_raw_delta"],
                color=colors.get(str(scope), PALETTE["gray"]),
                marker="o",
                linewidth=1.3,
                label=f"median; {label}",
            )
            axes[2].plot(
                group["l2_penalty"],
                group["mean_raw_delta"],
                color=colors.get(str(scope), PALETTE["gray"]),
                linestyle="--",
                marker=".",
                linewidth=0.9,
                label=f"mean; {label}",
            )
        axes[2].set_xscale("log")
        axes[2].set_xticks(
            sorted(work["l2_penalty"].dropna().unique()),
            [f"{value:g}" for value in sorted(work["l2_penalty"].dropna().unique())],
        )
        axes[2].axhline(0, color="black", lw=0.8, ls="--")
        axes[2].set_xlabel("L2 penalty")
        axes[2].set_ylabel("Raw LOMO ΔΨ (C−B)")
        axes[2].set_title(
            "C  Raw graph-policy penalty sensitivity", loc="left", fontweight="bold"
        )
        axes[2].legend(fontsize=5.2, ncol=2)
        _panel_claim_cap(axes[2], "Raw only; alternate nulls not rerun")
        source_rows.append(
            _with_panel(work, "C_penalty_sensitivity", "raw_penalty_sensitivity")
        )
        statuses["C"] = "ok"
    else:
        _missing_panel(
            axes[2],
            "C  Raw graph-policy penalty sensitivity",
            f"penalty sensitivity {penalty_status}",
        )
        source_rows.append(
            _status_frame("C_penalty_sensitivity", penalty_status, str(penalty_path))
        )
        statuses["C"] = penalty_status

    rivals_required = {
        "analysis",
        "n",
        "association",
        "estimate",
        "p_two_sided",
        "claim_cap",
    }
    if rivals_status == "ok" and rivals_required.issubset(rivals):
        work = rivals.copy()
        work["estimate"] = pd.to_numeric(work["estimate"], errors="coerce")
        work["p_two_sided"] = pd.to_numeric(work["p_two_sided"], errors="coerce")
        labels = {
            "S_local_composite": "S_local composite",
            "P_SF_from_parent_forward": "P_SF from-parent forward",
            "P_SA_from_parent_spatial_alternation": "P_SA spatial alternation",
            "P_BF_from_child_forward": "P_BF from-child forward",
            "P_BS_from_child_outward": "P_BS outward | forward",
            "S_local_residualized_for_P_SF": "S_local residualized for P_SF",
        }
        work["display_label"] = work["analysis"].map(labels).fillna(work["analysis"])
        y = np.arange(len(work))[::-1]
        colors = [
            PALETTE["gray"] if "residualized" in str(value) else PALETTE["purple"]
            for value in work["analysis"]
        ]
        axes[3].scatter(work["estimate"], y, color=colors, s=24, zorder=3)
        axes[3].axvline(0, color=PALETTE["gray"], lw=0.8, ls="--")
        axes[3].set_yticks(y, work["display_label"])
        axes[3].set_xlim(-1.05, 1.05)
        axes[3].set_xlabel("Association estimate")
        axes[3].set_title(
            "D  H-S2 component rivals (unadjusted diagnostics)",
            loc="left",
            fontweight="bold",
        )
        for y_value, p_value in zip(y, work["p_two_sided"], strict=True):
            axes[3].text(
                0.98,
                y_value,
                f"p={p_value:.3g}" if np.isfinite(p_value) else "p=NA",
                transform=axes[3].get_yaxis_transform(),
                ha="right",
                va="center",
                fontsize=5.5,
            )
        _panel_claim_cap(axes[3], "Rival diagnostic; n=9; no multiplicity claim")
        source_rows.append(
            _with_panel(work, "D_h_s2_component_rivals", "component_rival")
        )
        statuses["D"] = "ok"
    else:
        _missing_panel(
            axes[3],
            "D  H-S2 component rivals",
            f"component-specificity diagnostic {rivals_status}",
        )
        source_rows.append(
            _status_frame("D_h_s2_component_rivals", rivals_status, str(rivals_path))
        )
        statuses["D"] = rivals_status

    png = out_dir / "phase1_interpretation_diagnostics_audit.png"
    csv = out_dir / "phase1_interpretation_diagnostics_audit_source_data.csv"
    _save(fig, png)
    _write_source_csv(csv, source_rows)
    overall = "ok" if all(value == "ok" for value in statuses.values()) else "partial"
    return AuditFigureRecord(
        "phase1_interpretation_diagnostics",
        str(png),
        str(csv),
        overall,
        str(source_dir),
        _source_tier(source_dir),
        statuses,
    )


def _phase2_figure(source_dir: Path, out_dir: Path) -> AuditFigureRecord:
    estimates, estimates_path, estimates_status = _find_table(
        source_dir, ["elpc_estimates_long.csv"]
    )
    reliability, reliability_path, reliability_status = _find_table(
        source_dir, ["elpc_split_half_reliability.csv"]
    )
    windows, windows_path, windows_status = _find_table(
        source_dir, ["elpc_window_audit.csv"]
    )
    fig, axes = _new_grid("Phase 2 ELPC estimator audit", source_dir)
    source_rows: list[pd.DataFrame] = []
    statuses: dict[str, str] = {}

    ladder = {
        "L0 observed": "l0_observed_power",
        "L1 cell-shift excess": "l1_cell_shift_excess",
        "L2 zero-lag excess": "l2_zero_lag_excess",
        "L3 map/trajectory": "l3_map_trajectory_elpc",
    }
    available = {
        label: column for label, column in ladder.items() if column in estimates
    }
    if estimates_status == "ok" and available:
        id_columns = [
            column
            for column in ["animal_id", "cohort_group", "subset_index", "block"]
            if column in estimates
        ]
        long = estimates.melt(
            id_vars=id_columns,
            value_vars=list(available.values()),
            var_name="metric_column",
            value_name="value",
        )
        reverse = {column: label for label, column in available.items()}
        long["ladder_stage"] = long["metric_column"].map(reverse)
        long["value"] = pd.to_numeric(long["value"], errors="coerce")
        summary = (
            long.groupby("ladder_stage", dropna=False)["value"]
            .agg(["median", "count"])
            .reset_index()
        )
        order = [label for label in ladder if label in summary["ladder_stage"].values]
        summary["ladder_stage"] = pd.Categorical(
            summary["ladder_stage"], order, ordered=True
        )
        summary = summary.sort_values("ladder_stage")
        axes[0].bar(
            summary["ladder_stage"].astype(str),
            summary["median"],
            color=PALETTE["blue"],
        )
        axes[0].tick_params(axis="x", rotation=25)
        axes[0].set_ylabel("Median coordination power")
        axes[0].set_title("A  ELPC control ladder", loc="left", fontweight="bold")
        source_rows.append(_with_panel(long, "A_elpc_ladder", "estimate"))
        statuses["A"] = "ok"
    else:
        _missing_panel(
            axes[0], "A  ELPC control ladder", f"estimates {estimates_status}"
        )
        source_rows.append(
            _status_frame("A_elpc_ladder", estimates_status, str(estimates_path))
        )
        statuses["A"] = estimates_status

    if reliability_status == "ok" and "spearman_brown" in reliability:
        work = reliability.copy()
        work["spearman_brown"] = pd.to_numeric(work["spearman_brown"], errors="coerce")
        x = np.arange(len(work))
        axes[1].scatter(x, work["spearman_brown"], color=PALETTE["purple"], s=24)
        axes[1].axhline(
            0.75, color=PALETTE["red"], ls="--", lw=1, label="prespecified gate 0.75"
        )
        axes[1].set_xticks(x, work.get("subset_index", pd.Series(x)).astype(str))
        axes[1].set_ylim(-1.05, 1.05)
        axes[1].set_ylabel("Spearman–Brown reliability")
        axes[1].set_xlabel("Cell-subset replication")
        axes[1].set_title("B  Split-half reliability", loc="left", fontweight="bold")
        axes[1].legend(fontsize=6)
        source_rows.append(_with_panel(work, "B_reliability", "subset_reliability"))
        statuses["B"] = "ok"
    else:
        _missing_panel(
            axes[1], "B  Split-half reliability", f"reliability {reliability_status}"
        )
        source_rows.append(
            _status_frame("B_reliability", reliability_status, str(reliability_path))
        )
        statuses["B"] = reliability_status

    pre_column = "fraction_window_frames_pre_reward"
    if windows_status == "ok" and {"animal_id", "cohort_group", pre_column}.issubset(
        windows
    ):
        work = windows[["animal_id", "cohort_group", pre_column]].copy()
        work[pre_column] = pd.to_numeric(work[pre_column], errors="coerce")
        cohorts = sorted(work["cohort_group"].astype(str).unique())
        colors = _cohort_colors(cohorts)
        rng = np.random.default_rng(913)
        for index, cohort in enumerate(cohorts):
            values = work.loc[
                work["cohort_group"].astype(str).eq(cohort), pre_column
            ].dropna()
            axes[2].scatter(
                index + rng.uniform(-0.08, 0.08, len(values)),
                values,
                s=18,
                color=colors[cohort],
            )
        axes[2].set_xticks(range(len(cohorts)), cohorts, rotation=25)
        axes[2].set_ylim(-0.03, 1.03)
        axes[2].set_ylabel("Fraction of A window before first reward")
        axes[2].set_title("C  Temporal-order audit", loc="left", fontweight="bold")
        source_rows.append(_with_panel(work, "C_pre_reward", "window_fraction"))
        statuses["C"] = "ok"
    else:
        _missing_panel(
            axes[2], "C  Temporal-order audit", f"window audit {windows_status}"
        )
        source_rows.append(
            _status_frame("C_pre_reward", windows_status, str(windows_path))
        )
        statuses["C"] = windows_status

    support_columns = [
        column for column in ["n_segments", "n_unique_grid_bins"] if column in windows
    ]
    if (
        windows_status == "ok"
        and {"animal_id", "cohort_group"}.issubset(windows)
        and support_columns
    ):
        long = windows[["animal_id", "cohort_group", *support_columns]].melt(
            id_vars=["animal_id", "cohort_group"], var_name="metric", value_name="value"
        )
        long["value"] = pd.to_numeric(long["value"], errors="coerce")
        summary = (
            long.groupby(["cohort_group", "metric"], dropna=False)["value"]
            .median()
            .reset_index()
        )
        pivot = summary.pivot(index="cohort_group", columns="metric", values="value")
        pivot.plot(
            kind="bar",
            ax=axes[3],
            color=[PALETTE["gray"], PALETTE["green"]][: len(pivot.columns)],
        )
        axes[3].tick_params(axis="x", rotation=25)
        axes[3].set_ylabel("Median support count")
        axes[3].set_xlabel("")
        axes[3].set_title(
            "D  Window/support diagnostics", loc="left", fontweight="bold"
        )
        axes[3].legend(fontsize=6)
        source_rows.append(_with_panel(long, "D_window_support", "window_support"))
        statuses["D"] = "ok"
    else:
        _missing_panel(
            axes[3], "D  Window/support diagnostics", "support columns unavailable"
        )
        source_rows.append(
            _status_frame("D_window_support", "missing", "support columns unavailable")
        )
        statuses["D"] = "missing"

    png = out_dir / "phase2_elpc_audit.png"
    csv = out_dir / "phase2_elpc_audit_source_data.csv"
    _save(fig, png)
    _write_source_csv(csv, source_rows)
    overall = "ok" if all(value == "ok" for value in statuses.values()) else "partial"
    return AuditFigureRecord(
        "phase2",
        str(png),
        str(csv),
        overall,
        str(source_dir),
        _source_tier(source_dir),
        statuses,
    )


def _phase3_figure(source_dir: Path, out_dir: Path) -> AuditFigureRecord:
    within, within_path, within_status = _find_table(
        source_dir, ["phase3_within_epoch_depth_results.csv"]
    )
    support, support_path, support_status = _find_table(
        source_dir, ["phase3_within_epoch_support.csv"]
    )
    if support_status != "ok":
        rescue_support, rescue_support_path, rescue_support_status = _find_table(
            source_dir, ["phase3_common_depth_rescue_audit.csv"]
        )
        if rescue_support_status == "ok":
            support = rescue_support
            support_path = rescue_support_path
            support_status = "rescue_audit"
    cross, cross_path, cross_status = _find_table(
        source_dir, ["phase3_cross_subtree_results.csv"]
    )
    cross_posthoc, cross_posthoc_path, cross_posthoc_status = _find_table(
        source_dir,
        ["phase3_cross_subtree_posthoc_interior_depths_2_5_results.csv"],
    )
    reward, reward_path, reward_status = _find_table(
        source_dir,
        [
            "phase3_reward_pseudo_target_results.csv",
            "phase3_node94_pseudo_target_results.csv",
            "phase3_node94_did_scores.csv",
            "phase3_node94_branch_status.csv",
        ],
    )
    fig, axes = _new_grid(
        "Phase 3 neural-code support and comparator audit", source_dir
    )
    fig.set_size_inches(10.5, 7.4, forward=True)
    source_rows: list[pd.DataFrame] = []
    statuses: dict[str, str] = {}

    accuracy_columns = [
        "topology_balanced_accuracy",
        "position_to_depth_balanced_accuracy",
        "xy_behavior_balanced_accuracy",
        "shuffle_q95_balanced_accuracy",
    ]
    available_accuracy = [column for column in accuracy_columns if column in within]
    if within_status == "ok" and {"epoch"}.issubset(within) and available_accuracy:
        id_columns = [
            column
            for column in ["session_id", "animal_id", "cohort_group", "epoch"]
            if column in within
        ]
        long = within.melt(
            id_vars=id_columns,
            value_vars=available_accuracy,
            var_name="comparator",
            value_name="balanced_accuracy",
        )
        long["balanced_accuracy"] = pd.to_numeric(
            long["balanced_accuracy"], errors="coerce"
        )
        summary = (
            long.groupby(["epoch", "comparator"], dropna=False)["balanced_accuracy"]
            .median()
            .reset_index()
        )
        pivot = summary.pivot(
            index="epoch", columns="comparator", values="balanced_accuracy"
        )
        pivot.plot(kind="bar", ax=axes[0], colormap="Blues")
        axes[0].set_ylabel("Median balanced accuracy")
        axes[0].set_xlabel("")
        axes[0].set_title(
            "A  Within-epoch decoder comparators", loc="left", fontweight="bold"
        )
        axes[0].legend(fontsize=5)
        source_rows.append(_with_panel(long, "A_decoder_comparators", "accuracy"))
        statuses["A"] = "ok"
    elif within_status == "ok" and "status" in within:
        counts = (
            within["status"]
            .fillna("missing")
            .astype(str)
            .value_counts()
            .rename_axis("status")
            .reset_index(name="n")
        )
        axes[0].bar(counts["status"], counts["n"], color=PALETTE["gray"])
        axes[0].tick_params(axis="x", rotation=25)
        axes[0].set_ylabel("Session-epochs")
        axes[0].set_title(
            "A  Within-epoch decoder support outcomes",
            loc="left",
            fontweight="bold",
        )
        source_rows.append(_with_panel(within, "A_decoder_comparators", "support_only"))
        statuses["A"] = "support_only"
    else:
        _missing_panel(
            axes[0],
            "A  Within-epoch decoder comparators",
            f"within results {within_status}",
        )
        source_rows.append(
            _status_frame("A_decoder_comparators", within_status, str(within_path))
        )
        statuses["A"] = within_status

    support_numeric = [
        column
        for column in ["n_frames", "n_visits", "n_train_frames", "n_test_frames"]
        if column in support
    ]
    if support_status in {"ok", "rescue_audit"} and support_numeric:
        ids = [
            column
            for column in ["session_id", "epoch", "split", "depth", "support_tier"]
            if column in support
        ]
        long = support.melt(
            id_vars=ids,
            value_vars=support_numeric,
            var_name="support_metric",
            value_name="value",
        )
        long["value"] = pd.to_numeric(long["value"], errors="coerce")
        summary = (
            long.groupby("support_metric", dropna=False)["value"].median().reset_index()
        )
        axes[1].bar(
            summary["support_metric"].astype(str),
            summary["value"],
            color=PALETTE["gray"],
        )
        axes[1].tick_params(axis="x", rotation=25)
        axes[1].set_ylabel("Median support")
        title_suffix = " (rescue audit)" if support_status == "rescue_audit" else ""
        axes[1].set_title(
            f"B  Occupancy / visit support{title_suffix}",
            loc="left",
            fontweight="bold",
        )
        source_rows.append(_with_panel(long, "B_decoder_support", "support"))
        statuses["B"] = support_status
    else:
        _missing_panel(
            axes[1], "B  Occupancy / visit support", f"support {support_status}"
        )
        source_rows.append(
            _status_frame("B_decoder_support", support_status, str(support_path))
        )
        statuses["B"] = support_status

    if cross_status == "ok" and "topology_balanced_accuracy" in cross:
        work = cross.copy()
        cross_claim_tier = "primary"
        margins = {
            "topology-position": "position_to_depth_balanced_accuracy",
            "topology-XY": "xy_behavior_balanced_accuracy",
            "topology-shuffle95": "shuffle_q95_balanced_accuracy",
        }

        def _margin_rows(table: pd.DataFrame, claim_tier: str) -> pd.DataFrame:
            rows = []
            for label, comparator in margins.items():
                if comparator not in table:
                    continue
                values = pd.to_numeric(
                    table["topology_balanced_accuracy"], errors="coerce"
                ) - pd.to_numeric(table[comparator], errors="coerce")
                for index, value in enumerate(values):
                    rows.append(
                        {
                            "row_index": index,
                            "margin": label,
                            "value": value,
                            "session_id": table.iloc[index].get("session_id", ""),
                            "fold_name": table.iloc[index].get("fold_name", ""),
                            "claim_tier": claim_tier,
                        }
                    )
            return pd.DataFrame(rows)

        margin_table = _margin_rows(work, cross_claim_tier)
        finite_margin = (
            len(margin_table) > 0
            and pd.to_numeric(margin_table["value"], errors="coerce").notna().any()
        )
        if not finite_margin and cross_posthoc_status == "ok":
            work = cross_posthoc.copy()
            cross_claim_tier = "support_only_posthoc"
            margin_table = _margin_rows(work, cross_claim_tier)
            cross_path = cross_posthoc_path
            finite_margin = (
                len(margin_table) > 0
                and pd.to_numeric(margin_table["value"], errors="coerce").notna().any()
            )
        if finite_margin:
            labels = list(margins)
            rng = np.random.default_rng(101)
            for index, label in enumerate(labels):
                values = margin_table.loc[
                    margin_table["margin"].eq(label), "value"
                ].dropna()
                axes[2].scatter(
                    index + rng.uniform(-0.08, 0.08, len(values)),
                    values,
                    s=16,
                    color=PALETTE["blue"],
                )
            axes[2].axhline(0, color="black", lw=0.8, ls="--")
            axes[2].set_xticks(range(len(labels)), labels, rotation=25)
            axes[2].set_ylabel("Balanced-accuracy margin")
            title_suffix = (
                " (support-only post-hoc rescue)"
                if cross_claim_tier == "support_only_posthoc"
                else ""
            )
            axes[2].set_title(
                f"C  Cross-subtree comparator margins{title_suffix}",
                loc="left",
                fontweight="bold",
            )
            source_rows.append(
                _with_panel(margin_table, "C_cross_subtree", "comparator_margin")
            )
            statuses["C"] = cross_claim_tier
        else:
            _missing_panel(
                axes[2],
                "C  Cross-subtree comparator margins",
                "primary and support-only rescue have no finite margins",
            )
            source_rows.append(
                _status_frame(
                    "C_cross_subtree",
                    "support_unresolved",
                    str(cross_path),
                )
            )
            statuses["C"] = "support_unresolved"
    else:
        _missing_panel(
            axes[2],
            "C  Cross-subtree comparator margins",
            f"cross-subtree {cross_status}",
        )
        source_rows.append(
            _status_frame("C_cross_subtree", cross_status, str(cross_path))
        )
        statuses["C"] = cross_status

    pseudo_columns = {
        "pseudo_target_did",
        "rank_percentile_descending",
        "is_target_node",
    }
    if reward_status == "ok" and pseudo_columns.intersection(reward.columns):
        if {"pseudo_target_did", "is_target_node"}.issubset(reward):
            work = reward.copy()
            work["pseudo_target_did"] = pd.to_numeric(
                work["pseudo_target_did"], errors="coerce"
            )
            colors = np.where(
                _bool_series(work["is_target_node"]), PALETTE["red"], PALETTE["gray"]
            )
            axes[3].scatter(
                np.arange(len(work)), work["pseudo_target_did"], c=colors, s=18
            )
            axes[3].axhline(0, color="black", lw=0.8, ls="--")
            axes[3].set_ylabel("Pseudo-target DiD")
            axes[3].set_xlabel("Target/control row")
            sensitivity_suffix = (
                " (outcome-inclusive sensitivity)"
                if "analysis_variant" in work
                and work["analysis_variant"].astype(str).eq("outcome_inclusive").all()
                else ""
            )
            axes[3].set_title(
                f"D  Reward pseudo-target diagnostic{sensitivity_suffix}",
                loc="left",
                fontweight="bold",
            )
            source_rows.append(
                _with_panel(work, "D_reward_pseudo_target", "pseudo_target")
            )
            statuses["D"] = "ok"
        else:
            _missing_panel(
                axes[3],
                "D  Reward pseudo-target diagnostic",
                "partial pseudo-target schema",
            )
            source_rows.append(
                _with_panel(reward, "D_reward_pseudo_target", "partial_reward_output")
            )
            statuses["D"] = "partial"
    elif reward_status == "ok":
        status_column = next(
            (
                column
                for column in ["visit_support_status", "neural_did_status"]
                if column in reward
            ),
            None,
        )
        if status_column:
            counts = (
                reward[status_column]
                .fillna("missing")
                .astype(str)
                .value_counts()
                .rename_axis("status")
                .reset_index(name="n")
            )
            axes[3].bar(counts["status"], counts["n"], color=PALETTE["gray"])
            axes[3].tick_params(axis="x", rotation=25)
            axes[3].set_ylabel("Pairs")
            axes[3].set_title(
                "D  Reward branch status (neural DiD pending)",
                loc="left",
                fontweight="bold",
            )
            source_rows.append(
                _with_panel(reward, "D_reward_pseudo_target", "support_only")
            )
            statuses["D"] = "support_only"
        else:
            _missing_panel(
                axes[3],
                "D  Reward pseudo-target diagnostic",
                "reward output schema unresolved",
            )
            source_rows.append(
                _status_frame(
                    "D_reward_pseudo_target", "schema_unresolved", str(reward_path)
                )
            )
            statuses["D"] = "schema_unresolved"
    else:
        _missing_panel(
            axes[3],
            "D  Reward pseudo-target diagnostic",
            "pseudo-target output not yet available",
        )
        source_rows.append(
            _status_frame("D_reward_pseudo_target", reward_status, str(reward_path))
        )
        statuses["D"] = reward_status

    png = out_dir / "phase3_decoder_reward_audit.png"
    csv = out_dir / "phase3_decoder_reward_audit_source_data.csv"
    _save(fig, png)
    _write_source_csv(csv, source_rows)
    overall = "ok" if all(value == "ok" for value in statuses.values()) else "partial"
    return AuditFigureRecord(
        "phase3",
        str(png),
        str(csv),
        overall,
        str(source_dir),
        _source_tier(source_dir),
        statuses,
    )


def generate_rapid_learning_audit_figures(
    *,
    project_root: str | Path = DEFAULT_PROJECT_ROOT,
    out_dir: str | Path | None = None,
    phase0_dir: str | Path | None = None,
    phase1_dir: str | Path | None = None,
    phase2_dir: str | Path | None = None,
    phase3_dir: str | Path | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Generate diagnostic grids without interpreting biological effects."""

    _style()
    root = Path(project_root).resolve()
    destination = (
        Path(out_dir).resolve()
        if out_dir is not None
        else root / "phase5_report" / "audit_figures"
    )
    if destination.exists() and any(destination.iterdir()) and not overwrite:
        raise FileExistsError(
            f"refusing to overwrite nonempty audit directory: {destination}"
        )
    destination.mkdir(parents=True, exist_ok=True)

    resolved = {
        "phase0": _resolve_phase_dir(
            root, Path(phase0_dir) if phase0_dir else None, "phase0", ()
        ),
        "phase1": _resolve_phase_dir(
            root,
            Path(phase1_dir) if phase1_dir else None,
            "phase1",
            ("phase1_corrected_smoke", "phase1_smoke_fast", "phase1_smoke"),
        ),
        "phase2": _resolve_phase_dir(
            root,
            Path(phase2_dir) if phase2_dir else None,
            "phase2_elpc_exact_support_rescue",
            (
                "phase2_elpc",
                "phase2_elpc_validation_smoke",
                "phase2_elpc_lag08_smoke",
                "phase2_elpc_rescue400_smoke",
            ),
        ),
        "phase3": _resolve_phase_dir(
            root,
            Path(phase3_dir) if phase3_dir else None,
            "phase3_neural_codes",
            ("phase3",),
        ),
    }

    records = [
        _phase0_figure(resolved["phase0"], destination),
        _phase1_figure(resolved["phase1"], destination),
        _phase1_interpretation_diagnostics_figure(resolved["phase1"], destination),
        _phase2_figure(resolved["phase2"], destination),
        _phase3_figure(resolved["phase3"], destination),
    ]
    input_rows = []
    for phase, directory in resolved.items():
        for path in sorted(directory.glob("*.csv")) if directory.exists() else []:
            input_rows.append(
                {
                    "phase": phase,
                    "path": str(path),
                    "sha256": _sha256(path),
                    "bytes": int(path.stat().st_size),
                }
            )
    inputs_csv = destination / "audit_figure_input_manifest.csv"
    pd.DataFrame(input_rows, columns=["phase", "path", "sha256", "bytes"]).to_csv(
        inputs_csv, index=False
    )
    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "audit diagnostics only; no biological hypothesis classification",
        "project_root": str(root),
        "output_dir": str(destination),
        "resolved_phase_dirs": {key: str(value) for key, value in resolved.items()},
        "figures": [asdict(record) for record in records],
        "input_manifest_csv": str(inputs_csv),
    }
    manifest_path = destination / "audit_figure_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


__all__ = ["DEFAULT_PROJECT_ROOT", "generate_rapid_learning_audit_figures"]
