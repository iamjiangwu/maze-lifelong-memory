"""Strict adapter for the optional S-only distance-to-criticality appendix.

The reference Sooter estimator is intentionally not reimplemented here.  This
module accepts only a provenance-complete result table produced by a verified
reference implementation, then audits coverage and construct relationships.

Two quantities called ``d2`` in the source literature are kept distinct:

* ``dist_arcrit_S`` is Sooter's KL-divergence-rate distance to the beta=2
  temporal-RG critical manifold (bits/s), produced by ``calc_db``.
* ``hengen_euclidean_d2_S`` is Hengen et al.'s dimensionless Euclidean
  distance from an AR(p) kernel to the sum(phi)=1 boundary.

They can be calculated from the same S-only AR fit, but they are not the same
estimand and must never be pooled or silently relabelled.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats


REFERENCE_COLUMNS = (
    "animal_id",
    "session_id",
    "dist_arcrit_S",
    "reference_estimator",
    "reference_version",
    "bin_width_s",
    "ar_order",
    "hengen_euclidean_d2_S",
    "primary_qc_pass",
    "exit_status",
    "critical_manifold_beta",
    "fit_method",
    "dist_arcrit_S_units",
    "hengen_euclidean_d2_units",
    "kernel_json",
    "calc_db_sha256",
)

EXPECTED_REFERENCE_ESTIMATOR = "Sooter_calc_db_KLR_beta2_YuleWalker"
EXPECTED_REFERENCE_VERSION = (
    "prox_crit_toolkit@f91691f3595de6de5e9beac43c1c4cacbeb9f87f"
)
EXPECTED_CALC_DB_SHA256 = (
    "67771a5425f151692a6c90a21f73478b3b6f6bdfd6d1056a09c9b075f1582450"
)

OPTIONAL_REFERENCE_PREDICTORS = (
    "hengen_euclidean_d2_S",
    "dist_arcrit_S_fixed150_median",
    "hengen_euclidean_d2_S_fixed150_median",
    "ar_dominant_tau_s",
    "population_S_mean",
    "population_S_nonzero_fraction",
)


def hengen_euclidean_d2(kernel: np.ndarray) -> float:
    """Return Hengen et al.'s dimensionless AR-boundary distance.

    This is ``abs(1 - sum(phi)) / sqrt(p)`` for an order-p history kernel.
    It is deliberately named separately from Sooter's KL-rate ``calc_db``
    output, even though both source papers denote their quantity by ``d2``.
    """

    values = np.asarray(kernel, dtype=float).reshape(-1)
    if values.size == 0 or not np.isfinite(values).all():
        raise ValueError("kernel must contain at least one finite coefficient")
    return float(abs(1.0 - values.sum()) / np.sqrt(values.size))


def segmented_population_s(
    activity: np.ndarray,
    frames: np.ndarray,
    segment_ids: np.ndarray,
) -> tuple[list[np.ndarray], pd.DataFrame]:
    """Convert aligned time-by-cell S activity into contiguous population segments.

    The function rejects nonfinite activity and verifies that AR histories can
    never cross a frame gap.  Segment order follows first appearance in the
    supplied arrays.
    """

    values = np.asarray(activity, dtype=float)
    frame_values = np.asarray(frames, dtype=int).reshape(-1)
    ids = np.asarray(segment_ids).reshape(-1)
    if values.ndim != 2:
        raise ValueError("activity must be a time-by-cell matrix")
    if not (values.shape[0] == frame_values.size == ids.size):
        raise ValueError("activity, frames, and segment_ids must share time length")
    if values.shape[1] < 1 or values.shape[0] < 1:
        raise ValueError("activity must contain at least one frame and one cell")
    if not np.isfinite(values).all():
        raise ValueError("S activity contains nonfinite values")
    population = values.sum(axis=1)
    if not np.isfinite(population).all() or float(np.var(population)) <= 0.0:
        raise ValueError("population S series must be finite with positive variance")

    ordered_ids = list(dict.fromkeys(ids.tolist()))
    segments: list[np.ndarray] = []
    audit_rows: list[dict[str, Any]] = []
    for output_index, segment_id in enumerate(ordered_ids):
        take = np.flatnonzero(ids == segment_id)
        if take.size == 0:
            continue
        segment_frames = frame_values[take]
        continuous = bool(
            segment_frames.size <= 1 or np.all(np.diff(segment_frames) == 1)
        )
        if not continuous:
            raise ValueError(f"segment {segment_id!r} crosses a frame gap")
        segment = population[take].astype(float, copy=True)
        segments.append(segment)
        audit_rows.append(
            {
                "segment_index": int(output_index),
                "source_segment_id": str(segment_id),
                "frame_start": int(segment_frames[0]),
                "frame_end": int(segment_frames[-1]),
                "n_frames": int(segment_frames.size),
                "continuous": continuous,
                "population_S_mean": float(np.mean(segment)),
                "population_S_variance": float(np.var(segment)),
                "population_S_nonzero_fraction": float(np.mean(segment > 0)),
            }
        )
    if not segments:
        raise ValueError("no population S segments were produced")
    return segments, pd.DataFrame(audit_rows)


def _spearman(x: pd.Series, y: pd.Series) -> tuple[int, float, float]:
    keep = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(keep) < 4:
        return int(len(keep)), np.nan, np.nan
    result = stats.spearmanr(keep["x"], keep["y"])
    return int(len(keep)), float(result.statistic), float(result.pvalue)


def _spearman_detail(
    x: pd.Series,
    y: pd.Series,
    *,
    seed: int,
    n_bootstrap: int = 1000,
) -> dict[str, float | int]:
    """Return rank association, animal bootstrap CI, and LOO influence range."""

    keep = pd.DataFrame({"x": x, "y": y}).dropna().reset_index(drop=True)
    n = int(len(keep))
    if n < 4 or keep["x"].nunique() < 2 or keep["y"].nunique() < 2:
        return {
            "n": n,
            "rho": np.nan,
            "p": np.nan,
            "ci_low": np.nan,
            "ci_high": np.nan,
            "loo_rho_min": np.nan,
            "loo_rho_max": np.nan,
            "detectable_abs_r_80pct": np.nan,
        }
    result = stats.spearmanr(keep["x"], keep["y"])
    rng = np.random.default_rng(seed)
    bootstrap = []
    for _ in range(int(n_bootstrap)):
        take = rng.integers(0, n, size=n)
        sampled = keep.iloc[take]
        if sampled["x"].nunique() < 2 or sampled["y"].nunique() < 2:
            continue
        bootstrap.append(float(stats.spearmanr(sampled["x"], sampled["y"]).statistic))
    loo = []
    for index in range(n):
        sampled = keep.drop(index=index)
        if sampled["x"].nunique() >= 2 and sampled["y"].nunique() >= 2:
            loo.append(float(stats.spearmanr(sampled["x"], sampled["y"]).statistic))
    return {
        "n": n,
        "rho": float(result.statistic),
        "p": float(result.pvalue),
        "ci_low": float(np.quantile(bootstrap, 0.025)) if bootstrap else np.nan,
        "ci_high": float(np.quantile(bootstrap, 0.975)) if bootstrap else np.nan,
        "loo_rho_min": float(np.min(loo)) if loo else np.nan,
        "loo_rho_max": float(np.max(loo)) if loo else np.nan,
        "detectable_abs_r_80pct": float(
            np.tanh(
                (stats.norm.ppf(0.975) + stats.norm.ppf(0.80)) / np.sqrt(max(1, n - 3))
            )
        ),
    }


def _as_bool(series: pd.Series) -> pd.Series:
    """Parse persisted CSV booleans without treating nonempty strings as true."""

    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def _rank_ancova(
    table: pd.DataFrame,
    *,
    predictor: str,
    late: str,
    baseline: str,
    controls: list[str],
    context_column: str,
    seed: int,
    n_permutations: int = 5000,
) -> dict[str, Any]:
    """Rank ANCOVA with context-restricted Freedman-Lane permutations."""

    columns = [predictor, late, baseline, context_column] + controls
    current = table[columns].dropna().copy()
    if len(current) < 8:
        return {"n": int(len(current)), "beta": np.nan, "p_freedman_lane": np.nan}
    ranked = pd.DataFrame(index=current.index)
    for column in [predictor, late, baseline] + controls:
        values = pd.to_numeric(current[column], errors="coerce")
        ranked[column] = stats.rankdata(values, method="average")
        ranked[column] = (ranked[column] - ranked[column].mean()) / ranked[column].std(
            ddof=0
        )
    context = pd.get_dummies(
        current[context_column].astype(str), drop_first=True, dtype=float
    )
    reduced_columns = [np.ones(len(current)), ranked[baseline].to_numpy()]
    reduced_columns.extend(ranked[column].to_numpy() for column in controls)
    reduced_columns.extend(context[column].to_numpy() for column in context.columns)
    reduced = np.column_stack(reduced_columns)
    predictor_values = ranked[predictor].to_numpy()
    full = np.column_stack([reduced, predictor_values])
    if np.linalg.matrix_rank(full) < full.shape[1]:
        return {"n": int(len(current)), "beta": np.nan, "p_freedman_lane": np.nan}
    y = ranked[late].to_numpy()
    reduced_beta = np.linalg.lstsq(reduced, y, rcond=None)[0]
    fitted = reduced @ reduced_beta
    residual = y - fitted
    beta = float(np.linalg.lstsq(full, y, rcond=None)[0][-1])
    rng = np.random.default_rng(seed)
    permuted_betas = np.empty(int(n_permutations), dtype=float)
    groups = current[context_column].astype(str).to_numpy()
    group_indices = [np.flatnonzero(groups == group) for group in np.unique(groups)]
    for permutation_index in range(int(n_permutations)):
        permuted_residual = residual.copy()
        for indices in group_indices:
            permuted_residual[indices] = rng.permutation(residual[indices])
        permuted_y = fitted + permuted_residual
        permuted_betas[permutation_index] = np.linalg.lstsq(
            full, permuted_y, rcond=None
        )[0][-1]
    p_value = float(
        (1 + np.sum(np.abs(permuted_betas) >= abs(beta))) / (n_permutations + 1)
    )
    return {
        "n": int(len(current)),
        "beta": beta,
        "p_freedman_lane": p_value,
        "permutation_count": int(n_permutations),
        "n_model_parameters": int(full.shape[1]),
    }


def summarize_reference_diagnostics(
    reference_results: pd.DataFrame,
    split_half: pd.DataFrame,
    cell_subsets: pd.DataFrame,
    ar_bin_sensitivity: pd.DataFrame,
    *,
    reliability_threshold: float = 0.60,
) -> dict[str, pd.DataFrame]:
    """Summarize reliability without replacing the frozen all-cell primary."""

    metric_contract = {
        "dist_arcrit_S": {
            "subset": "sooter_kl_d2_bits_s",
            "primary_split": "primary_sooter_kl_d2_bits_s",
            "split_1": "split_1_sooter_kl_d2_bits_s",
            "split_2": "split_2_sooter_kl_d2_bits_s",
        },
        "hengen_euclidean_d2_S": {
            "subset": "hengen_euclidean_d2_S",
            "primary_split": "primary_hengen_euclidean_d2_S",
            "split_1": "split_1_hengen_euclidean_d2_S",
            "split_2": "split_2_hengen_euclidean_d2_S",
        },
    }
    reference = reference_results.copy()
    reference["animal_id"] = reference["animal_id"].astype(str)
    split = split_half.copy()
    split["animal_id"] = split["animal_id"].astype(str)
    subset = cell_subsets.copy()
    if len(subset):
        subset["animal_id"] = subset["animal_id"].astype(str)
    sensitivity = ar_bin_sensitivity.copy()
    if len(sensitivity):
        sensitivity["animal_id"] = sensitivity["animal_id"].astype(str)

    reliability_rows: list[dict[str, Any]] = []
    subset_rows: list[dict[str, Any]] = []
    subset_split_rows: list[dict[str, Any]] = []
    subset_pair_rows: list[dict[str, Any]] = []
    subset_median_tables: list[pd.DataFrame] = []
    sensitivity_rows: list[dict[str, Any]] = []
    for metric_index, (metric, columns) in enumerate(metric_contract.items()):
        usable_split = split.copy()
        for qc_column in ("primary_qc_pass", "split_1_qc_pass", "split_2_qc_pass"):
            if qc_column in usable_split:
                usable_split = usable_split.loc[_as_bool(usable_split[qc_column])]
        n, rho, p = _spearman(
            pd.to_numeric(usable_split.get(columns["split_1"]), errors="coerce"),
            pd.to_numeric(usable_split.get(columns["split_2"]), errors="coerce"),
        )
        spearman_brown = (
            float(2 * rho / (1 + rho)) if np.isfinite(rho) and rho > -1 else np.nan
        )
        reliability_rows.append(
            {
                "metric": metric,
                "n": n,
                "split_half_rho": rho,
                "split_half_p": p,
                "spearman_brown": spearman_brown,
                "threshold": float(reliability_threshold),
                "split_half_pass": bool(
                    np.isfinite(spearman_brown)
                    and spearman_brown >= reliability_threshold
                ),
            }
        )

        subset_metric_rows = []
        if len(subset) and columns["subset"] in subset:
            for subset_index in sorted(subset["subset_index"].dropna().unique()):
                current = subset.loc[subset["subset_index"].eq(subset_index)].copy()
                if "qc_pass" in current:
                    current = current.loc[_as_bool(current["qc_pass"])]
                current = current.merge(
                    reference[["animal_id", metric]].rename(
                        columns={metric: "all_cell_primary"}
                    ),
                    on="animal_id",
                    how="inner",
                    validate="one_to_one",
                )
                n_current, rho_current, p_current = _spearman(
                    pd.to_numeric(current[columns["subset"]], errors="coerce"),
                    pd.to_numeric(current["all_cell_primary"], errors="coerce"),
                )
                row = {
                    "metric": metric,
                    "subset_index": int(subset_index),
                    "n": n_current,
                    "rho_to_all_cells": rho_current,
                    "p": p_current,
                }
                subset_rows.append(row)
                subset_metric_rows.append(row)
        subset_rhos = np.asarray(
            [row["rho_to_all_cells"] for row in subset_metric_rows], dtype=float
        )
        finite_subset_rhos = subset_rhos[np.isfinite(subset_rhos)]
        median_subset_rho = (
            float(np.median(finite_subset_rhos)) if finite_subset_rhos.size else np.nan
        )
        reliability_rows[-1]["median_subset_rho_to_all_cells"] = median_subset_rho
        reliability_rows[-1]["sampling_generalization_to_all_cells_pass"] = bool(
            np.isfinite(median_subset_rho)
            and median_subset_rho >= reliability_threshold
        )
        subset_temporal_sb: list[float] = []
        split_columns = (
            (
                "split_1_sooter_kl_d2_bits_s",
                "split_2_sooter_kl_d2_bits_s",
            )
            if metric == "dist_arcrit_S"
            else (
                "split_1_hengen_euclidean_d2_S",
                "split_2_hengen_euclidean_d2_S",
            )
        )
        if {
            "split_1_qc_pass",
            "split_2_qc_pass",
            *split_columns,
        }.issubset(subset.columns):
            for subset_index in sorted(subset["subset_index"].dropna().unique()):
                current = subset.loc[subset["subset_index"].eq(subset_index)].copy()
                current = current.loc[
                    _as_bool(current["qc_pass"])
                    & _as_bool(current["split_1_qc_pass"])
                    & _as_bool(current["split_2_qc_pass"])
                ]
                n_current, rho_current, p_current = _spearman(
                    current[split_columns[0]], current[split_columns[1]]
                )
                sb_current = (
                    float(2 * rho_current / (1 + rho_current))
                    if np.isfinite(rho_current) and rho_current > -1
                    else np.nan
                )
                subset_split_rows.append(
                    {
                        "metric": metric,
                        "subset_index": int(subset_index),
                        "n": n_current,
                        "split_half_rho": rho_current,
                        "split_half_p": p_current,
                        "spearman_brown": sb_current,
                    }
                )
                subset_temporal_sb.append(sb_current)
        finite_temporal = np.asarray(subset_temporal_sb, dtype=float)
        finite_temporal = finite_temporal[np.isfinite(finite_temporal)]
        median_fixed_temporal = (
            float(np.median(finite_temporal)) if finite_temporal.size else np.nan
        )

        between_subset_rhos: list[float] = []
        median_to_all_rho = np.nan
        median_to_all_p = np.nan
        if len(subset) and columns["subset"] in subset:
            pivot = subset.pivot(
                index="animal_id",
                columns="subset_index",
                values=columns["subset"],
            )
            for first_position, first_subset in enumerate(pivot.columns):
                for second_subset in pivot.columns[first_position + 1 :]:
                    n_pair, rho_pair, p_pair = _spearman(
                        pivot[first_subset], pivot[second_subset]
                    )
                    subset_pair_rows.append(
                        {
                            "metric": metric,
                            "subset_1": int(first_subset),
                            "subset_2": int(second_subset),
                            "n": n_pair,
                            "rho": rho_pair,
                            "p": p_pair,
                        }
                    )
                    between_subset_rhos.append(rho_pair)
            median_column = f"{metric}_fixed150_median"
            medians = pivot.median(axis=1).rename(median_column).reset_index()
            subset_median_tables.append(medians)
            median_join = medians.merge(
                reference[["animal_id", metric]],
                on="animal_id",
                how="inner",
                validate="one_to_one",
            )
            _, median_to_all_rho, median_to_all_p = _spearman(
                median_join[median_column], median_join[metric]
            )
        finite_between = np.asarray(between_subset_rhos, dtype=float)
        finite_between = finite_between[np.isfinite(finite_between)]
        median_between_subset = (
            float(np.median(finite_between)) if finite_between.size else np.nan
        )
        reliability_rows[-1][
            "median_fixed150_split_spearman_brown"
        ] = median_fixed_temporal
        reliability_rows[-1][
            "median_between_fixed150_subset_rho"
        ] = median_between_subset
        reliability_rows[-1]["fixed150_median_to_all_cells_rho"] = median_to_all_rho
        reliability_rows[-1]["fixed150_median_to_all_cells_p"] = median_to_all_p
        reliability_rows[-1]["cell_subset_pass"] = bool(
            np.isfinite(median_fixed_temporal)
            and median_fixed_temporal >= reliability_threshold
            and np.isfinite(median_between_subset)
            and median_between_subset >= reliability_threshold
        )
        reliability_rows[-1]["measurement_pass"] = bool(
            reliability_rows[-1]["split_half_pass"]
            and reliability_rows[-1]["cell_subset_pass"]
        )

        if len(sensitivity) and columns["subset"] in sensitivity:
            for specification in sorted(sensitivity["specification"].unique()):
                current = sensitivity.loc[
                    sensitivity["specification"].eq(specification)
                ].copy()
                if "qc_pass" in current:
                    current = current.loc[_as_bool(current["qc_pass"])]
                current = current.merge(
                    reference[["animal_id", metric]].rename(
                        columns={metric: "all_cell_primary"}
                    ),
                    on="animal_id",
                    how="inner",
                    validate="one_to_one",
                )
                n_current, rho_current, p_current = _spearman(
                    pd.to_numeric(current[columns["subset"]], errors="coerce"),
                    pd.to_numeric(current["all_cell_primary"], errors="coerce"),
                )
                sensitivity_rows.append(
                    {
                        "metric": metric,
                        "specification": specification,
                        "n": n_current,
                        "rho_to_frozen_primary": rho_current,
                        "p": p_current,
                    }
                )
    fixed_medians = pd.DataFrame()
    for table in subset_median_tables:
        fixed_medians = (
            table
            if fixed_medians.empty
            else fixed_medians.merge(
                table, on="animal_id", how="outer", validate="one_to_one"
            )
        )
    return {
        "reliability_summary": pd.DataFrame(reliability_rows),
        "cell_subset_rank_stability": pd.DataFrame(subset_rows),
        "fixed_subset_split_reliability": pd.DataFrame(subset_split_rows),
        "fixed_subset_pairwise_reproducibility": pd.DataFrame(subset_pair_rows),
        "fixed_subset_median_values": fixed_medians,
        "ar_bin_rank_sensitivity": pd.DataFrame(sensitivity_rows),
    }


def audit_reference_arcrit_results(
    reference_results: pd.DataFrame,
    inventory: pd.DataFrame,
    *,
    structure_gain: pd.DataFrame | None = None,
    elpc: pd.DataFrame | None = None,
    input_audit: pd.DataFrame | None = None,
    reliability_summary: pd.DataFrame | None = None,
    separability_abs_rho: float = 0.80,
) -> dict[str, pd.DataFrame | dict[str, Any]]:
    """Validate and summarize externally produced S-only reference results."""

    missing = [
        column for column in REFERENCE_COLUMNS if column not in reference_results
    ]
    if missing:
        raise KeyError(f"reference result table missing columns: {missing}")
    results = reference_results.copy()
    results["animal_id"] = results["animal_id"].astype(str)
    results["session_id"] = results["session_id"].astype(str)
    if results.duplicated(["animal_id", "session_id"]).any():
        raise ValueError("reference results contain duplicate animal/session rows")
    numeric = pd.to_numeric(results["dist_arcrit_S"], errors="coerce")
    if not np.isfinite(numeric).all():
        raise ValueError("dist_arcrit_S must be finite for every supplied row")
    results["dist_arcrit_S"] = numeric
    if results["bin_width_s"].nunique(dropna=False) != 1:
        raise ValueError("reference results mix bin widths")
    if results["ar_order"].nunique(dropna=False) != 1:
        raise ValueError("reference results mix AR orders")
    if not np.isclose(
        pd.to_numeric(results["bin_width_s"], errors="coerce"), 0.04
    ).all():
        raise ValueError("reference primary must use frozen 40-ms bins")
    if not pd.to_numeric(results["ar_order"], errors="coerce").eq(10).all():
        raise ValueError("reference primary must use frozen AR(10)")
    if (
        not results["reference_estimator"]
        .astype(str)
        .eq(EXPECTED_REFERENCE_ESTIMATOR)
        .all()
    ):
        raise ValueError(
            "reference estimator identity does not match the frozen contract"
        )
    if (
        not results["reference_version"]
        .astype(str)
        .eq(EXPECTED_REFERENCE_VERSION)
        .all()
    ):
        raise ValueError("reference toolkit version does not match the frozen contract")
    if (
        not results["calc_db_sha256"]
        .astype(str)
        .str.lower()
        .eq(EXPECTED_CALC_DB_SHA256)
        .all()
    ):
        raise ValueError("calc_db.m SHA-256 does not match the frozen reference")
    if "primary_qc_pass" in results and not _as_bool(results["primary_qc_pass"]).all():
        raise ValueError("reference result table contains rows that failed primary QC")
    if (
        "exit_status" in results
        and not (pd.to_numeric(results["exit_status"], errors="coerce") == 0).all()
    ):
        raise ValueError("reference result table contains nonzero calc_db exit status")
    if (
        "critical_manifold_beta" in results
        and not (
            pd.to_numeric(results["critical_manifold_beta"], errors="coerce") == 2
        ).all()
    ):
        raise ValueError("dist_arcrit_S must use the beta=2 critical manifold")
    if (
        "fit_method" in results
        and not results["fit_method"].astype(str).eq("YuleWalker").all()
    ):
        raise ValueError("reference result table must use the frozen YuleWalker fit")
    if (
        "dist_arcrit_S_units" in results
        and not results["dist_arcrit_S_units"].astype(str).eq("bits_per_second").all()
    ):
        raise ValueError("Sooter dist_arcrit_S must be reported in bits_per_second")
    if not results["hengen_euclidean_d2_units"].astype(str).eq("dimensionless").all():
        raise ValueError("Hengen Euclidean distance must be dimensionless")
    for predictor in OPTIONAL_REFERENCE_PREDICTORS:
        if predictor in results:
            values = pd.to_numeric(results[predictor], errors="coerce")
            if not np.isfinite(values).all():
                raise ValueError(f"{predictor} must be finite for every supplied row")
            results[predictor] = values
    if {"kernel_json", "hengen_euclidean_d2_S"}.issubset(results.columns):
        recalculated = results["kernel_json"].map(
            lambda value: hengen_euclidean_d2(
                np.asarray(json.loads(value), dtype=float)
            )
        )
        if not np.allclose(
            recalculated,
            results["hengen_euclidean_d2_S"],
            rtol=1e-10,
            atol=1e-12,
        ):
            raise ValueError(
                "Hengen Euclidean d2 does not match the exported AR kernel"
            )

    ready = inventory.loc[
        inventory["dist_arcrit_S_ready"].astype(str).str.lower().eq("true")
    ].copy()
    ready["animal_id"] = ready["animal_id"].astype(str)
    ready["session_day1"] = ready["session_day1"].astype(str)
    expected_pairs = set(zip(ready["animal_id"], ready["session_day1"], strict=False))
    supplied_pairs = set(zip(results["animal_id"], results["session_id"], strict=False))
    if supplied_pairs != expected_pairs:
        missing_pairs = sorted(expected_pairs - supplied_pairs)
        extra_pairs = sorted(supplied_pairs - expected_pairs)
        raise ValueError(
            f"reference result session set mismatch; missing={missing_pairs}, "
            f"extra={extra_pairs}"
        )
    audit = ready[["animal_id", "session_day1", "cohort_group"]].merge(
        results,
        left_on=["animal_id", "session_day1"],
        right_on=["animal_id", "session_id"],
        how="left",
        validate="one_to_one",
    )
    audit["reference_result_present"] = audit["dist_arcrit_S"].notna()

    joined = results.copy()
    if "cohort_group" not in joined.columns:
        joined = joined.merge(
            ready[["animal_id", "session_day1", "cohort_group"]].rename(
                columns={"session_day1": "session_id"}
            ),
            on=["animal_id", "session_id"],
            how="left",
            validate="one_to_one",
        )
    if input_audit is not None and len(input_audit):
        provenance = input_audit.copy()
        provenance["animal_id"] = provenance["animal_id"].astype(str)
        provenance["session_id"] = provenance["session_id"].astype(str)
        keep_columns = [
            column
            for column in provenance.columns
            if column not in joined.columns or column in {"animal_id", "session_id"}
        ]
        joined = joined.merge(
            provenance[keep_columns],
            on=["animal_id", "session_id"],
            how="left",
            validate="one_to_one",
        )
        if {"population_S_mean", "n_cells"}.issubset(joined.columns):
            joined["population_S_mean_per_cell"] = pd.to_numeric(
                joined["population_S_mean"], errors="coerce"
            ) / pd.to_numeric(joined["n_cells"], errors="coerce")
    if structure_gain is not None and len(structure_gain):
        gain = structure_gain.copy()
        gain["animal_id"] = gain["animal_id"].astype(str)
        joined = joined.merge(
            gain[
                [
                    column
                    for column in (
                        "animal_id",
                        "psi_B",
                        "psi_C",
                        "delta_psi",
                        "p_bs_B",
                        "p_bs_C",
                        "delta_p_bs",
                    )
                    if column in gain
                ]
            ],
            on="animal_id",
            how="left",
            validate="one_to_one",
        )
    if elpc is not None and len(elpc):
        elpc_table = elpc.copy()
        elpc_table["animal_id"] = elpc_table["animal_id"].astype(str)
        joined = joined.merge(
            elpc_table[
                [column for column in ("animal_id", "ELPC_A") if column in elpc_table]
            ],
            on="animal_id",
            how="left",
            validate="one_to_one",
        )

    statistics_rows = []
    predictors = ("dist_arcrit_S",) + tuple(
        predictor for predictor in OPTIONAL_REFERENCE_PREDICTORS if predictor in joined
    )
    outcomes = tuple(
        outcome
        for outcome in ("delta_psi", "delta_p_bs", "ELPC_A")
        if outcome in joined
    )
    tier_masks = {
        "pooled_S_ready": pd.Series(True, index=joined.index),
        "reward_free_latent_plus_dry": joined["cohort_group"].isin(
            ["unrewarded_no_water", "unrewarded_dry_waterport"]
        ),
        "latent_no_water_only": joined["cohort_group"].eq("unrewarded_no_water"),
        "rewarded_from_day1_only": joined["cohort_group"].eq("rewarded"),
        "dry_port_only": joined["cohort_group"].eq("unrewarded_dry_waterport"),
    }
    if "window_entirely_pre_reward" in joined:
        tier_masks["entirely_prereward_window"] = _as_bool(
            joined["window_entirely_pre_reward"]
        )
    reliability_lookup: dict[str, dict[str, Any]] = {}
    if reliability_summary is not None and len(reliability_summary):
        reliability_lookup = reliability_summary.set_index("metric").to_dict("index")
    primary_metric_hypothesis = {
        "hengen_euclidean_d2_S": "H-N2a",
        "dist_arcrit_S": "H-N2b",
    }
    metric_hypothesis = {
        **primary_metric_hypothesis,
        "hengen_euclidean_d2_S_fixed150_median": "H-N2a",
        "dist_arcrit_S_fixed150_median": "H-N2b",
    }
    seed_counter = 0
    for predictor in predictors:
        for outcome in outcomes:
            for tier, mask in tier_masks.items():
                current = joined.loc[mask]
                detail = _spearman_detail(
                    current[predictor],
                    current[outcome],
                    seed=20260725 + seed_counter,
                )
                seed_counter += 1
                reliability = reliability_lookup.get(predictor, {})
                expected_negative = predictor in metric_hypothesis and outcome in {
                    "delta_psi",
                    "delta_p_bs",
                }
                statistics_rows.append(
                    {
                        "hypothesis_id": metric_hypothesis.get(
                            predictor, "diagnostic_control"
                        ),
                        "contrast": f"{predictor}_vs_{outcome}",
                        "analysis_variant": (
                            "fixed150_median_sampling_rescue"
                            if predictor.endswith("_fixed150_median")
                            else "frozen_all_cell_primary"
                        ),
                        "predictor": predictor,
                        "outcome": outcome,
                        "cohort_tier": tier,
                        **detail,
                        "expected_direction": (
                            "negative" if expected_negative else "not_prespecified"
                        ),
                        "expected_direction_agreement": (
                            bool(detail["rho"] < 0)
                            if expected_negative and np.isfinite(detail["rho"])
                            else np.nan
                        ),
                        "measurement_pass": reliability.get("measurement_pass", np.nan),
                        "spearman_brown": reliability.get("spearman_brown", np.nan),
                        "median_subset_rho_to_all_cells": reliability.get(
                            "median_subset_rho_to_all_cells", np.nan
                        ),
                    }
                )
    statistics_table = pd.DataFrame(statistics_rows)
    diagnostic_rows = []
    diagnostic_targets = [
        target
        for target in (
            "n_cells",
            "population_S_mean_per_cell",
            "population_S_nonzero_fraction",
            "ar_dominant_tau_s",
            "ELPC_A",
        )
        if target in joined
    ]
    for metric, hypothesis_id in metric_hypothesis.items():
        if metric not in joined:
            continue
        for target_index, target in enumerate(diagnostic_targets):
            detail = _spearman_detail(
                joined[metric],
                joined[target],
                seed=20269000 + target_index + 100 * len(diagnostic_rows),
            )
            diagnostic_rows.append(
                {
                    "hypothesis_id": hypothesis_id,
                    "metric": metric,
                    "analysis_variant": (
                        "fixed150_median_sampling_rescue"
                        if metric.endswith("_fixed150_median")
                        else "frozen_all_cell_primary"
                    ),
                    "diagnostic_target": target,
                    **detail,
                    "claim_cap": "rival-explanation diagnostic; no causal adjustment claim",
                }
            )
    diagnostic_table = pd.DataFrame(diagnostic_rows)
    adjusted_rows = []
    adjusted_contracts = (
        ("delta_psi", "psi_C", "psi_B"),
        ("delta_p_bs", "p_bs_C", "p_bs_B"),
    )
    adjusted_tiers = {
        "pooled_S_ready": tier_masks["pooled_S_ready"],
        "reward_free_latent_plus_dry": tier_masks["reward_free_latent_plus_dry"],
    }
    adjusted_seed = 20261700
    for metric, hypothesis_id in metric_hypothesis.items():
        for outcome, late, baseline in adjusted_contracts:
            if not {metric, late, baseline}.issubset(joined.columns):
                continue
            for tier, mask in adjusted_tiers.items():
                current = joined.loc[mask].copy()
                controls = (
                    ["population_S_mean_per_cell"]
                    if "population_S_mean_per_cell" in current
                    else []
                )
                detail = _rank_ancova(
                    current,
                    predictor=metric,
                    late=late,
                    baseline=baseline,
                    controls=controls,
                    context_column="cohort_group",
                    seed=adjusted_seed,
                )
                adjusted_seed += 1
                adjusted_rows.append(
                    {
                        "hypothesis_id": hypothesis_id,
                        "metric": metric,
                        "outcome": outcome,
                        "late_score": late,
                        "baseline_score": baseline,
                        "cohort_tier": tier,
                        "controls": "+".join(controls) or "none",
                        **detail,
                        "expected_direction": "negative",
                        "expected_direction_agreement": (
                            bool(detail["beta"] < 0)
                            if np.isfinite(detail["beta"])
                            else np.nan
                        ),
                        "measurement_error_caveat": "baseline policy is estimated with error; disagreement with raw change-score analysis is diagnostic",
                    }
                )
    adjusted_table = pd.DataFrame(adjusted_rows)
    elpc_row = statistics_table.loc[
        statistics_table.get("contrast", pd.Series(dtype=str)).eq(
            "dist_arcrit_S_vs_ELPC_A"
        )
    ]
    elpc_rho = float(elpc_row.iloc[0]["rho"]) if len(elpc_row) else np.nan
    complete = int(audit["reference_result_present"].sum()) == int(len(ready))
    separable = bool(
        np.isfinite(elpc_rho) and abs(elpc_rho) < float(separability_abs_rho)
    )
    if not complete:
        status = "reference_results_incomplete"
    elif "ELPC_A" not in joined or not np.isfinite(elpc_rho):
        status = "estimated_complete_ELPC_relationship_not_estimable"
    elif not separable:
        status = "estimated_complete_high_ELPC_rank_collinearity"
    else:
        status = "estimated_complete_low_ELPC_rank_collinearity_only"
    metric_statuses = {}
    metric_status_details = {}
    for metric, hypothesis_id in primary_metric_hypothesis.items():
        reliability = reliability_lookup.get(metric, {})
        if not complete:
            metric_status = "reference_results_incomplete"
        elif not reliability:
            metric_status = "measurement_reliability_not_evaluated"
        elif not bool(reliability.get("measurement_pass", False)):
            metric_status = "measurement_unresolved"
        elif not any(
            statistics_table["predictor"].eq(metric)
            & statistics_table["outcome"].isin(["delta_psi", "delta_p_bs"])
            & statistics_table["n"].ge(4)
        ):
            metric_status = "outcome_not_estimable"
        else:
            focal = statistics_table.loc[
                statistics_table["predictor"].eq(metric)
                & statistics_table["outcome"].eq("delta_p_bs")
                & statistics_table["cohort_tier"].eq("pooled_S_ready")
            ]
            if not len(focal):
                metric_status = "estimated_no_clear_association"
            else:
                focal_row = focal.iloc[0]
                rho = float(focal_row["rho"])
                p_value = float(focal_row["p"])
                loo_max = float(focal_row["loo_rho_max"])
                ci_low = float(focal_row["ci_low"])
                ci_high = float(focal_row["ci_high"])
                if rho < 0 and p_value < 0.05 and loo_max < 0:
                    metric_status = "associative_support_secondary_endpoint"
                elif rho < 0:
                    metric_status = "estimated_direction_consistent_uncertain"
                elif rho > 0 and p_value < 0.05 and ci_low > 0:
                    metric_status = "estimated_opposite_direction"
                else:
                    metric_status = "estimated_no_clear_association"
                metric_status_details[hypothesis_id] = {
                    "focal_outcome": "delta_p_bs",
                    "rho": rho,
                    "p": p_value,
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                    "loo_rho_max": loo_max,
                    "claim_cap": "secondary empirically supported behavioral endpoint; associative only",
                }
                rescue_metric = f"{metric}_fixed150_median"
                rescue = statistics_table.loc[
                    statistics_table["predictor"].eq(rescue_metric)
                    & statistics_table["outcome"].eq("delta_p_bs")
                    & statistics_table["cohort_tier"].eq("pooled_S_ready")
                ]
                if len(rescue):
                    rescue_row = rescue.iloc[0]
                    rescue_rho = float(rescue_row["rho"])
                    rescue_p = float(rescue_row["p"])
                    metric_status_details[hypothesis_id].update(
                        {
                            "fixed150_median_rescue_rho": rescue_rho,
                            "fixed150_median_rescue_p": rescue_p,
                        }
                    )
                    if rho < 0 and not (rescue_rho < 0):
                        metric_status = "association_sampling_sensitive_unresolved"
        metric_statuses[hypothesis_id] = metric_status
    summary = {
        "status": status,
        "n_ready": int(len(ready)),
        "n_reference_results": int(audit["reference_result_present"].sum()),
        "reference_estimators": sorted(
            results["reference_estimator"].astype(str).unique()
        ),
        "reference_versions": sorted(results["reference_version"].astype(str).unique()),
        "separability_abs_rho_threshold": float(separability_abs_rho),
        "dist_arcrit_S_vs_ELPC_A_rho": elpc_rho,
        "ELPC_relationship_interpretation": "descriptive rank collinearity only; ELPC failed its reliability gate and cannot establish construct separability or incremental information",
        "metric_contract": {
            "dist_arcrit_S": "Sooter calc_db beta=2 KL-divergence-rate distance in bits/s",
            "hengen_euclidean_d2_S": "dimensionless abs(1-sum(phi))/sqrt(p)",
        },
        "causal_claim_allowed": False,
        "metric_statuses": metric_statuses,
        "metric_status_details": metric_status_details,
    }
    return {
        "reference_coverage_audit": audit,
        "joined_inputs": joined,
        "statistics": statistics_table,
        "adjusted_statistics": adjusted_table,
        "diagnostic_relationships": diagnostic_table,
        "summary": summary,
    }


__all__ = [
    "OPTIONAL_REFERENCE_PREDICTORS",
    "REFERENCE_COLUMNS",
    "audit_reference_arcrit_results",
    "hengen_euclidean_d2",
    "segmented_population_s",
    "summarize_reference_diagnostics",
]
