from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from typing import Any, Callable

import h5py
import numpy as np
import pandas as pd

from .config import FPS, REWARD_NODE, get_behav_wd, get_neural_wd, get_repo_root
from .io import _extract_info
from .maze import Maze, NewMaze
from .trajectory import LoadTraj, SplitModeClips, TimeInMaze


MODE_LABELS = {-1: "unassigned", 0: "leave", 1: "drink", 2: "explore"}
EXPLORE_MODE = 2

DEFAULT_COHORT_MANIFEST = (
    get_repo_root()
    / "docs"
    / "reward_port_introduction_no_waterport_2026-05-28"
    / "report"
    / "cohort_manifest.csv"
)
DEFAULT_OUTPUT_DIR = (
    get_repo_root() / "docs" / "rapid_learning_structure_reward_2026-07-15" / "phase0"
)
DEFAULT_SORTED_NEURAL_WD = Path(r"D:\neuralData_sort")
DEFAULT_IDENTITY_PROVENANCE = (
    get_repo_root()
    / "docs"
    / "extended_data_figure_panel_refresh_2026-07-12"
    / "source_tables"
    / "extended_data_fig_07"
    / "ed07_joint_component_identity_provenance_current59.csv"
)

# Frozen from the maintained Level-2 cohort manifest.  This explicit list makes
# cohort drift fail loudly instead of silently changing the Phase-0 estimand.
FROZEN_PAIR_KEYS: tuple[tuple[str, str, str], ...] = (
    ("769day1", "769day2", "unrewarded_no_water"),
    ("838day1", "838day2", "unrewarded_no_water"),
    ("837day1", "837day2", "unrewarded_no_water"),
    ("839day1", "839day2", "unrewarded_no_water"),
    ("841day1", "841day2", "unrewarded_no_water"),
    ("842day1", "842day2", "unrewarded_no_water"),
    ("862day1", "862day2", "unrewarded_no_water"),
    ("1636Rday1", "1636Rday2", "unrewarded_no_water"),
    ("325RLday1", "325RLday2", "unrewarded_no_water"),
    ("1616day1", "1616day2", "rewarded"),
    ("163RLday1", "163RLday2", "rewarded"),
    ("1632Lday1", "1632Lday2", "rewarded"),
    ("418RRday1", "418RRday2", "rewarded"),
    ("434RRday1", "434RRday2", "rewarded"),
    ("451Rday1", "451Rday2", "rewarded"),
    ("488Rday1", "488Rday2", "rewarded"),
    ("489Lday1", "489Lday2", "rewarded"),
    ("579RLday1", "579RLday2", "rewarded"),
    ("468Lday1", "468Lday2", "rewarded"),
    ("1639RRday1", "1639RRday2", "unrewarded_dry_waterport"),
    ("347RLday1", "347RLday2", "unrewarded_dry_waterport"),
    ("422RRday1", "422RRday2", "unrewarded_dry_waterport"),
    ("1637Lday1", "1637Lday2", "unrewarded_dry_waterport"),
)

EXPECTED_GROUP_COUNTS = {
    "unrewarded_no_water": 9,
    "rewarded": 10,
    "unrewarded_dry_waterport": 4,
}

# These are input-readiness gates, not inferential thresholds.  Downstream
# analyses must still predeclare their own support requirements.
MIN_STRUCTURE_EXPLORE_DECISIONS = 10
MIN_POST_REWARD_DECISIONS = 5
MIN_ELPC_EXPLORE_SELECTED_ROWS = 50


@dataclass(frozen=True)
class Phase0Tables:
    inventory: pd.DataFrame
    session_support: pd.DataFrame
    transitions: pd.DataFrame
    decisions: pd.DataFrame
    mode_clips: pd.DataFrame
    reward_events: pd.DataFrame


def _as_bool(value: Any) -> bool:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value)


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return [_json_ready(v) for v in value.tolist()]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value) if np.isfinite(value) else None
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value


def load_frozen_cohort_manifest(
    path: str | Path = DEFAULT_COHORT_MANIFEST,
) -> pd.DataFrame:
    path = Path(path).resolve()
    cohort = pd.read_csv(path)
    required = {
        "session_day1",
        "session_day2",
        "animal_id",
        "cohort_group",
        "cohort_label",
        "day1_waterport_status",
        "analysis_ready_neural",
        "exclusion_reason",
    }
    missing = required.difference(cohort.columns)
    if missing:
        raise ValueError(f"Cohort manifest is missing columns: {sorted(missing)}")

    keys = [
        (str(row.session_day1), str(row.session_day2), str(row.cohort_group))
        for row in cohort.itertuples(index=False)
    ]
    if len(keys) != len(set(keys)):
        raise ValueError("Cohort manifest contains duplicate Day1-Day2-cohort rows.")
    expected = set(FROZEN_PAIR_KEYS)
    observed = set(keys)
    if observed != expected:
        missing_keys = sorted(expected.difference(observed))
        extra_keys = sorted(observed.difference(expected))
        raise ValueError(
            "Frozen 23-pair cohort mismatch: "
            f"missing={missing_keys}; extra={extra_keys}"
        )
    counts = cohort["cohort_group"].value_counts().to_dict()
    if counts != EXPECTED_GROUP_COUNTS:
        raise ValueError(
            f"Frozen cohort count mismatch: expected {EXPECTED_GROUP_COUNTS}, observed {counts}"
        )

    order = {key: idx for idx, key in enumerate(FROZEN_PAIR_KEYS, start=1)}
    cohort = cohort.copy()
    cohort["_key"] = list(
        zip(cohort.session_day1, cohort.session_day2, cohort.cohort_group)
    )
    cohort["frozen_pair_index"] = cohort["_key"].map(order).astype(int)
    cohort = (
        cohort.sort_values("frozen_pair_index")
        .drop(columns="_key")
        .reset_index(drop=True)
    )
    cohort["pair_id"] = (
        cohort["session_day1"].astype(str) + "__" + cohort["session_day2"].astype(str)
    )
    cohort["cohort_manifest_path"] = str(path)
    cohort["legacy_s_pair_ready"] = cohort["analysis_ready_neural"].map(_as_bool)
    cohort["forced_behavior_only"] = cohort["session_day1"].astype(str).eq("769day1")
    cohort["day1_reward_available"] = cohort["cohort_group"].astype(str).eq("rewarded")
    cohort["day2_reward_available"] = True
    cohort["canonical_reward_node"] = int(REWARD_NODE)
    return cohort


def load_identity_provenance(
    path: str | Path = DEFAULT_IDENTITY_PROVENANCE,
) -> pd.DataFrame:
    """Load the maintained same-stage component-identity provenance table."""

    path = Path(path).resolve()
    identity = pd.read_csv(path)
    required = {
        "pair_id",
        "session_a",
        "session_b",
        "effective_matching_mode",
        "shared_component_basis",
        "cimap_required",
        "target_neural_source",
        "reference_neural_source",
        "target_neural_wd",
        "reference_neural_wd",
        "provenance_basis",
    }
    missing = required.difference(identity.columns)
    if missing:
        raise ValueError(f"Identity provenance is missing columns: {sorted(missing)}")
    if identity["pair_id"].astype(str).duplicated().any():
        duplicated = (
            identity.loc[
                identity["pair_id"].astype(str).duplicated(keep=False), "pair_id"
            ]
            .astype(str)
            .tolist()
        )
        raise ValueError(f"Identity provenance has duplicate pair IDs: {duplicated}")
    identity = identity.copy()
    identity["identity_provenance_path"] = str(path)
    return identity


def _neural_dir_and_file(
    session_id: str,
    neural_wd: str | Path,
) -> tuple[Path | None, Path | None, str]:
    parsed = _extract_info(str(session_id))
    if parsed is None:
        return None, None, "parse_failed"
    mouse_id, exp_type, exp_date = parsed
    neural_dir = Path(neural_wd) / mouse_id
    if exp_type != 0:
        neural_dir = Path(neural_wd) / f"{mouse_id}-{exp_type}"
    candidates = [
        neural_dir / f"final_day{exp_date}.mat",
        neural_dir / f"{exp_date}.mat",
        neural_dir / f"day{exp_date}.mat",
        neural_dir / f"final_{exp_date}.mat",
    ]
    neural_file = next(
        (candidate for candidate in candidates if candidate.exists()), None
    )
    return (
        neural_dir,
        neural_file,
        "ok" if neural_file is not None else "missing_neural_file",
    )


def resolve_neural_source(
    session_id: str,
    *,
    original_neural_wd: str | Path,
    sorted_neural_wd: str | Path,
) -> dict[str, Any]:
    """Resolve one session with a visible sorted-first/original-fallback policy."""

    sorted_dir, sorted_file, sorted_status = _neural_dir_and_file(
        session_id, sorted_neural_wd
    )
    original_dir, original_file, original_status = _neural_dir_and_file(
        session_id, original_neural_wd
    )
    if sorted_file is not None:
        source = "sorted"
        root = Path(sorted_neural_wd)
        neural_dir = sorted_dir
        neural_file = sorted_file
        status = "ok"
    elif original_file is not None:
        source = "original_fallback"
        root = Path(original_neural_wd)
        neural_dir = original_dir
        neural_file = original_file
        status = "ok"
    else:
        source = "missing"
        root = Path(sorted_neural_wd)
        neural_dir = sorted_dir
        neural_file = None
        status = "missing_sorted_and_original"
    return {
        "neural_source_policy": "sorted_first",
        "neural_source": source,
        "neural_root": str(root),
        "neural_dir": "" if neural_dir is None else str(neural_dir),
        "neural_file": "" if neural_file is None else str(neural_file),
        "neural_lookup_status": status,
        "sorted_neural_root": str(Path(sorted_neural_wd)),
        "sorted_neural_file": "" if sorted_file is None else str(sorted_file),
        "sorted_neural_lookup_status": sorted_status,
        "original_neural_root": str(Path(original_neural_wd)),
        "original_neural_file": "" if original_file is None else str(original_file),
        "original_neural_lookup_status": original_status,
    }


def inspect_neural_metadata(neural_file: str | Path | None) -> dict[str, Any]:
    """Inspect HDF5 keys/shapes without materializing calcium arrays."""

    base: dict[str, Any] = {
        "has_C": False,
        "has_C_raw": False,
        "has_S_legacy": False,
        "C_storage_type": "missing",
        "C_stored_shape": "",
        "C_n_time": 0,
        "C_n_cells": 0,
        "C_metadata_status": "missing_C",
        "S_storage_type": "missing",
        "S_stored_shape": "",
        "S_n_time": 0,
        "S_n_cells": 0,
        "S_metadata_status": "missing_S",
        "neural_metadata_status": "missing_neural_file",
    }
    if neural_file is None or str(neural_file).strip() == "":
        return base
    path = Path(neural_file)
    if not path.exists():
        return {**base, "neural_metadata_status": "missing_neural_file"}
    try:
        with h5py.File(path, "r") as handle:
            base["has_C_raw"] = "C_raw" in handle

            def _inspect_signal(name: str) -> None:
                has_key = "has_C" if name == "C" else "has_S_legacy"
                if name not in handle:
                    return
                obj = handle[name]
                base[has_key] = True
                if isinstance(obj, h5py.Dataset):
                    shape = tuple(int(value) for value in obj.shape)
                    base[f"{name}_storage_type"] = "dense_hdf5_dataset"
                    base[f"{name}_stored_shape"] = "x".join(
                        str(value) for value in shape
                    )
                    if len(shape) != 2:
                        base[
                            f"{name}_metadata_status"
                        ] = f"{name}_rank_{len(shape)}_not_2"
                        return
                    # MATLAB v7.3 arrays are stored frames x components;
                    # maintained loaders transpose to components x frames.
                    base[f"{name}_n_time"] = int(shape[0])
                    base[f"{name}_n_cells"] = int(shape[1])
                    base[f"{name}_metadata_status"] = "ok"
                    return
                if isinstance(obj, h5py.Group):
                    base[f"{name}_storage_type"] = "sparse_hdf5_group"
                    base[f"{name}_stored_shape"] = "group"
                    base[f"{name}_metadata_status"] = f"unsupported_sparse_{name}_group"
                    return
                base[f"{name}_storage_type"] = type(obj).__name__
                base[f"{name}_metadata_status"] = f"unsupported_{name}_storage"

            _inspect_signal("C")
            _inspect_signal("S")
            base["neural_metadata_status"] = str(base["C_metadata_status"])
            return base
    except Exception as exc:
        return {
            **base,
            "neural_metadata_status": f"failed:{type(exc).__name__}:{exc}",
        }


def mode_split_include_reward(cohort_group: str, day_index: int) -> bool:
    """Return the frozen splitter setting for a cohort/day.

    No-water and dry-waterport Day 1 sessions must use ``re=False`` so a
    geometric visit to node 94 is not promoted to a reward/drink clip.
    """

    return not (
        int(day_index) == 1
        and str(cohort_group) in {"unrewarded_no_water", "unrewarded_dry_waterport"}
    )


def _safe_time_in_maze(abs_frame: float, tf: Any) -> float:
    try:
        return float(TimeInMaze(float(abs_frame), tf))
    except Exception:
        return np.nan


def extract_actual_reward_events(tf: Any) -> pd.DataFrame:
    """Extract rewards only from ``tf.re``; node identity is never a reward proxy."""

    rows: list[dict[str, Any]] = []
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    reward_bouts = getattr(tf, "re", []) or []
    n_bouts = len(getattr(tf, "no", []) or [])
    if n_bouts and len(reward_bouts) > n_bouts:
        raise ValueError(
            f"tf.re has {len(reward_bouts)} bouts but tf.no has {n_bouts}."
        )
    for bout, reward_arr in enumerate(reward_bouts):
        arr = np.asarray(reward_arr)
        if arr.size == 0:
            continue
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        if arr.ndim != 2 or arr.shape[1] < 1:
            continue
        if fr.ndim != 2 or fr.shape[1] < 1 or bout >= fr.shape[0]:
            raise ValueError(
                f"Cannot convert tf.re bout {bout} to absolute frames: tf.fr is invalid."
            )
        bout_start = float(fr[bout, 0])
        for local_event_index, local_frame_raw in enumerate(arr[:, 0]):
            try:
                local_frame = float(local_frame_raw)
            except (TypeError, ValueError):
                continue
            if not np.isfinite(local_frame):
                continue
            abs_frame = float(bout_start + local_frame)
            local_end = np.nan
            if arr.shape[1] >= 2:
                try:
                    local_end = float(arr[local_event_index, 1])
                except (TypeError, ValueError):
                    local_end = np.nan
            if not np.isfinite(local_end):
                local_end = np.nan
            abs_end = (
                float(bout_start + local_end) if np.isfinite(local_end) else np.nan
            )
            rows.append(
                {
                    "bout": int(bout),
                    "reward_event_index_in_bout": int(local_event_index),
                    "reward_local_frame": local_frame,
                    "reward_local_frame_end": local_end,
                    "reward_abs_frame": abs_frame,
                    "reward_abs_frame_end": abs_end,
                    "reward_duration_frames": (
                        float(local_end - local_frame)
                        if np.isfinite(local_end)
                        else np.nan
                    ),
                    "reward_maze_seconds": _safe_time_in_maze(abs_frame, tf),
                    "reward_source": "tf.re",
                }
            )
    columns = [
        "reward_event_index",
        "bout",
        "reward_event_index_in_bout",
        "reward_local_frame",
        "reward_local_frame_end",
        "reward_abs_frame",
        "reward_abs_frame_end",
        "reward_duration_frames",
        "reward_maze_seconds",
        "reward_source",
    ]
    if not rows:
        return pd.DataFrame(columns=columns)
    out = (
        pd.DataFrame(rows)
        .sort_values(["reward_abs_frame", "bout", "reward_event_index_in_bout"])
        .reset_index(drop=True)
    )
    out.insert(0, "reward_event_index", np.arange(len(out), dtype=int))
    return out[columns]


def _mode_clip_tables(
    tf: Any,
    ma: Maze,
    *,
    include_reward: bool,
    split_mode_fn: Callable[..., Any] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    split_mode_fn = SplitModeClips if split_mode_fn is None else split_mode_fn
    clips = np.asarray(split_mode_fn(tf, ma, re=bool(include_reward)), dtype=int)
    if clips.size == 0:
        clips = np.zeros((0, 4), dtype=int)
    if clips.ndim != 2 or clips.shape[1] < 4:
        raise ValueError(f"Invalid SplitModeClips shape: {clips.shape}")

    no_list = getattr(tf, "no", []) or []
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    clip_rows: list[dict[str, Any]] = []
    transition_rows: list[dict[str, Any]] = []
    for clip_index, clip in enumerate(clips[:, :4]):
        bout, start, nstep, mode = (int(v) for v in clip)
        if bout < 0 or bout >= len(no_list):
            raise ValueError(f"Mode clip {clip_index} has invalid bout {bout}.")
        if start < 0 or nstep < 0:
            raise ValueError(
                f"Mode clip {clip_index} has negative start/nstep: {start}/{nstep}."
            )
        nodes = np.asarray(no_list[bout])
        if nodes.ndim != 2 or nodes.shape[1] < 2:
            raise ValueError(f"Trajectory bout {bout} lacks node/frame columns.")
        segment = nodes[start : start + nstep + 1]
        if segment.shape[0] != nstep + 1:
            raise ValueError(
                f"Mode clip {clip_index} needs nstep+1={nstep + 1} node rows, "
                f"found {segment.shape[0]}."
            )
        if fr.ndim != 2 or fr.shape[1] < 1 or bout >= fr.shape[0]:
            raise ValueError(
                f"Mode clip {clip_index} cannot resolve tf.fr bout {bout}."
            )
        bout_start = float(fr[bout, 0])
        clip_start_abs = float(bout_start + segment[0, 1]) if segment.size else np.nan
        clip_end_abs = float(bout_start + segment[-1, 1]) if segment.size else np.nan
        clip_rows.append(
            {
                "clip_index": int(clip_index),
                "bout": bout,
                "clip_start_transition": start,
                "clip_n_transitions": nstep,
                "mode_code": mode,
                "mode_label": MODE_LABELS.get(mode, "unknown"),
                "splitter_include_reward": bool(include_reward),
                "clip_abs_frame_start": clip_start_abs,
                "clip_abs_frame_end": clip_end_abs,
                "clip_maze_seconds_start": _safe_time_in_maze(clip_start_abs, tf),
                "clip_maze_seconds_end": _safe_time_in_maze(clip_end_abs, tf),
            }
        )
        for offset in range(nstep):
            current = segment[offset]
            nxt = segment[offset + 1]
            transition_rows.append(
                {
                    "clip_index": int(clip_index),
                    "bout": bout,
                    "transition_index_in_bout": int(start + offset),
                    "clip_transition_offset": int(offset),
                    "clip_start_transition": start,
                    "clip_n_transitions": nstep,
                    "mode_code": mode,
                    "mode_label": MODE_LABELS.get(mode, "unknown"),
                    "splitter_include_reward": bool(include_reward),
                    "clip_current_node": int(current[0]),
                    "clip_next_node": int(nxt[0]),
                    "clip_abs_frame_start": float(bout_start + current[1]),
                    "clip_abs_frame_end": float(bout_start + nxt[1]),
                }
            )

    clip_columns = [
        "clip_index",
        "bout",
        "clip_start_transition",
        "clip_n_transitions",
        "mode_code",
        "mode_label",
        "splitter_include_reward",
        "clip_abs_frame_start",
        "clip_abs_frame_end",
        "clip_maze_seconds_start",
        "clip_maze_seconds_end",
    ]
    transition_columns = [
        "clip_index",
        "bout",
        "transition_index_in_bout",
        "clip_transition_offset",
        "clip_start_transition",
        "clip_n_transitions",
        "mode_code",
        "mode_label",
        "splitter_include_reward",
        "clip_current_node",
        "clip_next_node",
        "clip_abs_frame_start",
        "clip_abs_frame_end",
    ]
    clip_df = pd.DataFrame(clip_rows, columns=clip_columns)
    expanded = pd.DataFrame(transition_rows, columns=transition_columns)
    if (
        not expanded.empty
        and expanded.duplicated(["bout", "transition_index_in_bout"]).any()
    ):
        duplicated = expanded.loc[
            expanded.duplicated(["bout", "transition_index_in_bout"], keep=False),
            ["clip_index", "bout", "transition_index_in_bout"],
        ]
        raise ValueError(
            f"Overlapping mode clips assign one transition twice:\n{duplicated}"
        )
    return clip_df, expanded


def expand_mode_clips(
    tf: Any,
    ma: Maze,
    *,
    include_reward: bool,
    split_mode_fn: Callable[..., Any] | None = None,
) -> pd.DataFrame:
    """Expand each clip to exactly ``n_transitions`` adjacent-node rows."""

    return _mode_clip_tables(
        tf,
        ma,
        include_reward=include_reward,
        split_mode_fn=split_mode_fn,
    )[1]


def _trajectory_transitions(tf: Any) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    no_list = getattr(tf, "no", []) or []
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    session_index = 0
    for bout, bout_raw in enumerate(no_list):
        bout_arr = np.asarray(bout_raw)
        if bout_arr.ndim != 2 or bout_arr.shape[1] < 2 or bout_arr.shape[0] < 2:
            continue
        if fr.ndim != 2 or fr.shape[1] < 1 or bout >= fr.shape[0]:
            raise ValueError(f"Trajectory transition cannot resolve tf.fr bout {bout}.")
        bout_start = float(fr[bout, 0])
        for idx in range(bout_arr.shape[0] - 1):
            current = bout_arr[idx]
            nxt = bout_arr[idx + 1]
            prev_node = int(bout_arr[idx - 1, 0]) if idx > 0 else -1
            abs_start = float(bout_start + current[1])
            abs_end = float(bout_start + nxt[1])
            rows.append(
                {
                    "transition_index_session": int(session_index),
                    "bout": int(bout),
                    "transition_index_in_bout": int(idx),
                    "prev_node": prev_node,
                    "current_node": int(current[0]),
                    "next_node": int(nxt[0]),
                    "local_frame_start": float(current[1]),
                    "local_frame_end": float(nxt[1]),
                    "abs_frame_start": abs_start,
                    "abs_frame_end": abs_end,
                    "maze_seconds_start": _safe_time_in_maze(abs_start, tf),
                    "maze_seconds_end": _safe_time_in_maze(abs_end, tf),
                    "transition_duration_frames": float(abs_end - abs_start),
                    "transition_duration_seconds": float((abs_end - abs_start) / FPS),
                    "valid_positive_duration": bool(abs_end > abs_start),
                }
            )
            session_index += 1
    return pd.DataFrame(rows)


def _node_depths(ma: Maze) -> np.ndarray:
    depths = np.full(len(ma.ru), -1, dtype=int)
    for node in range(len(ma.ru)):
        cur = int(node)
        depth = 0
        while cur > 0 and depth <= len(ma.ru):
            cur = int(ma.pa[cur])
            depth += 1
        depths[node] = depth
    return depths


def _add_decision_and_prefix_features(
    transitions: pd.DataFrame, ma: Maze
) -> pd.DataFrame:
    if transitions.empty:
        return transitions.copy()
    out = transitions.copy()
    depths = _node_depths(ma)
    exit_state = len(ma.ru)
    terminal_start = 2 ** int(ma.le) - 1

    decision_rows: list[dict[str, Any]] = []
    seen_nodes: set[int] = set()
    node_visit_counts: dict[int, int] = {}
    active_bout = None
    decision_index = 0
    primary_decision_index = 0
    for row in out.itertuples(index=False):
        bout = int(row.bout)
        current = int(row.current_node)
        nxt = int(row.next_node)
        prev = int(row.prev_node)
        if active_bout != bout:
            active_bout = bout
            seen_nodes.add(current)
            node_visit_counts[current] = node_visit_counts.get(current, 0) + 1

        current_seen_before = current in seen_nodes
        next_seen_before = nxt in seen_nodes
        visited_terminal_count_before = sum(
            terminal_start <= node < len(ma.ru) for node in seen_nodes
        )

        is_internal = 0 <= current < len(ma.ru) and current < terminal_start
        if is_internal:
            children = np.asarray(ma.ch[current]).astype(int).ravel()
            left_child = int(children[0]) if children.size >= 1 else -1
            right_child = int(children[1]) if children.size >= 2 else -1
        else:
            left_child = right_child = -1
        has_two_children = left_child >= 0 and right_child >= 0
        exits_to_child = bool(has_two_children and nxt in {left_child, right_child})
        if current == 0:
            entered_from_parent = prev in {-1, exit_state}
        else:
            parent = int(ma.pa[current]) if 0 <= current < len(ma.pa) else -1
            entered_from_parent = prev == parent
        is_primary = bool(exits_to_child and entered_from_parent)
        choice_side = (
            "left"
            if nxt == left_child
            else ("right" if nxt == right_child else "other")
        )

        decision_rows.append(
            {
                "current_node_seen_before": bool(current_seen_before),
                "next_node_seen_before": bool(next_seen_before),
                "next_node_is_new": bool(
                    0 <= nxt < len(ma.ru) and not next_seen_before
                ),
                "current_node_visit_count_before": int(
                    node_visit_counts.get(current, 0)
                ),
                "next_node_visit_count_before": int(node_visit_counts.get(nxt, 0)),
                "visited_node_count_before": int(
                    sum(0 <= node < len(ma.ru) for node in seen_nodes)
                ),
                "visited_terminal_count_before": int(visited_terminal_count_before),
                "tree_depth": int(depths[current])
                if 0 <= current < len(depths)
                else -1,
                "left_child": left_child,
                "right_child": right_child,
                "has_two_children": bool(has_two_children),
                "exits_to_child": bool(exits_to_child),
                "entered_from_parent": bool(entered_from_parent),
                "is_child_exit_decision": bool(exits_to_child),
                "is_primary_decision": bool(is_primary),
                "choice_side": choice_side,
                "decision_index_session": int(decision_index) if exits_to_child else -1,
                "primary_decision_index_session": int(primary_decision_index)
                if is_primary
                else -1,
            }
        )
        if exits_to_child:
            decision_index += 1
        if is_primary:
            primary_decision_index += 1

        seen_nodes.add(nxt)
        node_visit_counts[nxt] = node_visit_counts.get(nxt, 0) + 1

    return pd.concat([out.reset_index(drop=True), pd.DataFrame(decision_rows)], axis=1)


def _add_reward_features(
    transitions: pd.DataFrame, rewards: pd.DataFrame
) -> pd.DataFrame:
    if transitions.empty:
        return transitions.copy()
    out = transitions.copy()
    reward_frames = (
        rewards["reward_abs_frame"].to_numpy(dtype=float)
        if not rewards.empty
        else np.zeros(0, dtype=float)
    )
    starts = out["abs_frame_start"].to_numpy(dtype=float)
    ends = out["abs_frame_end"].to_numpy(dtype=float)
    before = np.searchsorted(reward_frames, starts, side="right")
    through = np.searchsorted(reward_frames, ends, side="left")
    first_abs = float(reward_frames[0]) if reward_frames.size else np.nan
    first_maze = (
        float(rewards.iloc[0]["reward_maze_seconds"]) if reward_frames.size else np.nan
    )
    out["actual_reward_event_count_session"] = int(reward_frames.size)
    out["first_reward_abs_frame"] = first_abs
    out["first_reward_maze_seconds"] = first_maze
    out["reward_count_before_or_at_transition_start"] = before.astype(int)
    out["reward_received_before_or_at_transition_start"] = before > 0
    out["reward_events_during_transition"] = np.maximum(0, through - before).astype(int)
    out["reward_epoch"] = np.where(
        reward_frames.size == 0,
        "no_reward",
        np.where(before > 0, "post_first_reward", "pre_first_reward"),
    )
    return out


def _selected_frame_summary(selected_df: pd.DataFrame | None) -> dict[str, Any]:
    empty = {
        "selected_n_rows": 0 if selected_df is None else int(len(selected_df)),
        "selected_has_frame": False,
        "selected_frame_values_valid": False,
        "selected_frame_monotonic": False,
        "selected_frame_unique": False,
        "selected_frame_min": np.nan,
        "selected_frame_max": np.nan,
        "selected_frame_contiguous_fraction": np.nan,
        "selected_frame_max_contiguous_run": 0,
    }
    if selected_df is None:
        return empty
    n_rows = int(len(selected_df))
    if "frame" not in selected_df.columns:
        return empty
    raw_frames = pd.to_numeric(selected_df["frame"], errors="coerce").to_numpy(
        dtype=float
    )
    values_valid = bool(
        raw_frames.size > 0
        and np.all(np.isfinite(raw_frames))
        and np.all(raw_frames >= 0)
        and np.all(raw_frames == np.floor(raw_frames))
    )
    frames = raw_frames.astype(int) if values_valid else np.zeros(0, dtype=int)
    diffs = np.diff(frames)
    max_run = 1 if frames.size else 0
    run = 1
    for diff in diffs:
        if diff == 1:
            run += 1
            max_run = max(max_run, run)
        else:
            run = 1
    return {
        "selected_n_rows": n_rows,
        "selected_has_frame": True,
        "selected_frame_values_valid": values_valid,
        "selected_frame_monotonic": bool(np.all(diffs >= 0))
        if diffs.size
        else bool(frames.size),
        "selected_frame_unique": bool(np.unique(frames).size == frames.size),
        "selected_frame_min": int(np.min(frames)) if frames.size else np.nan,
        "selected_frame_max": int(np.max(frames)) if frames.size else np.nan,
        "selected_frame_contiguous_fraction": float(np.mean(diffs == 1))
        if diffs.size
        else np.nan,
        "selected_frame_max_contiguous_run": int(max_run),
    }


def _c_alignment_summary(c: Any, selected_df: pd.DataFrame | None) -> dict[str, Any]:
    selected = _selected_frame_summary(selected_df)
    if c is None:
        return {
            **selected,
            "has_C": False,
            "C_shape": "",
            "C_n_time": 0,
            "C_n_cells": 0,
            "C_alignment_mode": "missing_C",
            "C_frame_alignment_ok": False,
            "C_alignment_reason": "missing_C",
        }
    arr = np.asarray(c)
    if arr.ndim != 2:
        return {
            **selected,
            "has_C": True,
            "C_shape": "x".join(str(v) for v in arr.shape),
            "C_n_time": 0,
            "C_n_cells": 0,
            "C_alignment_mode": "invalid_C_rank",
            "C_frame_alignment_ok": False,
            "C_alignment_reason": f"C_rank_{arr.ndim}_not_2",
        }

    n_rows = int(selected["selected_n_rows"])
    frame_max = selected["selected_frame_max"]
    mode = "mismatch"
    time_axis = 0
    if n_rows > 0 and arr.shape[0] == n_rows:
        mode = "selected_rows"
        time_axis = 0
    elif n_rows > 0 and arr.shape[1] == n_rows:
        mode = "transpose_selected_rows"
        time_axis = 1
    elif np.isfinite(frame_max) and int(frame_max) < arr.shape[0]:
        mode = "absolute_frame_index"
        time_axis = 0
    elif np.isfinite(frame_max) and int(frame_max) < arr.shape[1]:
        mode = "transpose_absolute_frame_index"
        time_axis = 1
    n_time = int(arr.shape[time_axis])
    n_cells = int(arr.shape[1 - time_axis])
    frame_checks_ok = bool(
        selected["selected_has_frame"]
        and selected["selected_frame_values_valid"]
        and selected["selected_frame_monotonic"]
        and selected["selected_frame_unique"]
    )
    ok = mode != "mismatch" and frame_checks_ok
    if ok:
        reason = ""
    elif not selected["selected_has_frame"]:
        reason = "selected_df_missing_frame"
    elif not selected["selected_frame_values_valid"]:
        reason = "selected_frame_values_invalid"
    elif not selected["selected_frame_monotonic"]:
        reason = "selected_frames_nonmonotonic"
    elif not selected["selected_frame_unique"]:
        reason = "selected_frames_not_unique"
    else:
        reason = "C_selected_frame_mismatch"
    return {
        **selected,
        "has_C": True,
        "C_shape": f"{arr.shape[0]}x{arr.shape[1]}",
        "C_n_time": n_time,
        "C_n_cells": n_cells,
        "C_alignment_mode": mode,
        "C_frame_alignment_ok": bool(ok),
        "C_alignment_reason": reason,
    }


def summarize_c_alignment(c: Any, selected_df: pd.DataFrame | None) -> dict[str, Any]:
    """Public synthetic/small-array alignment helper used by targeted tests."""

    return _c_alignment_summary(c, selected_df)


def _c_metadata_alignment_summary(
    metadata: dict[str, Any], selected_df: pd.DataFrame | None
) -> dict[str, Any]:
    selected = _selected_frame_summary(selected_df)
    out = {**metadata, **selected}
    if not bool(metadata.get("has_C", False)):
        out.update(
            {
                "C_shape": "",
                "C_alignment_mode": "missing_C",
                "C_frame_alignment_ok": False,
                "C_alignment_reason": "missing_C",
            }
        )
        return out
    if str(metadata.get("neural_metadata_status", "")) != "ok":
        status = str(metadata.get("neural_metadata_status", "invalid_C_metadata"))
        out.update(
            {
                "C_shape": str(metadata.get("C_stored_shape", "")),
                "C_alignment_mode": "metadata_unusable",
                "C_frame_alignment_ok": False,
                "C_alignment_reason": status,
            }
        )
        return out
    if not selected["selected_has_frame"]:
        reason = "selected_df_missing_frame"
    elif not selected["selected_frame_values_valid"]:
        reason = "selected_frame_values_invalid"
    elif not selected["selected_frame_monotonic"]:
        reason = "selected_frames_nonmonotonic"
    elif not selected["selected_frame_unique"]:
        reason = "selected_frames_not_unique"
    elif int(selected["selected_frame_max"]) >= int(metadata["C_n_time"]):
        reason = "selected_frame_out_of_C_bounds"
    else:
        reason = ""
    out.update(
        {
            "C_shape": (f"{int(metadata['C_n_cells'])}x{int(metadata['C_n_time'])}"),
            "C_alignment_mode": "absolute_frame_index_cells_by_time",
            "C_frame_alignment_ok": reason == "",
            "C_alignment_reason": reason,
        }
    )
    return out


def _s_metadata_alignment_summary(
    metadata: dict[str, Any], selected_df: pd.DataFrame | None
) -> dict[str, Any]:
    selected = _selected_frame_summary(selected_df)
    if not bool(metadata.get("has_S_legacy", False)):
        return {
            "S_shape": "",
            "S_alignment_mode": "missing_S",
            "S_frame_alignment_ok": False,
            "S_alignment_reason": "missing_S",
        }
    if str(metadata.get("S_metadata_status", "")) != "ok":
        status = str(metadata.get("S_metadata_status", "invalid_S_metadata"))
        return {
            "S_shape": str(metadata.get("S_stored_shape", "")),
            "S_alignment_mode": "metadata_unusable",
            "S_frame_alignment_ok": False,
            "S_alignment_reason": status,
        }
    if not selected["selected_has_frame"]:
        reason = "selected_df_missing_frame"
    elif not selected["selected_frame_values_valid"]:
        reason = "selected_frame_values_invalid"
    elif not selected["selected_frame_monotonic"]:
        reason = "selected_frames_nonmonotonic"
    elif not selected["selected_frame_unique"]:
        reason = "selected_frames_not_unique"
    elif int(selected["selected_frame_max"]) >= int(metadata["S_n_time"]):
        reason = "selected_frame_out_of_S_bounds"
    else:
        reason = ""
    return {
        "S_shape": f"{int(metadata['S_n_cells'])}x{int(metadata['S_n_time'])}",
        "S_alignment_mode": "absolute_frame_index_cells_by_time",
        "S_frame_alignment_ok": reason == "",
        "S_alignment_reason": reason,
    }


def _add_selected_support(
    transitions: pd.DataFrame,
    selected_df: pd.DataFrame | None,
    *,
    c_alignment_ok: bool,
) -> pd.DataFrame:
    if transitions.empty:
        return transitions.copy()
    out = transitions.copy()
    selected_summary = _selected_frame_summary(selected_df)
    if (
        selected_df is None
        or "frame" not in selected_df.columns
        or not selected_summary["selected_frame_values_valid"]
        or not selected_summary["selected_frame_monotonic"]
        or not selected_summary["selected_frame_unique"]
    ):
        out["n_selected_rows_transition"] = 0
        out["has_selected_support"] = False
        out["has_C_support"] = False
        return out
    frames = pd.to_numeric(selected_df["frame"], errors="coerce").to_numpy(dtype=float)
    frames = np.sort(frames[np.isfinite(frames)].astype(int))
    starts = out["abs_frame_start"].to_numpy(dtype=float)
    ends = out["abs_frame_end"].to_numpy(dtype=float)
    left = np.searchsorted(frames, starts, side="left")
    right = np.searchsorted(frames, ends, side="left")
    counts = np.maximum(0, right - left).astype(int)
    out["n_selected_rows_transition"] = counts
    out["has_selected_support"] = counts > 0
    out["has_C_support"] = bool(c_alignment_ok) & (counts > 0)
    return out


def build_transition_decision_support(
    tf: Any,
    ma: Maze,
    *,
    session_id: str,
    pair_id: str,
    animal_id: str,
    cohort_group: str,
    day_index: int,
    selected_df: pd.DataFrame | None = None,
    c_alignment_ok: bool = False,
    split_mode_fn: Callable[..., Any] | None = None,
) -> dict[str, pd.DataFrame]:
    include_reward = mode_split_include_reward(cohort_group, day_index)
    clip_df, expanded = _mode_clip_tables(
        tf,
        ma,
        include_reward=include_reward,
        split_mode_fn=split_mode_fn,
    )
    transitions = _trajectory_transitions(tf)
    rewards = extract_actual_reward_events(tf)

    if not transitions.empty:
        merge_columns = [
            "clip_index",
            "bout",
            "transition_index_in_bout",
            "clip_transition_offset",
            "clip_start_transition",
            "clip_n_transitions",
            "mode_code",
            "mode_label",
            "splitter_include_reward",
            "clip_current_node",
            "clip_next_node",
            "clip_abs_frame_start",
            "clip_abs_frame_end",
        ]
        transitions = transitions.merge(
            expanded[merge_columns],
            on=["bout", "transition_index_in_bout"],
            how="left",
            validate="one_to_one",
        )
        assigned = transitions["mode_code"].notna()
        if assigned.any():
            node_mismatch = assigned & (
                transitions["current_node"].ne(transitions["clip_current_node"])
                | transitions["next_node"].ne(transitions["clip_next_node"])
            )
            if node_mismatch.any():
                raise ValueError(
                    "Expanded mode clips do not match trajectory transition nodes."
                )
        transitions["mode_code"] = transitions["mode_code"].fillna(-1).astype(int)
        transitions["mode_label"] = (
            transitions["mode_code"].map(MODE_LABELS).fillna("unknown")
        )
        transitions["splitter_include_reward"] = bool(include_reward)
        transitions = _add_decision_and_prefix_features(transitions, ma)
        transitions = _add_reward_features(transitions, rewards)
        transitions = _add_selected_support(
            transitions,
            selected_df,
            c_alignment_ok=bool(c_alignment_ok),
        )
        transitions.insert(0, "session_id", str(session_id))
        transitions.insert(0, "day_index", int(day_index))
        transitions.insert(0, "cohort_group", str(cohort_group))
        transitions.insert(0, "animal_id", str(animal_id))
        transitions.insert(0, "pair_id", str(pair_id))
        transitions["transition_id"] = (
            transitions["session_id"].astype(str)
            + ":"
            + transitions["bout"].astype(str)
            + ":"
            + transitions["transition_index_in_bout"].astype(str)
        )
    else:
        transitions = pd.DataFrame()

    decisions = (
        transitions.loc[transitions["is_child_exit_decision"].astype(bool)].copy()
        if not transitions.empty
        else pd.DataFrame()
    )
    for table in (clip_df, rewards):
        table.insert(0, "session_id", str(session_id))
        table.insert(0, "day_index", int(day_index))
        table.insert(0, "cohort_group", str(cohort_group))
        table.insert(0, "animal_id", str(animal_id))
        table.insert(0, "pair_id", str(pair_id))
    return {
        "transitions": transitions,
        "decisions": decisions,
        "mode_clips": clip_df,
        "reward_events": rewards,
    }


def _load_session_inputs(
    session_id: str,
    *,
    behav_wd: str | Path,
    original_neural_wd: str | Path,
    sorted_neural_wd: str | Path,
    expected_neural_source: str,
    expected_neural_root: str,
    trajectory_loader: Callable[[str], Any],
    neural_source_resolver: Callable[..., dict[str, Any]],
    neural_metadata_inspector: Callable[[str | Path | None], dict[str, Any]],
) -> dict[str, Any]:
    selected_path = Path(behav_wd) / "selected_data" / f"{session_id}_selected_data.csv"
    nose_path = Path(behav_wd) / "selected_data" / f"{session_id}_nose_interp_data.csv"
    tr = None
    trajectory_status = "not_loaded"
    try:
        tr = trajectory_loader(f"{session_id}-tf")
        trajectory_status = "ok" if tr is not None else "missing"
    except Exception as exc:
        trajectory_status = f"failed:{type(exc).__name__}:{exc}"

    selected_df: pd.DataFrame | None = None
    behavior_table_status = "not_loaded"
    try:
        selected_df = pd.read_csv(selected_path)
        behavior_table_status = "ok"
    except Exception as exc:
        behavior_table_status = f"failed:{type(exc).__name__}:{exc}"

    source = neural_source_resolver(
        session_id,
        original_neural_wd=original_neural_wd,
        sorted_neural_wd=sorted_neural_wd,
    )
    metadata = neural_metadata_inspector(source.get("neural_file", ""))
    c_summary = _c_metadata_alignment_summary(metadata, selected_df)
    s_summary = _s_metadata_alignment_summary(metadata, selected_df)

    expected_source = str(expected_neural_source).strip()
    expected_root = str(expected_neural_root).strip()

    def _norm_path(value: str) -> str:
        return str(Path(value)).replace("/", "\\").rstrip("\\").lower()

    source_matches = bool(
        expected_source
        and str(source.get("neural_source", "")) == expected_source
        and (
            not expected_root
            or _norm_path(str(source.get("neural_root", "")))
            == _norm_path(expected_root)
        )
    )
    if source_matches:
        source_match_reason = ""
    elif not expected_source:
        source_match_reason = "identity_provenance_missing"
    else:
        source_match_reason = (
            f"resolved={source.get('neural_source', '')}@{source.get('neural_root', '')};"
            f"expected={expected_source}@{expected_root}"
        )

    return {
        "session_id": str(session_id),
        "trajectory": tr,
        "selected_df": selected_df,
        "trajectory_load_status": trajectory_status,
        "behavior_table_load_status": behavior_table_status,
        "selected_data_path": str(selected_path),
        "nose_interp_data_path": str(nose_path),
        "selected_data_exists": bool(selected_path.exists()),
        "nose_interp_data_exists": bool(nose_path.exists()),
        "expected_neural_source": expected_source,
        "expected_neural_root": expected_root,
        "neural_source_matches_identity_provenance": source_matches,
        "neural_source_match_reason": source_match_reason,
        **source,
        **c_summary,
        **s_summary,
    }


def _session_summary(
    inputs: dict[str, Any],
    tables: dict[str, pd.DataFrame],
    *,
    pair_id: str,
    animal_id: str,
    cohort_group: str,
    day_index: int,
) -> dict[str, Any]:
    transitions = tables["transitions"]
    decisions = tables["decisions"]
    clips = tables["mode_clips"]
    rewards = tables["reward_events"]
    explore_trans = (
        transitions["mode_code"].eq(EXPLORE_MODE)
        if not transitions.empty
        else pd.Series(dtype=bool)
    )
    primary = (
        transitions["is_primary_decision"].astype(bool)
        if not transitions.empty
        else pd.Series(dtype=bool)
    )
    pre = (
        transitions["reward_epoch"].eq("pre_first_reward")
        if not transitions.empty
        else pd.Series(dtype=bool)
    )
    post = (
        transitions["reward_epoch"].eq("post_first_reward")
        if not transitions.empty
        else pd.Series(dtype=bool)
    )
    has_c = (
        transitions["has_C_support"].astype(bool)
        if not transitions.empty
        else pd.Series(dtype=bool)
    )
    selected_counts = (
        transitions["n_selected_rows_transition"].to_numpy(dtype=int)
        if not transitions.empty
        else np.zeros(0, dtype=int)
    )
    first_reward_abs = (
        float(rewards.iloc[0]["reward_abs_frame"]) if not rewards.empty else np.nan
    )
    first_reward_maze = (
        float(rewards.iloc[0]["reward_maze_seconds"]) if not rewards.empty else np.nan
    )
    n_total = int(len(transitions))
    n_known = int(transitions["mode_code"].ne(-1).sum()) if n_total else 0
    return {
        "pair_id": pair_id,
        "animal_id": str(animal_id),
        "cohort_group": str(cohort_group),
        "day_index": int(day_index),
        "session_id": str(inputs["session_id"]),
        "mode_split_re": mode_split_include_reward(cohort_group, day_index),
        "trajectory_load_status": inputs["trajectory_load_status"],
        "behavior_table_load_status": inputs["behavior_table_load_status"],
        "selected_data_path": inputs["selected_data_path"],
        "nose_interp_data_path": inputs["nose_interp_data_path"],
        "selected_data_exists": bool(inputs["selected_data_exists"]),
        "nose_interp_data_exists": bool(inputs["nose_interp_data_exists"]),
        "neural_source_policy": inputs["neural_source_policy"],
        "neural_source": inputs["neural_source"],
        "neural_root": inputs["neural_root"],
        "neural_dir": inputs["neural_dir"],
        "neural_file": inputs["neural_file"],
        "neural_lookup_status": inputs["neural_lookup_status"],
        "sorted_neural_root": inputs["sorted_neural_root"],
        "sorted_neural_file": inputs["sorted_neural_file"],
        "sorted_neural_lookup_status": inputs["sorted_neural_lookup_status"],
        "original_neural_root": inputs["original_neural_root"],
        "original_neural_file": inputs["original_neural_file"],
        "original_neural_lookup_status": inputs["original_neural_lookup_status"],
        "expected_neural_source": inputs["expected_neural_source"],
        "expected_neural_root": inputs["expected_neural_root"],
        "neural_source_matches_identity_provenance": bool(
            inputs["neural_source_matches_identity_provenance"]
        ),
        "neural_source_match_reason": inputs["neural_source_match_reason"],
        "neural_metadata_status": inputs["neural_metadata_status"],
        "has_C": bool(inputs["has_C"]),
        "has_C_raw": bool(inputs["has_C_raw"]),
        "has_S_legacy": bool(inputs["has_S_legacy"]),
        "C_storage_type": inputs["C_storage_type"],
        "C_stored_shape": inputs["C_stored_shape"],
        "C_shape": inputs["C_shape"],
        "C_n_time": int(inputs["C_n_time"]),
        "C_n_cells": int(inputs["C_n_cells"]),
        "C_alignment_mode": inputs["C_alignment_mode"],
        "C_frame_alignment_ok": bool(inputs["C_frame_alignment_ok"]),
        "C_alignment_reason": inputs["C_alignment_reason"],
        "S_storage_type": inputs["S_storage_type"],
        "S_stored_shape": inputs["S_stored_shape"],
        "S_metadata_status": inputs["S_metadata_status"],
        "S_shape": inputs["S_shape"],
        "S_n_time": int(inputs["S_n_time"]),
        "S_n_cells": int(inputs["S_n_cells"]),
        "S_alignment_mode": inputs["S_alignment_mode"],
        "S_frame_alignment_ok": bool(inputs["S_frame_alignment_ok"]),
        "S_alignment_reason": inputs["S_alignment_reason"],
        "selected_n_rows": int(inputs["selected_n_rows"]),
        "selected_has_frame": bool(inputs["selected_has_frame"]),
        "selected_frame_values_valid": bool(inputs["selected_frame_values_valid"]),
        "selected_frame_monotonic": bool(inputs["selected_frame_monotonic"]),
        "selected_frame_unique": bool(inputs["selected_frame_unique"]),
        "selected_frame_min": inputs["selected_frame_min"],
        "selected_frame_max": inputs["selected_frame_max"],
        "selected_frame_contiguous_fraction": inputs[
            "selected_frame_contiguous_fraction"
        ],
        "selected_frame_max_contiguous_run": int(
            inputs["selected_frame_max_contiguous_run"]
        ),
        "n_bouts": int(len(getattr(inputs.get("trajectory"), "no", []) or []))
        if inputs.get("trajectory") is not None
        else 0,
        "n_transitions": n_total,
        "n_valid_positive_duration_transitions": int(
            transitions["valid_positive_duration"].sum()
        )
        if n_total
        else 0,
        "n_mode_clips": int(len(clips)),
        "n_explore_clips": int(clips["mode_code"].eq(EXPLORE_MODE).sum())
        if not clips.empty
        else 0,
        "n_explore_transitions": int(explore_trans.sum()) if n_total else 0,
        "n_unassigned_transitions": int(n_total - n_known),
        "mode_known_fraction": float(n_known / n_total) if n_total else np.nan,
        "n_child_exit_decisions": int(len(decisions)),
        "n_primary_decisions": int(primary.sum()) if n_total else 0,
        "n_explore_primary_decisions": int((explore_trans & primary).sum())
        if n_total
        else 0,
        "n_pre_reward_explore_primary_decisions": int(
            (explore_trans & primary & pre).sum()
        )
        if n_total
        else 0,
        "n_post_reward_primary_decisions": int((primary & post).sum())
        if n_total
        else 0,
        "n_post_reward_explore_primary_decisions": int(
            (explore_trans & primary & post).sum()
        )
        if n_total
        else 0,
        "n_explore_primary_decisions_with_C_support": int(
            (explore_trans & primary & has_c).sum()
        )
        if n_total
        else 0,
        "n_post_reward_primary_decisions_with_C_support": int(
            (primary & post & has_c).sum()
        )
        if n_total
        else 0,
        "n_selected_rows_in_transitions": int(np.sum(selected_counts)),
        "n_explore_selected_rows": int(
            np.sum(selected_counts[explore_trans.to_numpy(dtype=bool)])
        )
        if n_total
        else 0,
        "n_actual_reward_events": int(len(rewards)),
        "first_reward_abs_frame": first_reward_abs,
        "first_reward_maze_seconds": first_reward_maze,
        "reward_source": "tf.re",
    }


def _gate_reason(checks: list[tuple[bool, str]]) -> tuple[bool, str]:
    failed = [reason for ok, reason in checks if not ok]
    return (not failed, "" if not failed else ";".join(failed))


def _pair_inventory_row(
    source_row: pd.Series,
    day1: dict[str, Any],
    day2: dict[str, Any],
    identity_row: pd.Series | None,
) -> dict[str, Any]:
    cohort = str(source_row["cohort_group"])
    forced_behavior_only = bool(source_row["forced_behavior_only"])
    reward_summary = day1 if cohort == "rewarded" else day2
    reward_day_index = 1 if cohort == "rewarded" else 2

    structure_ready, structure_reason = _gate_reason(
        [
            (
                str(day1["trajectory_load_status"]).startswith("ok"),
                "day1_trajectory_unavailable",
            ),
            (
                int(day1["n_explore_primary_decisions"])
                >= MIN_STRUCTURE_EXPLORE_DECISIONS,
                f"day1_explore_primary_decisions_below_{MIN_STRUCTURE_EXPLORE_DECISIONS}",
            ),
        ]
    )
    discovery_ready, discovery_reason = _gate_reason(
        [
            (
                str(reward_summary["trajectory_load_status"]).startswith("ok"),
                f"day{reward_day_index}_trajectory_unavailable",
            ),
            (
                int(reward_summary["n_actual_reward_events"]) >= 1,
                f"day{reward_day_index}_missing_tf_re_reward",
            ),
        ]
    )
    binding_ready, binding_reason = _gate_reason(
        [
            (discovery_ready, discovery_reason or "reward_discovery_not_ready"),
            (
                int(reward_summary["n_post_reward_primary_decisions"])
                >= MIN_POST_REWARD_DECISIONS,
                f"day{reward_day_index}_post_reward_primary_decisions_below_{MIN_POST_REWARD_DECISIONS}",
            ),
        ]
    )

    identity_available = identity_row is not None
    identity_sessions_match = bool(
        identity_available
        and str(identity_row["session_a"]) == str(source_row["session_day1"])
        and str(identity_row["session_b"]) == str(source_row["session_day2"])
    )
    shared_component_basis = bool(
        identity_available and _as_bool(identity_row["shared_component_basis"])
    )
    cimap_required = bool(
        _as_bool(identity_row["cimap_required"]) if identity_available else True
    )
    joint_deconvolution_documented = bool(
        identity_sessions_match
        and shared_component_basis
        and str(identity_row["effective_matching_mode"])
        == "joint_deconvolution_shared_component_identity"
    )
    matching_basis = (
        str(identity_row["effective_matching_mode"])
        if joint_deconvolution_documented
        else "unresolved_no_matching_provenance"
    )
    neural_sources_match_provenance = bool(
        day1["neural_source_matches_identity_provenance"]
        and day2["neural_source_matches_identity_provenance"]
    )
    c_cells_equal = bool(
        day1["C_frame_alignment_ok"]
        and day2["C_frame_alignment_ok"]
        and int(day1["C_n_cells"]) == int(day2["C_n_cells"])
    )
    c_pair_ready, c_pair_reason = _gate_reason(
        [
            (not forced_behavior_only, "frozen_behavior_only_769"),
            (
                joint_deconvolution_documented,
                "joint_deconvolution_identity_provenance_unresolved",
            ),
            (not cimap_required, "explicit_cimap_required"),
            (
                neural_sources_match_provenance,
                "resolved_neural_source_differs_from_identity_provenance",
            ),
            (
                bool(day1["C_frame_alignment_ok"]),
                f"day1_C_not_aligned:{day1['C_alignment_reason']}",
            ),
            (
                bool(day2["C_frame_alignment_ok"]),
                f"day2_C_not_aligned:{day2['C_alignment_reason']}",
            ),
            (c_cells_equal, "joint_deconvolution_component_count_mismatch"),
        ]
    )
    s_cells_equal = bool(
        day1["S_frame_alignment_ok"]
        and day2["S_frame_alignment_ok"]
        and int(day1["S_n_cells"]) == int(day2["S_n_cells"])
    )
    dist_arcrit_s_ready, dist_arcrit_s_reason = _gate_reason(
        [
            (not forced_behavior_only, "frozen_behavior_only_769"),
            (
                bool(source_row["legacy_s_pair_ready"]),
                "legacy_manifest_S_pair_not_ready",
            ),
            (
                joint_deconvolution_documented,
                "joint_deconvolution_identity_provenance_unresolved",
            ),
            (not cimap_required, "explicit_cimap_required"),
            (
                neural_sources_match_provenance,
                "resolved_neural_source_differs_from_identity_provenance",
            ),
            (
                bool(day1["S_frame_alignment_ok"]),
                f"day1_S_not_aligned:{day1['S_alignment_reason']}",
            ),
            (
                bool(day2["S_frame_alignment_ok"]),
                f"day2_S_not_aligned:{day2['S_alignment_reason']}",
            ),
            (s_cells_equal, "joint_deconvolution_S_component_count_mismatch"),
        ]
    )
    c_structure_within_ready, c_structure_within_reason = _gate_reason(
        [
            (not forced_behavior_only, "frozen_behavior_only_769"),
            (structure_ready, structure_reason or "structure_behavior_not_ready"),
            (
                bool(day1["C_frame_alignment_ok"]),
                f"day1_C_not_aligned:{day1['C_alignment_reason']}",
            ),
            (
                int(day1["n_explore_primary_decisions_with_C_support"])
                >= MIN_STRUCTURE_EXPLORE_DECISIONS,
                f"day1_C_supported_explore_decisions_below_{MIN_STRUCTURE_EXPLORE_DECISIONS}",
            ),
        ]
    )
    reward_c_summary = day1 if cohort == "rewarded" else day2
    c_reward_within_ready, c_reward_within_reason = _gate_reason(
        [
            (not forced_behavior_only, "frozen_behavior_only_769"),
            (binding_ready, binding_reason or "reward_binding_not_ready"),
            (
                bool(reward_c_summary["C_frame_alignment_ok"]),
                f"day{reward_day_index}_C_not_aligned:{reward_c_summary['C_alignment_reason']}",
            ),
            (
                int(reward_c_summary["n_post_reward_primary_decisions_with_C_support"])
                >= MIN_POST_REWARD_DECISIONS,
                f"day{reward_day_index}_C_supported_post_reward_decisions_below_{MIN_POST_REWARD_DECISIONS}",
            ),
        ]
    )
    elpc_within_ready, elpc_within_reason = _gate_reason(
        [
            (not forced_behavior_only, "frozen_behavior_only_769"),
            (
                c_structure_within_ready,
                c_structure_within_reason or "C_structure_within_session_not_ready",
            ),
            (
                int(day1["n_explore_selected_rows"]) >= MIN_ELPC_EXPLORE_SELECTED_ROWS,
                f"day1_explore_selected_rows_below_{MIN_ELPC_EXPLORE_SELECTED_ROWS}",
            ),
        ]
    )
    c_structure_cross_day_ready, c_structure_cross_day_reason = _gate_reason(
        [
            (c_pair_ready, c_pair_reason or "C_pair_not_ready"),
            (
                c_structure_within_ready,
                c_structure_within_reason or "C_structure_within_session_not_ready",
            ),
        ]
    )
    c_reward_cross_day_ready, c_reward_cross_day_reason = _gate_reason(
        [
            (c_pair_ready, c_pair_reason or "C_pair_not_ready"),
            (
                c_reward_within_ready,
                c_reward_within_reason or "C_reward_within_session_not_ready",
            ),
        ]
    )
    elpc_cross_day_ready, elpc_cross_day_reason = _gate_reason(
        [
            (c_pair_ready, c_pair_reason or "C_pair_not_ready"),
            (
                elpc_within_ready,
                elpc_within_reason or "ELPC_within_session_not_ready",
            ),
        ]
    )

    keep_source = {
        key: source_row[key]
        for key in source_row.index
        if key not in {"analysis_ready_neural", "exclusion_reason"}
    }
    out: dict[str, Any] = {
        **keep_source,
        "legacy_s_pair_ready": bool(source_row["legacy_s_pair_ready"]),
        "legacy_s_exclusion_reason": _clean_text(
            source_row.get("exclusion_reason", "")
        ),
        "reward_learning_day_index": int(reward_day_index),
        "identity_provenance_available": bool(identity_available),
        "identity_provenance_path": (
            str(identity_row["identity_provenance_path"]) if identity_available else ""
        ),
        "identity_sessions_match": bool(identity_sessions_match),
        "joint_deconvolution_documented": bool(joint_deconvolution_documented),
        "shared_component_basis": bool(shared_component_basis),
        "cimap_required": bool(cimap_required),
        "matching_basis": matching_basis,
        "identity_provenance_basis": (
            _clean_text(identity_row["provenance_basis"]) if identity_available else ""
        ),
        "identity_source_bundle": (
            _clean_text(identity_row.get("source_bundle", ""))
            if identity_available
            else ""
        ),
        "neural_sources_match_identity_provenance": bool(
            neural_sources_match_provenance
        ),
        "component_count_equal": bool(c_cells_equal),
        "C_pair_ready": bool(c_pair_ready),
        "C_pair_exclusion_reason": c_pair_reason,
        "S_component_count_equal": bool(s_cells_equal),
        "dist_arcrit_S_ready": bool(dist_arcrit_s_ready),
        "dist_arcrit_S_exclusion_reason": dist_arcrit_s_reason,
        "structure_behavior_ready": bool(structure_ready),
        "structure_behavior_exclusion_reason": structure_reason,
        "reward_discovery_ready": bool(discovery_ready),
        "reward_discovery_exclusion_reason": discovery_reason,
        "reward_binding_ready": bool(binding_ready),
        "reward_binding_exclusion_reason": binding_reason,
        "C_structure_within_session_ready": bool(c_structure_within_ready),
        "C_structure_within_session_exclusion_reason": c_structure_within_reason,
        "C_structure_cross_day_ready": bool(c_structure_cross_day_ready),
        "C_structure_cross_day_exclusion_reason": c_structure_cross_day_reason,
        "C_structure_ready": bool(c_structure_cross_day_ready),
        "C_structure_exclusion_reason": c_structure_cross_day_reason,
        "C_reward_within_session_ready": bool(c_reward_within_ready),
        "C_reward_within_session_exclusion_reason": c_reward_within_reason,
        "C_reward_cross_day_ready": bool(c_reward_cross_day_ready),
        "C_reward_cross_day_exclusion_reason": c_reward_cross_day_reason,
        "C_reward_ready": bool(c_reward_cross_day_ready),
        "C_reward_exclusion_reason": c_reward_cross_day_reason,
        "ELPC_within_session_ready": bool(elpc_within_ready),
        "ELPC_within_session_exclusion_reason": elpc_within_reason,
        "ELPC_cross_day_ready": bool(elpc_cross_day_ready),
        "ELPC_cross_day_exclusion_reason": elpc_cross_day_reason,
        "ELPC_ready": bool(elpc_cross_day_ready),
        "ELPC_exclusion_reason": elpc_cross_day_reason,
    }
    for prefix, summary in (("day1", day1), ("day2", day2)):
        for key, value in summary.items():
            if key in {
                "pair_id",
                "animal_id",
                "cohort_group",
                "day_index",
                "session_id",
            }:
                continue
            out[f"{prefix}_{key}"] = value
    return out


def build_phase0_tables(
    cohort_manifest: str | Path = DEFAULT_COHORT_MANIFEST,
    *,
    identity_provenance: str | Path = DEFAULT_IDENTITY_PROVENANCE,
    behav_wd: str | Path | None = None,
    neural_wd: str | Path | None = None,
    sorted_neural_wd: str | Path = DEFAULT_SORTED_NEURAL_WD,
    ma: Maze | None = None,
    trajectory_loader: Callable[[str], Any] = LoadTraj,
    neural_source_resolver: Callable[..., dict[str, Any]] = resolve_neural_source,
    neural_metadata_inspector: Callable[
        [str | Path | None], dict[str, Any]
    ] = inspect_neural_metadata,
) -> Phase0Tables:
    cohort = load_frozen_cohort_manifest(cohort_manifest)
    identity = load_identity_provenance(identity_provenance)
    identity_by_pair = {str(row["pair_id"]): row for _, row in identity.iterrows()}
    behav_wd = str(get_behav_wd() if behav_wd is None else behav_wd)
    neural_wd = str(get_neural_wd() if neural_wd is None else neural_wd)
    sorted_neural_wd = str(sorted_neural_wd)
    ma = NewMaze(6) if ma is None else ma

    inventory_rows: list[dict[str, Any]] = []
    support_rows: list[dict[str, Any]] = []
    transition_tables: list[pd.DataFrame] = []
    decision_tables: list[pd.DataFrame] = []
    clip_tables: list[pd.DataFrame] = []
    reward_tables: list[pd.DataFrame] = []

    for _, source_row in cohort.iterrows():
        pair_id = str(source_row["pair_id"])
        animal_id = str(source_row["animal_id"])
        cohort_group = str(source_row["cohort_group"])
        identity_row = identity_by_pair.get(pair_id)
        day_summaries: dict[int, dict[str, Any]] = {}
        for day_index in (1, 2):
            session_id = str(source_row[f"session_day{day_index}"])
            source_prefix = "target" if day_index == 1 else "reference"
            expected_source = (
                str(identity_row[f"{source_prefix}_neural_source"])
                if identity_row is not None
                else ""
            )
            expected_root = (
                str(identity_row[f"{source_prefix}_neural_wd"])
                if identity_row is not None
                else ""
            )
            inputs = _load_session_inputs(
                session_id,
                behav_wd=behav_wd,
                original_neural_wd=neural_wd,
                sorted_neural_wd=sorted_neural_wd,
                expected_neural_source=expected_source,
                expected_neural_root=expected_root,
                trajectory_loader=trajectory_loader,
                neural_source_resolver=neural_source_resolver,
                neural_metadata_inspector=neural_metadata_inspector,
            )
            if inputs["trajectory"] is None:
                session_tables = {
                    "transitions": pd.DataFrame(),
                    "decisions": pd.DataFrame(),
                    "mode_clips": pd.DataFrame(),
                    "reward_events": pd.DataFrame(),
                }
            else:
                try:
                    session_tables = build_transition_decision_support(
                        inputs["trajectory"],
                        ma,
                        session_id=session_id,
                        pair_id=pair_id,
                        animal_id=animal_id,
                        cohort_group=cohort_group,
                        day_index=day_index,
                        selected_df=inputs["selected_df"],
                        c_alignment_ok=bool(inputs["C_frame_alignment_ok"]),
                    )
                except Exception as exc:
                    inputs[
                        "trajectory_load_status"
                    ] = f"support_failed:{type(exc).__name__}:{exc}"
                    session_tables = {
                        "transitions": pd.DataFrame(),
                        "decisions": pd.DataFrame(),
                        "mode_clips": pd.DataFrame(),
                        "reward_events": pd.DataFrame(),
                    }
            summary = _session_summary(
                inputs,
                session_tables,
                pair_id=pair_id,
                animal_id=animal_id,
                cohort_group=cohort_group,
                day_index=day_index,
            )
            day_summaries[day_index] = summary
            support_rows.append(summary)
            if not session_tables["transitions"].empty:
                transition_tables.append(session_tables["transitions"])
            if not session_tables["decisions"].empty:
                decision_tables.append(session_tables["decisions"])
            if not session_tables["mode_clips"].empty:
                clip_tables.append(session_tables["mode_clips"])
            if not session_tables["reward_events"].empty:
                reward_tables.append(session_tables["reward_events"])
        inventory_rows.append(
            _pair_inventory_row(
                source_row,
                day_summaries[1],
                day_summaries[2],
                identity_row,
            )
        )

    def _concat(tables: list[pd.DataFrame]) -> pd.DataFrame:
        return pd.concat(tables, ignore_index=True) if tables else pd.DataFrame()

    inventory = (
        pd.DataFrame(inventory_rows)
        .sort_values("frozen_pair_index")
        .reset_index(drop=True)
    )
    return Phase0Tables(
        inventory=inventory,
        session_support=pd.DataFrame(support_rows),
        transitions=_concat(transition_tables),
        decisions=_concat(decision_tables),
        mode_clips=_concat(clip_tables),
        reward_events=_concat(reward_tables),
    )


def _git_commit(repo_root: Path) -> str:
    try:
        result = subprocess.run(
            [
                "git",
                "-c",
                f"safe.directory={repo_root.as_posix()}",
                "rev-parse",
                "HEAD",
            ],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()
    except Exception:
        return "unavailable"


def _git_worktree_dirty(repo_root: Path) -> bool | None:
    try:
        result = subprocess.run(
            [
                "git",
                "-c",
                f"safe.directory={repo_root.as_posix()}",
                "status",
                "--porcelain",
                "--untracked-files=normal",
            ],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
        return bool(result.stdout.strip())
    except Exception:
        return None


def _git_tracked(repo_root: Path, path: Path) -> bool | None:
    try:
        relative = path.resolve().relative_to(repo_root.resolve())
    except ValueError:
        return False
    try:
        result = subprocess.run(
            [
                "git",
                "-c",
                f"safe.directory={repo_root.as_posix()}",
                "ls-files",
                "--error-unmatch",
                relative.as_posix(),
            ],
            cwd=repo_root,
            check=False,
            capture_output=True,
            text=True,
        )
        return result.returncode == 0
    except Exception:
        return None


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _file_provenance(repo_root: Path, path: str | Path) -> dict[str, Any]:
    resolved = Path(path).resolve()
    exists = resolved.is_file()
    return {
        "path": str(resolved),
        "exists": bool(exists),
        "sha256": _sha256_file(resolved) if exists else "",
        "git_tracked": _git_tracked(repo_root, resolved),
    }


def _parquet_engine_available() -> bool:
    return bool(
        importlib.util.find_spec("pyarrow") is not None
        or importlib.util.find_spec("fastparquet") is not None
    )


def export_phase0_tables(
    tables: Phase0Tables,
    out_dir: str | Path = DEFAULT_OUTPUT_DIR,
    *,
    cohort_manifest: str | Path = DEFAULT_COHORT_MANIFEST,
    identity_provenance: str | Path = DEFAULT_IDENTITY_PROVENANCE,
    overwrite: bool = False,
) -> dict[str, Any]:
    out_dir = Path(out_dir).resolve()
    csv_outputs = {
        "rapid_learning_session_inventory.csv": tables.inventory,
        "rapid_learning_session_support.csv": tables.session_support,
        "rapid_learning_transition_support.csv": tables.transitions,
        "rapid_learning_choice_support.csv": tables.decisions,
        "mode_clip_audit.csv": tables.mode_clips,
        "actual_reward_events.csv": tables.reward_events,
    }
    parquet_outputs = (
        {"rapid_learning_choice_support.parquet": tables.decisions}
        if _parquet_engine_available()
        else {}
    )
    outputs = {**csv_outputs, **parquet_outputs}
    existing = [out_dir / name for name in outputs if (out_dir / name).exists()]
    manifest_path = out_dir / "phase0_manifest.json"
    if manifest_path.exists():
        existing.append(manifest_path)
    if existing and not overwrite:
        raise FileExistsError(
            "Refusing to overwrite Phase-0 outputs: "
            + ", ".join(str(path) for path in existing)
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, table in csv_outputs.items():
        table.to_csv(out_dir / name, index=False)
    for name, table in parquet_outputs.items():
        table.to_parquet(out_dir / name, index=False)

    repo_root = get_repo_root()
    input_provenance = {
        "cohort_manifest": _file_provenance(repo_root, cohort_manifest),
        "identity_provenance": _file_provenance(repo_root, identity_provenance),
    }
    implementation_provenance = {
        "module": _file_provenance(repo_root, Path(__file__)),
        "cli": _file_provenance(
            repo_root, repo_root / "scripts" / "build_rapid_learning_phase0.py"
        ),
        "tests": _file_provenance(
            repo_root, repo_root / "tests" / "test_rapid_learning_phase0.py"
        ),
    }
    output_provenance = {
        name: _file_provenance(repo_root, out_dir / name) for name in outputs
    }
    manifest = {
        "phase": "rapid_learning_structure_reward_phase0",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": _git_commit(repo_root),
        "git_worktree_dirty": _git_worktree_dirty(repo_root),
        "cohort_manifest": str(Path(cohort_manifest).resolve()),
        "identity_provenance": str(Path(identity_provenance).resolve()),
        "frozen_pair_count": int(len(tables.inventory)),
        "cohort_counts": tables.inventory["cohort_group"].value_counts().to_dict(),
        "forced_behavior_only_pairs": tables.inventory.loc[
            tables.inventory["forced_behavior_only"].astype(bool), "pair_id"
        ]
        .astype(str)
        .tolist(),
        "readiness_counts": {
            column: int(tables.inventory[column].astype(bool).sum())
            for column in [
                "structure_behavior_ready",
                "reward_discovery_ready",
                "reward_binding_ready",
                "C_pair_ready",
                "dist_arcrit_S_ready",
                "C_structure_within_session_ready",
                "C_structure_cross_day_ready",
                "C_structure_ready",
                "C_reward_within_session_ready",
                "C_reward_cross_day_ready",
                "C_reward_ready",
                "ELPC_within_session_ready",
                "ELPC_cross_day_ready",
                "ELPC_ready",
            ]
        },
        "input_readiness_gates": {
            "min_structure_explore_primary_decisions": MIN_STRUCTURE_EXPLORE_DECISIONS,
            "min_post_reward_primary_decisions": MIN_POST_REWARD_DECISIONS,
            "min_ELPC_explore_selected_rows": MIN_ELPC_EXPLORE_SELECTED_ROWS,
        },
        "mode_contract": {
            "columns": ["bout", "start_transition", "n_transitions", "mode_code"],
            "mode_codes": MODE_LABELS,
            "no_water_and_dry_day1_re": False,
            "all_other_sessions_re": True,
        },
        "reward_source": "tf.re only",
        "neural_source_policy": "sorted_first_with_labeled_original_fallback",
        "choice_cache_primary": (
            "rapid_learning_choice_support.parquet"
            if parquet_outputs
            else "rapid_learning_choice_support.csv"
        ),
        "choice_cache_parquet_available": bool(parquet_outputs),
        "timebase": "trajectory local frames plus tf.fr bout offsets; cumulative maze seconds from TimeInMaze; selected_df frame support kept explicit",
        "reproducibility": {
            "manifest_self_hash_excluded": True,
            "inputs": input_provenance,
            "implementation": implementation_provenance,
        },
        "outputs": {
            name: {
                "path": str(out_dir / name),
                "n_rows": int(len(table)),
                "format": Path(name).suffix.lstrip("."),
                "sha256": output_provenance[name]["sha256"],
                "git_tracked": output_provenance[name]["git_tracked"],
            }
            for name, table in outputs.items()
        },
    }
    manifest_path.write_text(
        json.dumps(_json_ready(manifest), indent=2),
        encoding="utf-8",
    )
    return manifest


def run_phase0(
    *,
    cohort_manifest: str | Path = DEFAULT_COHORT_MANIFEST,
    identity_provenance: str | Path = DEFAULT_IDENTITY_PROVENANCE,
    out_dir: str | Path = DEFAULT_OUTPUT_DIR,
    behav_wd: str | Path | None = None,
    neural_wd: str | Path | None = None,
    sorted_neural_wd: str | Path = DEFAULT_SORTED_NEURAL_WD,
    overwrite: bool = False,
) -> dict[str, Any]:
    tables = build_phase0_tables(
        cohort_manifest,
        identity_provenance=identity_provenance,
        behav_wd=behav_wd,
        neural_wd=neural_wd,
        sorted_neural_wd=sorted_neural_wd,
    )
    return export_phase0_tables(
        tables,
        out_dir,
        cohort_manifest=cohort_manifest,
        identity_provenance=identity_provenance,
        overwrite=overwrite,
    )


__all__ = [
    "DEFAULT_COHORT_MANIFEST",
    "DEFAULT_IDENTITY_PROVENANCE",
    "DEFAULT_OUTPUT_DIR",
    "DEFAULT_SORTED_NEURAL_WD",
    "EXPLORE_MODE",
    "EXPECTED_GROUP_COUNTS",
    "FROZEN_PAIR_KEYS",
    "MIN_ELPC_EXPLORE_SELECTED_ROWS",
    "Phase0Tables",
    "build_phase0_tables",
    "build_transition_decision_support",
    "expand_mode_clips",
    "export_phase0_tables",
    "extract_actual_reward_events",
    "inspect_neural_metadata",
    "load_frozen_cohort_manifest",
    "load_identity_provenance",
    "mode_split_include_reward",
    "resolve_neural_source",
    "run_phase0",
    "summarize_c_alignment",
]
