"""Helpers for cross-gap late-stability timing analyses.

The functions in this module are intentionally small and data-structure light:
scripts own session loading and export orchestration, while this module keeps
the numerical pieces testable.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats


LEVELS_8 = tuple(range(8))


@dataclass(frozen=True)
class EngagedTime:
    elapsed_sec: np.ndarray
    frame_duration_sec: float
    source: str
    wall_clock_duration_sec: float
    engaged_duration_sec: float
    gap_fraction: float


@dataclass(frozen=True)
class OLSResult:
    coef: dict[str, float]
    se: dict[str, float]
    p_value: dict[str, float]
    r_squared: float
    n_obs: int
    rank: int
    predictor_names: tuple[str, ...]


def estimate_frame_duration(selected_df: pd.DataFrame, *, default_dt: float = 0.04) -> tuple[float, str]:
    """Estimate frame duration from short positive ``maze_time`` steps."""
    if "maze_time" not in selected_df.columns or len(selected_df) < 2:
        return float(default_dt), "default_dt"
    t = pd.to_numeric(selected_df["maze_time"], errors="coerce").to_numpy(dtype=float)
    diffs = np.diff(t[np.isfinite(t)])
    diffs = diffs[np.isfinite(diffs) & (diffs > 0)]
    if diffs.size == 0:
        return float(default_dt), "default_dt"
    med = float(np.nanmedian(diffs))
    short = diffs[diffs <= max(0.25, med * 5.0)]
    if short.size == 0:
        return float(default_dt), "default_dt"
    return float(np.nanmedian(short)), "maze_time_short_positive_step"


def engaged_time_from_rows(selected_df: pd.DataFrame, *, default_dt: float = 0.04) -> EngagedTime:
    """Return engaged-time coordinates based on retained selected rows."""
    n_rows = int(len(selected_df))
    estimated_dt, estimate_source = estimate_frame_duration(selected_df, default_dt=default_dt)
    frame_dt = float(default_dt)
    source = f"default_dt_row_count;estimated_dt={estimated_dt:.6g};estimate_source={estimate_source}"
    elapsed = np.arange(n_rows, dtype=float) * float(frame_dt)
    engaged_duration = float(n_rows * frame_dt)
    wall_duration = np.nan
    gap_fraction = np.nan
    if "maze_time" in selected_df.columns and n_rows:
        t = pd.to_numeric(selected_df["maze_time"], errors="coerce").to_numpy(dtype=float)
        finite = t[np.isfinite(t)]
        if finite.size:
            wall_duration = float(np.nanmax(finite) - np.nanmin(finite))
            if wall_duration > 0:
                gap_fraction = float(max(0.0, 1.0 - engaged_duration / wall_duration))
    return EngagedTime(
        elapsed_sec=elapsed,
        frame_duration_sec=float(frame_dt),
        source=source,
        wall_clock_duration_sec=wall_duration,
        engaged_duration_sec=engaged_duration,
        gap_fraction=gap_fraction,
    )


def window_mask(
    elapsed_sec: np.ndarray,
    window_id: str,
    *,
    total_rows: int | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Build a mask for an engaged-time window."""
    elapsed = np.asarray(elapsed_sec, dtype=float)
    n_rows = int(elapsed.size if total_rows is None else total_rows)
    if elapsed.size != n_rows:
        raise ValueError("elapsed_sec length must match total_rows")
    if n_rows == 0:
        return np.zeros(0, dtype=bool), {"window_id": window_id, "window_sec": 0.0}
    duration = float(elapsed[-1] - elapsed[0]) if n_rows > 1 else 0.0
    stop = float(elapsed[-1] + (elapsed[1] - elapsed[0] if n_rows > 1 else 0.0))
    win = str(window_id).lower()
    if win == "full":
        return np.ones(n_rows, dtype=bool), {"window_id": window_id, "window_start_sec": 0.0, "window_stop_sec": stop}
    if win.startswith("firstfrac"):
        frac = float(win.replace("firstfrac", ""))
        frac = min(max(frac, 0.0), 1.0)
        n_keep = int(np.floor(n_rows * frac))
        mask = np.zeros(n_rows, dtype=bool)
        mask[:n_keep] = True
        return mask, {"window_id": window_id, "window_fraction": frac}
    if win.startswith("lastfrac"):
        frac = float(win.replace("lastfrac", ""))
        frac = min(max(frac, 0.0), 1.0)
        n_keep = int(np.floor(n_rows * frac))
        mask = np.zeros(n_rows, dtype=bool)
        if n_keep:
            mask[-n_keep:] = True
        return mask, {"window_id": window_id, "window_fraction": frac}
    if win.startswith("first"):
        minutes = float(win.replace("first", "").replace("min", ""))
        sec = minutes * 60.0
        return elapsed < sec, {"window_id": window_id, "window_start_sec": 0.0, "window_stop_sec": sec}
    if win.startswith("last"):
        minutes = float(win.replace("last", "").replace("min", ""))
        sec = minutes * 60.0
        start = max(0.0, stop - sec)
        return elapsed >= start, {"window_id": window_id, "window_start_sec": start, "window_stop_sec": stop}
    raise ValueError(f"Unknown window_id: {window_id}")


def split_even_odd_minutes(elapsed_sec: np.ndarray, base_mask: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Split a base window into even/odd relative engaged-minute bins."""
    elapsed = np.asarray(elapsed_sec, dtype=float)
    base = np.asarray(base_mask, dtype=bool)
    if elapsed.shape != base.shape:
        raise ValueError("elapsed_sec and base_mask shapes differ")
    even = np.zeros_like(base)
    odd = np.zeros_like(base)
    if not np.any(base):
        return even, odd
    start = float(np.nanmin(elapsed[base]))
    bins = np.floor((elapsed - start) / 60.0).astype(int)
    even = base & ((bins % 2) == 0)
    odd = base & ((bins % 2) == 1)
    return even, odd


def level_count_table(
    levels: np.ndarray,
    mask: np.ndarray,
    *,
    session_id: str,
    window_id: str,
    min_samples: int,
    frame_duration_sec: float,
    level_indices: tuple[int, ...] = LEVELS_8,
) -> pd.DataFrame:
    """Count retained rows per level for one window."""
    lv_arr = np.asarray(levels, dtype=float)
    base = np.asarray(mask, dtype=bool)
    rows = []
    for lv in level_indices:
        count = int(np.sum(base & (lv_arr == float(lv))))
        rows.append(
            {
                "session_id": str(session_id),
                "window_id": str(window_id),
                "level_index": int(lv),
                "paper_level_label": int(lv + 1),
                "n_samples": count,
                "duration_sec": float(count * frame_duration_sec),
                "passes_min_samples": bool(count >= int(min_samples)),
            }
        )
    return pd.DataFrame(rows)


def fit_label_tuning(
    signal: np.ndarray,
    labels: np.ndarray,
    mask: np.ndarray,
    neuron_ids: np.ndarray,
    *,
    label_values: tuple[int, ...] = LEVELS_8,
    min_samples: int = 125,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Fit mean-signal maps with rows as labels and columns as neurons."""
    sig = np.asarray(signal, dtype=float)
    lab = np.asarray(labels, dtype=float)
    base = np.asarray(mask, dtype=bool)
    ids = np.asarray(neuron_ids, dtype=int)
    if sig.ndim != 2:
        raise ValueError("signal must be 2D rows x neurons")
    if sig.shape[0] != lab.size or lab.size != base.size:
        raise ValueError("signal, labels, and mask row counts differ")
    maps = np.full((len(label_values), ids.size), np.nan, dtype=float)
    counts = np.zeros(len(label_values), dtype=int)
    if ids.size == 0:
        return maps, counts, counts >= int(min_samples)
    if int(np.max(ids)) >= sig.shape[1] or int(np.min(ids)) < 0:
        raise ValueError("neuron id out of range")
    sub = sig[:, ids]
    for idx, label in enumerate(label_values):
        rows = base & (lab == float(label))
        counts[idx] = int(np.sum(rows))
        if counts[idx] >= int(min_samples):
            maps[idx, :] = np.nanmean(sub[rows], axis=0)
    valid = counts >= int(min_samples)
    return maps, counts, valid


def column_corr(A: np.ndarray, B: np.ndarray, *, min_valid: int = 3) -> tuple[np.ndarray, np.ndarray]:
    """Column-wise Pearson correlation with per-column finite-value counts."""
    a = np.asarray(A, dtype=float)
    b = np.asarray(B, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"shape mismatch: {a.shape} vs {b.shape}")
    good = np.isfinite(a) & np.isfinite(b)
    valid_counts = np.sum(good, axis=0).astype(int)
    out = np.full(a.shape[1], np.nan, dtype=float)
    for col in range(a.shape[1]):
        if valid_counts[col] < int(min_valid):
            continue
        aa = a[good[:, col], col]
        bb = b[good[:, col], col]
        aa = aa - float(np.nanmean(aa))
        bb = bb - float(np.nanmean(bb))
        denom = float(np.sqrt(np.sum(aa * aa) * np.sum(bb * bb)))
        if denom > 0 and np.isfinite(denom):
            out[col] = float(np.sum(aa * bb) / denom)
    return out, valid_counts


def vector_corr(a: np.ndarray, b: np.ndarray, *, min_valid: int = 3) -> tuple[float, int]:
    """Pearson correlation between two vectors."""
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    good = np.isfinite(aa) & np.isfinite(bb)
    count = int(np.sum(good))
    if count < int(min_valid):
        return np.nan, count
    av = aa[good] - float(np.nanmean(aa[good]))
    bv = bb[good] - float(np.nanmean(bb[good]))
    denom = float(np.sqrt(np.sum(av * av) * np.sum(bv * bv)))
    if denom <= 0 or not np.isfinite(denom):
        return np.nan, count
    return float(np.sum(av * bv) / denom), count


def fisher_z(r: np.ndarray | float, *, clip: float = 0.95) -> np.ndarray:
    """Winsorize correlations and transform to Fisher-z."""
    arr = np.asarray(r, dtype=float)
    return np.arctanh(np.clip(arr, -float(clip), float(clip)))


def winsorization_counts(r: np.ndarray, *, clip: float = 0.95) -> dict[str, int]:
    arr = np.asarray(r, dtype=float)
    finite = np.isfinite(arr)
    return {
        "n_finite": int(np.sum(finite)),
        "n_clip_pos": int(np.sum(arr[finite] >= float(clip))),
        "n_clip_neg": int(np.sum(arr[finite] <= -float(clip))),
    }


def tuning_sharpness(values: np.ndarray) -> float:
    """Return 1-normalized entropy for a nonnegative tuning vector."""
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 2:
        return np.nan
    x = x - float(np.nanmin(x))
    total = float(np.nansum(x))
    if total <= 0 or not np.isfinite(total):
        return np.nan
    p = x / total
    p = p[p > 0]
    entropy = float(-np.sum(p * np.log(p)))
    return float(1.0 - entropy / np.log(x.size))


def activity_rate_per_minute(
    signal: np.ndarray,
    mask: np.ndarray,
    neuron_ids: np.ndarray,
    *,
    frame_duration_sec: float,
) -> np.ndarray:
    """Mean summed signal per engaged minute for selected rows."""
    sig = np.asarray(signal, dtype=float)
    base = np.asarray(mask, dtype=bool)
    ids = np.asarray(neuron_ids, dtype=int)
    out = np.full(ids.size, np.nan, dtype=float)
    n_rows = int(np.sum(base))
    if n_rows == 0 or ids.size == 0:
        return out
    sub = sig[base][:, ids]
    minutes = float(n_rows * frame_duration_sec / 60.0)
    if minutes <= 0:
        return out
    return np.nansum(sub, axis=0) / minutes


def within_group_zscore(df: pd.DataFrame, columns: list[str], group_col: str) -> pd.DataFrame:
    """Z-score columns within groups, preserving NaNs and constant columns."""
    out = df.copy()
    for col in columns:
        vals = pd.to_numeric(out[col], errors="coerce")
        z = pd.Series(np.nan, index=out.index, dtype=float)
        for _, idx in out.groupby(group_col, sort=False).groups.items():
            idx = list(idx)
            arr = vals.loc[idx].to_numpy(dtype=float)
            finite = np.isfinite(arr)
            if int(np.sum(finite)) < 2:
                continue
            mean = float(np.nanmean(arr[finite]))
            sd = float(np.nanstd(arr[finite], ddof=0))
            if sd <= 0 or not np.isfinite(sd):
                z.loc[np.asarray(idx)[finite]] = 0.0
                continue
            z.loc[idx] = (arr - mean) / sd
        out[col] = z
    return out


def fold_average_cell_metrics(
    df: pd.DataFrame,
    *,
    key_cols: list[str],
    value_cols: list[str],
) -> pd.DataFrame:
    """Average numeric fold-level rows into one row per matched cell."""
    missing = [col for col in [*key_cols, *value_cols] if col not in df.columns]
    if missing:
        raise KeyError(f"Missing columns: {missing}")
    work = df.loc[:, [*key_cols, *value_cols]].copy()
    for col in value_cols:
        work[col] = pd.to_numeric(work[col], errors="coerce")
    grouped = work.groupby(key_cols, sort=False, dropna=False)
    out = grouped[value_cols].mean().reset_index()
    out["n_folds_averaged"] = grouped.size().to_numpy(dtype=int)
    return out


def assign_within_group_quantiles(
    df: pd.DataFrame,
    *,
    value_col: str,
    group_col: str,
    out_col: str = "quantile",
    n_quantiles: int = 10,
) -> pd.DataFrame:
    """Assign 1-based within-group quantile labels using stable ranks."""
    if n_quantiles < 2:
        raise ValueError("n_quantiles must be at least 2")
    out = df.copy()
    labels = pd.Series(np.nan, index=out.index, dtype=float)
    values = pd.to_numeric(out[value_col], errors="coerce")
    for _, idx in out.groupby(group_col, sort=False).groups.items():
        idx = list(idx)
        vals = values.loc[idx]
        finite_idx = vals.index[np.isfinite(vals.to_numpy(dtype=float))]
        n = int(len(finite_idx))
        if n == 0:
            continue
        ranks = vals.loc[finite_idx].rank(method="first", ascending=True).to_numpy(dtype=float)
        q = np.ceil(ranks * float(n_quantiles) / float(n)).astype(int)
        labels.loc[finite_idx] = np.clip(q, 1, int(n_quantiles))
    out[out_col] = labels.astype("Int64")
    return out


def demean_by_group_matrix(y: np.ndarray, X: np.ndarray, groups: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Demean outcome and design matrix within groups."""
    yy = np.asarray(y, dtype=float).copy()
    XX = np.asarray(X, dtype=float).copy()
    gg = np.asarray(groups)
    for group in pd.Index(gg).astype(str).unique():
        mask = np.asarray(gg.astype(str) == str(group))
        yy[mask] = yy[mask] - float(np.nanmean(yy[mask]))
        XX[mask, :] = XX[mask, :] - np.nanmean(XX[mask, :], axis=0, keepdims=True)
    return yy, XX


def fit_pair_fixed_ols(
    df: pd.DataFrame,
    *,
    outcome: str,
    predictors: list[str],
    pair_col: str = "pair_id",
    zscore_within_pair: bool = True,
) -> OLSResult:
    """Fit OLS after optional within-pair z-scoring and pair demeaning."""
    cols = [outcome, *predictors, pair_col]
    work = df.loc[:, cols].copy()
    for col in [outcome, *predictors]:
        work[col] = pd.to_numeric(work[col], errors="coerce")
    work = work.dropna(subset=[outcome, *predictors, pair_col]).copy()
    if work.empty or work[pair_col].nunique() < 1:
        return OLSResult({}, {}, {}, np.nan, 0, 0, tuple(predictors))
    if zscore_within_pair:
        work = within_group_zscore(work, [outcome, *predictors], pair_col)
        work = work.dropna(subset=[outcome, *predictors]).copy()
    if len(work) <= len(predictors):
        return OLSResult({}, {}, {}, np.nan, int(len(work)), 0, tuple(predictors))
    y = work[outcome].to_numpy(dtype=float)
    X = work[predictors].to_numpy(dtype=float)
    y_dm, X_dm = demean_by_group_matrix(y, X, work[pair_col].astype(str).to_numpy())
    keep = np.isfinite(y_dm) & np.all(np.isfinite(X_dm), axis=1)
    y_dm = y_dm[keep]
    X_dm = X_dm[keep]
    if y_dm.size <= len(predictors):
        return OLSResult({}, {}, {}, np.nan, int(y_dm.size), 0, tuple(predictors))
    beta, _, rank, _ = np.linalg.lstsq(X_dm, y_dm, rcond=None)
    fitted = X_dm @ beta
    resid = y_dm - fitted
    dof = int(max(0, y_dm.size - rank))
    ss_res = float(np.sum(resid * resid))
    ss_tot = float(np.sum((y_dm - float(np.mean(y_dm))) ** 2))
    r_squared = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else np.nan
    se = np.full(beta.shape, np.nan, dtype=float)
    p_val = np.full(beta.shape, np.nan, dtype=float)
    if dof > 0:
        cov = (ss_res / dof) * np.linalg.pinv(X_dm.T @ X_dm)
        se = np.sqrt(np.clip(np.diag(cov), 0.0, np.inf))
        t_stat = np.divide(beta, se, out=np.full_like(beta, np.nan), where=se > 0)
        p_val = 2.0 * stats.t.sf(np.abs(t_stat), df=dof)
    return OLSResult(
        coef={name: float(beta[i]) for i, name in enumerate(predictors)},
        se={name: float(se[i]) if np.isfinite(se[i]) else np.nan for i, name in enumerate(predictors)},
        p_value={name: float(p_val[i]) if np.isfinite(p_val[i]) else np.nan for i, name in enumerate(predictors)},
        r_squared=r_squared,
        n_obs=int(y_dm.size),
        rank=int(rank),
        predictor_names=tuple(predictors),
    )


def compute_vif(df: pd.DataFrame, predictors: list[str], *, pair_col: str | None = None) -> dict[str, float]:
    """Compute VIFs with optional pair demeaning before auxiliary regressions."""
    work = df.loc[:, predictors + ([pair_col] if pair_col else [])].copy()
    for col in predictors:
        work[col] = pd.to_numeric(work[col], errors="coerce")
    work = work.dropna(subset=predictors).copy()
    if len(predictors) <= 1 or work.empty:
        return {name: 1.0 for name in predictors}
    X = work[predictors].to_numpy(dtype=float)
    if pair_col is not None:
        _, X = demean_by_group_matrix(np.zeros(X.shape[0]), X, work[pair_col].astype(str).to_numpy())
    out: dict[str, float] = {}
    for idx, name in enumerate(predictors):
        y = X[:, idx]
        others = np.delete(X, idx, axis=1)
        keep = np.isfinite(y) & np.all(np.isfinite(others), axis=1)
        if int(np.sum(keep)) <= others.shape[1] + 1:
            out[name] = np.nan
            continue
        beta, _, _, _ = np.linalg.lstsq(others[keep], y[keep], rcond=None)
        resid = y[keep] - others[keep] @ beta
        ss_res = float(np.sum(resid * resid))
        ss_tot = float(np.sum((y[keep] - float(np.mean(y[keep]))) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan
        out[name] = float(1.0 / max(1.0e-9, 1.0 - r2)) if np.isfinite(r2) else np.nan
    return out


def pc1_scores(X: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """Return PC1 scores, loadings, and explained variance ratio."""
    arr = np.asarray(X, dtype=float)
    if arr.ndim != 2:
        raise ValueError("X must be 2D")
    keep = np.all(np.isfinite(arr), axis=1)
    scores = np.full(arr.shape[0], np.nan, dtype=float)
    if int(np.sum(keep)) < 2:
        return scores, np.full(arr.shape[1], np.nan, dtype=float), np.nan
    Xc = arr[keep] - np.nanmean(arr[keep], axis=0, keepdims=True)
    if np.linalg.matrix_rank(Xc) < 1:
        return scores, np.full(arr.shape[1], np.nan, dtype=float), np.nan
    _, s, vt = np.linalg.svd(Xc, full_matrices=False)
    loadings = vt[0].astype(float)
    scores[keep] = Xc @ loadings
    ratio = float((s[0] ** 2) / np.sum(s ** 2)) if np.sum(s ** 2) > 0 else np.nan
    return scores, loadings, ratio


def contiguous_macro8_from_occupancy(
    occupancy: np.ndarray,
    *,
    n_bins: int = 8,
    min_cells_per_bin: int = 3,
    mass_tolerance: tuple[float, float] = (0.5, 2.0),
) -> tuple[np.ndarray, dict[str, Any]]:
    """Greedy contiguous occupancy-balanced partition of a 2D grid."""
    occ = np.asarray(occupancy, dtype=float)
    if occ.ndim != 2:
        raise ValueError("occupancy must be a 2D grid")
    support = np.isfinite(occ) & (occ > 0)
    labels = np.full(occ.shape, -1, dtype=int)
    total = float(np.nansum(occ[support]))
    if total <= 0 or int(np.sum(support)) < int(n_bins):
        return labels, {"valid": False, "reason": "insufficient_support"}
    target = total / float(n_bins)
    unassigned = support.copy()
    for bin_id in range(int(n_bins)):
        remaining_bins = int(n_bins) - bin_id
        remaining_cells = np.argwhere(unassigned)
        if remaining_cells.size == 0:
            break
        if bin_id == int(n_bins) - 1 or remaining_cells.shape[0] <= remaining_bins:
            labels[unassigned] = bin_id
            unassigned[:] = False
            break
        seed_values = occ[unassigned]
        seed_flat = np.flatnonzero(unassigned)[int(np.nanargmax(seed_values))]
        seed = np.unravel_index(seed_flat, occ.shape)
        labels[seed] = bin_id
        unassigned[seed] = False
        mass = float(occ[seed])
        frontier: list[tuple[float, int, int]] = []

        def add_frontier(r: int, c: int) -> None:
            for rr, cc in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if 0 <= rr < occ.shape[0] and 0 <= cc < occ.shape[1] and unassigned[rr, cc]:
                    frontier.append((-float(occ[rr, cc]), rr, cc))

        add_frontier(int(seed[0]), int(seed[1]))
        while mass < target and frontier:
            frontier.sort()
            _, rr, cc = frontier.pop(0)
            if not unassigned[rr, cc]:
                continue
            labels[rr, cc] = bin_id
            unassigned[rr, cc] = False
            mass += float(occ[rr, cc])
            add_frontier(rr, cc)
    if np.any(unassigned):
        labels[unassigned] = int(n_bins) - 1
    masses = np.array([float(np.nansum(occ[labels == i])) for i in range(int(n_bins))], dtype=float)
    cells = np.array([int(np.sum(labels == i)) for i in range(int(n_bins))], dtype=int)
    lo, hi = mass_tolerance
    valid = bool(
        np.all(cells >= int(min_cells_per_bin))
        and np.all(masses >= float(lo) * target)
        and np.all(masses <= float(hi) * target)
    )
    if valid:
        reason = ""
    elif not np.all(cells >= int(min_cells_per_bin)):
        reason = "too_few_cells_in_bucket"
    elif not np.all(masses >= float(lo) * target) or not np.all(masses <= float(hi) * target):
        reason = "mass_ratio_outside_tolerance"
    else:
        reason = "unknown_invalid_partition"
    return labels, {
        "valid": valid,
        "reason": reason,
        "target_mass": target,
        "min_mass_ratio": float(np.nanmin(masses / target)) if target > 0 else np.nan,
        "max_mass_ratio": float(np.nanmax(masses / target)) if target > 0 else np.nan,
        "min_cells": int(np.min(cells)) if cells.size else 0,
        "max_cells": int(np.max(cells)) if cells.size else 0,
        "masses": masses,
        "cells": cells,
    }


def nmi_and_purity(labels_a: np.ndarray, labels_b: np.ndarray) -> dict[str, float]:
    """Compute normalized mutual information and mean max-label purity."""
    a = np.asarray(labels_a).ravel()
    b = np.asarray(labels_b).ravel()
    keep = (a >= 0) & (b >= 0)
    a = a[keep]
    b = b[keep]
    if a.size == 0 or np.unique(a).size < 2 or np.unique(b).size < 2:
        return {"nmi": np.nan, "mean_max_purity": np.nan}
    try:
        from sklearn.metrics import normalized_mutual_info_score

        nmi = float(normalized_mutual_info_score(a, b))
    except Exception:
        nmi = np.nan
    purities = []
    for label in np.unique(a):
        vals = b[a == label]
        if vals.size:
            counts = np.bincount(vals.astype(int))
            purities.append(float(np.max(counts) / vals.size))
    return {"nmi": nmi, "mean_max_purity": float(np.nanmean(purities)) if purities else np.nan}
