"""Statistical helpers for the rapid-learning H-N1 analysis.

The module keeps the prospective neural predictor analysis separate from data
loading and metric construction.  Its two prespecified models are:

``M1``
    Rank(Psi_C) ~ context + Rank(ELPC_A) + Rank(Psi_B) + Rank(E_0)

``M2``
    Rank(Psi_C - Psi_B) ~ context + Rank(ELPC_A) + Rank(E_0)

Inference uses context-restricted Freedman--Lane residual permutations.  The
bootstrap resamples animals within context and re-ranks every resample.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
from scipy import stats as scipy_stats
from scipy.optimize import brentq


@dataclass(frozen=True)
class RankModelResult:
    """Result of one rank-regression model with resampling inference."""

    model_name: str
    n_obs: int
    n_contexts: int
    df_resid: int
    coefficient: float
    standard_error: float
    t_statistic: float
    partial_r: float
    permutation_p_two_sided: float
    coefficient_ci95: tuple[float, float]
    partial_r_ci95: tuple[float, float]
    partial_r_ci90: tuple[float, float]
    n_permutations: int
    n_bootstrap_requested: int
    n_bootstrap_valid: int
    context_levels: tuple[str, ...]
    design_columns: tuple[str, ...]
    seed: int


@dataclass(frozen=True)
class ReliabilitySummary:
    """Spearman--Brown summary across one or more split-half replications.

    The 2.5/97.5% range describes the finite set of seeded replications; it is
    not a bootstrap confidence interval for population reliability.
    """

    n_splits_requested: int
    n_splits_valid: int
    median_raw_correlation: float
    median_spearman_brown: float
    spearman_brown_subset_replication_q025_q975: tuple[float, float]
    threshold: float
    passed: bool
    raw_correlations: tuple[float, ...]
    corrected_reliabilities: tuple[float, ...]


@dataclass(frozen=True)
class HN1ConcordanceResult:
    """Joint interpretation of the ANCOVA and raw-change specifications."""

    ancova: RankModelResult
    change_score: RankModelResult
    intersection_union_p: float
    classification: str
    expected_direction: int
    alpha: float
    mde_margin: float | None


def _as_1d_float(values: Sequence[float], *, name: str) -> np.ndarray:
    out = np.asarray(values, dtype=float)
    if out.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    return out


def _as_1d_context(values: Sequence[object], *, name: str = "context") -> np.ndarray:
    out = np.asarray(values, dtype=object)
    if out.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    if any(
        value is None or (isinstance(value, float) and np.isnan(value)) for value in out
    ):
        raise ValueError(f"{name} contains missing values")
    return out


def rank_zscore(values: Sequence[float]) -> np.ndarray:
    """Return average-tie ranks standardized with population variance.

    The caller must remove non-finite observations first.  A constant input is
    not a usable regression variable and raises ``ValueError``.
    """

    x = _as_1d_float(values, name="values")
    if x.size == 0 or not np.all(np.isfinite(x)):
        raise ValueError("values must be non-empty and finite")
    ranks = scipy_stats.rankdata(x, method="average").astype(float)
    scale = float(np.std(ranks, ddof=0))
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError("values must vary")
    return (ranks - float(np.mean(ranks))) / scale


def _context_design(
    context: np.ndarray,
) -> tuple[np.ndarray, tuple[str, ...], tuple[str, ...]]:
    levels = tuple(sorted({str(value) for value in context}))
    labels = np.asarray([str(value) for value in context], dtype=object)
    columns = [np.ones(labels.size, dtype=float)]
    names = ["intercept"]
    for level in levels[1:]:
        columns.append((labels == level).astype(float))
        names.append(f"context[{level}]")
    return np.column_stack(columns), levels, tuple(names)


def _ols_target(
    y: np.ndarray, x: np.ndarray, target_index: int
) -> dict[str, float | int | np.ndarray]:
    n_obs, n_parameters = x.shape
    if n_obs <= n_parameters:
        raise ValueError("model has no residual degrees of freedom")
    if np.linalg.matrix_rank(x) < n_parameters:
        raise ValueError("design matrix is rank deficient")
    beta, _, _, _ = np.linalg.lstsq(x, y, rcond=None)
    residual = y - x @ beta
    df_resid = n_obs - n_parameters
    sigma2 = float(np.dot(residual, residual) / df_resid)
    xtx_inv = np.linalg.inv(x.T @ x)
    variance = float(sigma2 * xtx_inv[target_index, target_index])
    standard_error = float(np.sqrt(max(0.0, variance)))
    if standard_error <= 0 or not np.isfinite(standard_error):
        raise ValueError("target standard error is not finite and positive")
    coefficient = float(beta[target_index])
    t_statistic = coefficient / standard_error
    partial_r = float(
        np.sign(t_statistic) * np.sqrt(t_statistic**2 / (t_statistic**2 + df_resid))
    )
    return {
        "beta": beta,
        "residual": residual,
        "fitted": x @ beta,
        "df_resid": int(df_resid),
        "coefficient": coefficient,
        "standard_error": standard_error,
        "t_statistic": float(t_statistic),
        "partial_r": partial_r,
    }


def _prepare_rank_design(
    y: np.ndarray,
    target: np.ndarray,
    nuisance: Mapping[str, np.ndarray],
    context: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[str, ...], tuple[str, ...]]:
    y_rank = rank_zscore(y)
    target_rank = rank_zscore(target)
    context_x, levels, context_names = _context_design(context)
    nuisance_columns = []
    nuisance_names = []
    for name, values in nuisance.items():
        nuisance_columns.append(rank_zscore(values))
        nuisance_names.append(str(name))
    if nuisance_columns:
        reduced_x = np.column_stack([context_x, *nuisance_columns])
    else:
        reduced_x = context_x
    full_x = np.column_stack([reduced_x, target_rank])
    design_names = (*context_names, *nuisance_names, "target")
    return y_rank, reduced_x, full_x, levels, design_names


def _restricted_permutation_indices(
    context: np.ndarray, rng: np.random.Generator
) -> np.ndarray:
    labels = np.asarray([str(value) for value in context], dtype=object)
    permutation = np.arange(labels.size)
    for level in sorted(set(labels.tolist())):
        indices = np.flatnonzero(labels == level)
        permutation[indices] = rng.permutation(indices)
    return permutation


def _fit_rank_model_core(
    y: np.ndarray,
    target: np.ndarray,
    nuisance: Mapping[str, np.ndarray],
    context: np.ndarray,
) -> tuple[
    dict[str, float | int | np.ndarray],
    np.ndarray,
    np.ndarray,
    np.ndarray,
    tuple[str, ...],
    tuple[str, ...],
]:
    y_rank, reduced_x, full_x, levels, design_names = _prepare_rank_design(
        y, target, nuisance, context
    )
    observed = _ols_target(y_rank, full_x, full_x.shape[1] - 1)
    return observed, y_rank, reduced_x, full_x, levels, design_names


def fit_rank_freedman_lane(
    y: Sequence[float],
    target: Sequence[float],
    *,
    nuisance: Mapping[str, Sequence[float]] | None,
    context: Sequence[object],
    model_name: str = "rank_model",
    n_permutations: int = 10_000,
    n_bootstrap: int = 5_000,
    seed: int = 0,
) -> RankModelResult:
    """Fit a rank model with context-restricted permutation and bootstrap.

    Numeric rows containing any non-finite value are removed once and the same
    complete-case mask is used for the observed fit, permutations, and
    bootstrap.  Every bootstrap resample is re-ranked.
    """

    y_array = _as_1d_float(y, name="y")
    target_array = _as_1d_float(target, name="target")
    context_array = _as_1d_context(context)
    nuisance_arrays = {
        str(name): _as_1d_float(values, name=f"nuisance[{name}]")
        for name, values in (nuisance or {}).items()
    }
    lengths = {
        y_array.size,
        target_array.size,
        context_array.size,
        *(v.size for v in nuisance_arrays.values()),
    }
    if len(lengths) != 1:
        raise ValueError("all model inputs must have equal length")
    complete = np.isfinite(y_array) & np.isfinite(target_array)
    for values in nuisance_arrays.values():
        complete &= np.isfinite(values)
    y_array = y_array[complete]
    target_array = target_array[complete]
    context_array = context_array[complete]
    nuisance_arrays = {
        name: values[complete] for name, values in nuisance_arrays.items()
    }

    observed, y_rank, reduced_x, full_x, levels, design_names = _fit_rank_model_core(
        y_array, target_array, nuisance_arrays, context_array
    )
    reduced_beta, _, reduced_rank, _ = np.linalg.lstsq(reduced_x, y_rank, rcond=None)
    if reduced_rank < reduced_x.shape[1]:
        raise ValueError("reduced design matrix is rank deficient")
    reduced_fitted = reduced_x @ reduced_beta
    reduced_residual = y_rank - reduced_fitted

    n_permutations = int(max(0, n_permutations))
    n_bootstrap = int(max(0, n_bootstrap))
    seed_sequence = np.random.SeedSequence(int(seed))
    permutation_seed, bootstrap_seed = seed_sequence.spawn(2)
    permutation_rng = np.random.default_rng(permutation_seed)
    bootstrap_rng = np.random.default_rng(bootstrap_seed)

    exceedances = 0
    for _ in range(n_permutations):
        indices = _restricted_permutation_indices(context_array, permutation_rng)
        permuted_y = reduced_fitted + reduced_residual[indices]
        permuted_fit = _ols_target(permuted_y, full_x, full_x.shape[1] - 1)
        if abs(float(permuted_fit["t_statistic"])) >= abs(
            float(observed["t_statistic"])
        ):
            exceedances += 1
    permutation_p = (
        float((exceedances + 1) / (n_permutations + 1))
        if n_permutations > 0
        else np.nan
    )

    coefficient_boot = []
    partial_r_boot = []
    labels = np.asarray([str(value) for value in context_array], dtype=object)
    indices_by_context = [np.flatnonzero(labels == level) for level in levels]
    max_attempts = max(n_bootstrap, 10 * n_bootstrap)
    attempts = 0
    while len(coefficient_boot) < n_bootstrap and attempts < max_attempts:
        attempts += 1
        sampled = np.concatenate(
            [
                bootstrap_rng.choice(indices, size=indices.size, replace=True)
                for indices in indices_by_context
            ]
        )
        try:
            fitted, _, _, _, _, _ = _fit_rank_model_core(
                y_array[sampled],
                target_array[sampled],
                {name: values[sampled] for name, values in nuisance_arrays.items()},
                context_array[sampled],
            )
        except ValueError:
            continue
        coefficient_boot.append(float(fitted["coefficient"]))
        partial_r_boot.append(float(fitted["partial_r"]))

    def quantile_interval(values: list[float], alpha: float) -> tuple[float, float]:
        if not values:
            return (np.nan, np.nan)
        return (
            float(np.quantile(values, alpha / 2.0)),
            float(np.quantile(values, 1.0 - alpha / 2.0)),
        )

    return RankModelResult(
        model_name=str(model_name),
        n_obs=int(y_array.size),
        n_contexts=len(levels),
        df_resid=int(observed["df_resid"]),
        coefficient=float(observed["coefficient"]),
        standard_error=float(observed["standard_error"]),
        t_statistic=float(observed["t_statistic"]),
        partial_r=float(observed["partial_r"]),
        permutation_p_two_sided=permutation_p,
        coefficient_ci95=quantile_interval(coefficient_boot, 0.05),
        partial_r_ci95=quantile_interval(partial_r_boot, 0.05),
        partial_r_ci90=quantile_interval(partial_r_boot, 0.10),
        n_permutations=n_permutations,
        n_bootstrap_requested=n_bootstrap,
        n_bootstrap_valid=len(coefficient_boot),
        context_levels=levels,
        design_columns=design_names,
        seed=int(seed),
    )


def classify_hn1_concordance(
    ancova: RankModelResult,
    change_score: RankModelResult,
    *,
    alpha: float = 0.05,
    expected_direction: int = 1,
    mde_margin: float | None = None,
    metric_resolved: bool = True,
    heterogeneous: bool = False,
    engagement_linked: bool = False,
) -> HN1ConcordanceResult:
    """Apply the prespecified intersection-union interpretation ladder."""

    direction = 1 if int(expected_direction) >= 0 else -1
    p_values = [ancova.permutation_p_two_sided, change_score.permutation_p_two_sided]
    iut_p = float(max(p_values)) if np.all(np.isfinite(p_values)) else np.nan

    def supported(result: RankModelResult) -> bool:
        directional_ci = (
            result.coefficient_ci95[0] if direction > 0 else -result.coefficient_ci95[1]
        )
        return bool(
            direction * result.coefficient > 0
            and np.isfinite(result.permutation_p_two_sided)
            and result.permutation_p_two_sided < alpha
            and np.isfinite(directional_ci)
            and directional_ci > 0
        )

    if not metric_resolved:
        classification = "metric_unresolved"
    elif heterogeneous:
        classification = "heterogeneous_unresolved"
    elif engagement_linked:
        classification = "engagement_linked"
    elif ancova.coefficient * change_score.coefficient < 0:
        classification = "baseline_adjustment_sensitive"
    else:
        ancova_supported = supported(ancova)
        change_supported = supported(change_score)
        if ancova_supported and change_supported:
            classification = "supported_associative"
        elif ancova_supported != change_supported:
            classification = "model_sensitive"
        elif mde_margin is not None and np.isfinite(mde_margin):
            directional_upper = [
                ancova.partial_r_ci90[1]
                if direction > 0
                else -ancova.partial_r_ci90[0],
                change_score.partial_r_ci90[1]
                if direction > 0
                else -change_score.partial_r_ci90[0],
            ]
            classification = (
                "large_effect_ruled_out"
                if np.all(np.isfinite(directional_upper))
                and all(value < float(mde_margin) for value in directional_upper)
                else "inconclusive_power"
            )
        else:
            classification = "inconclusive_power"

    return HN1ConcordanceResult(
        ancova=ancova,
        change_score=change_score,
        intersection_union_p=iut_p,
        classification=classification,
        expected_direction=direction,
        alpha=float(alpha),
        mde_margin=None if mde_margin is None else float(mde_margin),
    )


def fit_hn1_concordance(
    psi_b: Sequence[float],
    psi_c: Sequence[float],
    elpc_a: Sequence[float],
    engagement: Sequence[float],
    context: Sequence[object],
    *,
    n_permutations: int = 10_000,
    n_bootstrap: int = 5_000,
    seed: int = 0,
    alpha: float = 0.05,
    expected_direction: int = 1,
    mde_margin: float | None = None,
    metric_resolved: bool = True,
    heterogeneous: bool = False,
    engagement_linked: bool = False,
) -> HN1ConcordanceResult:
    """Fit H-N1's ANCOVA and raw-change models on a common complete-case set."""

    psi_b_array = _as_1d_float(psi_b, name="psi_b")
    psi_c_array = _as_1d_float(psi_c, name="psi_c")
    elpc_array = _as_1d_float(elpc_a, name="elpc_a")
    engagement_array = _as_1d_float(engagement, name="engagement")
    context_array = _as_1d_context(context)
    lengths = {
        psi_b_array.size,
        psi_c_array.size,
        elpc_array.size,
        engagement_array.size,
        context_array.size,
    }
    if len(lengths) != 1:
        raise ValueError("all H-N1 inputs must have equal length")
    complete = (
        np.isfinite(psi_b_array)
        & np.isfinite(psi_c_array)
        & np.isfinite(elpc_array)
        & np.isfinite(engagement_array)
    )
    psi_b_array = psi_b_array[complete]
    psi_c_array = psi_c_array[complete]
    elpc_array = elpc_array[complete]
    engagement_array = engagement_array[complete]
    context_array = context_array[complete]

    seeds = np.random.SeedSequence(int(seed)).generate_state(2, dtype=np.uint32)
    ancova = fit_rank_freedman_lane(
        psi_c_array,
        elpc_array,
        nuisance={"psi_b": psi_b_array, "engagement": engagement_array},
        context=context_array,
        model_name="M1_ancova",
        n_permutations=n_permutations,
        n_bootstrap=n_bootstrap,
        seed=int(seeds[0]),
    )
    change = fit_rank_freedman_lane(
        psi_c_array - psi_b_array,
        elpc_array,
        nuisance={"engagement": engagement_array},
        context=context_array,
        model_name="M2_raw_change",
        n_permutations=n_permutations,
        n_bootstrap=n_bootstrap,
        seed=int(seeds[1]),
    )
    return classify_hn1_concordance(
        ancova,
        change,
        alpha=alpha,
        expected_direction=expected_direction,
        mde_margin=mde_margin,
        metric_resolved=metric_resolved,
        heterogeneous=heterogeneous,
        engagement_linked=engagement_linked,
    )


def spearman_brown_split_half(
    first_halves: Sequence[float] | Sequence[Sequence[float]],
    second_halves: Sequence[float] | Sequence[Sequence[float]],
    *,
    threshold: float = 0.75,
) -> ReliabilitySummary:
    """Summarize matched split-half estimates across subjects.

    Rows are independent split replications and columns are subjects.  One-
    dimensional inputs are treated as a single split replication.
    """

    first = np.asarray(first_halves, dtype=float)
    second = np.asarray(second_halves, dtype=float)
    if first.shape != second.shape:
        raise ValueError("first_halves and second_halves must have equal shape")
    if first.ndim == 1:
        first = first[None, :]
        second = second[None, :]
    if first.ndim != 2:
        raise ValueError("split-half arrays must be one- or two-dimensional")

    raw = []
    corrected = []
    for left, right in zip(first, second, strict=True):
        keep = np.isfinite(left) & np.isfinite(right)
        if np.count_nonzero(keep) < 3:
            continue
        correlation = float(scipy_stats.spearmanr(left[keep], right[keep]).statistic)
        if not np.isfinite(correlation) or correlation <= -1.0:
            continue
        raw.append(correlation)
        corrected.append(float((2.0 * correlation) / (1.0 + correlation)))

    if corrected:
        median_raw = float(np.median(raw))
        median_corrected = float(np.median(corrected))
        subset_replication_q025_q975 = (
            float(np.quantile(corrected, 0.025)),
            float(np.quantile(corrected, 0.975)),
        )
    else:
        median_raw = np.nan
        median_corrected = np.nan
        subset_replication_q025_q975 = (np.nan, np.nan)
    return ReliabilitySummary(
        n_splits_requested=int(first.shape[0]),
        n_splits_valid=len(corrected),
        median_raw_correlation=median_raw,
        median_spearman_brown=median_corrected,
        spearman_brown_subset_replication_q025_q975=(subset_replication_q025_q975),
        threshold=float(threshold),
        passed=bool(
            np.isfinite(median_corrected) and median_corrected >= float(threshold)
        ),
        raw_correlations=tuple(raw),
        corrected_reliabilities=tuple(corrected),
    )


def partial_r_power(partial_r: float, df_resid: int, *, alpha: float = 0.05) -> float:
    """Two-sided noncentral-t power for a partial correlation."""

    r = abs(float(partial_r))
    df = int(df_resid)
    if not 0 <= r < 1:
        raise ValueError("partial_r must satisfy abs(partial_r) < 1")
    if df <= 0:
        raise ValueError("df_resid must be positive")
    critical = float(scipy_stats.t.ppf(1.0 - float(alpha) / 2.0, df))
    noncentrality = r * np.sqrt(df / (1.0 - r**2))
    with np.errstate(divide="ignore", invalid="ignore"):
        power = float(
            scipy_stats.nct.sf(critical, df, noncentrality)
            + scipy_stats.nct.cdf(-critical, df, noncentrality)
        )
    if not np.isfinite(power):
        # Some SciPy builds return NaN from the noncentral-t routines once the
        # noncentrality grows large, which breaks the bracketing solver in
        # detectable_partial_r. Power saturates at one in that regime, and the
        # normal approximation is accurate there.
        power = float(
            scipy_stats.norm.sf(critical - noncentrality)
            + scipy_stats.norm.cdf(-critical - noncentrality)
        )
    return float(min(max(power, 0.0), 1.0))


def detectable_partial_r(
    df_resid: int,
    *,
    alpha: float = 0.05,
    power: float = 0.80,
) -> float:
    """Solve for the smallest partial correlation with the requested power."""

    if not 0 < float(power) < 1:
        raise ValueError("power must lie strictly between zero and one")
    return float(
        brentq(
            lambda value: partial_r_power(value, int(df_resid), alpha=alpha)
            - float(power),
            1e-9,
            0.99,
        )
    )


def build_hn1_mde_report(
    n_obs: int,
    n_contexts: int,
    *,
    alpha: float = 0.05,
    target_power: float = 0.80,
    n_simulations: int = 100_000,
    seed: int = 0,
) -> dict[str, object]:
    """Build a deterministic, hashable MDE report for the two H-N1 models.

    Empirical power draws directly from the noncentral-t distribution at the
    analytic MDE.  It therefore checks Monte Carlo reproducibility of the ideal
    partial-effect calculation; it does not include measurement error or the
    stricter two-model concordance rule.
    """

    n_obs = int(n_obs)
    n_contexts = int(n_contexts)
    n_simulations = int(max(1, n_simulations))
    model_df = {
        "M1_ancova": n_obs - n_contexts - 3,
        "M2_raw_change": n_obs - n_contexts - 2,
    }
    if min(model_df.values()) <= 0:
        raise ValueError("sample size is too small for the requested context structure")
    rngs = [
        np.random.default_rng(child)
        for child in np.random.SeedSequence(int(seed)).spawn(2)
    ]
    models: dict[str, object] = {}
    for (model_name, df_resid), rng in zip(model_df.items(), rngs, strict=True):
        mde = detectable_partial_r(df_resid, alpha=alpha, power=target_power)
        critical = float(scipy_stats.t.ppf(1.0 - float(alpha) / 2.0, df_resid))
        noncentrality = mde * np.sqrt(df_resid / (1.0 - mde**2))
        draws = scipy_stats.nct.rvs(
            df_resid,
            noncentrality,
            size=n_simulations,
            random_state=rng,
        )
        empirical_power = float(np.mean(np.abs(draws) >= critical))
        models[model_name] = {
            "df_resid": int(df_resid),
            "analytic_partial_r_mde": mde,
            "empirical_power_at_mde": empirical_power,
        }

    report: dict[str, object] = {
        "schema_version": "hn1_mde_v1",
        "n_obs": n_obs,
        "n_contexts": n_contexts,
        "alpha_two_sided": float(alpha),
        "target_power": float(target_power),
        "n_simulations": n_simulations,
        "seed": int(seed),
        "models": models,
        "limitations": (
            "Single-model ideal partial-effect MDEs; measurement error, predictor unreliability, "
            "and the M1/M2 intersection-union rule can only increase the required true effect."
        ),
    }
    canonical = json.dumps(
        report, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    report["content_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    return report


def write_frozen_mde_report(path: str | Path, report: Mapping[str, object]) -> Path:
    """Write a hashed MDE report once; refuse to overwrite different content."""

    destination = Path(path)
    payload = dict(report)
    claimed_hash = payload.pop("content_sha256", None)
    canonical = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    actual_hash = sha256(canonical.encode("utf-8")).hexdigest()
    if claimed_hash != actual_hash:
        raise ValueError("report content_sha256 does not match its payload")
    payload["content_sha256"] = actual_hash
    rendered = json.dumps(payload, sort_keys=True, indent=2, allow_nan=False) + "\n"
    if destination.exists():
        if destination.read_text(encoding="utf-8") != rendered:
            raise FileExistsError(f"refusing to overwrite frozen report: {destination}")
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(rendered, encoding="utf-8")
    return destination


def model_result_as_dict(result: RankModelResult) -> dict[str, object]:
    """Return a JSON-friendly audit representation of a model result."""

    return asdict(result)
