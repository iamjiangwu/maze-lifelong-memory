from __future__ import annotations

from .maze import (
    ConnectDistance,
    ConnectPath,
    HomePath,
    MakeStepType,
    Maze,
    MazeCenter,
    MazeWall,
    NewMaze,
    RunIndex,
)
from .trajectory import FindPathsToNode, LoadTraj, SplitModeClips, TimeInMaze, Traj
from .mm_maze_utils import (
    HomeDistance,
    NodeLevel,
    PlotMazeCells,
    PlotMazeCenter,
    PlotMazeFunction,
    PlotMazeNodes,
    PlotMazeNums,
    PlotMazeRuns,
    PlotMazeWall,
    StepType,
    StepType2,
    StepType3,
)
from .mm_plot_utils import hist, plot, save_mib_img, set_axes, test_plot
from .mm_traj import (
    DecisionInMaze,
    Entropy,
    ExtractNoseTraj,
    ExtractRewards,
    FindHomeRunNodes,
    FindPathsToExit,
    FirstTransProb,
    FixTraj,
    FixTraj2,
    FrameInExpt,
    HistoNodeDurations,
    InspectBouts,
    InspectXYvT,
    ListErrors,
    Ln,
    Make2ndMarkov,
    MakeRandomWalk,
    NewNodes4,
    NewNodesMerge3,
    NewTraj,
    NodeOccupancy,
    ParseNodeTrajectory,
    PlotAllXYvT,
    PlotCellOccupancy,
    PlotNodeBias,
    PlotNodeBiasLocation,
    PlotNodeOccupancy,
    PlotPathsToExit,
    PlotPathsToNode,
    PlotStringEntropy,
    PlotTraj,
    PlotXYvT,
    SaveTraj,
    SecondTransProb,
    SimulateFirstMarkov,
    SimulateRandomWalk,
    SimulateSecondMarkov,
    SmoothTrajectory,
    StepInMaze,
    StringEntropy,
    TallyNodeStepTypes,
    TallyStepTypes,
    TallyStrings,
    TallyTwoSteps,
    TestTrajModule,
    TransMatrix,
    xlogx,
)
from .similarity import (
    cross_session_level_shift_similarity,
    cross_session_pv_cross_similarity_matrix,
    pf_shuffle_level_shift_similarity,
    pivot_window_tuning_similarity,
    run_similarity_pipeline,
    within_session_pv_temporal_similarity,
)
from . import jw_utils as _jw_utils

_protected_callables = {name for name, value in globals().items() if callable(value)}
for _name in dir(_jw_utils):
    if _name.startswith("_") or _name in _protected_callables:
        continue
    _value = getattr(_jw_utils, _name)
    if callable(_value):
        globals()[_name] = _value


__all__ = sorted(
    name
    for name, value in globals().items()
    if not name.startswith("_") and callable(value)
)
