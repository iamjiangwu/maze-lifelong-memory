"""Canonical ensemble-rate estimators.

Ensemble rate is a temporal, not spatial, summary.  Each neuron's value is its
total activity during the analyzed samples divided by the duration represented
by those samples.  Ensemble-rate stability is the Pearson correlation between
matched-neuron rate vectors.
"""

from __future__ import annotations

import numpy as np


def duration_normalized_rate_vector(
    activity: np.ndarray,
    sample_duration_seconds: float | np.ndarray,
    *,
    per_seconds: float = 60.0,
) -> np.ndarray:
    """Return one duration-normalized activity rate per neuron.

    Parameters
    ----------
    activity
        Samples-by-neurons activity array. Missing activity samples are ignored
        in both the numerator and that neuron's denominator.
    sample_duration_seconds
        Either one duration shared by all samples or one duration per sample.
    per_seconds
        Reporting unit. The default returns activity per minute.
    """

    values = np.asarray(activity, dtype=float)
    if values.ndim != 2:
        raise ValueError("activity must be a samples-by-neurons array")
    if not np.isfinite(per_seconds) or per_seconds <= 0:
        raise ValueError("per_seconds must be finite and positive")

    durations = np.asarray(sample_duration_seconds, dtype=float)
    if durations.ndim == 0:
        durations = np.full(values.shape[0], float(durations), dtype=float)
    if durations.ndim != 1 or durations.size != values.shape[0]:
        raise ValueError("sample_duration_seconds must be scalar or match samples")
    if np.any(~np.isfinite(durations)) or np.any(durations <= 0):
        raise ValueError("sample durations must be finite and positive")

    finite = np.isfinite(values)
    numerator = np.nansum(values, axis=0)
    denominator_seconds = np.sum(finite * durations[:, None], axis=0)
    rates = np.full(values.shape[1], np.nan, dtype=float)
    defined = denominator_seconds > 0
    rates[defined] = numerator[defined] / denominator_seconds[defined] * per_seconds
    return rates


def ensemble_rate_correlation(
    rate_a: np.ndarray,
    rate_b: np.ndarray,
    *,
    remove_silent_both: bool = True,
    min_neurons: int = 3,
) -> float:
    """Pearson correlation between two matched-neuron rate vectors.

    A neuron with a zero rate in only one interval is retained. By default,
    neurons with zero rate in both intervals are removed, matching the current
    manuscript implementation.
    """

    left = np.asarray(rate_a, dtype=float).ravel()
    right = np.asarray(rate_b, dtype=float).ravel()
    if left.shape != right.shape:
        raise ValueError("matched-neuron rate vectors must have the same shape")
    if min_neurons < 2:
        raise ValueError("min_neurons must be at least 2")

    keep = np.isfinite(left) & np.isfinite(right)
    if remove_silent_both:
        keep &= (left != 0) | (right != 0)
    left = left[keep]
    right = right[keep]
    if left.size < min_neurons or np.ptp(left) == 0 or np.ptp(right) == 0:
        return float("nan")
    return float(np.corrcoef(left, right)[0, 1])
