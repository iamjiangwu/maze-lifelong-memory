from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .maze import Maze
from . import mm


@dataclass
class OccupancySummary:
    counts: np.ndarray
    fraction: np.ndarray


def _as_int_array(x) -> np.ndarray:
    a = np.asarray(x)
    if a.size == 0:
        return np.zeros(0, dtype=int)
    return a.astype(int).ravel()


def compute_cell_occupancy(cell_ids, n_cells: int | None = None) -> OccupancySummary:
    ids = _as_int_array(cell_ids)
    if ids.size == 0:
        n = int(n_cells or 0)
        z = np.zeros(n, dtype=float)
        return OccupancySummary(counts=z.astype(int), fraction=z)
    n = int(n_cells if n_cells is not None else (int(np.nanmax(ids)) + 1))
    counts = np.bincount(ids, minlength=n)
    frac = counts.astype(float) / max(1, int(np.sum(counts)))
    return OccupancySummary(counts=counts, fraction=frac)


def compute_node_occupancy(node_ids, n_nodes: int | None = None) -> OccupancySummary:
    return compute_cell_occupancy(node_ids, n_cells=n_nodes)


def tally_step_types(node_ids, ma: Maze) -> np.ndarray:
    """
    Count transitions by MM step-type code:
    0=in-left, 1=in-right, 2=out-left, 3=out-right.
    """
    nodes = _as_int_array(node_ids)
    if nodes.size < 2:
        return np.zeros(4, dtype=int)
    run_ids = np.asarray(ma.rc, dtype=int)
    st = np.asarray(ma.st, dtype=int)
    counts = np.zeros(4, dtype=int)
    for a, b in zip(nodes[:-1], nodes[1:]):
        if a < 0 or b < 0 or a >= len(run_ids) or b >= len(run_ids):
            continue
        ra = int(run_ids[int(a)])
        rb = int(run_ids[int(b)])
        if ra < 0 or rb < 0 or ra >= st.shape[0] or rb >= st.shape[1]:
            continue
        step = int(st[ra, rb])
        if 0 <= step < 4:
            counts[step] += 1
    return counts


def reward_run_durations(reward_frames, *, fps: float = 25.0) -> np.ndarray:
    rf = np.asarray(reward_frames, dtype=float).ravel()
    if rf.size < 2:
        return np.zeros(0, dtype=float)
    rf = np.sort(rf[np.isfinite(rf)])
    if rf.size < 2:
        return np.zeros(0, dtype=float)
    return np.diff(rf) / float(fps)


def time_to_first_reward(reward_frames, bout_start_frame: int, *, fps: float = 25.0) -> float:
    rf = np.asarray(reward_frames, dtype=float).ravel()
    rf = rf[np.isfinite(rf)]
    if rf.size == 0:
        return np.nan
    first = float(np.min(rf))
    return (first - float(bout_start_frame)) / float(fps)


def find_home_run_lengths(node_ids, ma: Maze, *, home_node: int = 0) -> np.ndarray:
    """
    Approximate home-run lengths as monotonic decreases in maze distance to home.
    """
    nodes = _as_int_array(node_ids)
    if nodes.size < 2:
        return np.zeros(0, dtype=int)
    di = np.asarray(ma.di, dtype=float)
    d = di[nodes, int(home_node)]
    out = []
    run = 0
    for i in range(1, len(d)):
        if d[i] < d[i - 1]:
            run += 1
        else:
            if run > 0:
                out.append(int(run))
            run = 0
    if run > 0:
        out.append(int(run))
    return np.asarray(out, dtype=int)


def flatten_traj_nodes(traj) -> np.ndarray:
    no = getattr(traj, "no", None)
    if no is None:
        return np.zeros(0, dtype=int)
    nodes = []
    for bout in no or []:
        b = np.asarray(bout)
        if b.ndim != 2 or b.shape[0] == 0:
            continue
        nodes.extend(b[:, 0].astype(int).tolist())
    return np.asarray(nodes, dtype=int)


def ensure_node_trajectory(traj, ma: Maze):
    """
    Ensure tr.no exists by parsing legacy cell trajectory when needed.
    """
    if getattr(traj, "no", None) is not None:
        return traj
    parser = getattr(mm, "ParseNodeTrajectory", None)
    if parser is None:
        return traj
    parser(traj, ma)
    return traj


def node_occupancy_from_traj(traj, ma: Maze, *, prefer_legacy: bool = True) -> np.ndarray:
    tr = ensure_node_trajectory(traj, ma)
    if prefer_legacy:
        fn = getattr(mm, "NodeOccupancy", None)
        if fn is not None:
            return np.asarray(fn(tr, ma), dtype=float)
    no = np.zeros(len(ma.ru), dtype=float)
    for bout in getattr(tr, "no", []) or []:
        b = np.asarray(bout, dtype=int)
        if b.ndim != 2 or b.shape[0] < 2:
            continue
        for n in range(len(b) - 1):
            node = int(b[n, 0])
            if 0 <= node < len(no):
                no[node] += float(b[n + 1, 1] - b[n, 1])
    return no


def step_type_tally_from_traj(traj, ma: Maze, *, prefer_legacy: bool = True) -> np.ndarray:
    tr = ensure_node_trajectory(traj, ma)
    if prefer_legacy:
        fn = getattr(mm, "TallyStepTypes", None)
        if fn is not None:
            d = fn(tr, ma)
            return np.asarray([d.get(0, 0), d.get(1, 0), d.get(2, 0), d.get(3, 0)], dtype=int)
    st = np.asarray(ma.st, dtype=int)
    out = np.zeros(4, dtype=int)
    for bout in getattr(tr, "no", []) or []:
        b = np.asarray(bout, dtype=int)
        if b.ndim != 2 or b.shape[0] < 2:
            continue
        for i in range(len(b) - 1):
            a = int(b[i, 0])
            c = int(b[i + 1, 0])
            if a < 0 or c < 0 or a >= st.shape[0] or c >= st.shape[1]:
                continue
            step = int(st[a, c])
            if 0 <= step < 4:
                out[step] += 1
    return out


def home_run_lengths_from_traj(traj, ma: Maze, *, prefer_legacy: bool = True) -> np.ndarray:
    tr = ensure_node_trajectory(traj, ma)
    if prefer_legacy:
        fn = getattr(mm, "FindHomeRunNodes", None)
        if fn is not None:
            hr = fn(tr, ma)
            if isinstance(hr, tuple) and len(hr) >= 2:
                lengths = np.asarray(hr[1], dtype=float).ravel()
                return lengths
    node_seq = flatten_traj_nodes(tr)
    return find_home_run_lengths(node_seq, ma)
