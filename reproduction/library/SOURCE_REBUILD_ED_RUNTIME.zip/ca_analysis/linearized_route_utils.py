"""Lightweight route helpers used by the linearized place-field exporter.

These functions preserve the implementations in ``ca_analysis.jw_utils`` without
importing that legacy monolith (and its plotting / sklearn dependency tree) in a
raw-data export process.
"""

from __future__ import annotations

import pickle

import numpy as np


def find_subsequences(states_frames, start_state, end_state, threshold):
    subsequences = []
    n = states_frames.shape[0]
    i = 0
    while i < n:
        if states_frames[i, 0] == start_state:
            subseq_start = i
            found_end_state = False
            for j in range(i + 1, min(i + threshold, n)):
                if states_frames[j, 0] == end_state and not (
                    start_state in states_frames[i + 1 : j, 0]
                    or end_state in states_frames[i + 1 : j, 0]
                ):
                    subsequences.append(states_frames[subseq_start : j + 1])
                    i = j
                    found_end_state = True
                    break
            if not found_end_state:
                i += 1
        else:
            i += 1
    return subsequences


def prepend_home_exit_state(bout, start_frame):
    exit_home_state = np.array([[127, start_frame]])
    return np.vstack((exit_home_state, bout))


def find_subsequences_in_bouts(bouts, tf_fr, start_state, end_state, threshold):
    all_subsequences = []
    for bout_index, bout in enumerate(bouts):
        if bout.shape[0] < 2:
            continue
        bout_start_frame = tf_fr[bout_index, 0]
        adjusted_bout = prepend_home_exit_state(bout, 0)
        subsequences = find_subsequences(
            adjusted_bout, start_state, end_state, threshold
        )
        if not subsequences:
            continue
        for subsequence in subsequences:
            adjusted_subsequence = subsequence.copy()
            adjusted_subsequence[:, 1] += bout_start_frame
            all_subsequences.append(adjusted_subsequence)
    return all_subsequences


def find_path_node_based(start_index, end_index):
    def path_to_root(index):
        path = []
        if index == 127:
            return [127, 0]
        while index >= 0:
            path.append(index)
            if index == 0:
                break
            index = (index - 1) // 2
        return path

    start_path = path_to_root(start_index)
    end_path = path_to_root(end_index)
    lca = -1
    for i in range(min(len(start_path), len(end_path))):
        if start_path[-1 - i] == end_path[-1 - i]:
            lca = start_path[-1 - i]
        else:
            break
    start_to_lca = start_path[: start_path.index(lca) + 1]
    lca_to_end = end_path[: end_path.index(lca) + 1]
    lca_to_end.reverse()
    return start_to_lca + lca_to_end[1:]


def load_hash_map(file_path):
    with open(file_path, "rb") as file:
        return pickle.load(file)


def get_node_positions(sequence, hash_map):
    return [hash_map[node] for node in sequence]


def get_edges(sequence):
    return [(i, i + 1) for i in range(len(sequence) - 1)]
