"""Literate specifications for the rapid-learning audit notebook suite.

This catalog does not redefine any estimator.  It records the contracts already
implemented by the maintained scripts so that the generated notebooks can show
animal selection, transformations, equations, parameters, leakage controls,
and known limitations next to the frozen outputs.
"""

from __future__ import annotations

from typing import Any


def _artifact(
    path: str,
    stage: str,
    role: str,
    *,
    key_columns: tuple[str, ...] = (),
    preview_columns: tuple[str, ...] = (),
) -> dict[str, Any]:
    return {
        "path": path,
        "stage": stage,
        "role": role,
        "key_columns": list(key_columns),
        "preview_columns": list(preview_columns),
    }


PHASE_SPECS: tuple[dict[str, Any], ...] = (
    {
        "phase": "phase0",
        "title": "Phase 0 — frozen cohort, alignment, timebase, and event truth",
        "analysis_ids": [],
        "hypotheses": [],
        "purpose": (
            "Create the immutable session inventory and expand trajectories into "
            "absolute-frame graph decisions before any outcome or neural model is fit."
        ),
        "sources": [
            "scripts/build_rapid_learning_phase0.py",
            "src/ca_analysis/rapid_learning_phase0.py",
            "src/ca_analysis/trajectory.py",
        ],
        "manifests": ["phase0/phase0_manifest.json"],
        "reproduction": ["python scripts/build_rapid_learning_phase0.py --overwrite"],
        "groups": [
            "23 first-exposure Day1↔Day2 pairs: 9 no-water latent, 10 rewarded from Day1, and 4 dry-port.",
            "Animal 769 is behavior-only because no usable neural matrix exists; it is retained for behavioral analyses and excluded from neural denominators.",
            "Sorted neural data are preferred, with original-data fallback explicitly recorded. Same-visit Day1↔Day2 index identity is accepted only when the provenance table verifies a joint component basis and equal component counts.",
        ],
        "selection_rules": [
            "Load each frozen pair from the maintained cohort manifest; never infer membership from the 153-session behavioral pool.",
            "Use SplitModeClips codes leave=0, drink=1, explore=2 and expand each explore clip into candidate transitions and alternatives.",
            "Take reward onset from actual tf.re events. Node 94 is the canonical target, but entering node 94 is not used as a reward-delivery proxy.",
            "Read absolute frames from bout-local frames plus trajectory offsets. Use maze time only for selection; selected_df may be discontinuous and is not treated as a continuous clock.",
            "Apply analysis-specific readiness gates: ≥10 Day1 explore structure decisions, ≥1 actual reward event for discovery, ≥5 postreward primary decisions for binding, and ≥50 selected Day1 explore rows plus neural alignment for ELPC.",
        ],
        "signal": "Behavioral trajectory and tf.re are primary. C/S availability is audited but no neural value is analyzed in Phase 0.",
        "timebase": "Absolute frame and cumulative maze time; half-open transition intervals; no joining across missing/filtered samples.",
        "representation": "Binary-tree graph nodes, directed transitions, candidate next-node alternatives, and clip/bout identity.",
        "steps": [
            "Freeze pair and cohort labels before analysis.",
            "Resolve behavior and neural files and record every fallback or exclusion reason.",
            "Expand explore clips into one row per transition and one row per candidate choice alternative.",
            "Attach previous/current/next node, arrival relation, depth, absolute frame, maze seconds, clip, bout, and reward epoch.",
            "Extract every actual tf.re interval and identify the reward-learning day separately for rewarded, latent, and dry-port animals.",
            "Compute, but do not silently relax, readiness gates for every downstream phase.",
            "Hash all exported tables and freeze the inventory used by later analyses.",
        ],
        "equations": r"""
For bout-local frame (f_{b,t}) with bout offset (o_b), the common frame is

\[
f^{\mathrm{abs}}_{b,t}=o_b+f_{b,t}.
\]

An inclusive calcium count window with configured look-back (w) contains
(w+1) samples, so its exposure is

\[
T_{\mathrm{exposure}}=(w+1)\Delta t.
\]

These definitions are bookkeeping contracts, not scientific estimators.
""",
        "parameters": [
            {"name": "canonical_reward_node", "value": 94, "class": "task-defined", "hand_chosen": False, "held_out": False, "reason": "Current experimental reward endpoint."},
            {"name": "explore_mode_code", "value": 2, "class": "legacy data contract", "hand_chosen": False, "held_out": False, "reason": "SplitModeClips maintained convention."},
            {"name": "minimum structure decisions", "value": 10, "class": "quality gate", "hand_chosen": True, "held_out": True, "reason": "Minimum support fixed before outcome models."},
            {"name": "minimum postreward binding decisions", "value": 5, "class": "quality gate", "hand_chosen": True, "held_out": True, "reason": "Prevents a binding estimate from one or two choices."},
            {"name": "minimum ELPC selected rows", "value": 50, "class": "quality gate", "hand_chosen": True, "held_out": True, "reason": "Feasibility screen only; later reliability remains mandatory."},
        ],
        "held_out_logic": [
            "Cohort membership and reward context were frozen before model fitting.",
            "Phase 0 performs no hypothesis test and therefore cannot use outcomes to select animals.",
            "Different-session biological identity is never inferred from matching array indices; joint-basis provenance or an explicit CIMap is required.",
        ],
        "risks": [
            "There is no single canonical behavior-neural metafile; the exported provenance table is load-bearing.",
            "Selected neural rows are discontinuous in absolute time; joining them would create artificial temporal correlations.",
            "The 153 behavioral sessions are a broad source pool, not the denominator for the 23-pair rapid-learning design.",
        ],
        "selection_artifact": {
            "path": "phase0/rapid_learning_session_inventory.csv",
            "columns": ["animal_id", "pair_id", "cohort_group", "session_day1", "session_day2", "forced_behavior_only", "day1_neural_source_policy", "day2_neural_source_policy", "C_pair_ready", "dist_arcrit_S_ready", "ELPC_ready"],
        },
        "artifacts": [
            _artifact("phase0/rapid_learning_session_inventory.csv", "source", "Frozen pair/cohort inventory", key_columns=("animal_id", "cohort_group"), preview_columns=("animal_id", "pair_id", "cohort_group", "session_day1", "session_day2", "forced_behavior_only")),
            _artifact("phase0/rapid_learning_session_support.csv", "alignment", "Behavior-neural file resolution and readiness", key_columns=("session_id", "neural_lookup_status"), preview_columns=("animal_id", "session_id", "day_index", "cohort_group", "neural_source", "neural_lookup_status")),
            _artifact("phase0/mode_clip_audit.csv", "transformation", "Clip-to-mode and absolute-frame audit", key_columns=("session_id", "mode_label", "clip_abs_frame_start"), preview_columns=("animal_id", "session_id", "bout", "mode_label", "clip_abs_frame_start", "clip_abs_frame_end")),
            _artifact("phase0/rapid_learning_transition_support.csv", "transformation", "Expanded graph transitions", key_columns=("session_id", "transition_index_session", "abs_frame_start"), preview_columns=("animal_id", "session_id", "day_index", "prev_node", "current_node", "next_node", "abs_frame_start", "maze_seconds_start")),
            _artifact("phase0/actual_reward_events.csv", "event truth", "Actual tf.re reward intervals", key_columns=("session_id", "reward_abs_frame"), preview_columns=("animal_id", "session_id", "cohort_group", "day_index", "reward_event_index", "reward_abs_frame", "reward_maze_seconds", "reward_source")),
        ],
        "panels": [
            {"path": "phase0/rapid_learning_session_inventory.csv", "kind": "animal_counts", "x": "cohort_group", "title": "A  Frozen animals by context"},
            {"path": "phase0/rapid_learning_session_support.csv", "kind": "animal_counts", "x": "day_index", "hue": "neural_lookup_status", "title": "B  Neural readiness by day"},
            {"path": "phase0/actual_reward_events.csv", "kind": "counts", "x": "cohort_group", "hue": "day_index", "title": "C  Actual reward events"},
            {"path": "phase0/mode_clip_audit.csv", "kind": "counts", "x": "mode_label", "title": "D  Clip expansion by mode"},
        ],
        "figures": ["phase5_report/audit_figures/phase0_cohort_support_audit.png"],
        "conclusion": "The cohort and timebase are frozen and auditable. Phase 0 makes no learning claim.",
    },
    {
        "phase": "phase1",
        "title": "Phase 1 — behavioral structure acquisition and reward endpoints",
        "analysis_ids": ["H-S0", "H-S1", "H-S1-PBS", "H-S1-PBF", "H-S1G", "H-R1", "H-S2"],
        "hypotheses": [
            {"id": "H-S0", "statement": "The proposed graph-policy score is not a mechanical consequence of accumulating visited nodes.", "test": "Apply the exact-support fixed-policy null and require centered C-minus-B gain beyond it.", "why": "Frontier/history features become available over time even under a fixed policy."},
            {"id": "H-S1", "statement": "Held-out graph-policy choice prediction improves from early B to late C.", "test": "Leave-one-mouse-out conditional-logit M1-minus-M0 log probability, centered by H-S0.", "why": "Tests acquisition of graph-relative structure without reward dependence."},
            {"id": "H-S1-PBS", "statement": "Outward/parentward P_BS increases from B to C.", "test": "Node-balanced common-support and denominator-floor sensitivity.", "why": "Provides an interpretable local-policy component distinct from the composite score."},
            {"id": "H-S1-PBF", "statement": "Forward/visited-subtree P_BF changes from B to C.", "test": "Same node-balanced local-policy decomposition.", "why": "Tests whether the supported change is specific to one branch policy."},
            {"id": "H-S1G", "statement": "Dynamic frontier/route features add late predictive value beyond static graph geometry.", "test": "LOMO M2-minus-M1g gain plus feature-availability null and late-opportunity audit.", "why": "Distinguishes global planning from a local policy re-description."},
            {"id": "H-R1", "statement": "Reward discovery and sustained binding are separable learning endpoints.", "test": "First tf.re reward versus sustained long-path cluster, with legacy long-bout firewall.", "why": "A mouse can discover reward before learning efficient exploitation."},
            {"id": "H-S2", "statement": "Reward-free Day-1 structure acquisition predicts Day-2 target search or binding.", "test": "Latent/dry transfer models with support, influence, and precision audits.", "why": "Separates structure learning from reward learning."},
        ],
        "purpose": "Separate reward-free graph-policy acquisition, global-frontier planning, reward discovery, and post-discovery binding.",
        "sources": [
            "scripts/analyze_rapid_learning_structure_reward.py",
            "src/ca_analysis/rapid_learning_policy.py",
            "src/ca_analysis/rapid_learning_reward.py",
            "src/ca_analysis/rapid_learning_stats.py",
        ],
        "manifests": ["phase1/phase1_manifest.json", "phase1/phase1_diagnostic_manifest.json"],
        "reproduction": ["python scripts/analyze_rapid_learning_structure_reward.py --n-null 200 --n-jobs 8 --overwrite", "python scripts/finalize_rapid_learning_phase1_status.py"],
        "groups": [
            "All 23 naive Day1 sessions enter reward-agnostic structure analyses when decision support passes.",
            "The 13 no-water plus dry-port animals form the reward-free structure tier; the 9 no-water latent animals form the clean Day1-structure to Day2-reward transfer tier.",
            "Reward learning is analyzed on the first day reward is available: Day1 for rewarded-from-start animals and Day2 for latent/dry-port animals.",
        ],
        "selection_rules": [
            "Restrict to explore decisions and at most 60 maze-minutes for the primary window (90-minute rescue only).",
            "Choose the largest K in {100,75,50,40,30,25} with at least 3K choices and minimum cohort support (all≥18, latent≥6, rewarded≥8, dry≥3); the frozen primary selected K=100.",
            "Epoch B is the first K eligible choices, C is the last K, and the middle K-or-more choices are an unused buffer.",
            "Conditional-logit features are scaled on training animals only; one animal is held out at a time.",
            "H-S2 uses latent animals only and preserves censored/nonbinding outcomes instead of dropping them.",
        ],
        "signal": "Behavior only; actual tf.re supplies reward onset.",
        "timebase": "Exposure-matched choice index within explore behavior; reward endpoints additionally retain absolute frame, maze seconds, transitions, and primary-decision counts.",
        "representation": "Variable-outdegree binary-tree graph alternatives, arrival relation, local history, maintained graph-policy utilities, and dynamic unvisited-frontier/route features.",
        "steps": [
            "Build all legal alternatives for each supported junction choice without using future visits in history features.",
            "Assign equal-evidence B/buffer/C epochs using the frozen K support rule.",
            "Fit M0 history-only and M1 history-plus-four-graph-policy conditional-logit models in leave-one-mouse-out folds.",
            "Compute held-out per-decision log-probability gain, average within animal/epoch, subtract the fixed-policy exact-support null, and form C-minus-B gain.",
            "Decompose behavior into node-balanced P_SF, P_SA, P_BF, and P_BS; repeat on common nodes and denominator floors 1/3/5.",
            "Fit the stronger M1g-to-M2 frontier/route branch and audit whether late frontier opportunities still exist.",
            "Define discovery from first actual reward and binding from a sustained postreward long-path cluster; firewall the legacy long-bout endpoint.",
            "Relate Day1 reward-free structure estimates to Day2 reward search only in latent animals, with influence and precision audits.",
        ],
        "equations": r"""
For decision (j), legal alternative (a\in\mathcal A_j), and feature vector
(x_{ja}), the variable-outdegree conditional logit is

\[
P(a\mid j,M)=\frac{\exp(x_{ja}^{\mathsf T}\beta_M)}
{\sum_{b\in\mathcal A_j}\exp(x_{jb}^{\mathsf T}\beta_M)}.
\]

The held-out structural score is

\[
\psi_j=\log P(a_j\mid j,M_1)-\log P(a_j\mid j,M_0),\qquad
\Delta\Psi=(\bar\psi_C-\bar\psi_B)-E_{\mathrm{fixed\ policy\ null}}[\Delta\Psi].
\]

The stronger global score replaces (M_0\rightarrow M_1) with
(M_{1g}\rightarrow M_2), where (M_{1g}) includes static geometry and (M_2)
adds dynamic frontier and route value.
""",
        "parameters": [
            {"name": "candidate K", "value": "100,75,50,40,30,25", "class": "prespecified support ladder", "hand_chosen": True, "held_out": True, "reason": "Select largest equal-evidence epoch supported across contexts."},
            {"name": "primary K", "value": 100, "class": "data-support selected", "hand_chosen": False, "held_out": True, "reason": "Result of the frozen support rule, not outcome optimization."},
            {"name": "L2 penalty", "value": 1.0, "class": "model regularization", "hand_chosen": True, "held_out": True, "reason": "Fixed before hypothesis inference; sensitivity exported."},
            {"name": "fixed-policy nulls", "value": 200, "class": "null precision", "hand_chosen": True, "held_out": True, "reason": "Primary mechanical feature-availability test."},
            {"name": "global nulls", "value": 20, "class": "bounded post-primary diagnostic", "hand_chosen": True, "held_out": False, "reason": "Computationally bounded; too coarse for a strong confirmatory claim."},
            {"name": "binding path length", "value": "≥7", "class": "behavioral endpoint", "hand_chosen": True, "held_out": True, "reason": "Long-path definition inherited from task behavior."},
            {"name": "binding cluster", "value": "≥3 successful bouts in 5", "class": "behavioral endpoint", "hand_chosen": True, "held_out": True, "reason": "Sustained rather than single-run binding criterion."},
        ],
        "held_out_logic": [
            "Feature scaling and coefficients are learned without the test animal.",
            "B and C have equal choice counts and an unused middle buffer; late data do not enter early features.",
            "History features are prefix-only. Frontier and route values are computed from what had been visited before that decision.",
            "The fixed-policy null reuses exact observed decision support and is fit without using the observed C-minus-B outcome.",
        ],
        "risks": [
            "The rejected childward trajectory generator cannot reproduce from-child/backtrack support (max absolute SMD >0.5) and must not be treated as the primary counterfactual.",
            "Only 20 global-frontier null draws were run; H-S1G is preliminary and also loses late opportunity support.",
            "P_BS means outward/toward-parent conditional on continuing forward after arriving from a child. It does not encode whether the sibling subtree was visited and is not proof of an internal map.",
            "H-S2 is observational and small-n. Baseline adjustment can reverse results because baseline P_BS and change are strongly coupled.",
        ],
        "selection_artifact": {
            "path": "phase1/all_neighbor_primary_structure_epoch_support.csv",
            "columns": ["session_id", "cohort_group", "n_eligible_decisions"],
        },
        "artifacts": [
            _artifact("phase1/all_neighbor_primary_topology_choice_rows.csv", "source", "One row per legal choice alternative", key_columns=("animal_id", "decision_id", "chosen"), preview_columns=("animal_id", "cohort_group", "decision_id", "prev_node", "current_node", "alternative_id", "alternative_relation", "chosen", "tree_depth")),
            _artifact("phase1/all_neighbor_primary_structure_epoch_audit.csv", "selection", "B/buffer/C assignment", key_columns=("session_id", "k", "window"), preview_columns=("session_id", "status", "k", "window", "n_supported", "n_buffer")),
            _artifact("phase1/all_neighbor_primary_graph_policy_per_decision.csv", "transformation", "Held-out M1-minus-M0 decision score", key_columns=("animal_id", "epoch", "decision_id"), preview_columns=("animal_id", "epoch", "decision_id", "local_log_probability", "topology_log_probability", "psi_decision_raw", "held_out_animal")),
            _artifact("phase1/all_neighbor_primary_graph_policy_null_delta.csv", "null", "Fixed-policy exact-support null", key_columns=("animal_id", "null_iteration"), preview_columns=("animal_id", "null_iteration", "B", "C", "delta_psi_null_raw", "delta_psi_null_centered")),
            _artifact("phase1/all_neighbor_primary_graph_policy_gain.csv", "estimand", "Animal C-minus-B null-corrected score", key_columns=("animal_id", "delta_psi"), preview_columns=("animal_id", "cohort_group", "psi_B", "psi_C", "delta_psi")),
            _artifact("phase1/all_neighbor_primary_local_policy_gain_audit.csv", "decomposition", "Four maintained policy changes", key_columns=("animal_id", "metric"), preview_columns=("animal_id", "cohort_group", "metric", "value_B", "value_C", "delta_C_minus_B")),
            _artifact("phase1/phase1_policy_denominator_floor_sensitivity.csv", "sensitivity", "Policy denominator-floor ladder", key_columns=("metric", "opportunity_floor_per_node_epoch"), preview_columns=("metric", "opportunity_floor_per_node_epoch", "scope", "n_animals", "mean_delta_C_minus_B", "sign_flip_p_two_sided")),
            _artifact("phase1/phase1_global_frontier_support_diagnostic.csv", "support", "Frontier opportunity depletion", key_columns=("scope", "epoch"), preview_columns=("scope", "epoch", "n_decisions", "frontier_discriminating_fraction", "route_discriminating_fraction", "frontier_exhausted_fraction")),
            _artifact("phase1/reward_learning_endpoints.csv", "reward endpoint", "Discovery, binding, and legacy long-bout firewall", key_columns=("animal_id", "reward_learning_session"), preview_columns=("animal_id", "cohort_group", "reward_learning_day_index", "discovery_observed", "T_discovery_primary_decisions", "binding_status", "T_binding_primary_decisions", "legacy_lb0_predates_reward")),
            _artifact("phase1/hypothesis_status.csv", "inference", "Phase-level classifications", key_columns=("hypothesis_id", "status"), preview_columns=("hypothesis_id", "n", "status", "observed_direction", "interpretation_cap")),
        ],
        "panels": [
            {"path": "phase1/all_neighbor_primary_graph_policy_gain.csv", "kind": "strip", "x": "cohort_group", "y": "delta_psi", "title": "A  Null-corrected graph-policy gain"},
            {"path": "phase1/all_neighbor_primary_local_policy_gain_audit.csv", "query": "metric == 'P_BS_Lo_from_child_outward_given_forward'", "kind": "paired", "left": "value_B", "right": "value_C", "left_label": "B", "right_label": "C", "title": "B  P_BS per animal"},
            {"path": "phase1/phase1_policy_denominator_floor_sensitivity.csv", "query": "metric == 'P_BS_Lo_from_child_outward_given_forward'", "kind": "scatter", "x": "opportunity_floor_per_node_epoch", "y": "mean_delta_C_minus_B", "hue": "scope", "title": "C  P_BS denominator-floor ladder"},
            {"path": "phase1/reward_learning_endpoints.csv", "kind": "scatter", "x": "T_discovery_primary_decisions", "y": "T_binding_primary_decisions", "hue": "cohort_group", "title": "D  Discovery and binding are separate"},
        ],
        "figures": [
            "phase5_report/audit_figures/phase1_topology_null_audit.png",
            "phase5_report/audit_figures/phase1_interpretation_diagnostics_audit.png",
        ],
        "conclusion": "A narrow graph-relative P_BS change is supported; the composite increment and global-frontier claim are not. Reward discovery and binding remain separate endpoints.",
    },
    {
        "phase": "phase2",
        "title": "Phase 2 — ELPC measurement validity and reliability gate",
        "analysis_ids": ["H-N0"],
        "hypotheses": [
            {"id": "H-N0", "statement": "Early excess lagged cross-cell coordination can be estimated reliably from C after removing each neuron's own calcium/history dynamics.", "test": "Exact cell/pair support, alternating-block split reliability, subset stability, and zero-lag-preserving null.", "why": "The prospective H-N1 analysis is invalid unless its neural predictor is reproducible and not just the OASIS/GCaMP kernel."},
        ],
        "purpose": "Determine whether C-primary excess lagged cross-cell coordination can be measured reproducibly before any learning-outcome association is inspected.",
        "sources": [
            "scripts/analyze_rapid_learning_elpc.py",
            "scripts/summarize_rapid_learning_elpc_diagnostics.py",
            "src/ca_analysis/rapid_learning_dynamics.py",
        ],
        "manifests": [
            "phase2_elpc_exact_support_rescue/phase2_manifest.json",
            "phase2_elpc_exact_support_rescue/elpc_reliability_diagnostic_manifest.json",
        ],
        "reproduction": [
            "python scripts/analyze_rapid_learning_elpc.py --out-dir docs/rapid_learning_structure_reward_2026-07-15/phase2_elpc_exact_support_rescue --window-seconds 400 --max-maze-minutes 15 --max-lag-seconds 0.8 --n-lags 7 --overwrite",
            "python scripts/summarize_rapid_learning_elpc_diagnostics.py --phase2-dir docs/rapid_learning_structure_reward_2026-07-15/phase2_elpc_exact_support_rescue",
        ],
        "groups": [
            "22 C-ready naive Day1 sessions; 769 is excluded because it has no neural signal.",
            "Twenty selected windows are fully prereward. Rewarded sessions 163RLday1 and 1632Lday1 are partly postreward; pooled ELPC is therefore reward-agnostic early-learning state, not reward-free.",
            "Five deterministic 150-cell subsets are reliability replications, not five biological observations per animal.",
        ],
        "selection_rules": [
            "Select the first 400 s (10,000 full-rate frames at 25 Hz) of explore activity occurring within the first 15 maze-minutes.",
            "Preserve clip/gap segment IDs; never compute a lag across a discontinuity.",
            "Select at most 150 eligible cells and 512 ordered off-diagonal cell pairs.",
            "Freeze exactly the same original cell IDs and pair IDs for full, split-1, and split-2 estimates.",
            "Split reliability uses alternating 10-s blocks and Spearman-Brown correction across animals. The confirmatory gate is ≥0.75.",
        ],
        "signal": "C primary. Each neuron's diagonal AR calcium/history component is removed before cross-cell lag structure is measured; S is reserved for the separate literal criticality appendix.",
        "timebase": "Full-rate 25-Hz explore frames with segment-safe lags; selected frames are not concatenated across gaps.",
        "representation": "Whitened time-by-cell residual matrix and sampled ordered off-diagonal cross-cell lag covariances.",
        "steps": [
            "Load time-by-cell C and the frozen segmented explore window.",
            "For each cell, choose AR(1) or AR(2) by BIC, fit only within segments, and standardize the residual.",
            "Compute squared off-diagonal covariance at seven lags spanning 0.2–0.8 s and average over pairs and lags (L0).",
            "Subtract the independent-cell circular-shift null (L1 diagnostic).",
            "Subtract the joint-time-shuffle null that preserves instantaneous population vectors and zero-lag covariance (L2, primary ELPC).",
            "Optionally residualize measured map/trajectory covariates before repeating ELPC (L3 conservative bound).",
            "Repeat on five fixed cell/pair subsets and alternating-block halves; verify identity equality before calculating reliability.",
            "Stop H-N1 if the reliability gate fails; preserve all attempts and failure reasons.",
        ],
        "equations": r"""
For cell (i), own-history whitening gives

\[
e_i(t)=\frac{C_i(t)-\sum_{k=1}^{p_i}\hat a_{ik}C_i(t-k)}{\hat\sigma_i},
\qquad p_i\in\{1,2\}\ \text{chosen by BIC}.
\]

For sampled ordered pairs (\mathcal P) and lag set (\mathcal L),

\[
V(\tau)=\frac{1}{|\mathcal P|}\sum_{(i,j)\in\mathcal P}
\left[\frac{1}{T_\tau}\sum_t e_i(t)e_j(t+\tau)\right]^2,
\qquad L_0=\frac{1}{|\mathcal L|}\sum_{\tau\in\mathcal L}V(\tau).
\]

The primary value is

\[
\mathrm{ELPC}=L_0-E_{\mathrm{joint\ time\ shuffle}}[L_0],
\]

and split-half reliability is corrected as (r_{SB}=2r/(1+r)).
""",
        "parameters": [
            {"name": "window", "value": "400 s within first 15 maze-min", "class": "named exact-support rescue", "hand_chosen": True, "held_out": False, "reason": "Longer than the original 300-s window to improve reliability; explicitly post-primary rescue."},
            {"name": "cells / pairs", "value": "150 / 512", "class": "sampling design", "hand_chosen": True, "held_out": True, "reason": "Fixed computational support per animal and subset."},
            {"name": "lag range", "value": "0.2–0.8 s, 7 lags", "class": "estimator definition", "hand_chosen": True, "held_out": True, "reason": "Avoids same-frame calcium dynamics while targeting short population sequences."},
            {"name": "null draws", "value": 20, "class": "bounded null precision", "hand_chosen": True, "held_out": True, "reason": "Minimum one-sided Monte Carlo p is 1/21; suitable for measurement diagnostics, not precise inference."},
            {"name": "reliability threshold", "value": 0.75, "class": "confirmatory gate", "hand_chosen": True, "held_out": True, "reason": "Required before any outcome access."},
            {"name": "behavior residualization ridge", "value": "1e-8", "class": "interpretation sensitivity", "hand_chosen": True, "held_out": True, "reason": "Numerical stabilization; L3 is a conservative bound, not the sole estimate."},
        ],
        "held_out_logic": [
            "No behavioral outcome is read when H-N0 fails.",
            "Cell and pair identities are sampled once and reused exactly across reliability halves.",
            "Nulls preserve the declared lower-order structure; the primary null preserves the complete zero-lag population-vector distribution within segments.",
        ],
        "risks": [
            "The median Spearman-Brown reliability is below 0.75; H-N0 is measurement-unresolved rather than a biological null.",
            "Five subset estimates are correlated technical replications and their quantile range is not a confidence interval.",
            "L3 may remove genuine position- or trajectory-locked neural dynamics, so it is not an all-or-none validity gate.",
            "ELPC measures excess lagged cross-cell coordination. Calling it generic persistence or physical criticality would be inaccurate.",
        ],
        "selection_artifact": {
            "path": "phase2_elpc_exact_support_rescue/elpc_window_audit.csv",
            "columns": ["animal_id", "session_id", "cohort_group", "status", "n_selected", "n_segments", "fraction_window_frames_pre_reward", "window_entirely_pre_reward"],
        },
        "artifacts": [
            _artifact("phase2_elpc_exact_support_rescue/elpc_window_audit.csv", "selection", "Frame/segment/reward-overlap audit", key_columns=("animal_id", "status"), preview_columns=("animal_id", "session_id", "cohort_group", "status", "n_frames_selected", "fully_prereward")),
            _artifact("phase2_elpc_exact_support_rescue/elpc_exact_support_verification.csv", "support", "Frozen cell/pair identity equality", key_columns=("session_id", "subset_index")),
            _artifact("phase2_elpc_exact_support_rescue/elpc_estimates_long.csv", "transformation", "L0/L1/L2/L3 estimates", key_columns=("animal_id", "subset_index", "block"), preview_columns=("animal_id", "cohort_group", "subset_index", "block", "l0_observed_power", "l1_cell_shift_excess", "l2_zero_lag_excess", "l3_map_trajectory_elpc", "n_cells_selected")),
            _artifact("phase2_elpc_exact_support_rescue/elpc_split_half_reliability.csv", "reliability", "Across-animal split-half gate", key_columns=("subset_index", "spearman_brown")),
            _artifact("phase2_elpc_exact_support_rescue/elpc_cell_subset_stability_diagnostic.csv", "reliability", "Between-subset rank stability", key_columns=("metric", "subset_left", "subset_right")),
            _artifact("phase2_elpc_exact_support_rescue/analysis_attempt_registry.csv", "attempt history", "Named rescues and failure reasons", key_columns=("stage", "status"), preview_columns=("session_id", "stage", "status", "reason", "next_attempt")),
            _artifact("phase2_elpc_exact_support_rescue/hypothesis_status.csv", "inference", "Measurement-gate classification", key_columns=("hypothesis_id", "status")),
        ],
        "panels": [
            {"path": "phase2_elpc_exact_support_rescue/elpc_estimates_long.csv", "kind": "strip", "x": "block", "y": "l2_zero_lag_excess", "title": "A  L2 ELPC by reliability block"},
            {"path": "phase2_elpc_exact_support_rescue/elpc_early_day1_per_animal.csv", "kind": "scatter", "x": "ELPC_A_L1", "y": "ELPC_A", "hue": "cohort_group", "title": "B  Cell-shift and zero-lag null layers"},
            {"path": "phase2_elpc_exact_support_rescue/elpc_split_half_reliability.csv", "kind": "scatter", "x": "subset_index", "y": "spearman_brown", "title": "C  Split-half reliability gate"},
            {"path": "phase2_elpc_exact_support_rescue/analysis_attempt_registry.csv", "kind": "counts", "x": "status", "title": "D  Retained attempt history"},
        ],
        "figures": ["phase5_report/audit_figures/phase2_elpc_audit.png"],
        "conclusion": "The primary ELPC estimator failed its reliability gate after a bounded exact-support rescue. H-N1 was therefore not tested confirmatorily.",
    },
)


def _compact_phase(
    *,
    phase: str,
    title: str,
    analysis_ids: tuple[str, ...],
    purpose: str,
    hypotheses: tuple[dict[str, str], ...],
    sources: tuple[str, ...],
    directory: str,
    manifest: str,
    reproduction: tuple[str, ...],
    groups: tuple[str, ...],
    selection_rules: tuple[str, ...],
    signal: str,
    timebase: str,
    representation: str,
    steps: tuple[str, ...],
    equations: str,
    parameters: tuple[dict[str, Any], ...],
    held_out_logic: tuple[str, ...],
    risks: tuple[str, ...],
    selection_file: str,
    artifact_files: tuple[tuple[str, str, str], ...],
    panels: tuple[dict[str, Any], ...],
    figures: tuple[str, ...],
    conclusion: str,
) -> dict[str, Any]:
    """Build a complete phase specification without redefining an estimator."""

    selection_columns_by_phase: dict[str, list[str]] = {
        "phase3": ["animal_id", "session_id", "cohort_group", "analysis", "attempt_index", "support_tier", "epoch", "split", "depth", "n_frames", "n_visits", "depth_selected", "excluded_reason", "plan_status"],
        "phase4": ["animal_id", "session_id", "cohort_group", "status", "primary_qc_pass", "n_cells", "n_frames", "fraction_window_frames_pre_reward", "window_entirely_pre_reward"],
        "phase5": ["analysis_id", "scientific_question", "final_classification", "reason", "evidence"],
        "phase6": ["animal_id", "session_id", "cohort_group", "n_baseline_Lo", "n_future_Lo", "passes_baseline_floor_20", "passes_future_floor_20", "included", "exclusion_reason", "equal_future_support_k"],
        "phase7": ["animal_id", "session_id", "cohort_group", "window_index", "n_frames", "n_Lo_events", "passes_Lo_floor", "coverage_end"],
        "phase8": ["animal_id", "pair_id", "cohort_group", "reward_learning_session", "reward_learning_day_index", "status", "discovery_observed", "binding_status", "legacy_lb0_predates_reward"],
        "phase9": ["animal_id", "session_id", "neural_file", "n_union_cells", "n_subsets", "subset_size", "n_frames", "status"],
        "phase10": ["animal_id", "pair_id", "cohort_group", "reward_learning_session", "reward_history_stratum", "shared_component_basis", "component_count_equal", "cimap_required", "first_reward_abs_frame", "binding_abs_frame", "source_status"],
        "phase11": ["animal_id", "session_id", "cohort_group", "epoch", "neural_file", "C_n_cells", "n_requested_frames", "n_epoch_rows"],
        "phase12": ["animal_id", "session_id", "cohort_group", "variant", "n_selected_prereward_explore_transitions", "n_candidate_all_neighbor_decisions", "n_scored_reward_anchor_decisions", "min_decisions_primary", "has_day1_structure_estimand", "has_day1_engagement", "status"],
        "phase13": ["animal_id", "pair_id", "cohort_group", "anchor_node", "is_reward_anchor", "pre_loono_spearman", "post_loono_spearman", "delta_post_minus_pre", "n_nodes", "n_cells", "status"],
        "phase14": ["animal_id", "session_id", "cohort_group", "visit_selection", "status", "n_selected_rows", "n_visits", "n_pairs", "n_cells", "neural_file"],
        "phase15": ["animal_id", "session_id", "cohort_group", "epoch", "fold_index", "visit_id", "true_depth", "neural_predicted_depth", "xy_behavior_predicted_depth", "supported_depth_min", "supported_depth_max"],
        "phase16": ["animal_id", "session_id", "cohort_group", "variant", "claim_tier", "mode_policy", "n_eligible_pre_non_target_visits", "n_eligible_post_non_target_visits_total", "n_post_visits_retained_exposure_match", "n_common_non_target_nodes", "distributed_status", "status"],
    }

    return {
        "phase": phase,
        "title": title,
        "analysis_ids": list(analysis_ids),
        "purpose": purpose,
        "hypotheses": [dict(item) for item in hypotheses],
        "sources": list(sources),
        "manifests": [f"{directory}/{manifest}"],
        "reproduction": list(reproduction),
        "groups": list(groups),
        "selection_rules": list(selection_rules),
        "signal": signal,
        "timebase": timebase,
        "representation": representation,
        "steps": list(steps),
        "equations": equations,
        "parameters": [dict(item) for item in parameters],
        "held_out_logic": list(held_out_logic),
        "risks": list(risks),
        "selection_artifact": {
            "path": f"{directory}/{selection_file}",
            "columns": selection_columns_by_phase[phase],
        },
        "artifacts": [
            _artifact(f"{directory}/{name}", stage, role)
            for name, stage, role in artifact_files
        ],
        "panels": [dict(item) for item in panels],
        "figures": [f"{directory}/{name}" for name in figures],
        "conclusion": conclusion,
    }


# Phases 3-16 were added after the first three contracts.  They are kept in
# the same catalog so registry coverage and notebook generation are checked in
# one place.  A hypothesis ID may appear in more than one phase when a later
# phase is an explicitly labelled rescue of the same scientific question.
PHASE_SPECS = PHASE_SPECS + (
    _compact_phase(
        phase="phase3",
        title="Phase 3 - C-based neural codes for structure and reward",
        analysis_ids=("H-NS1A", "H-NS1B", "H-NS2"),
        purpose="Test whether tree-depth and reward-coordinate information becomes accessible during naive learning, using visit-held-out decoders and explicit support gates.",
        hypotheses=(
            {"id": "H-NS1A", "statement": "Late Day-1 exploration has greater tree-depth decoding than early exploration.", "test": "Held-out-visit Poisson depth decoder, compared with position/behavior and label-shuffle controls.", "why": "Separates acquisition of abstract maze structure from reward learning."},
            {"id": "H-NS1B", "statement": "A depth code generalizes to physically distant, structurally equivalent subtrees.", "test": "Train/test on distant subtree folds and require an advantage over a matched XY decoder.", "why": "A true topology code must generalize beyond spatial interpolation."},
            {"id": "H-NS2", "statement": "The late Day-1 structure code transfers to Day-2 prereward exploration.", "test": "Train on late Day-1 C and test on prereward Day-2 C in the verified shared component basis.", "why": "Tests retained structure before Day-2 reward experience."},
        ),
        sources=("scripts/analyze_rapid_learning_neural_codes.py", "src/ca_analysis/rapid_learning_phase3.py", "src/ca_analysis/rapid_learning_neural_codes.py"),
        directory="phase3_neural_codes",
        manifest="phase3_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_neural_codes.py --overwrite",),
        groups=("Attempt all 23 naive Day-1 sessions; 22 have usable C and 769 is behavior-only.", "Day1-to-Day2 transfer is limited to reward-free-Day1 animals with joint-deconvolution/index-identity provenance."),
        selection_rules=("Use full transition/run/bout/clip visits, not selected_df continuity.", "Gate cells on training data only: at least 0.1 C/min, nonzero variance, and at least 10 retained cells.", "Primary depth support is at least 50 frames and two visits per depth; 25 frames is a named rescue; require at least five common depths.", "Distant-subtree folds are primary; interior depths 2-5 are explicitly post-hoc."),
        signal="C is primary for maps and decoding; S is not substituted.",
        timebase="Absolute imaging frames within whole graph visits; cross-day identity is used only because the provenance audit verifies a shared joint component basis.",
        representation="Tree depth 0-6, run node, physical XY/behavior comparator, and reward-coordinate distance.",
        steps=("Load C and align full visits to graph depth.", "Apply training-only cell gates and freeze common depths/visits.", "Build nine-sample trailing C counts.", "Fit leave-one-visit-out depth and comparator decoders.", "Run training-label shuffles and distant-subtree transfer.", "Run Day1-late to Day2-prereward transfer and export every prediction/support row."),
        equations=r"""For neuron i and frame t the inclusive trailing count is
\[x_i(t)=\sum_{u=t-8}^{t}C_i(u).\]
For depth d, the Poisson decoder uses
\[\log P(d\mid x)\propto\sum_i[x_i\log\lambda_{id}-\lambda_{id}].\]
The primary gain is \(\Delta BA=BA_C-BA_B\), with separate margins versus
the XY/behavior decoder and the 95th percentile label-shuffle null.""",
        parameters=(
            {"name": "count lookback", "value": "8 frames plus current = 9 samples", "class": "decoder definition", "hand_chosen": True, "held_out": True, "reason": "Inherited inclusive C-count window."},
            {"name": "depth support", "value": "50 frames primary; 25 rescue; >=2 visits; >=5 depths", "class": "support ladder", "hand_chosen": True, "held_out": False, "reason": "Rescue is labelled and never chosen by effect size."},
            {"name": "label shuffles", "value": 200, "class": "null precision", "hand_chosen": True, "held_out": True, "reason": "Training labels only; seed 2718."},
        ),
        held_out_logic=("Every neural prediction holds out a complete visit or subtree.", "Cell/depth gates are learned from training support only.", "Abstract topology requires an advantage over the same-split position decoder, not merely over shuffle."),
        risks=("Primary H-NS1A and H-NS1B had zero fully supported animals; this is support-unresolved, not a biological null.", "Post-hoc interior-depth folds are descriptive.", "Day1-to-Day2 transfer has only eight supported animals and topology did not beat XY."),
        selection_file="phase3_common_depth_rescue_audit.csv",
        artifact_files=(("phase3_C_load_audit.csv", "source", "C source and exclusions"), ("phase3_within_epoch_support.csv", "support", "Depth and visit support"), ("phase3_prediction_audit.csv", "transformation", "Held-out prediction rows"), ("phase3_cross_subtree_support.csv", "support", "Distant-subtree folds"), ("phase3_day1C_to_day2_prereward_support.csv", "support", "Cross-day transfer support"), ("phase3_animal_inference_summary.csv", "inference", "Animal-level tests"), ("phase3_exclusions.csv", "exclusion", "Explicit failures")),
        panels=(
            {"path": "phase3_neural_codes/phase3_C_load_audit.csv", "kind": "counts", "x": "neural_source", "title": "A  C-load source"},
            {"path": "phase3_neural_codes/phase3_common_depth_rescue_audit.csv", "kind": "animal_counts", "x": "plan_status", "hue": "cohort_group", "title": "B  Common-depth support"},
            {"path": "phase3_neural_codes/phase3_day1C_to_day2_prereward_results.csv", "kind": "scatter", "x": "topology_balanced_accuracy", "y": "xy_behavior_balanced_accuracy", "title": "C  Neural versus XY transfer"},
            {"path": "phase3_neural_codes/phase3_animal_inference_summary.csv", "kind": "strip", "x": "estimand", "y": "effect_mean", "title": "D  Animal estimands"},
        ),
        figures=(),
        conclusion="The strict within-Day1 and cross-subtree tests are support-unresolved; the supported cross-day test does not show topology-specific transfer beyond XY.",
    ),
    _compact_phase(
        phase="phase4",
        title="Phase 4 - gated ELPC outcome test and S-only criticality appendix",
        analysis_ids=("H-N1", "H-N2a", "H-N2b"),
        purpose="Enforce the ELPC measurement firewall, then separately evaluate literal S-based distance-to-criticality estimators without conflating them with C-based maps.",
        hypotheses=(
            {"id": "H-N1", "statement": "Early ELPC predicts later structure-policy acquisition.", "test": "ANCOVA and change-score models only if H-N0 passes.", "why": "Prospective readiness claim must not be tested with an unreliable predictor."},
            {"id": "H-N2a", "statement": "Hengen-style AR-boundary distance predicts Day-1 structure gain after standardized S sampling.", "test": "Audit split/subset reliability and all-cell versus fixed-150 agreement before reporting rank and adjusted structure-gain associations.", "why": "The behavioral association is uninterpretable if cell yield changes the animal ranking."},
            {"id": "H-N2b", "statement": "The Sooter KL-rate distance converges across time blocks, fixed cell samples, and the prespecified AR/bin ladder.", "test": "Reference-toolkit reproduction, split/subset reliability, sampling agreement, and parameter-sensitivity audit.", "why": "A literal criticality estimator must first converge as a measurement; this registry endpoint is not a separate behavioral association."},
        ),
        sources=("scripts/analyze_rapid_learning_hn1.py", "scripts/export_rapid_learning_dist_arcrit_s_inputs.py", "scripts/analyze_rapid_learning_dist_arcrit_s.py"),
        directory="phase4_dist_arcrit_S",
        manifest="phase4_dist_arcrit_S_manifest.json",
        reproduction=(
            "python scripts/export_rapid_learning_dist_arcrit_s_inputs.py --window-seconds 300 --max-maze-minutes 60 --ar-order 10 --overwrite",
            "matlab -batch \"addpath('scripts'); run_rapid_learning_dist_arcrit_s_reference('docs/rapid_learning_structure_reward_2026-07-15/phase4_dist_arcrit_S_inputs/mat_inputs','docs/rapid_learning_structure_reward_2026-07-15/phase4_dist_arcrit_S_reference','<prox_crit_toolkit_dir>',10,0.04,2)\"  # scripts/run_rapid_learning_dist_arcrit_s_reference.m; toolkit commit f91691f...",
            "python scripts/analyze_rapid_learning_dist_arcrit_s.py --overwrite",
        ),
        groups=("H-N1 is locked because ELPC failed H-N0; no outcome coefficient is interpreted.", "S-only appendix uses 22 S-ready sessions and five fixed 150-cell subsets; 769 remains behavior-only."),
        selection_rules=("Use first 300 s of explore S within first 60 maze-minutes.", "Preserve discontinuity segments and use 40-ms bins for the primary AR fit.", "Report all cells only as a sampling diagnostic; fixed-150 is the standardized estimand.", "Gate behavioral inference on split and subset reliability."),
        signal="S only for AR/temporal-RG criticality; C only in the separate ELPC branch.",
        timebase="Segmented 25-Hz explore frames; 40-ms primary bins; deterministic cell subsets.",
        representation="Univariate population S count for AR distance and temporal coarse-graining.",
        steps=("Export exact S windows and segments.", "Fit AR(10) and temporal-RG estimators for all cells and fixed subsets.", "Audit alternating-block split reliability, subset reproducibility, bin/order sensitivity, and cell-yield dependence.", "Apply outcome firewall when measurement fails."),
        equations=r"""For an AR(p) population process
\[x_t=\sum_{k=1}^{p}\phi_kx_{t-k}+\epsilon_t,\]
the Hengen-style Euclidean boundary proxy is
\[d_E=|1-\sum_k\phi_k|/\sqrt{p}.\]
The Sooter temporal-RG branch estimates information-loss scaling \(\beta_2\)
under repeated temporal coarse graining. H-N1 was planned as both
\(R(\Psi_C)\sim R(ELPC_A)+R(\Psi_B)+E_0+context\) and a co-primary
change-score model.""",
        parameters=(
            {"name": "AR order", "value": "10 primary; order/bin ladder", "class": "paper-matched plus sensitivity", "hand_chosen": True, "held_out": True, "reason": "Matches the referenced method; alternatives are retained."},
            {"name": "cell subsets", "value": "5 x 150", "class": "sampling standardization", "hand_chosen": True, "held_out": True, "reason": "Prevents cell yield from defining the metric."},
            {"name": "H-N1 permutations", "value": "10,000 Freedman-Lane; 5,000 bootstrap planned", "class": "locked analysis", "hand_chosen": True, "held_out": True, "reason": "Never executed confirmatorily because H-N0 failed."},
        ),
        held_out_logic=("H-N1 never joins ELPC to outcome after H-N0 fails.", "S-only estimates use fixed cell identities and deterministic split blocks.", "All-cell correlations cannot rescue a fixed-support measurement failure."),
        risks=("The all-cell raw association is cell-yield sensitive and vanishes under fixed support/adjustment.", "S-based proximity and conventional autocorrelation can be highly related; criticality-specific incremental value is unresolved.", "The 300-s S window differs from the 400-s ELPC rescue and must not be silently compared."),
        selection_file="joined_inputs.csv",
        artifact_files=(("joined_inputs.csv", "source", "S-only animal inputs"), ("fixed_subset_median_values.csv", "transformation", "Standardized proximity estimates"), ("fixed_subset_split_reliability.csv", "reliability", "Split reliability"), ("cell_subset_rank_stability.csv", "reliability", "Subset stability"), ("ar_bin_rank_sensitivity.csv", "sensitivity", "AR order and bin ladder"), ("adjusted_statistics.csv", "inference", "Adjusted diagnostic associations"), ("analysis_attempt_registry.csv", "attempt history", "Invalid and rescue attempts")),
        panels=(
            {"path": "phase4_dist_arcrit_S/fixed_subset_split_reliability.csv", "kind": "strip", "x": "metric", "y": "spearman_brown", "title": "A  Split reliability"},
            {"path": "phase4_dist_arcrit_S/fixed_subset_median_values.csv", "kind": "scatter", "x": "dist_arcrit_S_fixed150_median", "y": "hengen_euclidean_d2_S_fixed150_median", "title": "B  Two proximity estimators"},
            {"path": "phase4_dist_arcrit_S/ar_bin_rank_sensitivity.csv", "kind": "strip", "x": "specification", "y": "rho_to_frozen_primary", "title": "C  Parameter sensitivity"},
            {"path": "phase4_dist_arcrit_S/analysis_attempt_registry.csv", "kind": "counts", "x": "status", "title": "D  Attempt history"},
        ),
        figures=("../phase4_dist_arcrit_S_audits/phase4_arcrit_measurement_audit.png", "../phase4_dist_arcrit_S_audits/phase4_arcrit_outcome_audit.png"),
        conclusion="H-N1 was not tested because ELPC was unreliable. S-only criticality estimates remain measurement/sampling unresolved and do not justify a learning claim.",
    ),
    _compact_phase(
        phase="phase5",
        title="Phase 5 - integrated report and claim firewall",
        analysis_ids=(),
        purpose="Reconcile phase artifacts without replacing them, and distinguish script completion, estimator validity, support, and scientific inference.",
        hypotheses=(),
        sources=("scripts/build_rapid_learning_integrated_report.py",),
        directory="phase5_report",
        manifest="phase5_manifest.json",
        reproduction=("python scripts/build_rapid_learning_integrated_report.py",),
        groups=("No new biological cohort is created; this phase joins phase-level status rows.",),
        selection_rules=("Never upgrade a gated-out or support-unresolved phase to a biological null.", "Preserve each attempt rather than selecting the most favorable result.", "Treat the final 29-row registry as newer authority than the original Phase-5 subset report."),
        signal="No new signal; provenance-only integration.",
        timebase="Inherited and reported per source phase.",
        representation="Hypothesis/attempt cards keyed by analysis ID.",
        steps=("Read phase manifests and statuses.", "Crosswalk analysis IDs and attempt states.", "Check claim caps against evidence class.", "Render audit cards and identify stale integrated summaries."),
        equations=r"""No new estimator is fit. The key classification is
\[status\in\{invalid,\ measurement\ unresolved,\ support\ limited,\ heterogeneous\ unresolved,\ suggestive,\ informative\ negative,\ supported\}.\]""",
        parameters=(
            {"name": "status authority", "value": "final 29-row attempt registry supersedes the early integrated subset", "class": "reporting contract", "hand_chosen": False, "held_out": True, "reason": "Prevents an older phase report from upgrading or erasing later bounded attempts."},
        ),
        held_out_logic=("Integration cannot rescue a failed upstream gate.",),
        risks=("The original Phase-5 report covers only early phases and is stale relative to the 29-row final registry.",),
        selection_file="../final_existing_data_attempt_registry.csv",
        artifact_files=(("analysis_cards.csv", "integration", "Phase cards"), ("integrated_attempt_registry.csv", "attempt history", "Early integrated attempts"), ("integrated_hypothesis_status.csv", "status", "Early status table")),
        panels=(
            {"path": "phase5_report/integrated_hypothesis_status.csv", "kind": "counts", "x": "status", "title": "A  Early integrated statuses"},
            {"path": "final_existing_data_attempt_registry.csv", "kind": "counts", "x": "final_classification", "title": "B  Current 29-analysis registry"},
        ),
        figures=("audit_figures/phase0_cohort_support_audit.png", "audit_figures/phase1_interpretation_diagnostics_audit.png"),
        conclusion="This is a reporting layer, not evidence that all later scientific goals were resolved.",
    ),
    _compact_phase(
        phase="phase6",
        title="Phase 6 - conventional early dynamics and strict-future structure policy",
        analysis_ids=("P6-CD1",),
        purpose="Test whether a reliable, conventional S-derived neural timescale predicts later P_BS choices using only decisions after the neural window.",
        hypotheses=({"id": "P6-CD1", "statement": "Longer early neural decay time predicts stronger later outward/parentward P_BS policy.", "test": "Decision-level logistic model, animal-rank models, and leave-one-animal-out prediction.", "why": "Provides a simpler rival to criticality and enforces prospective ordering."},),
        sources=("scripts/analyze_rapid_learning_conventional_dynamics.py", "src/ca_analysis/rapid_learning_conventional_dynamics.py"),
        directory="phase6_conventional_dynamics",
        manifest="phase6_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_conventional_dynamics.py --overwrite",),
        groups=("All 22 S-ready Day-1 sessions; context fixed effects for no-water, dry-port, and rewarded.", "Two rewarded windows are partly postreward, so the pooled neural state is early-learning, not uniformly prereward."),
        selection_rules=("Require at least 20 baseline and 20 strict-future Lo decisions.", "Equalize strict-future support to K=27 decisions per animal.", "Use five deterministic 150-cell subsets and require split SB>=0.75 plus subset rho>=0.60."),
        signal="S population counts; 40-ms native bins.",
        timebase="First 300 s of segmented explore exposure; future choices begin strictly after frame_max.",
        representation="Lag slopes, lag-1 decay time, positive ACF area, and multistep-regression time.",
        steps=("Compute segment-safe lag curves.", "Estimate three rival timescales.", "Gate reliability before outcome testing.", "Equalize strict-future decisions.", "Fit block-permutation logistic and rank models.", "Compare base and neural models under LOAO prediction."),
        equations=r"""\[b_\ell=\frac{\sum_t(x_t-\bar x)(x_{t+\ell}-\bar y)}{\sum_t(x_t-\bar x)^2},\qquad \tau_1=-\Delta t/\log b_1.\]
The multistep branch fits \(b_\ell\approx A m^\ell\), with
\(\tau_{MR}=-\Delta t/\log m\). The decision model adds animal-level
\(\tau_1\) and its interaction with decision index to context, baseline
policy, graph covariates, and event mass.""",
        parameters=(
            {"name": "max lag", "value": "50 frames = 2 s", "class": "estimator definition", "hand_chosen": True, "held_out": True, "reason": "Covers short population reverberation."},
            {"name": "future K", "value": 27, "class": "support selected", "hand_chosen": False, "held_out": True, "reason": "Minimum available across all included animals."},
            {"name": "permutations", "value": 5000, "class": "inference", "hand_chosen": True, "held_out": True, "reason": "Permute whole-animal neural values within context."},
        ),
        held_out_logic=("No future choice enters the neural estimate.", "LOAO scaling and coefficients use training animals only.", "Whole-animal permutations preserve within-animal decision blocks."),
        risks=("Only lag-1 time passes reliability; ACF/MR are not interchangeable rescue outcomes.", "Fixed subsets overlap and are not independent replicates.", "All-cell versus fixed-support agreement is low, indicating sampling sensitivity."),
        selection_file="strict_future_support_audit.csv",
        artifact_files=(("conventional_dynamics_lag_curves.csv", "transformation", "Lag-by-subset curves"), ("conventional_dynamics_reliability.csv", "reliability", "Estimator gates"), ("strict_future_support_audit.csv", "support", "Derivation of K=27"), ("strict_future_Lo_decisions.csv", "source", "Exact future choices"), ("strict_future_decision_permutation_null.csv", "null", "Block permutation"), ("strict_future_decision_loao.csv", "prediction", "Held-animal loss"), ("strict_future_animal_rank_models.csv", "inference", "Animal-level sensitivities")),
        panels=(
            {"path": "phase6_conventional_dynamics/conventional_dynamics_reliability.csv", "kind": "strip", "x": "metric", "y": "spearman_brown", "title": "A  Measurement reliability"},
            {"path": "phase6_conventional_dynamics/strict_future_support_audit.csv", "kind": "hist", "x": "n_future_Lo", "title": "B  Strict-future support"},
            {"path": "phase6_conventional_dynamics/strict_future_structure_outcomes.csv", "kind": "scatter", "x": "fixed150_median_lag1_tau_s", "y": "future_pbs", "hue": "cohort_group", "title": "C  Raw animal association"},
            {"path": "phase6_conventional_dynamics/strict_future_decision_loao.csv", "kind": "strip", "x": "model", "y": "log_loss", "title": "D  LOAO prediction"},
        ),
        figures=("conventional_dynamics_audit.png",),
        conclusion="Lag-1 time is measurable, but it does not improve later P_BS association or held-animal prediction in the current cohort.",
    ),
    _compact_phase(
        phase="phase7",
        title="Phase 7 - repeated-window within-animal temporal precedence",
        analysis_ids=("P7-RW1",),
        purpose="Ask whether deviations in neural timescale within an animal predict P_BS in the next exposure window, reducing stable-trait confounding.",
        hypotheses=({"id": "P7-RW1", "statement": "A window with longer-than-usual neural decay time predicts higher P_BS in the next window.", "test": "Animal-fixed grouped-binomial cross-lag model with within-animal circular-shift null.", "why": "Tests temporal precedence within animals rather than only between-animal traits."},),
        sources=("scripts/analyze_rapid_learning_repeated_window_dynamics.py", "src/ca_analysis/rapid_learning_conventional_dynamics.py"),
        directory="phase7_repeated_window_dynamics",
        manifest="phase7_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_repeated_window_dynamics.py --bin-frames 2 --overwrite",),
        groups=("Primary reward-free scope is 12 animals: 8 no-water plus 4 dry-port; all 22 are an interaction sensitivity.",),
        selection_rules=("Use complete 120-s exposure windows within first 60 explore minutes.", "Require at least five Lo decisions in both current and next window.", "Use 80-ms S bins and alternating 30-s blocks.", "Center neural time within animal and use a true per-window S engagement covariate."),
        signal="S population counts in each exposure window.",
        timebase="Segmented 120-s explore-exposure windows; adjacent in exposure order, without bridging gaps.",
        representation="Within-animal centered lag-1 decay time and next-window grouped P_BS counts.",
        steps=("Create exposure windows and segment ledger.", "Estimate subset/split timescales and per-window event mass.", "Apply within-animal reliability gates.", "Pair current and next windows with supported choices.", "Fit animal-fixed grouped-binomial model.", "Circularly shift neural sequences within animal; bootstrap whole animals."),
        equations=r"""\[\tau^c_{iw}=\tau_{iw}-\bar\tau_i,\qquad \widetilde P_{BS}=(s+0.5)/(n+1).\]
\[Y_{i,w+1}\sim Binomial(N_{i,w+1},p_{i,w+1}),\quad logit(p_{i,w+1})=\alpha_i+\beta_Blogit(\widetilde P_{BS,iw})+\beta_\tau\tau^c_{iw}+\gamma^TZ_{iw}.\]""",
        parameters=(
            {"name": "window/bin", "value": "120 s / 80 ms", "class": "reliability rescue", "hand_chosen": True, "held_out": False, "reason": "300/180/120-s native-bin variants failed reliability; rescue history is retained."},
            {"name": "circular shifts", "value": 5000, "class": "serial null", "hand_chosen": True, "held_out": True, "reason": "Preserves each animal's neural distribution and behavior."},
            {"name": "animal bootstrap", "value": 2000, "class": "uncertainty", "hand_chosen": True, "held_out": True, "reason": "Resamples the independent biological unit."},
        ),
        held_out_logic=("Predictor comes from current window and outcome from the next.", "Circular shifts never exchange values across animals.", "The 80-ms configuration is a labelled rescue, not a clean prespecified primary."),
        risks=("Parameter selection followed reliability probing; outcome results from the probe are not independent discovery evidence.", "Even repeated windows do not create more independent animals.", "Per-window engagement must be used; the earlier animal-level merge was collinear with animal fixed effects."),
        selection_file="repeated_window_support.csv",
        artifact_files=(("repeated_window_segments.csv", "source", "Exposure and discontinuity ledger"), ("repeated_window_dynamics_estimates.csv", "transformation", "Subset/split estimates"), ("repeated_window_dynamics_per_window.csv", "estimand", "Window medians and engagement"), ("repeated_window_reliability.csv", "reliability", "Within-animal gate"), ("repeated_window_prospective_pairs.csv", "alignment", "Current-next pairs"), ("repeated_window_cross_lag_null.csv", "null", "Circular-shift distribution"), ("repeated_window_cross_lag_bootstrap.csv", "uncertainty", "Whole-animal bootstrap")),
        panels=(
            {"path": "phase7_repeated_window_dynamics/repeated_window_support.csv", "kind": "hist", "x": "n_Lo_events", "title": "A  Choice support per window"},
            {"path": "phase7_repeated_window_dynamics/repeated_window_reliability.csv", "kind": "strip", "x": "metric", "y": "within_animal_centered_spearman_brown", "title": "B  Within-animal reliability"},
            {"path": "phase7_repeated_window_dynamics/repeated_window_dynamics_per_window.csv", "kind": "scatter", "x": "population_S_rate_per_cell_s_window", "y": "tau_fixed150_median_s", "hue": "cohort_group", "title": "C  Window engagement audit"},
            {"path": "phase7_repeated_window_dynamics/repeated_window_cross_lag_null.csv", "kind": "hist", "x": "tau_within_animal_coefficient", "title": "D  Circular-shift null"},
        ),
        figures=("repeated_window_audit.png",),
        conclusion="The within-animal cross-lag association is unsupported after a reliability rescue; the result remains precision- and specification-limited rather than proving no relation.",
    ),
    _compact_phase(
        phase="phase8",
        title="Phase 8 - separate structure transfer from reward discovery and binding",
        analysis_ids=("H-SR1", "H-SR2", "P8-H-NR1", "P8-H-NR2"),
        purpose="Test structure and neural predictors against two distinct reward-learning endpoints rather than collapsing discovery and exploitation.",
        hypotheses=(
            {"id": "H-SR1", "statement": "Greater Day-1 structure gain predicts fewer Day-2 choices to discover reward.", "test": "Rank Freedman-Lane model in 13 reward-free-Day1 animals.", "why": "Search efficiency can transfer before any reward binding."},
            {"id": "H-SR2", "statement": "Greater Day-1 structure gain predicts fewer choices from discovery to sustained binding.", "test": "Separate rank model adjusted for discovery burden.", "why": "Reward credit/binding is a different learning problem."},
            {"id": "P8-H-NR1", "statement": "Early neural time predicts reward discovery burden.", "test": "12-animal neural rank model with event-mass sensitivity.", "why": "Tests a neural readiness rival to behavioral structure."},
            {"id": "P8-H-NR2", "statement": "Early neural time predicts binding burden after discovery.", "test": "Separate binding model and rewarded-Day1 prereward sensitivity.", "why": "Avoids treating first reward as learned exploitation."},
        ),
        sources=("scripts/analyze_rapid_learning_structure_reward_specificity.py", "src/ca_analysis/rapid_learning_reward.py", "src/ca_analysis/rapid_learning_stats.py"),
        directory="phase8_structure_reward_specificity",
        manifest="phase8_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_structure_reward_specificity.py --overwrite",),
        groups=("Behavior: 13 reward-free-Day1 animals, including 769.", "Neural: 12 S-ready reward-free-Day1 animals.", "Rewarded-Day1 prereward sensitivity: 8 sessions whose full early window precedes reward."),
        selection_rules=("Discovery is the first actual tf.re reward onset.", "Binding is the first >=7-step reward path in a cluster of >=3 qualifying paths within five bouts.", "Use decisions as primary burden and elapsed time as sensitivity.", "Adjust discovery and binding separately; do not compare significance across endpoints."),
        signal="Behavioral P_BS structure gain and S-derived lag-1 time are tested in separate model families.",
        timebase="Day-1 structure epochs followed by Day-2 actual reward events; decision counts are primary.",
        representation="Structure gain, reward discovery burden, and post-discovery binding burden.",
        steps=("Join frozen structure estimates to reward endpoints.", "Preserve censored/nonbinding cases.", "Rank-z transform within the declared model.", "Fit context-restricted Freedman-Lane models.", "Bootstrap animals and apply Holm correction separately within structure and neural families.", "Audit baseline/change coupling, influence, and context heterogeneity."),
        equations=r"""\[\Delta P_{BS}=P_{BS,C}-P_{BS,B}.\]
\[Y_{disc}=\log(1+N_{choices\ to\ first\ reward}),\qquad Y_{bind}=\log(1+N_{choices\ from\ reward\ to\ binding}).\]
\[R(Y)=\alpha+\alpha_{context}+\gamma^TR(Z)+\beta R(X)+\epsilon.\]""",
        parameters=(
            {"name": "Freedman-Lane permutations", "value": 5000, "class": "inference", "hand_chosen": True, "held_out": True, "reason": "Restricted within reward-free context."},
            {"name": "bootstrap", "value": 2000, "class": "uncertainty", "hand_chosen": True, "held_out": True, "reason": "Context-stratified animal resampling."},
            {"name": "multiplicity", "value": "Holm over discovery/binding within predictor family", "class": "correction", "hand_chosen": True, "held_out": True, "reason": "Does not pool distinct behavioral and neural families."},
        ),
        held_out_logic=("Predictors are Day-1 and outcomes are later reward-learning endpoints.", "Discovery and binding are never substituted for each other.", "LOO diagnostics must refit the actual adjusted model, not only raw Spearman correlations."),
        risks=("n=13/12 gives detectable partial correlations roughly 0.70-0.88.", "Baseline adjustment and change scores can reverse because of mathematical coupling and measurement error.", "A longer neural timescale descriptively predicted slower, not faster, discovery; this is opposite-signed and not Holm-supported."),
        selection_file="reward_free_structure_to_reward_inputs.csv",
        artifact_files=(("reward_free_structure_to_reward_inputs.csv", "join", "Behavioral structure/reward inputs"), ("reward_free_neural_to_reward_inputs.csv", "join", "Neural/reward inputs"), ("rewarded_day1_prereward_neural_inputs.csv", "sensitivity", "Rewarded prereward subset"), ("structure_reward_specificity_models.csv", "inference", "All model estimates"), ("structure_reward_model_concordance.csv", "diagnostic", "Specification agreement")),
        panels=(
            {"path": "phase8_structure_reward_specificity/reward_free_structure_to_reward_inputs.csv", "kind": "scatter", "x": "delta_P_BS", "y": "log_discovery_primary_decisions", "hue": "cohort_group", "title": "A  Structure and discovery"},
            {"path": "phase8_structure_reward_specificity/reward_free_structure_to_reward_inputs.csv", "kind": "scatter", "x": "delta_P_BS", "y": "log_binding_primary_decisions", "hue": "cohort_group", "title": "B  Structure and binding"},
            {"path": "phase8_structure_reward_specificity/reward_free_neural_to_reward_inputs.csv", "kind": "scatter", "x": "fixed150_median_lag1_tau_s", "y": "log_discovery_primary_decisions", "hue": "cohort_group", "title": "C  Neural time and discovery"},
            {"path": "phase8_structure_reward_specificity/structure_reward_specificity_models.csv", "kind": "strip", "x": "analysis_id", "y": "partial_r", "title": "D  Adjusted estimates"},
        ),
        figures=("structure_reward_specificity_audit.png",),
        conclusion="Discovery and binding remain empirically distinct; current structure/neural predictors are suggestive or unsupported under severe precision limits, not decisive negatives.",
    ),
    _compact_phase(
        phase="phase9",
        title="Phase 9 - effective dimensionality and latent VAR geometry",
        analysis_ids=("H-G1", "H-G2"),
        purpose="Test whether early population geometry and latent dynamical radius provide reliable, predictive information beyond scalar timescales.",
        hypotheses=(
            {"id": "H-G1", "statement": "Higher early correlation-based participation ratio predicts later structure gain.", "test": "Reliability-gated q-independent dimensionality association.", "why": "A rich population state may support rapid readout formation."},
            {"id": "H-G2", "statement": "Excess latent VAR spectral radius predicts later structure gain.", "test": "q=5/10/20 reliability, predictive R2 gate, and time-shuffle excess association.", "why": "Tests a multivariate marginal-stability analogue."},
        ),
        sources=("scripts/analyze_rapid_learning_geometry_var.py", "src/ca_analysis/rapid_learning_conventional_dynamics.py"),
        directory="phase9_geometry_var",
        manifest="phase9_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_geometry_var.py --overwrite",),
        groups=("All 22 S-ready early Day-1 sessions; five fixed 150-cell subsets.",),
        selection_rules=("Bin S into 200-ms segment-safe bins and apply square root.", "Participation ratio uses the cell correlation matrix.", "Fit independent half-specific PCA bases for split reliability.", "Evaluate q=5,10,20 and require at least 4/5 predictive subsets before behavioral inference."),
        signal="S, fixed-cell subsets.",
        timebase="First 300 s segmented explore exposure; 200-ms bins; alternating 30-s split blocks.",
        representation="Correlation eigenvalues and ridge VAR(1) latent dynamics.",
        steps=("Standardize cells and compute correlation eigenvalues/participation ratio.", "Fit PCA and ridge VAR on each half independently for reliability.", "Select alpha by inner block CV.", "Compute held-out R2 and spectral radius.", "Destroy temporal order with within-segment joint-time shuffles.", "Compute half-specific and full spectral-radius excess for q=5/10/20.", "Gate animal-level behavior models on reliability and predictive support."),
        equations=r"""\[D_{PR}=\frac{(\sum_k\lambda_k)^2}{\sum_k\lambda_k^2}.\]
\[z_{t+1}=Az_t+\epsilon_t,\quad \hat A=\arg\min_A\sum_t\|z_{t+1}-Az_t\|^2+\alpha\|A\|_F^2.\]
\[\rho(A)=\max_j|\lambda_j(A)|,\qquad \rho_{excess}=\rho_{obs}-median(\rho_{shuffle}).\]""",
        parameters=(
            {"name": "latent dimensions", "value": "q=10 primary; q=5,20 sensitivity", "class": "dimension ladder", "hand_chosen": True, "held_out": True, "reason": "All dimensions receive their own reliability audit."},
            {"name": "ridge alpha", "value": "1e-4 to 1e2, 9 values", "class": "inner CV", "hand_chosen": False, "held_out": True, "reason": "Chosen using training-half temporal blocks."},
            {"name": "shuffle draws", "value": "100 at q10; 20 at q5/q20", "class": "null precision", "hand_chosen": True, "held_out": True, "reason": "Sensitivities have coarser Monte Carlo resolution."},
        ),
        held_out_logic=("VAR predictive validity is evaluated on a held temporal half.", "Split reliability uses independently fitted half bases.", "Time shuffle preserves zero-lag latent covariance but destroys transitions."),
        risks=("Spectral radius is not interpreted if held-out prediction or reliability fails.", "q5/q20 nulls are coarse.", "PCA basis/sign differences do not affect spectral radius, but finite-sample subspace instability remains."),
        selection_file="geometry_var_source_audit.csv",
        artifact_files=(("geometry_var_source_audit.csv", "source", "Cell/segment inputs"), ("geometry_var_eigenvalues.csv", "transformation", "Correlation spectrum"), ("geometry_var_ridge_cv.csv", "model selection", "Alpha CV"), ("geometry_var_shuffle_null.csv", "null", "Time-shuffle radii"), ("geometry_var_subset_estimates.csv", "estimand", "q/subset metrics"), ("geometry_var_reliability.csv", "reliability", "q-specific gates"), ("geometry_var_structure_associations.csv", "inference", "Behavior associations")),
        panels=(
            {"path": "phase9_geometry_var/geometry_var_reliability.csv", "kind": "scatter", "x": "q", "y": "median_split_half_spearman_brown", "hue": "metric", "title": "A  q-specific reliability"},
            {"path": "phase9_geometry_var/geometry_var_eigenvalues.csv", "kind": "scatter", "x": "eigen_index", "y": "magnitude", "hue": "q", "title": "B  VAR eigenvalues"},
            {"path": "phase9_geometry_var/geometry_var_ridge_cv.csv", "kind": "scatter", "x": "alpha", "y": "inner_valid_r2", "hue": "q", "title": "C  Ridge selection"},
            {"path": "phase9_geometry_var/geometry_var_shuffle_null.csv", "kind": "hist", "x": "spectral_radius", "title": "D  Temporal-order null"},
        ),
        figures=("geometry_var_audit.png",),
        conclusion="Participation ratio is measurable but not behaviorally supported. Spectral-radius conclusions depend on the corrected q-specific reliability and predictive gates.",
    ),
    _compact_phase(
        phase="phase10",
        title="Phase 10 - dynamics change across learning and reward events",
        analysis_ids=("P10-STRUCT", "P10-REWARD"),
        purpose="Test state change rather than readiness: reward-free Day1 early-to-late dynamics, and first-reward/binding-aligned dynamics with trend controls.",
        hypotheses=(
            {"id": "P10-STRUCT", "statement": "Conventional neural timescale changes from early to late reward-free Day1 and covaries with P_BS change.", "test": "First-three versus last-three exposure windows, change reliability, sign flips, and rank association.", "why": "A learning-related transition may exist even if baseline prediction fails."},
            {"id": "P10-REWARD", "statement": "Dynamics change specifically at first reward or behavioral binding.", "test": "Paired pre/post exposure windows plus 60/30-s and four-block local-trend controls.", "why": "Separates event-specific changes from smooth within-session drift."},
        ),
        sources=("scripts/analyze_rapid_learning_dynamics_change.py",),
        directory="phase10_dynamics_change",
        manifest="phase10_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_dynamics_change.py --overwrite",),
        groups=("Reward-free early/late primary: 12 animals.", "Reward-event analysis: rewarded Day1 plus reward-free Day2, requiring verified shared component basis; 769 excluded."),
        selection_rules=("Early/late uses medians of first/last three 120-s windows.", "Event primary uses last 120 s pre and first 120 s post; 60/30 s are support sensitivities.", "Binding pre begins after first reward.", "Require change-score reliability before inference."),
        signal="S lag-1 time primary; ACF area and MR are rival sensitivities.",
        timebase="Explore exposure windows and absolute tf.re/binding event frames; no lag crosses a segment gap.",
        representation="Within-animal post-minus-pre/late-minus-early neural change.",
        steps=("Construct edge/event exposure windows and source ledger.", "Estimate subset/split dynamics on both sides.", "Compute change-score reliability.", "Run exact/random animal sign flips.", "Apply BH across first-reward and binding primary tests.", "Build four-block trend contrast and context/event-mass alternatives."),
        equations=r"""\[\Delta_i=median_s(M_{is,late}-M_{is,early}).\]
The event trend contrast is
\[D=(post_1-pre_1)-\tfrac12[(pre_1-pre_2)+(post_2-post_1)].\]
Sign-flip inference uses the mean signed change, while medians are descriptive.""",
        parameters=(
            {"name": "edge epoch", "value": "3 x 120 s", "class": "exposure-matched", "hand_chosen": True, "held_out": True, "reason": "Uses repeated-window support."},
            {"name": "event ladder", "value": "120/60/30 s", "class": "support sensitivity", "hand_chosen": True, "held_out": False, "reason": "Checks duration dependence without selecting the best p-value."},
            {"name": "primary correction", "value": "BH over first reward and binding", "class": "multiplicity", "hand_chosen": True, "held_out": True, "reason": "Only reliable 120-s lag1 tests enter family."},
        ),
        held_out_logic=("Event windows exclude the reward-containing interval and preserve frozen Day1 cell subsets.", "Shorter windows and local trends are interpretation tests, not replacements for unsupported results.", "A pre/post shift is not called event-specific unless it survives the local-trend contrast."),
        risks=("First-reward and binding nominal changes do not survive the full event-specificity ladder.", "Inference tests the mean while figures may foreground the median.", "Smooth drift and reward-history heterogeneity remain viable alternatives."),
        selection_file="reward_event_source_audit.csv",
        artifact_files=(("early_late_epoch_summary.csv", "selection", "Edge windows"), ("early_late_change_reliability.csv", "reliability", "Change gate"), ("early_late_structure_associations.csv", "inference", "P_BS association"), ("reward_event_window_support.csv", "support", "Event duration ladder"), ("reward_event_dynamics_estimates.csv", "transformation", "Pre/post subset estimates"), ("reward_event_paired_inference.csv", "inference", "Primary event tests"), ("reward_event_local_trend_estimates.csv", "control", "Four-block trend data"), ("reward_event_local_trend_inference.csv", "control", "Trend-adjusted tests")),
        panels=(
            {"path": "phase10_dynamics_change/early_late_animal_change.csv", "kind": "strip", "x": "metric", "y": "delta", "title": "A  Reward-free early-late change"},
            {"path": "phase10_dynamics_change/reward_event_window_support.csv", "kind": "animal_counts", "x": "event_type", "hue": "duration_seconds", "title": "B  Event support ladder"},
            {"path": "phase10_dynamics_change/reward_event_animal_change.csv", "kind": "strip", "x": "event_type", "y": "delta", "title": "C  Event pre/post changes"},
            {"path": "phase10_dynamics_change/reward_event_local_trend_inference.csv", "kind": "strip", "x": "event_type", "y": "mean_delta", "title": "D  Local-trend contrasts"},
        ),
        figures=("dynamics_change_audit.png",),
        conclusion="Reward-free early/late lag-1 change is absent. Event-aligned changes are descriptive because shorter windows/trend controls do not establish event specificity.",
    ),
    _compact_phase(
        phase="phase11",
        title="Phase 11 - visit-held-out structure and reward representation rescues",
        analysis_ids=("H-NR1-VISIT", "H-NS1A-POSTHOC"),
        purpose="Recover interpretable visit-level neural tests when frame/depth support prevents the stricter Phase-3 decoders.",
        hypotheses=(
            {"id": "H-NS1A-POSTHOC", "statement": "Late whole-visit tree-depth decoding improves beyond XY and shuffle.", "test": "Common-depth/common-quota leave-one-visit-out folds.", "why": "Uses visits as the independent prediction unit instead of sparse frames."},
            {"id": "H-NR1-VISIT", "statement": "Node-94 visit representations reorganize after reward more than matched pseudo nodes.", "test": "First-post and few-shot k=1/2/3 target-minus-pseudo estimands.", "why": "Tests rapid reward coding with estimand-specific support rather than forcing k=3 support on all tests."},
        ),
        sources=("scripts/analyze_rapid_learning_phase11_neural_code_rescues.py",),
        directory="phase11_neural_code_rescues",
        manifest="phase11_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_phase11_neural_code_rescues.py --overwrite",),
        groups=("Structure: 12/22 C-loadable animals have at least three supported common depths.", "Reward: support is estimand-specific: n=10 first-post, 9 k1, 8 k2, 5 k3."),
        selection_rules=("Match B/C depths and visit quotas.", "Hold out one complete visit per depth.", "Use the Phase-3 0.1 C/min and nonzero-variance training gate.", "Exclude reward-containing visits and match pseudo nodes on speed, dwell, frames, and orientation where support allows.", "Do not use the retained dead strict-k3 function as evidence."),
        signal="C visit vectors built from nine-sample trailing counts.",
        timebase="Whole graph visits; reward post pool ends at first reward + 3600 s.",
        representation="Visit-mean population vector, depth label, and node-94/pseudo-node representation similarity.",
        steps=("Build explicit C/exclusion and visit-support ledgers.", "Freeze common depth/visit quotas.", "Fit visit-held-out neural and XY decoders.", "Shuffle training labels.", "Match reward/pseudo visits separately for each estimand.", "Compute first-post and k-shot target-minus-pseudo effects with animal-level inference and BH."),
        equations=r"""\[\Delta BA=BA_C-BA_B.\]
For reward node r and pseudo node a,
\[E_i^{(k)}=\Delta similarity_i^{(k)}(r)-median_a\Delta similarity_i^{(k)}(a).\]
The few-shot estimands are separate for \(k\in\{1,2,3\}\); support is not inherited from k=3.""",
        parameters=(
            {"name": "minimum common depths", "value": 3, "class": "support rescue", "hand_chosen": True, "held_out": False, "reason": "Phase3 stricter support failed; this is post-primary."},
            {"name": "structure label shuffles", "value": 1000, "class": "null", "hand_chosen": True, "held_out": True, "reason": "Training labels only."},
            {"name": "reward post horizon", "value": "60 min", "class": "support rescue", "hand_chosen": True, "held_out": False, "reason": "Retains rapid-learning scope while increasing visits."},
        ),
        held_out_logic=("Predictions hold out complete visits.", "Pseudo matching is redone for every estimand.", "Reward-containing visits are excluded from templates and tests."),
        risks=("Only depths 3-5 happened to support the structure rescue.", "k3 has only five animals and BH-corrected inference is coarse.", "The old strict one-pre/four-post implementation remains dead code and must be labelled invalid/unused."),
        selection_file="phase11_structure_C_load_audit.csv",
        artifact_files=(("phase11_exclusions.csv", "exclusion", "Attempted-session waterfall"), ("phase11_structure_visit_support.csv", "support", "Depth-by-epoch visits"), ("phase11_structure_population_vector_audit.csv", "transformation", "C to visit vectors"), ("phase11_structure_visit_predictions.csv", "prediction", "Held-out predictions"), ("phase11_structure_shuffle_audit.csv", "null", "Label shuffles"), ("phase11_reward_pseudo_match_audit.csv", "matching", "Reward/pseudo balance"), ("phase11_reward_DiD_support.csv", "support", "Estimand-specific k support"), ("phase11_reward_group_inference.csv", "inference", "Reward tests")),
        panels=(
            {"path": "phase11_neural_code_rescues/phase11_exclusions.csv", "kind": "counts", "x": "reason", "title": "A  Structure exclusions"},
            {"path": "phase11_neural_code_rescues/phase11_structure_visit_support.csv", "kind": "animal_counts", "x": "depth", "hue": "epoch", "title": "B  Visit support by depth"},
            {"path": "phase11_neural_code_rescues/phase11_reward_DiD_support.csv", "kind": "animal_counts", "x": "estimand", "title": "C  Reward estimand support"},
            {"path": "phase11_neural_code_rescues/phase11_reward_pseudo_match_audit.csv", "kind": "strip", "x": "estimand", "y": "behavior_match_distance", "title": "D  Pseudo-match distance"},
        ),
        figures=("phase11_support_and_estimand_audit.png",),
        conclusion="Visit-level rescues improve transparency/support but do not support late depth gain or reward-specific reorganization after correction.",
    ),
    _compact_phase(
        phase="phase12",
        title="Phase 12 - reward-free structure transfer into target-directed search",
        analysis_ids=("H-S2",),
        purpose="Test whether reward-free Day-1 structure learning biases Day-2 prereward choices toward the future reward node.",
        hypotheses=({"id": "H-S2", "statement": "Animals with stronger Day-1 structural acquisition show more opportunity-adjusted Day-2 prereward search toward node 94.", "test": "Target-minus-pseudo choice score, group sign flips, and structure association with stability/influence ladder.", "why": "Separates latent structure learning from reward learning."},),
        sources=("scripts/analyze_rapid_learning_target_search_transfer.py",),
        directory="phase12_target_search_transfer",
        manifest="phase12_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_target_search_transfer.py --overwrite",),
        groups=("Attempt all 13 reward-free-Day1 animals: 9 no-water and 4 dry-port.", "Primary support is 11; 839 has insufficient choices and 769 has zero prereward explore decisions and must appear in the exclusion ledger."),
        selection_rules=("Use Day-2 explore-mode nonforced choices before first reward.", "Primary excludes the reward-containing transition; inclusive is a sensitivity.", "Primary minimum is 20 decisions; report 5/10/20/30/50 support ladder.", "Audit collinearity, VIF, one-covariate, penalized, LOAO, and context influence rather than treating an unstable adjusted sign as definitive."),
        signal="Behavior only.",
        timebase="Day-2 prereward absolute-frame choices.",
        representation="Graph-distance opportunity-adjusted progress toward node 94 versus all alternative anchors.",
        steps=("Enumerate legal alternatives for every supported choice.", "Score chosen progress relative to available alternatives for node 94 and pseudo anchors.", "Aggregate target-minus-median-pseudo per animal.", "Run threshold and transition-inclusion ladders.", "Fit context-only and stability diagnostics for the Day-1 structure association.", "Export all attempted animals and influence results."),
        equations=r"""\[q_{dj}(a)=d(current,a)-d(alternative_j,a),\]
\[OAP_d(a)=q_{d,chosen}(a)-mean_j q_{dj}(a),\]
\[T_i=S_i(94)-median_{a\ne94}S_i(a).\]""",
        parameters=(
            {"name": "minimum decisions", "value": "20 primary; 5/10/30/50 ladder", "class": "support plus sensitivity", "hand_chosen": True, "held_out": False, "reason": "Shows precision/support tradeoff without selecting by p-value."},
            {"name": "group sign flips", "value": 5000, "class": "inference", "hand_chosen": True, "held_out": True, "reason": "Animal is the unit."},
            {"name": "bootstrap", "value": 2000, "class": "uncertainty", "hand_chosen": True, "held_out": True, "reason": "Context-stratified animal resampling."},
        ),
        held_out_logic=("All choice features use information available before reward.", "Pseudo anchors are evaluated on exactly the same decisions.", "Sensitivity ladders are interpreted for stability, not significance selection."),
        risks=("The fully adjusted n~11 model is severely collinear and can reverse sign.", "Prior maze exposure is not uniquely structural knowledge; within-latent gradients carry the structural interpretation.", "Sparse prereward decisions can make absence of an effect non-identifiable."),
        selection_file="target_search_attempt_ledger.csv",
        artifact_files=(("target_search_attempt_ledger.csv", "selection", "All 13 attempted animals"), ("target_search_choice_support.csv", "support", "Decision counts"), ("target_search_alternative_rows.csv", "source", "Choice alternatives"), ("target_search_anchor_scores.csv", "transformation", "Anchor score profiles"), ("target_search_support_threshold_sensitivity.csv", "sensitivity", "Decision threshold ladder"), ("target_search_predictor_correlation_audit.csv", "diagnostic", "Collinearity and influence"), ("target_search_structure_models.csv", "inference", "Context/adjusted/penalized models"), ("target_search_leave_one_out.csv", "influence", "LOAO results")),
        panels=(
            {"path": "phase12_target_search_transfer/target_search_attempt_ledger.csv", "kind": "counts", "x": "status", "title": "A  Full attempted cohort"},
            {"path": "phase12_target_search_transfer/target_search_support_threshold_sensitivity.csv", "kind": "scatter", "x": "min_decisions", "y": "reward_minus_pseudo_mean", "hue": "variant", "title": "B  Support ladder"},
            {"path": "phase12_target_search_transfer/target_search_anchor_scores.csv", "kind": "scatter", "x": "anchor_node", "y": "mean_opportunity_adjusted_progress", "hue": "is_reward_anchor", "title": "C  Anchor profiles"},
            {"path": "phase12_target_search_transfer/target_search_leave_one_out.csv", "kind": "strip", "x": "model", "y": "partial_r", "title": "D  Influence stability"},
        ),
        figures=("target_search_transfer_audit.png",),
        conclusion="Target-directed prereward search is not decisively supported; sparse support and unstable adjustment prevent a biological-null interpretation.",
    ),
    _compact_phase(
        phase="phase13",
        title="Phase 13 - distributed reward-coordinate group analysis",
        analysis_ids=("H-NR1-GROUP",),
        purpose="Aggregate distributed goal-coordinate accessibility across reward-free animals while keeping the Day1-versus-Day2-postreward contrast explicit.",
        hypotheses=({"id": "H-NR1-GROUP", "statement": "Distance-to-node-94 accessibility improves from reward-free Day1 to Day2 postreward more than accessibility to pseudo anchors.", "test": "LOONO ridge target-minus-pseudo group sign flip and exact context-label moderation.", "why": "Tests a distributed code when local node-94 visits are sparse."},),
        sources=("scripts/analyze_rapid_learning_distributed_reward_group.py",),
        directory="phase13_distributed_reward_group",
        manifest="phase13_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_distributed_reward_group.py --overwrite",),
        groups=("Eleven estimable reward-free animals: eight no-water and three dry-port.", "769 lacks C; 347 has node support but fails the cell gate."),
        selection_rules=("Pre is reward-free Day1; post is Day2 after first reward. Do not call this a within-Day2 reward contrast.", "Require at least eight common non-target nodes and up to four visits per node.", "Use ridge alpha=10 and leave-one-node-out prediction.", "Test target minus median pseudo-anchor change per animal."),
        signal="C visit-mean population vectors from Phase3 distributed coordinate outputs.",
        timebase="Cross-day Day1-pre-experience versus Day2-postreward; day/session and reward experience are confounded.",
        representation="Predicted graph distance to candidate anchors across distributed non-target nodes.",
        steps=("Load and hash upstream Phase3 source rows.", "Apply node/cell support and export exclusions.", "Fit LOONO ridge separately for each anchor and epoch.", "Compute Spearman accessibility change and target-minus-pseudo effect.", "Run animal sign flips, context bootstrap, and exact 8-versus-3 label enumeration."),
        equations=r"""\[E_i=\Delta\rho_i(94)-median_{a\ne94}\Delta\rho_i(a),\qquad \Delta\rho_i=\rho_{Day2\ post}-\rho_{Day1\ reward-free}.\]""",
        parameters=(
            {"name": "ridge alpha", "value": 10, "class": "fixed model", "hand_chosen": True, "held_out": True, "reason": "Inherited from distributed-code branch."},
            {"name": "common nodes", "value": ">=8; max 4 visits/node", "class": "support", "hand_chosen": True, "held_out": True, "reason": "Balances node diversity and animals."},
            {"name": "sign flips", "value": 20000, "class": "inference", "hand_chosen": True, "held_out": True, "reason": "Monte Carlo animal-level test."},
        ),
        held_out_logic=("Prediction holds out the target node being scored.", "Pseudo anchors use the same source rows.", "Context moderation uses exact label allocations where possible."),
        risks=("Day and reward experience cannot be separated in this contrast.", "The mean effect is suggestive but p~0.077 and context n is 8 versus 3.", "A group aggregate can conceal animal/anchor heterogeneity."),
        selection_file="distributed_reward_source_rows.csv",
        artifact_files=(("distributed_reward_source_rows.csv", "source", "Upstream rows and exclusions"), ("distributed_reward_animal_estimands.csv", "estimand", "Target/pseudo effects"), ("distributed_reward_sign_flip_null.csv", "null", "Group sign flips"), ("distributed_reward_context_difference_null.csv", "null", "Exact context labels"), ("distributed_reward_context_diagnostics.csv", "diagnostic", "Context heterogeneity"), ("distributed_reward_group_inference.csv", "inference", "Group result")),
        panels=(
            {"path": "phase13_distributed_reward_group/distributed_reward_source_rows.csv", "kind": "counts", "x": "status", "title": "A  Source and exclusion waterfall"},
            {"path": "phase13_distributed_reward_group/distributed_reward_animal_estimands.csv", "kind": "strip", "x": "cohort_group", "y": "reward_minus_pseudo_delta_median", "title": "B  Animal effects"},
            {"path": "phase13_distributed_reward_group/distributed_reward_sign_flip_null.csv", "kind": "hist", "x": "null_mean", "title": "C  Sign-flip null"},
            {"path": "phase13_distributed_reward_group/distributed_reward_context_difference_null.csv", "kind": "hist", "x": "null_no_water_minus_dry_mean", "title": "D  Exact context null"},
        ),
        figures=("distributed_reward_group_audit.png",),
        conclusion="The distributed target-minus-pseudo change is suggestive, but it is a Day1-to-Day2-postreward association and cannot isolate reward-induced reorganization.",
    ),
    _compact_phase(
        phase="phase14",
        title="Phase 14 - geometry-controlled depth representational similarity",
        analysis_ids=("H-NS1B-POSTHOC",),
        purpose="Test whether same-depth visits share neural geometry after controlling physical distance, graph distance, heading, speed, and support.",
        hypotheses=({"id": "H-NS1B-POSTHOC", "statement": "Late same-depth visits are more similar than different-depth visits after geometry controls and label shuffling.", "test": "Animal-specific pair regression and run-node-block label shuffles over a physical-separation ladder.", "why": "Addresses spatial interpolation after the original distant-subtree decoder was support-limited."},),
        sources=("scripts/analyze_rapid_learning_geometry_controlled_rsa.py",),
        directory="phase14_geometry_controlled_rsa",
        manifest="phase14_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_geometry_controlled_rsa.py --overwrite --distance-ladder",),
        groups=("Twelve Phase11-supported animals, with inherited exclusions exported.",),
        selection_rules=("Use the declared Phase11 cell gate: >=0.1 C/min, finite nonzero variance, >=10 cells.", "Exclude identical run-node pairs.", "Require split-half visit support.", "Primary all-eligible visits; matched B/C quota is a named sensitivity.", "Evaluate minimum physical separation near 2/4/6 grid cells with BH across the ladder."),
        signal="C visit vectors split into alternating within-visit halves.",
        timebase="Late-session whole visits; no cross-visit frame concatenation.",
        representation="Cross-half neural correlation and pairwise physical/behavior geometry.",
        steps=("Reapply and audit the declared cell gate.", "Build visit vectors and within-visit reliability.", "Enumerate valid visit pairs and geometry covariates.", "Fit same-depth coefficient per animal.", "Shuffle depth labels across run-node blocks.", "Compare all-eligible and matched-quota estimands; sign-flip animal effects and correct distance ladder."),
        equations=r"""\[sim_{ij}=\tfrac12[r(h_i^{(1)},h_j^{(2)})+r(h_i^{(2)},h_j^{(1)})].\]
\[sim_{ij}=\beta_0+\beta_1z(d_E)+\beta_2z(d_G)+\beta_3z(cos\Delta\theta)+\beta_4z(|\Delta v|)+\beta_5z(\log(1+n))+\beta_D I(depth_i=depth_j)+\epsilon.\]""",
        parameters=(
            {"name": "cell gate", "value": ">=0.1 C/min, nonzero variance, >=10 cells", "class": "declared upstream gate", "hand_chosen": True, "held_out": True, "reason": "Aligns implementation and report."},
            {"name": "depth shuffles", "value": 200, "class": "animal null", "hand_chosen": True, "held_out": True, "reason": "Permutes run-node blocks, not dependent pair rows."},
            {"name": "group sign flips", "value": 20000, "class": "inference", "hand_chosen": True, "held_out": True, "reason": "Animal remains the statistical unit."},
        ),
        held_out_logic=("Cross-half similarity prevents same-frame reuse.", "Depth labels are shuffled at unique run-node level.", "Pair-row hierarchical models are sensitivity only; primary inference remains animal-level."),
        risks=("Visit pairs are dependent within animal.", "The 2-cell threshold is nominally suggestive but does not survive BH.", "All-eligible and matched-quota estimates answer slightly different support-weighting questions."),
        selection_file="rsa_source_and_conversion_audit.csv",
        artifact_files=(("rsa_source_and_conversion_audit.csv", "source", "Inherited support and cell gate"), ("rsa_visit_metadata.csv", "transformation", "Visit vectors and split support"), ("rsa_pairwise_inputs.csv", "transformation", "Pair geometry"), ("rsa_depth_label_shuffle_audit.csv", "null", "Animal label shuffles"), ("rsa_distance_threshold_sensitivity.csv", "sensitivity", "Distance/quota ladder"), ("rsa_animal_estimands.csv", "estimand", "Animal same-depth effects"), ("rsa_group_inference.csv", "inference", "Group tests")),
        panels=(
            {"path": "phase14_geometry_controlled_rsa/rsa_source_and_conversion_audit.csv", "kind": "counts", "x": "status", "title": "A  Inherited cohort/cell gate"},
            {"path": "phase14_geometry_controlled_rsa/rsa_visit_metadata.csv", "kind": "scatter", "x": "n_frames", "y": "mean_speed_grid_units_per_s", "hue": "depth", "title": "B  Visit support and speed"},
            {"path": "phase14_geometry_controlled_rsa/rsa_pairwise_inputs.csv", "kind": "scatter", "x": "euclidean_distance", "y": "neural_crosshalf_similarity", "hue": "same_depth", "title": "C  Geometry overlap"},
            {"path": "phase14_geometry_controlled_rsa/rsa_distance_threshold_sensitivity.csv", "kind": "scatter", "x": "approx_grid_cells", "y": "mean_actual_minus_shuffle_median", "title": "D  Distance ladder"},
        ),
        figures=("geometry_controlled_rsa_audit.png",),
        conclusion="Geometry-controlled same-depth similarity is not supported after the correction family; current evidence is post-hoc and support-weighting sensitive.",
    ),
    _compact_phase(
        phase="phase15",
        title="Phase 15 - ordinal depth accessibility rescue",
        analysis_ids=("H-NS1A-POSTHOC",),
        purpose="Test whether late predictions become closer in ordinal depth even when exact categorical accuracy does not improve.",
        hypotheses=({"id": "H-NS1A-POSTHOC", "statement": "Late held-out neural predictions have smaller ordinal depth error, beyond XY and shuffle.", "test": "Re-score unchanged Phase11 held-out predictions with normalized absolute depth error.", "why": "A graded depth code can be missed by exact classification."},),
        sources=("scripts/analyze_rapid_learning_ordinal_depth_accessibility.py",),
        directory="phase15_ordinal_depth_accessibility",
        manifest="phase15_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_ordinal_depth_accessibility.py --overwrite",),
        groups=("Exactly the 12 Phase11 structure-supported animals; no threshold relaxation or refitting.",),
        selection_rules=("Reuse exact folds/predictions.", "Normalize absolute error by supported depth range.", "Permute labels only within the fold that generated each prediction.", "Require raw, beyond-XY, and beyond-shuffle conjunctive evidence."),
        signal="No new neural extraction; Phase11 held-out C predictions.",
        timebase="Phase11 B/C whole visits.",
        representation="Ordinal depth accessibility from held-out predictions.",
        steps=("Load inherited prediction/exclusion ledger.", "Compute visit absolute depth errors.", "Aggregate accessibility by animal and epoch.", "Generate within-fold label nulls.", "Test B-to-C changes for neural, neural-minus-XY, and neural-minus-shuffle estimands."),
        equations=r"""\[A=1-\frac1N\sum_v\frac{|\hat d_v-d_v|}{d_{max}-d_{min}}.\]""",
        parameters=(
            {"name": "label permutations", "value": 2000, "class": "null", "hand_chosen": True, "held_out": True, "reason": "Within the original held-out fold."},
        ),
        held_out_logic=("No model is refit and no support threshold is changed.", "The rescue changes only the loss function.", "XY and shuffle comparisons use the same visits."),
        risks=("This is a post-primary loss-function rescue.", "The supported depths are narrow, limiting ordinal range.", "No result is supported, but the conclusion applies to this inherited support only."),
        selection_file="phase15_visit_ordered_loss_audit.csv",
        artifact_files=(("phase15_visit_ordered_loss_audit.csv", "source", "True/predicted visit depths"), ("phase15_epoch_estimands.csv", "transformation", "Epoch accessibility"), ("phase15_heldout_label_permutations.csv", "null", "Within-fold null"), ("phase15_animal_estimands.csv", "estimand", "Animal B/C changes"), ("phase15_animal_inference.csv", "inference", "Conjunctive tests")),
        panels=(
            {"path": "phase15_ordinal_depth_accessibility/phase15_visit_ordered_loss_audit.csv", "kind": "scatter", "x": "true_depth", "y": "neural_predicted_depth", "title": "A  Neural predicted depth"},
            {"path": "phase15_ordinal_depth_accessibility/phase15_visit_ordered_loss_audit.csv", "kind": "scatter", "x": "true_depth", "y": "xy_behavior_predicted_depth", "title": "B  XY predicted depth"},
            {"path": "phase15_ordinal_depth_accessibility/phase15_animal_estimands.csv", "kind": "paired", "left": "neural_ordinal_accessibility_B", "right": "neural_ordinal_accessibility_C", "left_label": "Early B", "right_label": "Late C", "title": "C  Ordinal accessibility"},
            {"path": "phase15_ordinal_depth_accessibility/phase15_animal_inference.csv", "kind": "strip", "x": "estimand", "y": "mean", "title": "D  Three conjunctive effects"},
        ),
        figures=(),
        conclusion="Changing from categorical to ordinal loss does not reveal supported late depth-code improvement on the Phase11 visits.",
    ),
    _compact_phase(
        phase="phase16",
        title="Phase 16 - rewarded-Day1 distributed goal-code rescue",
        analysis_ids=("H-NR1-RD1",),
        purpose="Use the rewarded-from-start cohort to test within-Day1 distributed goal-code formation with node- and support-matched pre/post visits.",
        hypotheses=({"id": "H-NR1-RD1", "statement": "After first reward, distributed non-target node representations better predict distance to node 94 than to pseudo targets.", "test": "Dual-form LOONO ridge, rank and normalized-MAE accessibility, variant/support ladder, exact sign flips, BH.", "why": "Provides a within-day reward-learning test separate from reward-free structure learning."},),
        sources=("scripts/analyze_rapid_learning_rewarded_day1_distributed_code.py",),
        directory="phase16_rewarded_day1_distributed_code",
        manifest="phase16_manifest.json",
        reproduction=("python scripts/analyze_rapid_learning_rewarded_day1_distributed_code.py --overwrite",),
        groups=("All 10 rewarded-from-start Day1 animals attempted; seven pass primary node/cell support, four have finite rank and six finite normalized-MAE effects.",),
        selection_rules=("Exclude node 94 and the reward-containing visit.", "Match pre/post visits within non-target node and exposure-truncate post support.", "Primary: explore only, >=10 frames/visit, >=8 common nodes.", "Report lower-support and nonconsumption variants as a complete multiverse; do not select variants by significance.", "Reject extrapolating predictions outside valid graph-distance range."),
        signal="Raw visit-mean C with explicit rate/variance cell gate.",
        timebase="Within rewarded Day1 before versus after first reward.",
        representation="LOONO prediction of graph distance to node 94 and pseudo anchors across distributed non-target nodes.",
        steps=("Audit all C sources and visit support.", "Match node-specific pre/post visits and build cell vectors.", "Fit algebraically equivalent dual node-space ridge.", "Clip/validate predictions to the admissible distance scale.", "Compute rank and normalized-MAE accessibility changes for target and pseudo anchors.", "Run exact animal sign flips, bootstrap, BH, and all declared support/state variants.", "Retain invalid and timed-out implementations in the attempt registry."),
        equations=r"""For held-out node n and anchor a, ridge predicts graph distance
\(\hat d_{n,a}\). Accessibility is either Spearman
\(\rho(\hat d_a,d_a)\) or
\[A_{NMAE}=1-\frac{mean|\hat d_a-d_a|}{d_{max}-d_{min}}.\]
The animal effect is target change minus the median pseudo-anchor change.""",
        parameters=(
            {"name": "ridge alpha", "value": 10, "class": "fixed model", "hand_chosen": True, "held_out": True, "reason": "Dual form is algebraically equivalent to the timed-out cell-space fit."},
            {"name": "support", "value": ">=10 frames/visit; >=8 nodes", "class": "primary support", "hand_chosen": True, "held_out": True, "reason": "Lower gates are retained sensitivities."},
            {"name": "bootstrap/correction", "value": "10,000; BH over 10 variant-metric rows", "class": "uncertainty/multiplicity", "hand_chosen": True, "held_out": True, "reason": "Prevents variant selection."},
        ),
        held_out_logic=("Every prediction holds out a non-target node.", "Post visits are exposure-matched to prereward support.", "Nonfinite anchor deltas cannot receive ranks.", "The dual solution is validated as algebraically equivalent rather than a new estimator."),
        risks=("Only two unique support configurations underlie five named variants.", "Rank is finite in only four primary animals.", "The unconstrained and timed-out implementations are invalid/failed attempts, not negative evidence."),
        selection_file="phase16_support_status.csv",
        artifact_files=(("phase16_C_load_audit.csv", "source", "C source audit"), ("phase16_support_status.csv", "support", "Variant waterfall"), ("phase16_selected_visit_audit.csv", "transformation", "Pre/post visit matching"), ("phase16_anchor_estimands.csv", "estimand", "Target and pseudo profiles"), ("phase16_animal_estimands.csv", "estimand", "Animal effects"), ("phase16_group_inference.csv", "inference", "Variant-by-metric tests"), ("phase16_analysis_attempt_registry.csv", "attempt history", "Invalid/timed-out/corrected attempts")),
        panels=(
            {"path": "phase16_rewarded_day1_distributed_code/phase16_support_status.csv", "kind": "animal_counts", "x": "variant", "hue": "status", "title": "A  Support waterfall"},
            {"path": "phase16_rewarded_day1_distributed_code/phase16_selected_visit_audit.csv", "kind": "counts", "x": "epoch", "hue": "variant", "title": "B  Pre/post visit support"},
            {"path": "phase16_rewarded_day1_distributed_code/phase16_anchor_estimands.csv", "kind": "scatter", "x": "anchor_node", "y": "delta_post_minus_pre", "hue": "is_reward_anchor", "title": "C  Anchor profiles"},
            {"path": "phase16_rewarded_day1_distributed_code/phase16_group_inference.csv", "kind": "strip", "x": "variant", "y": "mean_reward_minus_median_pseudo_delta", "hue": "metric", "title": "D  Complete multiverse"},
        ),
        figures=(),
        conclusion="The within-Day1 distributed goal-code rescue is unsupported across the corrected variant family; limited finite rank support remains a major constraint.",
    ),
)


def phase_specs() -> tuple[dict[str, Any], ...]:
    return PHASE_SPECS


def get_phase_spec(phase: str) -> dict[str, Any]:
    for spec in PHASE_SPECS:
        if spec["phase"] == phase:
            return spec
    raise KeyError(f"Unknown rapid-learning audit phase: {phase}")


__all__ = ["PHASE_SPECS", "get_phase_spec", "phase_specs"]
