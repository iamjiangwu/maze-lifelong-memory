from __future__ import annotations

import numpy as np

from .trajectory import SplitModeClips

MODE_LEAVE = 0
MODE_DRINK = 1
MODE_EXPLORE = 2


def split_mode_clips(traj, ma, *, include_reward: bool = True) -> np.ndarray:
    return np.asarray(SplitModeClips(traj, ma, re=bool(include_reward)), dtype=int)


def mode_fractions(clips: np.ndarray, *, mode_col: int = 3, dur_col: int = 2) -> dict[str, float]:
    arr = np.asarray(clips)
    if arr.size == 0:
        return {"leave": np.nan, "drink": np.nan, "explore": np.nan}
    d = arr[:, int(dur_col)].astype(float)
    m = arr[:, int(mode_col)].astype(int)
    total = np.sum(d)
    if total <= 0:
        return {"leave": np.nan, "drink": np.nan, "explore": np.nan}
    return {
        "leave": float(np.sum(d[m == MODE_LEAVE]) / total),
        "drink": float(np.sum(d[m == MODE_DRINK]) / total),
        "explore": float(np.sum(d[m == MODE_EXPLORE]) / total),
    }


def mode_transition_matrix(clips: np.ndarray, *, n_modes: int = 3, mode_col: int = 3) -> np.ndarray:
    arr = np.asarray(clips)
    M = np.zeros((int(n_modes), int(n_modes)), dtype=int)
    if arr.size == 0:
        return M
    m = arr[:, int(mode_col)].astype(int)
    for a, b in zip(m[:-1], m[1:]):
        if 0 <= a < n_modes and 0 <= b < n_modes:
            M[a, b] += 1
    return M


def mode_fraction_over_time(
    clips: np.ndarray,
    *,
    n_frames: int,
    window_frames: int = 1500,
    step_frames: int = 250,
) -> dict[str, np.ndarray]:
    """
    Build rolling mode fractions using clip frame-start and clip duration.
    """
    arr = np.asarray(clips)
    if arr.size == 0:
        return {
            "window_start": np.zeros(0, dtype=int),
            "leave": np.zeros(0),
            "drink": np.zeros(0),
            "explore": np.zeros(0),
        }
    n_frames = int(n_frames)
    W = max(1, int(window_frames))
    S = max(1, int(step_frames))
    starts = np.arange(0, max(1, n_frames - W + 1), S, dtype=int)
    frac = np.full((len(starts), 3), np.nan, dtype=float)
    clip_bout = arr[:, 0].astype(int)
    clip_start = arr[:, 1].astype(int)
    clip_dur = arr[:, 2].astype(int)
    clip_mode = arr[:, 3].astype(int)
    # Within each bout, clip_start is local; we treat clips as contiguous proxy for trends.
    # This preserves relative within-notebook trend checks even when absolute timing differs.
    pseudo_start = np.cumsum(np.r_[0, np.maximum(1, clip_dur[:-1])]).astype(int)
    pseudo_end = pseudo_start + np.maximum(1, clip_dur)
    _ = clip_bout  # keep explicit; bout labels are available for downstream filtering.
    for i, s0 in enumerate(starts):
        s1 = int(s0 + W)
        w = np.maximum(0, np.minimum(pseudo_end, s1) - np.maximum(pseudo_start, s0)).astype(float)
        den = np.sum(w)
        if den <= 0:
            continue
        for mode in (MODE_LEAVE, MODE_DRINK, MODE_EXPLORE):
            frac[i, mode] = float(np.sum(w[clip_mode == mode]) / den)
    return {
        "window_start": starts,
        "leave": frac[:, MODE_LEAVE],
        "drink": frac[:, MODE_DRINK],
        "explore": frac[:, MODE_EXPLORE],
    }

