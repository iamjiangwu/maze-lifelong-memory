from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import re

import numpy as np
import pandas as pd

from .alignment import AlignmentReport, validate_alignment
from .behavior import default_behavior_groups_260113
from .config import DT, MAZE_ID, N_BINS_X, N_BINS_Y, get_behav_wd, get_neural_wd, get_parity_metafile
from .legacy_si_reproduction import load_single_session_subset
from .maze import NewMaze
from .population_sparsity_controls import QuartetSpec, default_expanded_cohort_specs, load_cimap_pairs
from .si_primary_curves import interpolate_then_average_group_curves
from .similarity import paired_pivot_window_spatial_information_fast, pivot_window_spatial_information_fast


SESSION_RE = re.compile(r"^(?P<animal>\d+)(?P<suffix>[A-Za-z]*)(?:-(?P<month>\d+))?day(?P<day>\d+)$")


@dataclass(frozen=True)
class SpatialInfoMemoryConfig:
    behav_wd: str = field(default_factory=get_behav_wd)
    neural_wd: str = field(default_factory=get_neural_wd)
    parity_metafile: str = field(default_factory=get_parity_metafile)
    maze_id: int = MAZE_ID
    dt: float = DT
    n_bins_x: int = N_BINS_X
    n_bins_y: int = N_BINS_Y
    mode_filter: str = "explore"
    window_style: str = "step"
    window_steps: int = 8000
    step_steps: int = 4000
    window_sec: float = 20.0 * 60.0
    step_sec: float = 5.0 * 60.0
    pivot_time_axis: str = "selected"
    min_time_per_bin_sec: float = 5.0
    min_time_policy: str = "scaled_nonoverlap"
    min_spikes_per_min: float = 0.5
    rate_source: str = "spike"
    prior_mode: str = "empirical"
    support_mode: str = "window"
    common_support_frac: float = 1.0
    pair_support_mode: str = "intersection"
    group_min_support_count: int = 3


def _parse_session_name(session_id: str) -> dict[str, Any] | None:
    m = SESSION_RE.match(str(session_id).strip())
    if not m:
        return None
    return {
        "animal": str(m.group("animal")),
        "suffix": str(m.group("suffix") or ""),
        "month": int(m.group("month")) if m.group("month") else 0,
        "day": int(m.group("day")),
    }


def _stage_rank(stage: str) -> int:
    mapping = {
        "naive": 0,
        "3mo": 1,
        "6mo": 2,
        "9mo": 3,
        "12mo": 4,
        "stage2": 5,
        "stage3": 6,
        "unrewarded": 7,
    }
    return int(mapping.get(str(stage), 99))


def _session_sort_key(session_id: str) -> tuple[Any, ...]:
    parsed = _parse_session_name(session_id)
    if parsed is None:
        return (1, str(session_id))
    return (
        0,
        int(parsed["animal"]),
        int(parsed["month"]),
        int(parsed["day"]),
        str(parsed["suffix"]),
        str(session_id),
    )


def _window_kwargs(config: SpatialInfoMemoryConfig) -> dict[str, Any]:
    if str(config.window_style) == "step":
        return {
            "win_len_sec": float(config.window_steps) * float(config.dt),
            "pivot_step_sec": float(config.step_steps) * float(config.dt),
            "pivot_time_axis": "selected",
        }
    return {
        "win_len_sec": float(config.window_sec),
        "pivot_step_sec": float(config.step_sec),
        "pivot_time_axis": str(config.pivot_time_axis),
    }


def _normalize_relative_time(win: dict[str, Any]) -> dict[str, Any]:
    out = dict(win)
    t = pd.to_numeric(np.asarray(out.get("pivot_times", np.array([]))), errors="coerce").astype(float)
    finite = np.flatnonzero(np.isfinite(t))
    out["pivot_times"] = t - float(t[finite[0]]) if finite.size else t
    return out


def _map_step_window_to_maze_time(win: dict[str, Any], df: pd.DataFrame) -> dict[str, Any]:
    out = dict(win)
    if "maze_time" not in df.columns:
        raise RuntimeError("Step-window analyses require selected_df['maze_time'].")
    maze_time = pd.to_numeric(df["maze_time"], errors="coerce").to_numpy(dtype=float)
    mapped = np.full(len(out.get("pivot_bounds", [])), np.nan, dtype=float)
    for i, (start, stop) in enumerate(out.get("pivot_bounds", [])):
        s0 = int(start)
        e0 = int(stop)
        if s0 < 0 or e0 <= s0 or e0 > maze_time.size:
            continue
        seg = maze_time[s0:e0]
        seg = seg[np.isfinite(seg)]
        if seg.size:
            mapped[i] = float(np.nanmedian(seg))
    finite = np.flatnonzero(np.isfinite(mapped))
    out["pivot_times_native"] = np.asarray(out.get("pivot_times", np.array([])), dtype=float)
    out["pivot_times"] = mapped - float(mapped[finite[0]]) if finite.size else mapped
    meta = dict(out.get("meta", {}))
    meta["timebase"] = "maze_time_median_per_window"
    out["meta"] = meta
    return out


def _load_parity_meta(meta: str | Path | pd.DataFrame | None) -> pd.DataFrame:
    if meta is None:
        return pd.DataFrame(columns=["ID1", "ID2", "cimap", "cimap_path"])
    if isinstance(meta, pd.DataFrame):
        return meta.copy()
    return pd.read_csv(str(meta))


def _build_cimap_graph(meta: pd.DataFrame) -> dict[str, list[tuple[str, str]]]:
    graph: dict[str, list[tuple[str, str]]] = {}
    if meta.empty:
        return graph
    for _, row in meta.iterrows():
        try:
            use_cimap = int(row.get("cimap", 0)) == 1
        except Exception:
            use_cimap = False
        if not use_cimap:
            continue
        src = str(row.get("ID1", "")).strip()
        dst = str(row.get("ID2", "")).strip()
        path = str(row.get("cimap_path", "")).strip()
        if not src or not dst or not path or path.lower() == "nan":
            continue
        graph.setdefault(src, []).append((dst, path))
    return graph


def _find_cimap_chain(graph: dict[str, list[tuple[str, str]]], start: str, end: str) -> list[str]:
    if start == end:
        return []
    queue: list[tuple[str, list[str]]] = [(str(start), [])]
    seen = {str(start)}
    while queue:
        node, paths = queue.pop(0)
        for nxt, cimap_path in graph.get(node, []):
            next_paths = [*paths, str(cimap_path)]
            if str(nxt) == str(end):
                return next_paths
            if str(nxt) in seen:
                continue
            seen.add(str(nxt))
            queue.append((str(nxt), next_paths))
    return []


def _reward_context_for_group(group_name: str) -> str:
    return "unrewarded" if str(group_name).startswith("Unrewarded") else "rewarded"


def _reward_context_for_session(spec: QuartetSpec, session_id: str, group_name: str) -> str:
    """Resolve session-specific exceptions recorded in a quartet's provenance note."""
    note = str(getattr(spec, "reward_context_note", "") or "").strip().lower()
    role_phrases: tuple[str, ...] = ()
    if str(session_id) == str(spec.naive_day1):
        role_phrases = ("naive day1", "naive_day1")
    elif str(session_id) == str(spec.naive_day2):
        role_phrases = ("naive day2", "naive_day2")
    elif str(session_id) == str(spec.gap_day1):
        role_phrases = ("gap day1", "ltm day1", "gap_day1")
    elif str(session_id) == str(spec.gap_day2):
        role_phrases = ("gap day2", "ltm day2", "gap_day2")
    if "unrewarded" in note and any(phrase in note for phrase in role_phrases):
        return "unrewarded"
    return _reward_context_for_group(group_name)


def _validate_cimap_chain(cimap_chain: list[str]) -> tuple[bool, str]:
    if not cimap_chain:
        return False, "no CIMap chain"
    paths = [Path(value) for value in cimap_chain]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        return False, f"CIMap file not found: {';'.join(missing)}"
    try:
        train_ids, test_ids = load_cimap_pairs(
            paths if len(paths) > 1 else paths[0],
            split=True,
            compose=len(paths) > 1,
        )
    except (FileNotFoundError, OSError, KeyError, TypeError, ValueError) as exc:
        return False, f"invalid CIMap chain: {exc}"
    if len(train_ids) == 0 or len(test_ids) == 0:
        return False, "CIMap chain contains no matched neurons"
    return True, ""


def build_single_session_manifest(
    *,
    quartets: list[QuartetSpec] | None = None,
    behavior_groups: dict[str, list[str]] | None = None,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for spec in quartets or default_expanded_cohort_specs():
        quartet_rows = [
            ("Rewarded Day1", spec.naive_day1, "rewarded", "naive", 1),
            ("Rewarded Day2", spec.naive_day2, "rewarded", "naive", 2),
        ]
        if str(spec.gap_day1).strip():
            quartet_rows.append(("LTM Day1", spec.gap_day1, "ltm", str(spec.gap_label), 1))
        if str(spec.gap_day2).strip():
            quartet_rows.append(("LTM Day2", spec.gap_day2, "ltm", str(spec.gap_label), 2))
        for cohort_group, session_id, cohort_family, stage, day_index in quartet_rows:
            session_id = str(session_id).strip()
            if not session_id or session_id in seen:
                continue
            parsed = _parse_session_name(session_id)
            animal = str(spec.animal if spec.animal else (parsed["animal"] if parsed else ""))
            reward_context = _reward_context_for_session(spec, session_id, cohort_group)
            rows.append(
                {
                    "animal": animal,
                    "session_id": session_id,
                    "cohort_family": str(cohort_family),
                    "cohort_group": str(cohort_group),
                    "memory_stage": str(stage),
                    "day_index": int(day_index),
                    "reward_context": reward_context,
                    "session_source": "default_expanded_cohort_specs",
                    "session_order_key": "|".join(map(str, _session_sort_key(session_id))),
                }
            )
            seen.add(session_id)

    groups = behavior_groups or default_behavior_groups_260113()
    for group_key, cohort_group, day_index in (
        ("UnrewardedDay1", "Unrewarded Day1", 1),
        ("UnrewardedDay2", "Unrewarded Day2", 2),
    ):
        for session_id in [str(v) for v in groups.get(group_key, [])]:
            if session_id in seen:
                continue
            parsed = _parse_session_name(session_id)
            animal = parsed["animal"] if parsed else ""
            rows.append(
                {
                    "animal": str(animal),
                    "session_id": str(session_id),
                    "cohort_family": "unrewarded",
                    "cohort_group": str(cohort_group),
                    "memory_stage": "unrewarded",
                    "day_index": int(day_index),
                    "reward_context": "unrewarded",
                    "session_source": "default_behavior_groups_260113",
                    "session_order_key": "|".join(map(str, _session_sort_key(session_id))),
                }
            )
            seen.add(session_id)

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out = out.sort_values(
        by=["cohort_family", "memory_stage", "animal", "day_index", "session_id"],
        key=lambda col: col.map(_stage_rank) if col.name == "memory_stage" else col,
    ).reset_index(drop=True)
    return out


def build_cross_session_pair_manifest(
    *,
    quartets: list[QuartetSpec] | None = None,
    parity_meta: str | Path | pd.DataFrame | None = None,
) -> pd.DataFrame:
    meta = _load_parity_meta(get_parity_metafile() if parity_meta is None else parity_meta)
    graph = _build_cimap_graph(meta)
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, str, str]] = set()

    for spec in quartets or default_expanded_cohort_specs():
        animal = str(spec.animal)
        naive_d1 = str(spec.naive_day1).strip()
        naive_d2 = str(spec.naive_day2).strip()
        gap_d1 = str(spec.gap_day1).strip()
        gap_d2 = str(spec.gap_day2).strip()
        stage = str(spec.gap_label or "naive")
        chain_naive = _find_cimap_chain(graph, naive_d1, naive_d2)
        pair_defs = [
            ("naive_day1_vs_naive_day2", naive_d1, naive_d2, "Rewarded Day1", "Rewarded Day2", "naive", chain_naive),
        ]
        if gap_d1 and gap_d2:
            chain_ltm = _find_cimap_chain(graph, gap_d1, gap_d2)
            pair_defs.append(("ltm_day1_vs_ltm_day2", gap_d1, gap_d2, "LTM Day1", "LTM Day2", stage, chain_ltm))
            chain_d1 = _find_cimap_chain(graph, naive_d1, gap_d1)
            pair_defs.append(("naive_day1_vs_ltm_day1", naive_d1, gap_d1, "Rewarded Day1", "LTM Day1", stage, chain_d1))
            chain_d2 = _find_cimap_chain(graph, naive_d2, gap_d2)
            pair_defs.append(("naive_day2_vs_ltm_day2", naive_d2, gap_d2, "Rewarded Day2", "LTM Day2", stage, chain_d2))

        for pair_family, session_a, session_b, group_a, group_b, memory_stage, cimap_chain in pair_defs:
            key = (animal, pair_family, session_a, session_b, memory_stage)
            if key in seen:
                continue
            seen.add(key)
            cimap_validated, cimap_validation_error = _validate_cimap_chain(cimap_chain)
            matching_mode = (
                "cimap_direct"
                if cimap_validated and len(cimap_chain) == 1
                else ("cimap_composed" if cimap_validated and len(cimap_chain) > 1 else "unavailable")
            )
            rows.append(
                {
                    "animal": animal,
                    "pair_id": f"{session_a}__{session_b}",
                    "pair_family": str(pair_family),
                    "session_a": str(session_a),
                    "session_b": str(session_b),
                    "session_a_group": str(group_a),
                    "session_b_group": str(group_b),
                    "memory_stage": str(memory_stage),
                    "reward_context_a": _reward_context_for_session(spec, session_a, group_a),
                    "reward_context_b": _reward_context_for_session(spec, session_b, group_b),
                    "cimap_path": ";".join(str(v) for v in cimap_chain),
                    "cimap_source": "decoding_metafile_chain" if cimap_chain else "",
                    "matching_mode": str(matching_mode),
                    "cimap_validated": bool(cimap_validated),
                    "cimap_validation_error": str(cimap_validation_error),
                    "pair_available": bool(cimap_validated),
                    "pair_inclusion_rule": "same_animal_only",
                    "pair_order_key": "|".join([str(animal), str(_stage_rank(memory_stage)), str(pair_family), str(session_a), str(session_b)]),
                }
            )

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out = out.sort_values(by=["animal", "memory_stage", "pair_family", "session_a", "session_b"]).reset_index(drop=True)
    return out


def _load_session_cache_entry(
    session_id: str,
    *,
    is_unrewarded: bool,
    ma_obj: Any,
    config: SpatialInfoMemoryConfig,
    cache: dict[tuple[str, bool, str], tuple[Any, ...]],
) -> tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]]:
    key = (str(session_id), bool(is_unrewarded), str(config.mode_filter))
    if key not in cache:
        cache[key] = load_single_session_subset(
            str(session_id),
            is_unrewarded=bool(is_unrewarded),
            ma_obj=ma_obj,
            behav_wd=str(config.behav_wd),
            neural_wd=str(config.neural_wd),
            mode_filter=str(config.mode_filter),
        )
    sp_use, rc_use, df_use, pos_use, meta = cache[key]
    return (
        np.asarray(sp_use, dtype=float),
        np.asarray(rc_use, dtype=float),
        df_use.copy(),
        np.asarray(pos_use, dtype=float),
        dict(meta),
    )


def _single_session_window_result(
    sp_use: np.ndarray,
    rc_use: np.ndarray,
    df_use: pd.DataFrame,
    pos_use: np.ndarray,
    *,
    config: SpatialInfoMemoryConfig,
) -> dict[str, Any]:
    kwargs = _window_kwargs(config)
    out = pivot_window_spatial_information_fast(
        sp_use,
        rc_use,
        df_use,
        pos_use,
        n_bins_x=int(config.n_bins_x),
        n_bins_y=int(config.n_bins_y),
        dt=float(config.dt),
        time_window=0,
        win_len_sec=float(kwargs["win_len_sec"]),
        pivot_step_sec=float(kwargs["pivot_step_sec"]),
        pivot_time_axis=str(kwargs["pivot_time_axis"]),
        prior_mode=str(config.prior_mode),
        min_time_per_bin_sec=float(config.min_time_per_bin_sec),
        min_spikes_per_min=(None if float(config.min_spikes_per_min) <= 0 else float(config.min_spikes_per_min)),
        rate_source=str(config.rate_source),
        min_time_policy=str(config.min_time_policy),
        support_mode=str(config.support_mode),
        common_support_frac=float(config.common_support_frac),
        maze_id=int(config.maze_id),
    )
    return _map_step_window_to_maze_time(out, df_use) if str(config.window_style) == "step" else _normalize_relative_time(out)


def run_single_session_spatial_information(
    manifest: pd.DataFrame,
    *,
    config: SpatialInfoMemoryConfig | None = None,
) -> dict[str, pd.DataFrame]:
    cfg = config or SpatialInfoMemoryConfig()
    ma_obj = NewMaze(int(cfg.maze_id))
    cache: dict[tuple[str, bool, str], tuple[Any, ...]] = {}
    summary_rows: list[dict[str, Any]] = []
    curve_rows: list[dict[str, Any]] = []
    neuron_rows: list[dict[str, Any]] = []
    window_metric_rows: list[dict[str, Any]] = []
    alignment_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    group_curves: dict[str, list[dict[str, Any]]] = {}

    for _, row in manifest.iterrows():
        session_id = str(row["session_id"])
        cohort_group = str(row["cohort_group"])
        is_unrewarded = str(row.get("reward_context", "")) == "unrewarded"
        group_curves.setdefault(cohort_group, [])
        try:
            sp_use, rc_use, df_use, pos_use, load_meta = _load_session_cache_entry(
                session_id,
                is_unrewarded=is_unrewarded,
                ma_obj=ma_obj,
                config=cfg,
                cache=cache,
            )
            win = _single_session_window_result(sp_use, rc_use, df_use, pos_use, config=cfg)
            si_mat = np.asarray(win.get("si_matrix", np.zeros((0, 0))), dtype=float)
            pivot_times = pd.to_numeric(np.asarray(win.get("pivot_times", np.array([]))), errors="coerce").astype(float)
            si_mean = pd.to_numeric(np.asarray(win.get("si_mean", np.array([]))), errors="coerce").astype(float)
            si_std = pd.to_numeric(np.asarray(win.get("si_std", np.array([]))), errors="coerce").astype(float)
            kept_ids = np.asarray(win.get("kept_neuron_ids", np.array([], dtype=int)), dtype=int)
            metrics = win.get("window_metrics", pd.DataFrame()).copy()
            if not isinstance(metrics, pd.DataFrame):
                metrics = pd.DataFrame(metrics)

            report = AlignmentReport(
                session_matching_source="single_session_manifest",
                included_sessions=[session_id],
                excluded_sessions=[],
                timebase="maze",
                continuity_assumptions=str(load_meta.get("continuity_assumption", "")),
            )
            validate_alignment(report)
            alignment_rows.append(
                {
                    "session_id": session_id,
                    "animal": str(row.get("animal", "")),
                    "cohort_group": cohort_group,
                    "included_sessions": ";".join(report.included_sessions),
                    "excluded_sessions": ";".join(report.excluded_sessions),
                    "timebase": report.timebase,
                    "continuity_assumptions": report.continuity_assumptions,
                }
            )
            summary_rows.append(
                {
                    **row.to_dict(),
                    "n_rows_after_mode_filter": int(len(df_use)),
                    "n_kept_neurons": int(len(kept_ids)),
                    "n_windows": int(len(pivot_times)),
                    "si_mean_global": float(np.nanmean(si_mean)) if si_mean.size else np.nan,
                    "finite_window_fraction": float(np.isfinite(si_mean).mean()) if si_mean.size else np.nan,
                    "label_source": str(win.get("meta", {}).get("label_source", "")),
                    "support_mode": str(win.get("meta", {}).get("support_mode", "")),
                    "common_support_bin_count": win.get("meta", {}).get("common_support_bin_count"),
                    "equalized_bin_count": win.get("meta", {}).get("equalized_bin_count"),
                    "timebase": str(win.get("meta", {}).get("timebase", "")),
                }
            )

            n_curve = min(len(pivot_times), len(si_mean))
            for idx in range(n_curve):
                curve_rows.append(
                    {
                        **row.to_dict(),
                        "window_index": int(idx),
                        "maze_time_rel_sec": float(pivot_times[idx]) if np.isfinite(pivot_times[idx]) else np.nan,
                        "maze_time_rel_min": float(pivot_times[idx] / 60.0) if np.isfinite(pivot_times[idx]) else np.nan,
                        "mean_si": float(si_mean[idx]) if np.isfinite(si_mean[idx]) else np.nan,
                        "std_si": float(si_std[idx]) if idx < len(si_std) and np.isfinite(si_std[idx]) else np.nan,
                    }
                )
            for wi, t_val in enumerate(pivot_times):
                if wi >= si_mat.shape[0]:
                    break
                for ni, neuron_id in enumerate(kept_ids):
                    if ni >= si_mat.shape[1]:
                        break
                    neuron_rows.append(
                        {
                            **row.to_dict(),
                            "window_index": int(wi),
                            "maze_time_rel_sec": float(t_val) if np.isfinite(t_val) else np.nan,
                            "maze_time_rel_min": float(t_val / 60.0) if np.isfinite(t_val) else np.nan,
                            "neuron_id": int(neuron_id),
                            "si_value": float(si_mat[wi, ni]) if np.isfinite(si_mat[wi, ni]) else np.nan,
                            "passes_rate_gate": True,
                        }
                    )
            if not metrics.empty:
                metrics = metrics.copy()
                metrics.insert(0, "session_id", session_id)
                metrics.insert(1, "animal", str(row.get("animal", "")))
                metrics.insert(2, "cohort_group", cohort_group)
                window_metric_rows.extend(metrics.to_dict(orient="records"))

            finite = np.isfinite(pivot_times) & np.isfinite(si_mean)
            if np.any(finite):
                group_curves[cohort_group].append(
                    {
                        "session_id": session_id,
                        "maze_time_rel": pivot_times[finite],
                        "si_mean": si_mean[finite],
                    }
                )
        except Exception as exc:
            failures.append({**row.to_dict(), "error": str(exc)})
            alignment_rows.append(
                {
                    "session_id": session_id,
                    "animal": str(row.get("animal", "")),
                    "cohort_group": cohort_group,
                    "included_sessions": "",
                    "excluded_sessions": session_id,
                    "timebase": "maze",
                    "continuity_assumptions": str(exc),
                }
            )

    group_interp = interpolate_then_average_group_curves(
        group_curves,
        grid_dt_sec=float(cfg.step_steps) * float(cfg.dt) if str(cfg.window_style) == "step" else float(cfg.step_sec),
        min_support_count=int(cfg.group_min_support_count),
    )
    group_curves_df = group_interp["curves_df"].copy()
    if not group_curves_df.empty:
        group_curves_df = group_curves_df.rename(columns={"group": "cohort_group"})
    group_summary_df = group_interp["summary_df"].copy()
    if not group_summary_df.empty:
        group_summary_df = group_summary_df.rename(columns={"group": "cohort_group"})

    return {
        "single_session_summary": pd.DataFrame(summary_rows),
        "single_session_curves": pd.DataFrame(curve_rows),
        "single_session_neuron_curves": pd.DataFrame(neuron_rows),
        "single_session_window_metrics": pd.DataFrame(window_metric_rows),
        "single_session_failures": pd.DataFrame(failures),
        "single_session_group_curves": group_curves_df,
        "single_session_group_summary": group_summary_df,
        "single_session_alignment_report": pd.DataFrame(alignment_rows),
    }


def _resolve_pair_matching(pair_row: pd.Series, n_train: int, n_test: int) -> tuple[np.ndarray, np.ndarray]:
    matching_mode = str(pair_row.get("matching_mode", ""))
    if matching_mode == "index_identity":
        session_a = str(pair_row.get("session_a", ""))
        session_b = str(pair_row.get("session_b", ""))
        smoke_value = pair_row.get("identity_match_smoke", False)
        smoke_only = smoke_value is True or str(smoke_value).strip().lower() in {
            "1",
            "true",
            "yes",
        }
        if session_a != session_b and not smoke_only:
            raise ValueError(
                "index_identity is not valid for different biological sessions; "
                "provide a verified CIMap/chain or set identity_match_smoke=True for an explicitly labeled smoke test"
            )
        n = int(min(n_train, n_test))
        ids = np.arange(n, dtype=int)
        return ids.copy(), ids.copy()
    cimap_text = str(pair_row.get("cimap_path", "")).strip()
    if not cimap_text:
        return np.asarray([], dtype=int), np.asarray([], dtype=int)
    parts = [Path(part.strip()) for part in cimap_text.split(";") if part.strip()]
    compose = len(parts) > 1
    train_ids, test_ids = load_cimap_pairs(parts if compose else parts[0], split=True, compose=compose)
    train_ids = np.asarray(train_ids, dtype=int)
    test_ids = np.asarray(test_ids, dtype=int)
    if (
        train_ids.size == 0
        or train_ids.size != test_ids.size
        or np.any(train_ids < 0)
        or np.any(test_ids < 0)
        or np.any(train_ids >= int(n_train))
        or np.any(test_ids >= int(n_test))
    ):
        raise ValueError("CIMap neuron IDs are empty, unequal, or out of range for the loaded sessions")
    return train_ids, test_ids


def _pair_window_result(
    train_payload: tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]],
    test_payload: tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]],
    *,
    train_ids: np.ndarray,
    test_ids: np.ndarray,
    config: SpatialInfoMemoryConfig,
) -> dict[str, Any]:
    sp_tr, rc_tr, df_tr, pos_tr, _ = train_payload
    sp_te, rc_te, df_te, pos_te, _ = test_payload
    kwargs = _window_kwargs(config)
    paired = paired_pivot_window_spatial_information_fast(
        sp_tr,
        rc_tr,
        df_tr,
        pos_tr,
        sp_te,
        rc_te,
        df_te,
        pos_te,
        cimap=None,
        train_ids=np.asarray(train_ids, dtype=int),
        test_ids=np.asarray(test_ids, dtype=int),
        n_bins_x=int(config.n_bins_x),
        n_bins_y=int(config.n_bins_y),
        dt=float(config.dt),
        time_window=0,
        win_len_sec=float(kwargs["win_len_sec"]),
        pivot_step_sec=float(kwargs["pivot_step_sec"]),
        pivot_time_axis=str(kwargs["pivot_time_axis"]),
        min_time_per_bin_sec=float(config.min_time_per_bin_sec),
        min_spikes_per_min=(None if float(config.min_spikes_per_min) <= 0 else float(config.min_spikes_per_min)),
        rate_source=str(config.rate_source),
        prior_mode=str(config.prior_mode),
        min_time_policy=str(config.min_time_policy),
        maze_id=int(config.maze_id),
        pair_support_mode=str(config.pair_support_mode),
    )
    train_out = paired["train_window_result"]
    test_out = paired["test_window_result"]
    if str(config.window_style) == "step":
        train_out = _map_step_window_to_maze_time(train_out, df_tr)
        test_out = _map_step_window_to_maze_time(test_out, df_te)
    else:
        train_out = _normalize_relative_time(train_out)
        test_out = _normalize_relative_time(test_out)
    paired["train_window_result"] = train_out
    paired["test_window_result"] = test_out
    return paired


def _pair_side_curve_rows(pair_row: pd.Series, side_label: str, win: dict[str, Any]) -> list[dict[str, Any]]:
    times = pd.to_numeric(np.asarray(win.get("pivot_times", np.array([]))), errors="coerce").astype(float)
    means = pd.to_numeric(np.asarray(win.get("si_mean", np.array([]))), errors="coerce").astype(float)
    stds = pd.to_numeric(np.asarray(win.get("si_std", np.array([]))), errors="coerce").astype(float)
    rows: list[dict[str, Any]] = []
    for idx in range(min(len(times), len(means))):
        rows.append(
            {
                **pair_row.to_dict(),
                "side": str(side_label),
                "window_index": int(idx),
                "maze_time_rel_sec": float(times[idx]) if np.isfinite(times[idx]) else np.nan,
                "maze_time_rel_min": float(times[idx] / 60.0) if np.isfinite(times[idx]) else np.nan,
                "mean_si": float(means[idx]) if np.isfinite(means[idx]) else np.nan,
                "std_si": float(stds[idx]) if idx < len(stds) and np.isfinite(stds[idx]) else np.nan,
            }
        )
    return rows


def _pair_window_metric_rows(pair_row: pd.Series, paired: dict[str, Any]) -> list[dict[str, Any]]:
    train_metrics = paired["train_window_result"].get("window_metrics", pd.DataFrame()).copy()
    test_metrics = paired["test_window_result"].get("window_metrics", pd.DataFrame()).copy()
    if not isinstance(train_metrics, pd.DataFrame):
        train_metrics = pd.DataFrame(train_metrics)
    if not isinstance(test_metrics, pd.DataFrame):
        test_metrics = pd.DataFrame(test_metrics)
    rows: list[dict[str, Any]] = []
    for idx in range(int(min(len(train_metrics), len(test_metrics)))):
        row = {**pair_row.to_dict(), "window_index": int(idx)}
        for key, value in train_metrics.iloc[idx].to_dict().items():
            row[f"session_a_{key}"] = value
        for key, value in test_metrics.iloc[idx].to_dict().items():
            row[f"session_b_{key}"] = value
        rows.append(row)
    return rows


def _pair_neuron_rows(
    pair_row: pd.Series,
    paired: dict[str, Any],
    *,
    train_key: str = "train_window_result",
    test_key: str = "test_window_result",
) -> list[dict[str, Any]]:
    train_win = paired[train_key]
    test_win = paired[test_key]
    train_si = np.asarray(train_win.get("si_matrix", np.zeros((0, 0))), dtype=float)
    test_si = np.asarray(test_win.get("si_matrix", np.zeros((0, 0))), dtype=float)
    train_times = pd.to_numeric(np.asarray(train_win.get("pivot_times", np.array([]))), errors="coerce").astype(float)
    test_times = pd.to_numeric(np.asarray(test_win.get("pivot_times", np.array([]))), errors="coerce").astype(float)
    train_ids = np.asarray(paired.get("train_ids", np.array([], dtype=int)), dtype=int)
    test_ids = np.asarray(paired.get("test_ids", np.array([], dtype=int)), dtype=int)
    n_windows = min(train_si.shape[0], test_si.shape[0], len(train_times), len(test_times))
    n_neurons = min(
        train_si.shape[1] if train_si.ndim == 2 else 0,
        test_si.shape[1] if test_si.ndim == 2 else 0,
        len(train_ids),
        len(test_ids),
    )
    rows: list[dict[str, Any]] = []
    for wi in range(int(n_windows)):
        for ni in range(int(n_neurons)):
            left_val = train_si[wi, ni]
            right_val = test_si[wi, ni]
            rows.append(
                {
                    **pair_row.to_dict(),
                    "window_index": int(wi),
                    "maze_time_rel_sec_session_a": float(train_times[wi]) if np.isfinite(train_times[wi]) else np.nan,
                    "maze_time_rel_sec_session_b": float(test_times[wi]) if np.isfinite(test_times[wi]) else np.nan,
                    "maze_time_rel_min_session_a": float(train_times[wi] / 60.0) if np.isfinite(train_times[wi]) else np.nan,
                    "maze_time_rel_min_session_b": float(test_times[wi] / 60.0) if np.isfinite(test_times[wi]) else np.nan,
                    "matched_neuron_rank": int(ni),
                    "train_neuron_id": int(train_ids[ni]),
                    "test_neuron_id": int(test_ids[ni]),
                    "si_session_a": float(left_val) if np.isfinite(left_val) else np.nan,
                    "si_session_b": float(right_val) if np.isfinite(right_val) else np.nan,
                    "delta_b_minus_a": float(right_val - left_val) if np.isfinite(left_val) and np.isfinite(right_val) else np.nan,
                }
            )
    return rows


def _pair_summary_row(
    pair_row: pd.Series,
    paired: dict[str, Any],
    *,
    train_key: str = "train_window_result",
    test_key: str = "test_window_result",
    matched_neuron_count_before_gate: int | None = None,
) -> dict[str, Any]:
    train_win = paired[train_key]
    test_win = paired[test_key]
    train_mean = pd.to_numeric(np.asarray(train_win.get("si_mean", np.array([]))), errors="coerce").astype(float)
    test_mean = pd.to_numeric(np.asarray(test_win.get("si_mean", np.array([]))), errors="coerce").astype(float)
    n_curve = int(min(len(train_mean), len(test_mean)))
    delta = test_mean[:n_curve] - train_mean[:n_curve] if n_curve else np.array([], dtype=float)
    return {
        **pair_row.to_dict(),
        "paired_window_count": int(paired.get("paired_window_count", 0)),
        "matched_neuron_count_before_gate": (
            int(matched_neuron_count_before_gate)
            if matched_neuron_count_before_gate is not None
            else int(len(np.asarray(paired.get("train_ids", np.array([])), dtype=int)))
        ),
        "matched_neuron_count_after_gate": int(len(np.asarray(paired.get("train_ids", np.array([])), dtype=int))),
        "pair_equalized_bin_count": paired.get("pair_equalized_bin_count"),
        "median_si_session_a": float(np.nanmedian(train_mean)) if train_mean.size else np.nan,
        "median_si_session_b": float(np.nanmedian(test_mean)) if test_mean.size else np.nan,
        "median_delta_b_minus_a": float(np.nanmedian(delta)) if delta.size else np.nan,
    }


def _append_family_curve(
    family_curves: dict[str, list[dict[str, Any]]],
    *,
    family: str,
    side: str,
    session_id: str,
    win: dict[str, Any],
) -> None:
    family_curves.setdefault(f"{family} :: {side}", [])
    pivot_times = pd.to_numeric(np.asarray(win.get("pivot_times", np.array([]))), errors="coerce").astype(float)
    si_mean = pd.to_numeric(np.asarray(win.get("si_mean", np.array([]))), errors="coerce").astype(float)
    finite = np.isfinite(pivot_times) & np.isfinite(si_mean)
    if np.any(finite):
        family_curves[f"{family} :: {side}"].append(
            {
                "session_id": session_id,
                "maze_time_rel": pivot_times[finite],
                "si_mean": si_mean[finite],
            }
        )


def run_cross_session_spatial_information(
    pair_manifest: pd.DataFrame,
    *,
    config: SpatialInfoMemoryConfig | None = None,
) -> dict[str, pd.DataFrame]:
    cfg = config or SpatialInfoMemoryConfig()
    ma_obj = NewMaze(int(cfg.maze_id))
    cache: dict[tuple[str, bool, str], tuple[Any, ...]] = {}
    summary_rows: list[dict[str, Any]] = []
    curve_rows: list[dict[str, Any]] = []
    neuron_rows: list[dict[str, Any]] = []
    summary_rows_common_avg: list[dict[str, Any]] = []
    curve_rows_common_avg: list[dict[str, Any]] = []
    neuron_rows_common_avg: list[dict[str, Any]] = []
    summary_rows_uniform: list[dict[str, Any]] = []
    curve_rows_uniform: list[dict[str, Any]] = []
    neuron_rows_uniform: list[dict[str, Any]] = []
    window_metric_rows: list[dict[str, Any]] = []
    support_audit_rows: list[dict[str, Any]] = []
    prior_diagnostic_rows: list[dict[str, Any]] = []
    alignment_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    family_curves: dict[str, list[dict[str, Any]]] = {}
    family_curves_common_avg: dict[str, list[dict[str, Any]]] = {}
    family_curves_uniform: dict[str, list[dict[str, Any]]] = {}

    runnable = pair_manifest.loc[pair_manifest["pair_available"].astype(bool)].reset_index(drop=True)
    for _, row in runnable.iterrows():
        pair_row = row.copy()
        s_a = str(pair_row["session_a"])
        s_b = str(pair_row["session_b"])
        try:
            context_a = str(pair_row.get("reward_context_a", "")).strip().lower()
            context_b = str(pair_row.get("reward_context_b", "")).strip().lower()
            if context_a not in {"rewarded", "unrewarded"} or context_b not in {"rewarded", "unrewarded"}:
                raise ValueError("Pair manifest requires reward_context_a/reward_context_b as rewarded or unrewarded")
            train_payload = _load_session_cache_entry(
                s_a,
                is_unrewarded=context_a == "unrewarded",
                ma_obj=ma_obj,
                config=cfg,
                cache=cache,
            )
            test_payload = _load_session_cache_entry(
                s_b,
                is_unrewarded=context_b == "unrewarded",
                ma_obj=ma_obj,
                config=cfg,
                cache=cache,
            )
            n_train = int(np.asarray(train_payload[0]).shape[1])
            n_test = int(np.asarray(test_payload[0]).shape[1])
            train_ids, test_ids = _resolve_pair_matching(pair_row, n_train=n_train, n_test=n_test)
            if train_ids.size == 0 or test_ids.size == 0:
                raise RuntimeError("No matched neurons available for pair.")

            matched_neuron_count_before_gate = int(len(train_ids))
            paired = _pair_window_result(train_payload, test_payload, train_ids=train_ids, test_ids=test_ids, config=cfg)
            report = AlignmentReport(
                session_matching_source="cross_session_pair_manifest",
                included_sessions=[s_a, s_b],
                excluded_sessions=[],
                timebase="maze",
                continuity_assumptions="selected_df is speed-thresholded and may be discontinuous",
            )
            validate_alignment(report)
            alignment_rows.append(
                {
                    "pair_id": str(pair_row["pair_id"]),
                    "pair_family": str(pair_row["pair_family"]),
                    "animal": str(pair_row["animal"]),
                    "included_sessions": ";".join(report.included_sessions),
                    "excluded_sessions": ";".join(report.excluded_sessions),
                    "timebase": report.timebase,
                    "continuity_assumptions": report.continuity_assumptions,
                    "matching_mode": str(pair_row["matching_mode"]),
                }
            )

            summary_rows.append(
                _pair_summary_row(
                    pair_row,
                    paired,
                    matched_neuron_count_before_gate=matched_neuron_count_before_gate,
                )
            )
            summary_rows_common_avg.append(
                _pair_summary_row(
                    pair_row,
                    paired,
                    train_key="train_window_result_common_avg_prior",
                    test_key="test_window_result_common_avg_prior",
                    matched_neuron_count_before_gate=matched_neuron_count_before_gate,
                )
            )
            summary_rows_uniform.append(
                _pair_summary_row(
                    pair_row,
                    paired,
                    train_key="train_window_result_uniform_prior",
                    test_key="test_window_result_uniform_prior",
                    matched_neuron_count_before_gate=matched_neuron_count_before_gate,
                )
            )
            train_win = paired["train_window_result"]
            test_win = paired["test_window_result"]
            curve_rows.extend(_pair_side_curve_rows(pair_row, "session_a", train_win))
            curve_rows.extend(_pair_side_curve_rows(pair_row, "session_b", test_win))
            neuron_rows.extend(_pair_neuron_rows(pair_row, paired))
            curve_rows_common_avg.extend(
                _pair_side_curve_rows(pair_row, "session_a", paired["train_window_result_common_avg_prior"])
            )
            curve_rows_common_avg.extend(
                _pair_side_curve_rows(pair_row, "session_b", paired["test_window_result_common_avg_prior"])
            )
            neuron_rows_common_avg.extend(
                _pair_neuron_rows(
                    pair_row,
                    paired,
                    train_key="train_window_result_common_avg_prior",
                    test_key="test_window_result_common_avg_prior",
                )
            )
            curve_rows_uniform.extend(
                _pair_side_curve_rows(pair_row, "session_a", paired["train_window_result_uniform_prior"])
            )
            curve_rows_uniform.extend(
                _pair_side_curve_rows(pair_row, "session_b", paired["test_window_result_uniform_prior"])
            )
            neuron_rows_uniform.extend(
                _pair_neuron_rows(
                    pair_row,
                    paired,
                    train_key="train_window_result_uniform_prior",
                    test_key="test_window_result_uniform_prior",
                )
            )

            pair_window_rows = _pair_window_metric_rows(pair_row, paired)
            window_metric_rows.extend(pair_window_rows)
            for metric_row in pair_window_rows:
                support_audit_rows.append(
                    {
                        "pair_id": metric_row["pair_id"],
                        "pair_family": metric_row["pair_family"],
                        "animal": metric_row["animal"],
                        "window_index": metric_row["window_index"],
                        "session_a_valid_bin_count": metric_row.get("session_a_valid_bin_count_after_min_occ"),
                        "session_b_valid_bin_count": metric_row.get("session_b_valid_bin_count_after_min_occ"),
                        "pair_common_valid_bin_count": metric_row.get("session_a_pair_common_valid_bin_count"),
                        "pair_support_bin_count": metric_row.get("session_a_pair_support_bin_count"),
                        "pair_fraction_of_common_valid": metric_row.get("session_a_pair_fraction_of_common_valid"),
                        "pair_fraction_of_session_a_valid": metric_row.get("session_a_pair_support_fraction_of_session_valid"),
                        "pair_fraction_of_session_b_valid": metric_row.get("session_b_pair_support_fraction_of_session_valid"),
                        "paired_window_count_total": int(paired.get("paired_window_count", 0)),
                    }
                )
                prior_diagnostic_rows.append(
                    {
                        "pair_id": metric_row["pair_id"],
                        "pair_family": metric_row["pair_family"],
                        "animal": metric_row["animal"],
                        "window_index": metric_row["window_index"],
                        "session_a_valid_bin_count": metric_row.get("session_a_valid_bin_count_after_min_occ"),
                        "session_b_valid_bin_count": metric_row.get("session_b_valid_bin_count_after_min_occ"),
                        "pair_common_valid_bin_count": metric_row.get("session_a_pair_common_valid_bin_count"),
                        "pair_support_bin_count": metric_row.get("session_a_pair_support_bin_count"),
                        "pair_fraction_of_session_a_valid": metric_row.get("session_a_pair_support_fraction_of_session_valid"),
                        "pair_fraction_of_session_b_valid": metric_row.get("session_b_pair_support_fraction_of_session_valid"),
                        "pair_prior_js_divergence": metric_row.get("session_a_pair_prior_js_divergence"),
                        "pair_prior_total_variation": metric_row.get("session_a_pair_prior_total_variation"),
                    }
                )

            _append_family_curve(
                family_curves,
                family=str(pair_row["pair_family"]),
                side="session_a",
                session_id=f"{pair_row['pair_id']}::session_a",
                win=train_win,
            )
            _append_family_curve(
                family_curves,
                family=str(pair_row["pair_family"]),
                side="session_b",
                session_id=f"{pair_row['pair_id']}::session_b",
                win=test_win,
            )
            _append_family_curve(
                family_curves_common_avg,
                family=str(pair_row["pair_family"]),
                side="session_a",
                session_id=f"{pair_row['pair_id']}::session_a",
                win=paired["train_window_result_common_avg_prior"],
            )
            _append_family_curve(
                family_curves_common_avg,
                family=str(pair_row["pair_family"]),
                side="session_b",
                session_id=f"{pair_row['pair_id']}::session_b",
                win=paired["test_window_result_common_avg_prior"],
            )
            _append_family_curve(
                family_curves_uniform,
                family=str(pair_row["pair_family"]),
                side="session_a",
                session_id=f"{pair_row['pair_id']}::session_a",
                win=paired["train_window_result_uniform_prior"],
            )
            _append_family_curve(
                family_curves_uniform,
                family=str(pair_row["pair_family"]),
                side="session_b",
                session_id=f"{pair_row['pair_id']}::session_b",
                win=paired["test_window_result_uniform_prior"],
            )
        except Exception as exc:
            failures.append({**pair_row.to_dict(), "error": str(exc)})
            alignment_rows.append(
                {
                    "pair_id": str(pair_row["pair_id"]),
                    "pair_family": str(pair_row["pair_family"]),
                    "animal": str(pair_row["animal"]),
                    "included_sessions": "",
                    "excluded_sessions": f"{s_a};{s_b}",
                    "timebase": "maze",
                    "continuity_assumptions": str(exc),
                    "matching_mode": str(pair_row["matching_mode"]),
                }
            )

    def _interp_family_tables(curve_dict: dict[str, list[dict[str, Any]]]) -> tuple[pd.DataFrame, pd.DataFrame]:
        interp = interpolate_then_average_group_curves(
            curve_dict,
            grid_dt_sec=float(cfg.step_steps) * float(cfg.dt) if str(cfg.window_style) == "step" else float(cfg.step_sec),
            min_support_count=int(cfg.group_min_support_count),
        )
        curves_df = interp["curves_df"].copy()
        if not curves_df.empty:
            parts = curves_df["group"].astype(str).str.split(" :: ", n=1, expand=True)
            curves_df["pair_family"] = parts[0]
            curves_df["side"] = parts[1]
        summary_df = interp["summary_df"].copy()
        if not summary_df.empty:
            parts = summary_df["group"].astype(str).str.split(" :: ", n=1, expand=True)
            summary_df["pair_family"] = parts[0]
            summary_df["side"] = parts[1]
        return curves_df, summary_df

    family_curves_df, family_summary_df = _interp_family_tables(family_curves)
    family_curves_common_avg_df, family_summary_common_avg_df = _interp_family_tables(family_curves_common_avg)
    family_curves_uniform_df, family_summary_uniform_df = _interp_family_tables(family_curves_uniform)

    return {
        "cross_session_pair_summary": pd.DataFrame(summary_rows),
        "cross_session_pair_curves": pd.DataFrame(curve_rows),
        "cross_session_pair_neuron_curves": pd.DataFrame(neuron_rows),
        "cross_session_pair_summary_common_avg_prior": pd.DataFrame(summary_rows_common_avg),
        "cross_session_pair_curves_common_avg_prior": pd.DataFrame(curve_rows_common_avg),
        "cross_session_pair_neuron_curves_common_avg_prior": pd.DataFrame(neuron_rows_common_avg),
        "cross_session_pair_summary_uniform_prior": pd.DataFrame(summary_rows_uniform),
        "cross_session_pair_curves_uniform_prior": pd.DataFrame(curve_rows_uniform),
        "cross_session_pair_neuron_curves_uniform_prior": pd.DataFrame(neuron_rows_uniform),
        "cross_session_pair_window_metrics": pd.DataFrame(window_metric_rows),
        "cross_session_pair_support_audit": pd.DataFrame(support_audit_rows),
        "cross_session_pair_prior_diagnostics": pd.DataFrame(prior_diagnostic_rows),
        "cross_session_pair_family_curves": family_curves_df,
        "cross_session_pair_family_summary": family_summary_df,
        "cross_session_pair_family_curves_common_avg_prior": family_curves_common_avg_df,
        "cross_session_pair_family_summary_common_avg_prior": family_summary_common_avg_df,
        "cross_session_pair_family_curves_uniform_prior": family_curves_uniform_df,
        "cross_session_pair_family_summary_uniform_prior": family_summary_uniform_df,
        "cross_session_failures": pd.DataFrame(failures),
        "cross_session_alignment_report": pd.DataFrame(alignment_rows),
    }


def _split_payload_interleaved(
    payload: tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]],
) -> tuple[
    tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]],
    tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]],
]:
    sp_use, rc_use, df_use, pos_use, meta = payload
    idx = np.arange(int(len(df_use)), dtype=int)
    mask_a = (idx % 2) == 0
    mask_b = ~mask_a
    if int(np.count_nonzero(mask_a)) == 0 or int(np.count_nonzero(mask_b)) == 0:
        raise RuntimeError("Split-half baseline requires at least two selected rows.")

    def _subset(mask: np.ndarray, label: str) -> tuple[np.ndarray, np.ndarray, pd.DataFrame, np.ndarray, dict[str, Any]]:
        out_meta = dict(meta)
        out_meta["split_half_label"] = label
        out_meta["split_half_strategy"] = "interleaved_even_odd"
        return (
            np.asarray(sp_use[mask], dtype=float),
            np.asarray(rc_use[mask], dtype=float),
            df_use.iloc[np.flatnonzero(mask)].reset_index(drop=True).copy(),
            np.asarray(pos_use[mask], dtype=float),
            out_meta,
        )

    return _subset(mask_a, "split_a"), _subset(mask_b, "split_b")


def run_single_session_split_half_baseline(
    manifest: pd.DataFrame,
    *,
    config: SpatialInfoMemoryConfig | None = None,
) -> dict[str, pd.DataFrame]:
    cfg = config or SpatialInfoMemoryConfig()
    ma_obj = NewMaze(int(cfg.maze_id))
    cache: dict[tuple[str, bool, str], tuple[Any, ...]] = {}
    summary_rows: list[dict[str, Any]] = []
    curve_rows: list[dict[str, Any]] = []
    neuron_rows: list[dict[str, Any]] = []
    window_metric_rows: list[dict[str, Any]] = []
    support_audit_rows: list[dict[str, Any]] = []
    prior_diagnostic_rows: list[dict[str, Any]] = []
    alignment_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    group_curves: dict[str, list[dict[str, Any]]] = {}

    for _, row in manifest.iterrows():
        session_id = str(row["session_id"])
        cohort_group = str(row["cohort_group"])
        is_unrewarded = str(row.get("reward_context", "")) == "unrewarded"
        group_curves.setdefault(f"{cohort_group} :: split_a", [])
        group_curves.setdefault(f"{cohort_group} :: split_b", [])
        try:
            payload = _load_session_cache_entry(
                session_id,
                is_unrewarded=is_unrewarded,
                ma_obj=ma_obj,
                config=cfg,
                cache=cache,
            )
            split_a_payload, split_b_payload = _split_payload_interleaved(payload)
            n_neurons = int(np.asarray(split_a_payload[0]).shape[1])
            pair_row = pd.Series(
                {
                    **row.to_dict(),
                    "pair_id": f"{session_id}::split_half",
                    "pair_family": cohort_group,
                    "session_a": f"{session_id}::split_a",
                    "session_b": f"{session_id}::split_b",
                    "session_a_group": cohort_group,
                    "session_b_group": cohort_group,
                    "matching_mode": "index_identity",
                    "pair_available": True,
                    "pair_inclusion_rule": "same_session_split_half",
                    "pair_order_key": str(row.get("session_order_key", session_id)),
                    "split_strategy": "interleaved_even_odd",
                }
            )
            ids = np.arange(n_neurons, dtype=int)
            paired = _pair_window_result(
                split_a_payload,
                split_b_payload,
                train_ids=ids,
                test_ids=ids,
                config=cfg,
            )
            report = AlignmentReport(
                session_matching_source="single_session_manifest_split_half",
                included_sessions=[session_id],
                excluded_sessions=[],
                timebase="maze",
                continuity_assumptions="split-half baseline uses interleaved odd/even selected rows",
            )
            validate_alignment(report)
            alignment_rows.append(
                {
                    "session_id": session_id,
                    "animal": str(row.get("animal", "")),
                    "cohort_group": cohort_group,
                    "included_sessions": ";".join(report.included_sessions),
                    "excluded_sessions": ";".join(report.excluded_sessions),
                    "timebase": report.timebase,
                    "continuity_assumptions": report.continuity_assumptions,
                    "split_strategy": "interleaved_even_odd",
                }
            )
            summary_rows.append(
                _pair_summary_row(
                    pair_row,
                    paired,
                    matched_neuron_count_before_gate=n_neurons,
                )
            )
            curve_rows.extend(_pair_side_curve_rows(pair_row, "split_a", paired["train_window_result"]))
            curve_rows.extend(_pair_side_curve_rows(pair_row, "split_b", paired["test_window_result"]))
            neuron_rows.extend(_pair_neuron_rows(pair_row, paired))
            pair_window_rows = _pair_window_metric_rows(pair_row, paired)
            window_metric_rows.extend(pair_window_rows)
            for metric_row in pair_window_rows:
                support_audit_rows.append(
                    {
                        "pair_id": metric_row["pair_id"],
                        "pair_family": metric_row["pair_family"],
                        "animal": metric_row["animal"],
                        "window_index": metric_row["window_index"],
                        "session_a_valid_bin_count": metric_row.get("session_a_valid_bin_count_after_min_occ"),
                        "session_b_valid_bin_count": metric_row.get("session_b_valid_bin_count_after_min_occ"),
                        "pair_common_valid_bin_count": metric_row.get("session_a_pair_common_valid_bin_count"),
                        "pair_support_bin_count": metric_row.get("session_a_pair_support_bin_count"),
                        "pair_fraction_of_common_valid": metric_row.get("session_a_pair_fraction_of_common_valid"),
                        "pair_fraction_of_session_a_valid": metric_row.get("session_a_pair_support_fraction_of_session_valid"),
                        "pair_fraction_of_session_b_valid": metric_row.get("session_b_pair_support_fraction_of_session_valid"),
                        "paired_window_count_total": int(paired.get("paired_window_count", 0)),
                    }
                )
                prior_diagnostic_rows.append(
                    {
                        "pair_id": metric_row["pair_id"],
                        "pair_family": metric_row["pair_family"],
                        "animal": metric_row["animal"],
                        "window_index": metric_row["window_index"],
                        "pair_prior_js_divergence": metric_row.get("session_a_pair_prior_js_divergence"),
                        "pair_prior_total_variation": metric_row.get("session_a_pair_prior_total_variation"),
                        "pair_common_valid_bin_count": metric_row.get("session_a_pair_common_valid_bin_count"),
                        "pair_support_bin_count": metric_row.get("session_a_pair_support_bin_count"),
                    }
                )
            _append_family_curve(
                group_curves,
                family=cohort_group,
                side="split_a",
                session_id=f"{session_id}::split_a",
                win=paired["train_window_result"],
            )
            _append_family_curve(
                group_curves,
                family=cohort_group,
                side="split_b",
                session_id=f"{session_id}::split_b",
                win=paired["test_window_result"],
            )
        except Exception as exc:
            failures.append({**row.to_dict(), "error": str(exc)})
            alignment_rows.append(
                {
                    "session_id": session_id,
                    "animal": str(row.get("animal", "")),
                    "cohort_group": cohort_group,
                    "included_sessions": "",
                    "excluded_sessions": session_id,
                    "timebase": "maze",
                    "continuity_assumptions": str(exc),
                    "split_strategy": "interleaved_even_odd",
                }
            )

    interp = interpolate_then_average_group_curves(
        group_curves,
        grid_dt_sec=float(cfg.step_steps) * float(cfg.dt) if str(cfg.window_style) == "step" else float(cfg.step_sec),
        min_support_count=int(cfg.group_min_support_count),
    )
    group_curves_df = interp["curves_df"].copy()
    if not group_curves_df.empty:
        parts = group_curves_df["group"].astype(str).str.split(" :: ", n=1, expand=True)
        group_curves_df["cohort_group"] = parts[0]
        group_curves_df["side"] = parts[1]
    group_summary_df = interp["summary_df"].copy()
    if not group_summary_df.empty:
        parts = group_summary_df["group"].astype(str).str.split(" :: ", n=1, expand=True)
        group_summary_df["cohort_group"] = parts[0]
        group_summary_df["side"] = parts[1]

    return {
        "single_session_split_half_summary": pd.DataFrame(summary_rows),
        "single_session_split_half_curves": pd.DataFrame(curve_rows),
        "single_session_split_half_neuron_curves": pd.DataFrame(neuron_rows),
        "single_session_split_half_window_metrics": pd.DataFrame(window_metric_rows),
        "single_session_split_half_support_audit": pd.DataFrame(support_audit_rows),
        "single_session_split_half_prior_diagnostics": pd.DataFrame(prior_diagnostic_rows),
        "single_session_split_half_group_curves": group_curves_df,
        "single_session_split_half_group_summary": group_summary_df,
        "single_session_split_half_failures": pd.DataFrame(failures),
        "single_session_split_half_alignment_report": pd.DataFrame(alignment_rows),
    }


def run_spatial_information_memory_controls(
    *,
    config: SpatialInfoMemoryConfig | None = None,
    quartets: list[QuartetSpec] | None = None,
    behavior_groups: dict[str, list[str]] | None = None,
    parity_meta: str | Path | pd.DataFrame | None = None,
) -> dict[str, pd.DataFrame]:
    cfg = config or SpatialInfoMemoryConfig()
    single_manifest = build_single_session_manifest(quartets=quartets, behavior_groups=behavior_groups)
    pair_manifest = build_cross_session_pair_manifest(quartets=quartets, parity_meta=parity_meta or cfg.parity_metafile)
    single = run_single_session_spatial_information(single_manifest, config=cfg)
    split_half = run_single_session_split_half_baseline(single_manifest, config=cfg)
    cross = run_cross_session_spatial_information(pair_manifest, config=cfg)
    return {
        "single_session_manifest": single_manifest,
        "cross_session_pair_manifest": pair_manifest,
        **single,
        **split_half,
        **cross,
    }


def export_spatial_information_memory_results(results: dict[str, pd.DataFrame], out_dir: str | Path) -> dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, str] = {}
    for key, value in results.items():
        if not isinstance(value, pd.DataFrame):
            continue
        path = out_path / f"{key}.csv"
        value.to_csv(path, index=False)
        manifest[key] = str(path)
    return manifest


__all__ = [
    "SpatialInfoMemoryConfig",
    "build_single_session_manifest",
    "build_cross_session_pair_manifest",
    "run_single_session_spatial_information",
    "run_single_session_split_half_baseline",
    "run_cross_session_spatial_information",
    "run_spatial_information_memory_controls",
    "export_spatial_information_memory_results",
]
