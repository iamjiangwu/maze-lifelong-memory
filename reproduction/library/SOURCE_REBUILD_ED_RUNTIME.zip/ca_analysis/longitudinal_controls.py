"""Shared mechanics for longitudinal reliability and registration controls.

The module is deliberately independent of figure code.  It turns one session
into location-episode and retained-time-block sufficient statistics, constructs
whole-episode A/B splits, fits occupancy-normalized maps, and supplies the
small clustered linear models used by the control analyses.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy import stats

from .maze import NewMaze
from .spatial import (
    LEVEL_DEFINITION_GEOMETRIC8,
    LEVEL_DEFINITION_TREE_DEPTH7,
    get_level_list,
)


DT = 0.04
N_SPATIAL_BINS = 15 * 15
DEFAULT_BLOCK_SAMPLES = 1_500
DEFAULT_MAX_HALF_FRACTION = 0.70

# Exact mappings used by the maintained matched-resolution control.
HORIZONTAL_DUMBBELL8 = {
    0: (0, 1),
    1: (4, 5),
    2: (2, 3),
    3: (6, 7),
    4: (8, 9),
    5: (12, 13),
    6: (10, 11),
    7: (14, 15),
}
VERTICAL_DUMBBELL8 = {
    0: (0, 4),
    1: (1, 5),
    2: (2, 6),
    3: (3, 7),
    4: (8, 12),
    5: (9, 13),
    6: (10, 14),
    7: (11, 15),
}
CONNECTOR_COORDS = {3, 7, 11}


@dataclass(frozen=True)
class SessionSufficientStats:
    """Cached frame-linear quantities for one selected-data session."""

    session_id: str
    episode_location: np.ndarray
    episode_start_frame: np.ndarray
    episode_end_frame: np.ndarray
    episode_n_frames: np.ndarray
    episode_duration_sec: np.ndarray
    episode_count_sum: np.ndarray
    block_n_samples: np.ndarray
    block_count_sum: np.ndarray
    full_count_sum: np.ndarray
    full_event_rate_per_min: np.ndarray
    total_retained_samples: int
    total_retained_duration_sec: float
    n_dropped_nan_rows: int = 0

    @property
    def n_neurons(self) -> int:
        return int(self.full_count_sum.size)

    @property
    def n_episodes(self) -> int:
        return int(self.episode_location.size)


@dataclass(frozen=True)
class EpisodeIndex:
    """Location-pure runs and the row-to-episode mapping used to aggregate C."""

    row_episode: np.ndarray
    location: np.ndarray
    start_frame: np.ndarray
    end_frame: np.ndarray
    n_frames: np.ndarray


@dataclass(frozen=True)
class SplitAssignment:
    """Episode assignment and location-level balance diagnostics."""

    assignment: np.ndarray
    location_audit: pd.DataFrame


def stable_seed(*parts: object, base_seed: int = 0) -> int:
    """Return a platform-stable uint32 seed."""

    text = "|".join(str(part) for part in parts)
    digest = hashlib.blake2b(
        text.encode("utf-8"), digest_size=8, person=b"longctl"
    ).digest()
    return (int.from_bytes(digest, "little") + int(base_seed)) % (2**32)


def location_labels_from_selected_df(selected_df: pd.DataFrame) -> np.ndarray:
    """Return fixed 15x15 body-centre labels, or -1 outside the grid."""

    bx = pd.to_numeric(selected_df["mass_bx"], errors="coerce").to_numpy(float)
    by = pd.to_numeric(selected_df["mass_by"], errors="coerce").to_numpy(float)
    valid = np.isfinite(bx) & np.isfinite(by)
    bx_i = np.full(bx.shape, -1, dtype=int)
    by_i = np.full(by.shape, -1, dtype=int)
    bx_i[valid] = np.floor(bx[valid]).astype(int)
    by_i[valid] = np.floor(by[valid]).astype(int)
    in_grid = valid & (bx_i >= 0) & (bx_i < 15) & (by_i >= 0) & (by_i < 15)
    labels = np.full(bx.shape, -1, dtype=int)
    labels[in_grid] = bx_i[in_grid] + 15 * by_i[in_grid]
    return labels


def build_location_episode_index(
    frames: Sequence[int], location_labels: Sequence[int]
) -> EpisodeIndex:
    """Build maximal same-location runs of consecutive acquisition frames.

    Invalid locations break a run and receive row episode ``-1``.
    """

    frames_arr = np.asarray(frames, dtype=int).ravel()
    labels = np.asarray(location_labels, dtype=int).ravel()
    if frames_arr.shape != labels.shape:
        raise ValueError("frames and location_labels must have the same shape")
    row_episode = np.full(frames_arr.size, -1, dtype=int)
    locs: list[int] = []
    starts: list[int] = []
    ends: list[int] = []
    counts: list[int] = []
    active_episode = -1
    previous_row = -2
    previous_frame = -2
    previous_label = -2
    for row, (frame, label) in enumerate(zip(frames_arr, labels, strict=True)):
        if label < 0:
            active_episode = -1
            previous_row = row
            previous_frame = int(frame)
            previous_label = int(label)
            continue
        continuing = (
            active_episode >= 0
            and row == previous_row + 1
            and int(frame) == previous_frame + 1
            and int(label) == previous_label
        )
        if not continuing:
            active_episode = len(locs)
            locs.append(int(label))
            starts.append(int(frame))
            ends.append(int(frame))
            counts.append(0)
        row_episode[row] = active_episode
        ends[active_episode] = int(frame)
        counts[active_episode] += 1
        previous_row = row
        previous_frame = int(frame)
        previous_label = int(label)
    return EpisodeIndex(
        row_episode=row_episode,
        location=np.asarray(locs, dtype=int),
        start_frame=np.asarray(starts, dtype=int),
        end_frame=np.asarray(ends, dtype=int),
        n_frames=np.asarray(counts, dtype=int),
    )


def aggregate_session_sufficient_stats(
    *,
    session_id: str,
    frames: Sequence[int],
    location_labels: Sequence[int],
    count_samples: np.ndarray,
    event_samples: np.ndarray,
    dt: float = DT,
    block_samples: int = DEFAULT_BLOCK_SAMPLES,
    n_dropped_nan_rows: int = 0,
) -> SessionSufficientStats:
    """Construct session sufficient statistics from retained frame matrices."""

    frames_arr = np.asarray(frames, dtype=int).ravel()
    counts = np.asarray(count_samples, dtype=np.float64)
    events = np.asarray(event_samples, dtype=np.float64)
    if counts.ndim != 2 or events.shape != counts.shape:
        raise ValueError("count_samples and event_samples must share T x N shape")
    if counts.shape[0] != frames_arr.size:
        raise ValueError("sample matrices must match frame count")
    if not np.isfinite(counts).all() or not np.isfinite(events).all():
        raise ValueError("retained count/event samples must be finite")
    episodes = build_location_episode_index(frames_arr, location_labels)
    episode_sum = np.zeros((episodes.location.size, counts.shape[1]), dtype=np.float64)
    valid_episode_rows = episodes.row_episode >= 0
    if valid_episode_rows.any():
        np.add.at(
            episode_sum,
            episodes.row_episode[valid_episode_rows],
            counts[valid_episode_rows],
        )
    n_blocks = int(np.ceil(counts.shape[0] / int(block_samples))) if counts.size else 0
    block_sum = np.zeros((n_blocks, counts.shape[1]), dtype=np.float64)
    block_n = np.zeros(n_blocks, dtype=int)
    if n_blocks:
        block_index = np.arange(counts.shape[0], dtype=int) // int(block_samples)
        np.add.at(block_sum, block_index, counts)
        np.add.at(block_n, block_index, 1)
    duration = float(counts.shape[0]) * float(dt)
    event_rate = (
        events.sum(axis=0) / (duration / 60.0)
        if duration > 0
        else np.full(counts.shape[1], np.nan, dtype=float)
    )
    return SessionSufficientStats(
        session_id=str(session_id),
        episode_location=episodes.location,
        episode_start_frame=episodes.start_frame,
        episode_end_frame=episodes.end_frame,
        episode_n_frames=episodes.n_frames,
        episode_duration_sec=episodes.n_frames.astype(float) * float(dt),
        episode_count_sum=episode_sum,
        block_n_samples=block_n,
        block_count_sum=block_sum,
        full_count_sum=counts.sum(axis=0),
        full_event_rate_per_min=np.asarray(event_rate, dtype=float),
        total_retained_samples=int(counts.shape[0]),
        total_retained_duration_sec=duration,
        n_dropped_nan_rows=int(n_dropped_nan_rows),
    )


def save_session_stats(path: Path, stats_obj: SessionSufficientStats) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        session_id=np.asarray(stats_obj.session_id),
        episode_location=stats_obj.episode_location,
        episode_start_frame=stats_obj.episode_start_frame,
        episode_end_frame=stats_obj.episode_end_frame,
        episode_n_frames=stats_obj.episode_n_frames,
        episode_duration_sec=stats_obj.episode_duration_sec,
        episode_count_sum=stats_obj.episode_count_sum.astype(np.float32),
        block_n_samples=stats_obj.block_n_samples,
        block_count_sum=stats_obj.block_count_sum.astype(np.float32),
        full_count_sum=stats_obj.full_count_sum.astype(np.float64),
        full_event_rate_per_min=stats_obj.full_event_rate_per_min.astype(np.float64),
        total_retained_samples=np.asarray(stats_obj.total_retained_samples),
        total_retained_duration_sec=np.asarray(stats_obj.total_retained_duration_sec),
        n_dropped_nan_rows=np.asarray(stats_obj.n_dropped_nan_rows),
    )


def load_session_stats(path: Path) -> SessionSufficientStats:
    with np.load(Path(path), allow_pickle=False) as data:
        return SessionSufficientStats(
            session_id=str(data["session_id"].item()),
            episode_location=np.asarray(data["episode_location"], dtype=int),
            episode_start_frame=np.asarray(data["episode_start_frame"], dtype=int),
            episode_end_frame=np.asarray(data["episode_end_frame"], dtype=int),
            episode_n_frames=np.asarray(data["episode_n_frames"], dtype=int),
            episode_duration_sec=np.asarray(data["episode_duration_sec"], dtype=float),
            episode_count_sum=np.asarray(data["episode_count_sum"], dtype=float),
            block_n_samples=np.asarray(data["block_n_samples"], dtype=int),
            block_count_sum=np.asarray(data["block_count_sum"], dtype=float),
            full_count_sum=np.asarray(data["full_count_sum"], dtype=float),
            full_event_rate_per_min=np.asarray(data["full_event_rate_per_min"], dtype=float),
            total_retained_samples=int(data["total_retained_samples"].item()),
            total_retained_duration_sec=float(data["total_retained_duration_sec"].item()),
            n_dropped_nan_rows=int(data["n_dropped_nan_rows"].item()),
        )


def _half_fraction(duration_a: float, duration_b: float) -> float:
    total = float(duration_a) + float(duration_b)
    return float(max(duration_a, duration_b) / total) if total > 0 else 1.0


def _canonical_location_assignment(
    indices: np.ndarray, durations: np.ndarray
) -> tuple[np.ndarray, float, float]:
    local = np.full(indices.size, -1, dtype=np.int8)
    totals = [0.0, 0.0]
    for pair_number, start in enumerate(range(0, indices.size - 1, 2)):
        d0 = float(durations[start])
        d1 = float(durations[start + 1])
        if np.isclose(d0, d1):
            first_half = pair_number % 2
            local[start] = first_half
            local[start + 1] = 1 - first_half
        else:
            longer = start if d0 > d1 else start + 1
            shorter = start + 1 if longer == start else start
            if np.isclose(totals[0], totals[1]):
                less_half = pair_number % 2
            else:
                less_half = int(totals[1] < totals[0])
            local[longer] = less_half
            local[shorter] = 1 - less_half
        totals[0] += float(durations[start]) if local[start] == 0 else float(durations[start + 1])
        totals[1] += float(durations[start]) if local[start] == 1 else float(durations[start + 1])
    if indices.size % 2:
        last = indices.size - 1
        half = int(totals[1] < totals[0])
        local[last] = half
        totals[half] += float(durations[last])
    return local, totals[0], totals[1]


def _random_location_assignment(
    indices: np.ndarray,
    durations: np.ndarray,
    *,
    rng: np.random.Generator,
) -> tuple[np.ndarray, float, float]:
    local = np.full(indices.size, -1, dtype=np.int8)
    totals = [0.0, 0.0]
    for start in range(0, indices.size - 1, 2):
        first_half = int(rng.integers(0, 2))
        local[start] = first_half
        local[start + 1] = 1 - first_half
        totals[first_half] += float(durations[start])
        totals[1 - first_half] += float(durations[start + 1])
    if indices.size % 2:
        last = indices.size - 1
        half = int(totals[1] < totals[0])
        local[last] = half
        totals[half] += float(durations[last])
    return local, totals[0], totals[1]


def split_location_episodes(
    episode_locations: Sequence[int],
    episode_durations: Sequence[float],
    *,
    canonical: bool,
    seed: int | None = None,
    max_half_fraction: float = DEFAULT_MAX_HALF_FRACTION,
    max_attempts: int = 100,
) -> SplitAssignment:
    """Assign complete episodes to A/B independently within location."""

    locations = np.asarray(episode_locations, dtype=int).ravel()
    durations = np.asarray(episode_durations, dtype=float).ravel()
    if locations.shape != durations.shape:
        raise ValueError("episode locations and durations must have the same shape")
    if np.any(durations <= 0):
        raise ValueError("episode durations must be positive")
    assignment = np.full(locations.size, -1, dtype=np.int8)
    rng = np.random.default_rng(seed)
    audits: list[dict[str, object]] = []
    for location in sorted(int(value) for value in np.unique(locations)):
        idx = np.flatnonzero(locations == location)
        local_durations = durations[idx]
        if canonical:
            local, dur_a, dur_b = _canonical_location_assignment(idx, local_durations)
            attempts = 1
            accepted = _half_fraction(dur_a, dur_b) <= float(max_half_fraction)
        else:
            best: tuple[np.ndarray, float, float] | None = None
            best_fraction = np.inf
            accepted = False
            attempts = 0
            for attempt in range(1, int(max_attempts) + 1):
                candidate = _random_location_assignment(idx, local_durations, rng=rng)
                fraction = _half_fraction(candidate[1], candidate[2])
                if fraction < best_fraction:
                    best = candidate
                    best_fraction = fraction
                attempts = attempt
                if fraction <= float(max_half_fraction):
                    best = candidate
                    accepted = True
                    break
            assert best is not None
            local, dur_a, dur_b = best
        assignment[idx] = local
        fraction = _half_fraction(dur_a, dur_b)
        audits.append(
            {
                "location": location,
                "n_episodes": int(idx.size),
                "duration_a_sec": float(dur_a),
                "duration_b_sec": float(dur_b),
                "max_half_fraction": float(fraction),
                "eligible_70_30": bool(accepted),
                "attempts": int(attempts),
                "canonical": bool(canonical),
                "seed": seed,
            }
        )
    return SplitAssignment(assignment=assignment, location_audit=pd.DataFrame(audits))


def split_retained_blocks(
    block_n_samples: Sequence[int],
    *,
    canonical: bool,
    seed: int | None = None,
) -> np.ndarray:
    """Assign adjacent retained-data blocks to opposite halves."""

    sizes = np.asarray(block_n_samples, dtype=int).ravel()
    out = np.full(sizes.size, -1, dtype=np.int8)
    rng = np.random.default_rng(seed)
    totals = [0, 0]
    for pair_number, start in enumerate(range(0, sizes.size - 1, 2)):
        first_half = pair_number % 2 if canonical else int(rng.integers(0, 2))
        out[start] = first_half
        out[start + 1] = 1 - first_half
        totals[first_half] += int(sizes[start])
        totals[1 - first_half] += int(sizes[start + 1])
    if sizes.size % 2:
        half = int(totals[1] < totals[0])
        out[-1] = half
    return out


def _grid_labels_from_level_masks(level_masks: Sequence[np.ndarray]) -> np.ndarray:
    maze = NewMaze(6)
    out = np.full(N_SPATIAL_BINS, -1, dtype=int)
    cell_level = np.full(len(maze.xc), -1, dtype=int)
    for level, mask in enumerate(level_masks):
        cell_level[np.asarray(mask, dtype=bool)] = int(level)
    for (row, col), cell_id in maze.ce.items():
        out[int(col) + 15 * int(row)] = int(cell_level[int(cell_id)])
    return out


def representation_location_maps() -> dict[str, np.ndarray]:
    """Return the five fixed maps from 15x15 location to category."""

    maze = NewMaze(6)
    place = np.arange(N_SPATIAL_BINS, dtype=int)
    tree = _grid_labels_from_level_masks(
        get_level_list(LEVEL_DEFINITION_TREE_DEPTH7, maze=maze)
    )
    geometric = _grid_labels_from_level_masks(
        get_level_list(LEVEL_DEFINITION_GEOMETRIC8, maze=maze, ma_ce=maze.ce)
    )
    dumb16 = np.full(N_SPATIAL_BINS, -1, dtype=int)
    for by in range(15):
        for bx in range(15):
            location = bx + 15 * by
            if bx in CONNECTOR_COORDS or by in CONNECTOR_COORDS:
                continue
            gx = 0 if bx <= 2 else 1 if bx <= 6 else 2 if bx <= 10 else 3
            gy = 0 if by <= 2 else 1 if by <= 6 else 2 if by <= 10 else 3
            dumb16[location] = gx + 4 * gy

    def remap(mapping: Mapping[int, Sequence[int]]) -> np.ndarray:
        output = np.full(N_SPATIAL_BINS, -1, dtype=int)
        for category, members in mapping.items():
            output[np.isin(dumb16, np.asarray(members, dtype=int))] = int(category)
        return output

    return {
        "place15x15": place,
        "tree_depth7": tree,
        "geometric8": geometric,
        "horizontal8": remap(HORIZONTAL_DUMBBELL8),
        "vertical8": remap(VERTICAL_DUMBBELL8),
    }


REPRESENTATION_N_CATEGORIES = {
    "place15x15": 225,
    "tree_depth7": 7,
    "geometric8": 8,
    "horizontal8": 8,
    "vertical8": 8,
}
REPRESENTATION_MIN_LABELS = {
    "place15x15": 3,
    "tree_depth7": 3,
    "geometric8": 6,
    "horizontal8": 6,
    "vertical8": 6,
}


def fit_representation_map(
    stats_obj: SessionSufficientStats,
    representation: str,
    neuron_ids: Sequence[int] | None = None,
    *,
    min_occupancy_sec: float,
    assignment: np.ndarray | None = None,
    half: int | None = None,
    permitted_locations: np.ndarray | None = None,
    location_maps: Mapping[str, np.ndarray] | None = None,
) -> dict[str, np.ndarray]:
    """Aggregate cached episodes into one occupancy-normalized map."""

    maps = representation_location_maps() if location_maps is None else location_maps
    if representation not in maps:
        raise KeyError(representation)
    category_by_location = np.asarray(maps[representation], dtype=int)
    locations = np.asarray(stats_obj.episode_location, dtype=int)
    categories = category_by_location[locations]
    keep = categories >= 0
    if permitted_locations is not None:
        allowed = np.asarray(permitted_locations, dtype=bool)
        if allowed.size != N_SPATIAL_BINS:
            raise ValueError("permitted_locations must have length 225")
        keep &= allowed[locations]
    if assignment is not None:
        if half not in (0, 1):
            raise ValueError("half must be 0 or 1 when assignment is supplied")
        assign = np.asarray(assignment, dtype=int)
        if assign.size != locations.size:
            raise ValueError("assignment must match episode count")
        keep &= assign == int(half)
    ids = (
        np.arange(stats_obj.n_neurons, dtype=int)
        if neuron_ids is None
        else np.asarray(neuron_ids, dtype=int)
    )
    if ids.size and (ids.min() < 0 or ids.max() >= stats_obj.n_neurons):
        raise IndexError("neuron_ids out of range")
    n_categories = REPRESENTATION_N_CATEGORIES[representation]
    count_map = np.zeros((n_categories, ids.size), dtype=np.float64)
    occupancy = np.zeros(n_categories, dtype=np.float64)
    valid_episode_idx = np.flatnonzero(keep)
    if valid_episode_idx.size:
        np.add.at(
            count_map,
            categories[valid_episode_idx],
            stats_obj.episode_count_sum[valid_episode_idx][:, ids],
        )
        np.add.at(
            occupancy,
            categories[valid_episode_idx],
            stats_obj.episode_duration_sec[valid_episode_idx],
        )
    valid_mask = occupancy >= float(min_occupancy_sec)
    rate_map = np.full(count_map.shape, np.nan, dtype=float)
    if valid_mask.any():
        rate_map[valid_mask] = count_map[valid_mask] / occupancy[valid_mask, None]
    return {
        "count_map": count_map,
        "occupancy_sec": occupancy,
        "valid_mask": valid_mask,
        "rate_map": rate_map,
        "neuron_ids": ids,
    }


def aggregate_location_sums(
    stats_obj: SessionSufficientStats,
    neuron_ids: Sequence[int] | None = None,
    *,
    assignment: np.ndarray | None = None,
    half: int | None = None,
) -> dict[str, np.ndarray]:
    """Aggregate episode sufficient statistics once onto the 15x15 grid."""

    ids = (
        np.arange(stats_obj.n_neurons, dtype=int)
        if neuron_ids is None
        else np.asarray(neuron_ids, dtype=int)
    )
    locations = np.asarray(stats_obj.episode_location, dtype=int)
    keep = np.ones(locations.size, dtype=bool)
    if assignment is not None:
        assigned = np.asarray(assignment, dtype=int)
        if assigned.size != locations.size or half not in (0, 1):
            raise ValueError("invalid episode assignment or half")
        keep &= assigned == int(half)
    counts = np.zeros((N_SPATIAL_BINS, ids.size), dtype=np.float64)
    occupancy = np.zeros(N_SPATIAL_BINS, dtype=np.float64)
    for location in np.unique(locations[keep]):
        use = keep & (locations == int(location))
        counts[int(location)] = stats_obj.episode_count_sum[use][:, ids].sum(
            axis=0, dtype=np.float64
        )
        occupancy[int(location)] = stats_obj.episode_duration_sec[use].sum()
    return {"count_by_location": counts, "occupancy_by_location_sec": occupancy, "neuron_ids": ids}


def fit_representation_from_location_sums(
    location_sums: Mapping[str, np.ndarray],
    representation: str,
    *,
    min_occupancy_sec: float,
    permitted_locations: np.ndarray | None = None,
    location_maps: Mapping[str, np.ndarray] | None = None,
) -> dict[str, np.ndarray]:
    """Regroup cached location-level sums into a representation map."""

    maps = representation_location_maps() if location_maps is None else location_maps
    category_by_location = np.asarray(maps[representation], dtype=int)
    counts_by_location = np.asarray(location_sums["count_by_location"], dtype=float)
    occupancy_by_location = np.asarray(
        location_sums["occupancy_by_location_sec"], dtype=float
    )
    if counts_by_location.shape[0] != N_SPATIAL_BINS:
        raise ValueError("location counts must have 225 rows")
    keep = category_by_location >= 0
    if permitted_locations is not None:
        allowed = np.asarray(permitted_locations, dtype=bool)
        if allowed.size != N_SPATIAL_BINS:
            raise ValueError("permitted_locations must have length 225")
        keep &= allowed
    n_categories = REPRESENTATION_N_CATEGORIES[representation]
    count_map = np.zeros((n_categories, counts_by_location.shape[1]), dtype=float)
    occupancy = np.zeros(n_categories, dtype=float)
    locations = np.flatnonzero(keep)
    if locations.size:
        np.add.at(count_map, category_by_location[locations], counts_by_location[locations])
        np.add.at(occupancy, category_by_location[locations], occupancy_by_location[locations])
    valid_mask = occupancy >= float(min_occupancy_sec)
    rate_map = np.full(count_map.shape, np.nan, dtype=float)
    rate_map[valid_mask] = count_map[valid_mask] / occupancy[valid_mask, None]
    return {
        "count_map": count_map,
        "occupancy_sec": occupancy,
        "valid_mask": valid_mask,
        "rate_map": rate_map,
        "neuron_ids": np.asarray(location_sums["neuron_ids"], dtype=int),
    }


def common_permitted_locations(
    representation_a: str,
    representation_b: str,
    *,
    location_maps: Mapping[str, np.ndarray] | None = None,
) -> np.ndarray:
    maps = representation_location_maps() if location_maps is None else location_maps
    return (np.asarray(maps[representation_a]) >= 0) & (
        np.asarray(maps[representation_b]) >= 0
    )


def safe_pearson(a: Sequence[float], b: Sequence[float]) -> float:
    x = np.asarray(a, dtype=float).ravel()
    y = np.asarray(b, dtype=float).ravel()
    valid = np.isfinite(x) & np.isfinite(y)
    if int(valid.sum()) < 2:
        return float("nan")
    x = x[valid]
    y = y[valid]
    x = x - x.mean()
    y = y - y.mean()
    denominator = float(np.sqrt(np.sum(x * x) * np.sum(y * y)))
    return float(np.sum(x * y) / denominator) if denominator > 0 else float("nan")


def columnwise_correlations(
    map_a: np.ndarray,
    map_b: np.ndarray,
    shared_labels: np.ndarray,
    *,
    min_labels: int,
) -> np.ndarray:
    a = np.asarray(map_a, dtype=float)
    b = np.asarray(map_b, dtype=float)
    mask = np.asarray(shared_labels, dtype=bool)
    out = np.full(a.shape[1], np.nan, dtype=float)
    if a.shape != b.shape or mask.size != a.shape[0] or int(mask.sum()) < int(min_labels):
        return out
    for neuron in range(a.shape[1]):
        out[neuron] = safe_pearson(a[mask, neuron], b[mask, neuron])
    return out


def rowwise_correlations(
    map_a: np.ndarray,
    map_b: np.ndarray,
    shared_labels: np.ndarray,
    *,
    min_neurons: int = 3,
) -> np.ndarray:
    a = np.asarray(map_a, dtype=float)
    b = np.asarray(map_b, dtype=float)
    mask = np.asarray(shared_labels, dtype=bool)
    out = np.full(a.shape[0], np.nan, dtype=float)
    if a.shape != b.shape or mask.size != a.shape[0]:
        return out
    for label in np.flatnonzero(mask):
        valid = np.isfinite(a[label]) & np.isfinite(b[label])
        if int(valid.sum()) >= int(min_neurons):
            out[label] = safe_pearson(a[label, valid], b[label, valid])
    return out


def rate_vector(
    stats_obj: SessionSufficientStats,
    neuron_ids: Sequence[int],
    *,
    block_assignment: np.ndarray | None = None,
    half: int | None = None,
) -> np.ndarray:
    ids = np.asarray(neuron_ids, dtype=int)
    if block_assignment is None:
        duration = float(stats_obj.total_retained_duration_sec)
        return (
            stats_obj.full_count_sum[ids] / duration
            if duration > 0
            else np.full(ids.size, np.nan)
        )
    assignment = np.asarray(block_assignment, dtype=int)
    if assignment.size != stats_obj.block_n_samples.size or half not in (0, 1):
        raise ValueError("invalid block assignment or half")
    keep = assignment == int(half)
    duration = float(stats_obj.block_n_samples[keep].sum()) * DT
    return (
        stats_obj.block_count_sum[keep][:, ids].sum(axis=0) / duration
        if duration > 0
        else np.full(ids.size, np.nan)
    )


def spearman_brown(split_r: float) -> float:
    value = float(split_r)
    if not np.isfinite(value) or np.isclose(value, -1.0):
        return float("nan")
    return float(2.0 * value / (1.0 + value))


def benjamini_hochberg(values: Sequence[float]) -> np.ndarray:
    p = np.asarray(values, dtype=float)
    output = np.full(p.shape, np.nan, dtype=float)
    finite = np.flatnonzero(np.isfinite(p))
    if finite.size == 0:
        return output
    order_local = np.argsort(p[finite])
    ranked_indices = finite[order_local]
    ranked = p[ranked_indices]
    adjusted = np.minimum.accumulate(
        (ranked * ranked.size / np.arange(1, ranked.size + 1))[::-1]
    )[::-1]
    output[ranked_indices] = np.minimum(adjusted, 1.0)
    return output


def cr1_ols(
    y: Sequence[float], X: np.ndarray, clusters: Sequence[object]
) -> dict[str, np.ndarray | float | int]:
    """OLS with animal-clustered CR1 covariance and G-1 inference df."""

    y_arr = np.asarray(y, dtype=float).ravel()
    x_arr = np.asarray(X, dtype=float)
    cluster_arr = np.asarray(clusters).ravel()
    finite = np.isfinite(y_arr) & np.isfinite(x_arr).all(axis=1)
    y_arr = y_arr[finite]
    x_arr = x_arr[finite]
    cluster_arr = cluster_arr[finite]
    if y_arr.size == 0 or x_arr.shape[0] <= x_arr.shape[1]:
        raise ValueError("insufficient finite observations for CR1 OLS")
    bread = np.linalg.pinv(x_arr.T @ x_arr)
    beta = bread @ (x_arr.T @ y_arr)
    residual = y_arr - x_arr @ beta
    groups = pd.unique(cluster_arr)
    n = int(y_arr.size)
    k = int(x_arr.shape[1])
    g = int(groups.size)
    if g < 2 or n <= k:
        raise ValueError("CR1 requires at least two clusters and N > K")
    meat = np.zeros((k, k), dtype=float)
    for group in groups:
        use = cluster_arr == group
        score = x_arr[use].T @ residual[use]
        meat += np.outer(score, score)
    correction = (g / (g - 1.0)) * ((n - 1.0) / (n - k))
    covariance = correction * bread @ meat @ bread
    return {
        "beta": beta,
        "covariance": covariance,
        "n": n,
        "k": k,
        "g": g,
        "df": g - 1,
        "residual": residual,
        "finite_mask": finite,
    }


def linear_contrast(
    fit: Mapping[str, object], contrast: Sequence[float]
) -> dict[str, float]:
    vector = np.asarray(contrast, dtype=float)
    beta = np.asarray(fit["beta"], dtype=float)
    covariance = np.asarray(fit["covariance"], dtype=float)
    estimate = float(vector @ beta)
    variance = float(vector @ covariance @ vector)
    se = float(np.sqrt(max(variance, 0.0)))
    t_value = estimate / se if se > 0 else np.nan
    df = int(fit["df"])
    p = float(2.0 * stats.t.sf(abs(t_value), df=df)) if np.isfinite(t_value) else np.nan
    return {
        "estimate": estimate,
        "se": se,
        "t": float(t_value),
        "df": df,
        "p_two_sided": p,
    }


STACKED_ORIENTATIONS = ("AA", "BB", "AB", "BA")


def stacked_recurrence_design(
    frame: pd.DataFrame,
    *,
    orientation_col: str = "orientation",
    predictor_col: str = "predictor",
) -> tuple[np.ndarray, list[str]]:
    orientation = frame[orientation_col].astype(str).to_numpy()
    predictor = pd.to_numeric(frame[predictor_col], errors="coerce").to_numpy(float)
    columns: list[np.ndarray] = []
    names: list[str] = []
    for label in STACKED_ORIENTATIONS:
        indicator = (orientation == label).astype(float)
        columns.append(indicator)
        names.append(f"intercept_{label}")
    for label in STACKED_ORIENTATIONS:
        indicator = (orientation == label).astype(float)
        columns.append(indicator * predictor)
        names.append(f"slope_{label}")
    return np.column_stack(columns), names


def stacked_recurrence_contrasts(names: Sequence[str]) -> dict[str, np.ndarray]:
    index = {name: position for position, name in enumerate(names)}

    def vector(weights: Mapping[str, float]) -> np.ndarray:
        out = np.zeros(len(names), dtype=float)
        for name, weight in weights.items():
            out[index[name]] = float(weight)
        return out

    shared = vector({"slope_AA": 0.5, "slope_BB": 0.5})
    disjoint = vector({"slope_AB": 0.5, "slope_BA": 0.5})
    return {
        "shared": shared,
        "disjoint": disjoint,
        "shared_minus_disjoint": shared - disjoint,
        "AA": vector({"slope_AA": 1.0}),
        "BB": vector({"slope_BB": 1.0}),
        "AB": vector({"slope_AB": 1.0}),
        "BA": vector({"slope_BA": 1.0}),
    }


def animal_bootstrap_contrasts(
    frame: pd.DataFrame,
    *,
    outcome_col: str,
    cluster_col: str,
    contrasts: Mapping[str, np.ndarray],
    n_bootstrap: int,
    seed: int,
) -> pd.DataFrame:
    """Animal bootstrap using cluster-level X'X and X'y sufficient statistics."""

    X, names = stacked_recurrence_design(frame)
    y = pd.to_numeric(frame[outcome_col], errors="coerce").to_numpy(float)
    groups = frame[cluster_col].astype(str).to_numpy()
    finite = np.isfinite(y) & np.isfinite(X).all(axis=1)
    X = X[finite]
    y = y[finite]
    groups = groups[finite]
    unique_groups = np.asarray(pd.unique(groups), dtype=object)
    group_xtx: list[np.ndarray] = []
    group_xty: list[np.ndarray] = []
    for group in unique_groups:
        use = groups == group
        group_xtx.append(X[use].T @ X[use])
        group_xty.append(X[use].T @ y[use])
    rng = np.random.default_rng(seed)
    values = {name: np.full(int(n_bootstrap), np.nan, dtype=float) for name in contrasts}
    for repeat in range(int(n_bootstrap)):
        sampled = rng.integers(0, unique_groups.size, size=unique_groups.size)
        xtx = np.sum([group_xtx[idx] for idx in sampled], axis=0)
        xty = np.sum([group_xty[idx] for idx in sampled], axis=0)
        beta = np.linalg.pinv(xtx) @ xty
        for name, contrast in contrasts.items():
            values[name][repeat] = float(np.asarray(contrast) @ beta)
    rows = []
    for name, samples in values.items():
        finite_samples = samples[np.isfinite(samples)]
        rows.append(
            {
                "contrast": name,
                "n_bootstrap": int(finite_samples.size),
                "ci_low": float(np.percentile(finite_samples, 2.5)),
                "ci_high": float(np.percentile(finite_samples, 97.5)),
                "bootstrap_sd": float(np.std(finite_samples, ddof=1)),
                "bootstrap_median": float(np.median(finite_samples)),
                "design_columns": ";".join(names),
            }
        )
    return pd.DataFrame(rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()
