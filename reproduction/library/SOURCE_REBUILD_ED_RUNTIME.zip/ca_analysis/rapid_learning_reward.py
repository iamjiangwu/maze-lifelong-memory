"""Reward-discovery and post-discovery binding endpoints.

The rapid-learning analysis deliberately keeps three events distinct:

``discovery``
    The first actual reward delivery recorded in ``Traj.re``.
``binding``
    The onset of the first post-discovery qualifying reward path that belongs
    to a sustained cluster of successful paths.
``legacy execution``
    The conventional first qualifying long path (``lb0``), regardless of
    whether its onset precedes the first reward delivery.

This separation prevents a path that starts before reward discovery from
being interpreted as evidence that the newly discovered reward was already
bound to the maze representation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from .maze import Maze
from .rapid_learning_phase0 import extract_actual_reward_events
from .trajectory import FindPathsToNode, TimeInMaze


@dataclass(frozen=True)
class RewardBindingSpec:
    reward_node: int = 94
    long_path_min: int = 7
    sustained_window_bouts: int = 5
    sustained_min_successes: int = 3


def _reward_frames(
    tf: Any,
    *,
    reward_events: pd.DataFrame | None = None,
) -> np.ndarray:
    """Return actual reward *onset* frames using the Phase-0 contract.

    ``Traj.re`` stores event onset in column 0 and event end in column 1. A
    supplied frozen event table is preferred so Phase 1 cannot silently drift
    from the Phase-0 source representation.
    """

    events = (
        extract_actual_reward_events(tf)
        if reward_events is None
        else reward_events.copy()
    )
    if events.empty:
        return np.zeros(0, dtype=float)
    if "reward_abs_frame" not in events:
        raise ValueError("reward event table is missing reward_abs_frame")
    values = pd.to_numeric(events["reward_abs_frame"], errors="coerce").to_numpy(
        dtype=float
    )
    values = values[np.isfinite(values)]
    return np.sort(values)


def reward_path_table(
    tf: Any,
    ma: Maze,
    spec: RewardBindingSpec = RewardBindingSpec(),
) -> pd.DataFrame:
    """Return every monotonic path to the canonical reward node."""

    paths = np.asarray(FindPathsToNode(int(spec.reward_node), tf, ma))
    columns = [
        "bout",
        "start_index_in_bout",
        "path_length",
        "onset_abs_frame",
        "completion_abs_frame",
        "onset_maze_seconds",
        "completion_maze_seconds",
        "qualifying_long_path",
    ]
    if paths.ndim != 2 or paths.shape[1] < 4 or len(paths) == 0:
        return pd.DataFrame(columns=columns)
    records: list[dict[str, Any]] = []
    for bout, start_index, path_length, onset_abs in paths[:, :4]:
        bout = int(bout)
        start_index = int(start_index)
        path_length = int(path_length)
        onset_abs = float(onset_abs)
        node_runs = np.asarray(tf.no[bout])
        completion_index = start_index + path_length
        completion_abs = (
            float(node_runs[completion_index, 1]) + float(tf.fr[bout, 0])
            if node_runs.ndim == 2 and completion_index < len(node_runs)
            else np.nan
        )
        records.append(
            {
                "bout": bout,
                "start_index_in_bout": start_index,
                "path_length": path_length,
                "onset_abs_frame": onset_abs,
                "completion_abs_frame": completion_abs,
                "onset_maze_seconds": float(TimeInMaze(onset_abs, tf)),
                "completion_maze_seconds": (
                    float(TimeInMaze(completion_abs, tf))
                    if np.isfinite(completion_abs)
                    else np.nan
                ),
                "qualifying_long_path": path_length >= int(spec.long_path_min),
            }
        )
    return (
        pd.DataFrame(records)
        .sort_values("onset_abs_frame", kind="stable")
        .reset_index(drop=True)
    )


def find_sustained_binding_path(
    paths: pd.DataFrame,
    *,
    first_reward_abs_frame: float,
    spec: RewardBindingSpec = RewardBindingSpec(),
) -> dict[str, Any]:
    """Find the first post-reward long path initiating a sustained cluster.

    A cluster is the earliest block of ``sustained_window_bouts`` consecutive
    observed maze bouts containing long reward paths in at least
    ``sustained_min_successes`` distinct bouts.  The endpoint is the onset of
    the first qualifying path in that successful block; the third (or later)
    success is retained as a confirmation time in the audit output.
    """

    if not np.isfinite(first_reward_abs_frame):
        return {"status": "no_reward", "binding_path_index": None}
    if paths.empty:
        return {"status": "right_censored_no_reward_path", "binding_path_index": None}
    post = paths[
        paths["qualifying_long_path"].astype(bool)
        & pd.to_numeric(paths["onset_abs_frame"], errors="coerce").ge(
            first_reward_abs_frame
        )
    ].copy()
    if post.empty:
        return {
            "status": "right_censored_no_postreward_long_path",
            "binding_path_index": None,
        }

    first_bout = int(post["bout"].min())
    last_bout = int(post["bout"].max())
    width = int(spec.sustained_window_bouts)
    need = int(spec.sustained_min_successes)
    if width < 1 or need < 1 or need > width:
        raise ValueError("invalid sustained binding specification")
    for start_bout in range(first_bout, last_bout + 1):
        stop_bout = start_bout + width - 1
        window = post[post["bout"].between(start_bout, stop_bout)]
        success_bouts = np.sort(window["bout"].astype(int).unique())
        if success_bouts.size < need:
            continue
        qualifying = window[window["bout"].isin(success_bouts[:need])].sort_values(
            "onset_abs_frame", kind="stable"
        )
        first_index = int(qualifying.index[0])
        confirmation_bout = int(success_bouts[need - 1])
        confirmation = (
            window[window["bout"].eq(confirmation_bout)]
            .sort_values("onset_abs_frame", kind="stable")
            .iloc[0]
        )
        return {
            "status": "observed",
            "binding_path_index": first_index,
            "binding_window_start_bout": int(start_bout),
            "binding_window_stop_bout": int(stop_bout),
            "binding_success_bouts": success_bouts[:need].tolist(),
            "binding_confirmation_abs_frame": float(confirmation["onset_abs_frame"]),
            "binding_confirmation_maze_seconds": float(
                confirmation["onset_maze_seconds"]
            ),
        }
    return {
        "status": "right_censored_no_sustained_cluster",
        "binding_path_index": None,
    }


def _count_between(
    transitions: pd.DataFrame | None,
    *,
    start_frame: float,
    stop_frame: float,
    mask_column: str | None = None,
) -> float:
    if transitions is None or transitions.empty or not np.isfinite(stop_frame):
        return np.nan
    starts = pd.to_numeric(transitions["abs_frame_start"], errors="coerce")
    keep = starts.ge(start_frame) & starts.lt(stop_frame)
    if mask_column is not None:
        keep &= transitions[mask_column].astype(bool)
    return float(keep.sum())


def compute_reward_learning_endpoints(
    tf: Any,
    ma: Maze,
    *,
    transitions: pd.DataFrame | None = None,
    reward_events: pd.DataFrame | None = None,
    spec: RewardBindingSpec = RewardBindingSpec(),
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Compute auditable discovery, binding, and legacy execution outcomes."""

    reward_frames = _reward_frames(tf, reward_events=reward_events)
    first_reward = float(reward_frames[0]) if reward_frames.size else np.nan
    first_reward_time = np.nan
    if reward_frames.size and reward_events is not None and len(reward_events):
        ordered = reward_events.assign(
            _frame=pd.to_numeric(reward_events["reward_abs_frame"], errors="coerce")
        ).sort_values("_frame", kind="stable")
        if "reward_maze_seconds" in ordered:
            first_reward_time = float(
                pd.to_numeric(ordered.iloc[0]["reward_maze_seconds"], errors="coerce")
            )
    if reward_frames.size and not np.isfinite(first_reward_time):
        first_reward_time = float(TimeInMaze(first_reward, tf))
    paths = reward_path_table(tf, ma, spec)
    binding = find_sustained_binding_path(
        paths,
        first_reward_abs_frame=first_reward,
        spec=spec,
    )
    long_paths = (
        paths[paths["qualifying_long_path"].astype(bool)] if len(paths) else paths
    )
    legacy = long_paths.iloc[0] if len(long_paths) else None
    binding_row = (
        paths.loc[int(binding["binding_path_index"])]
        if binding.get("binding_path_index") is not None
        else None
    )
    binding_abs = (
        float(binding_row["onset_abs_frame"]) if binding_row is not None else np.nan
    )
    binding_time = (
        float(binding_row["onset_maze_seconds"]) if binding_row is not None else np.nan
    )
    outcome = {
        "n_rewards": int(reward_frames.size),
        "reward_event_source": (
            "phase0_frozen_actual_reward_events"
            if reward_events is not None
            else "live_tf.re_phase0_extractor"
        ),
        "discovery_observed": bool(reward_frames.size),
        "first_reward_abs_frame": first_reward,
        "T_discovery_time_s": first_reward_time,
        "binding_status": str(binding["status"]),
        "binding_observed": binding_row is not None,
        "binding_abs_frame": binding_abs,
        "binding_maze_seconds": binding_time,
        "T_binding_time_s": (
            float(binding_time - first_reward_time)
            if binding_row is not None and np.isfinite(first_reward_time)
            else np.nan
        ),
        "T_binding_node_transitions": _count_between(
            transitions, start_frame=first_reward, stop_frame=binding_abs
        ),
        "T_binding_primary_decisions": _count_between(
            transitions,
            start_frame=first_reward,
            stop_frame=binding_abs,
            mask_column="is_primary_decision",
        ),
        "legacy_lb0_abs_frame": (
            float(legacy["onset_abs_frame"]) if legacy is not None else np.nan
        ),
        "legacy_lb0_maze_seconds": (
            float(legacy["onset_maze_seconds"]) if legacy is not None else np.nan
        ),
        "legacy_lb0_predates_reward": bool(
            legacy is not None
            and np.isfinite(first_reward)
            and float(legacy["onset_abs_frame"]) < first_reward
        ),
        **{key: value for key, value in binding.items() if key != "binding_path_index"},
    }
    if transitions is not None and not transitions.empty and np.isfinite(first_reward):
        first_entry = float(
            pd.to_numeric(transitions["abs_frame_start"], errors="coerce").min()
        )
        outcome["T_discovery_node_transitions"] = _count_between(
            transitions, start_frame=first_entry, stop_frame=first_reward
        )
        outcome["T_discovery_primary_decisions"] = _count_between(
            transitions,
            start_frame=first_entry,
            stop_frame=first_reward,
            mask_column="is_primary_decision",
        )
    else:
        outcome["T_discovery_node_transitions"] = np.nan
        outcome["T_discovery_primary_decisions"] = np.nan
    return outcome, paths


__all__ = [
    "RewardBindingSpec",
    "compute_reward_learning_endpoints",
    "find_sustained_binding_path",
    "reward_path_table",
]
