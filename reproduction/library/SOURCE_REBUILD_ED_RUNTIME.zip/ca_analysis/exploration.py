from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Callable, Sequence

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import curve_fit

from .behavior import cover_time
from .behavior_models import fit_four_bias_model, predict_four_bias_walk
from .config import FPS
from .maze import NewMaze
from .mm_traj import Make2ndMarkov, NewNodes4
from .stats import compute_gini_coefficient
from .trajectory import LoadTraj, SplitModeClips


# Inner/outer node sets copied from Maze_Analysis_3C lineage (node ids, not zero-shifted indices).
DEFAULT_INNER_NODES = np.array([75, 76, 77, 78, 87, 88, 89, 90, 99, 100, 101, 102, 111, 112, 113, 114], dtype=int)
DEFAULT_OUTER_NODES = np.array(
    [63, 65, 71, 73, 95, 97, 103, 105, 106, 109, 110, 121, 122, 125, 126, 124, 94, 92, 86, 84, 83, 80, 79, 68, 67, 64],
    dtype=int,
)
_MODE_OFFSETS = {"random": 0, "4bias": 1000, "uniform": 2000}


@dataclass
class ExplorationMetricSet:
    nickname: str
    n_explore_endnodes: int
    half_cover_eff: float
    late_cover_eff: float
    late_minus_early: float
    late_over_early: float
    auc_unique_norm: float
    sliding_unique_mean: float
    new_node_rate_mean: float
    revisit_eff_mean: float
    recurrence_lag_median: float
    entropy_norm_mean: float
    gini_mean: float
    outer_inner_ratio_mean: float
    outer_inner_preference_mean: float
    fit_eff_numstates_over_a: float


@dataclass
class AxisConfig:
    axis_name: str
    bin_width: float
    horizon: float | None = None
    window_steps: int = 100
    window_seconds: float = 60.0
    common_horizon_quantile: float = 0.75


def _safe_rolling_nanmean(arr: np.ndarray, window_size: int) -> np.ndarray:
    x = np.asarray(arr, dtype=float).ravel()
    w = int(max(1, window_size))
    if x.size == 0:
        return np.asarray([], dtype=float)
    out = np.full(x.size, np.nan, dtype=float)
    for i in range(x.size):
        lo = max(0, i - w + 1)
        seg = x[lo : i + 1]
        seg = seg[np.isfinite(seg)]
        if seg.size:
            out[i] = float(np.nanmean(seg))
    return out


def _frame_to_maze_seconds(abs_frames: np.ndarray, tf: Any, *, fps: float = FPS) -> np.ndarray:
    frames = np.asarray(abs_frames, dtype=float).ravel()
    if frames.size == 0:
        return np.asarray([], dtype=float)
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    if fr.ndim != 2 or fr.shape[1] < 2 or fr.shape[0] == 0:
        return frames / float(max(fps, 1e-9))
    starts = fr[:, 0].astype(float, copy=False)
    ends = fr[:, 1].astype(float, copy=False)
    lengths = np.maximum(0.0, ends - starts)
    cum = np.zeros(fr.shape[0], dtype=float)
    if cum.size > 1:
        cum[1:] = np.cumsum(lengths[:-1])
    idx = np.searchsorted(starts, frames, side="right") - 1
    out = np.full(frames.size, np.nan, dtype=float)
    ok = (idx >= 0) & (idx < fr.shape[0])
    if np.any(ok):
        ii = idx[ok]
        f = frames[ok]
        valid = f <= ends[ii]
        j = np.where(ok)[0][valid]
        if j.size:
            iii = idx[j]
            out[j] = (cum[iii] + (frames[j] - starts[iii])) / float(max(fps, 1e-9))
    if np.any(~np.isfinite(out)):
        fallback = frames / float(max(fps, 1e-9))
        bad = ~np.isfinite(out)
        out[bad] = fallback[bad]
    return out


def build_exploration_axis_table(
    ns_frames: np.ndarray,
    tf: Any | None = None,
    *,
    fps: float = FPS,
) -> pd.DataFrame:
    fr = np.asarray(ns_frames, dtype=float).ravel()
    n = int(fr.size)
    if n == 0:
        return pd.DataFrame(columns=["step_index", "abs_frame", "maze_seconds", "progression_frac"])
    step_index = np.arange(n, dtype=int)
    if tf is None:
        maze_seconds = fr / float(max(fps, 1e-9))
    else:
        maze_seconds = _frame_to_maze_seconds(fr, tf, fps=fps)
    denom = float(max(1, n - 1))
    progression = step_index.astype(float) / denom
    return pd.DataFrame(
        {
            "step_index": step_index,
            "abs_frame": fr.astype(float, copy=False),
            "maze_seconds": maze_seconds.astype(float, copy=False),
            "progression_frac": progression,
        }
    )


def end_level_nodes(level: int = 6) -> np.ndarray:
    return np.arange(2**level - 1, 2 ** (level + 1) - 1, dtype=int)


def _safe_series_mean(x: np.ndarray) -> float:
    arr = np.asarray(x, dtype=float)
    arr = arr[np.isfinite(arr)]
    return float(np.nanmean(arr)) if arr.size else np.nan


def _safe_series_median(x: np.ndarray) -> float:
    arr = np.asarray(x, dtype=float)
    arr = arr[np.isfinite(arr)]
    return float(np.nanmedian(arr)) if arr.size else np.nan


def _rolling_mean(x: np.ndarray, window_size: int) -> np.ndarray:
    arr = np.asarray(x, dtype=float).ravel()
    w = int(window_size)
    if w <= 0 or arr.size < w:
        return np.asarray([], dtype=float)
    cs = np.cumsum(np.insert(arr, 0, 0.0))
    return (cs[w:] - cs[:-w]) / float(w)


def _rolling_nanmedian(x: np.ndarray, window_size: int) -> np.ndarray:
    arr = np.asarray(x, dtype=float).ravel()
    w = int(window_size)
    if w <= 0 or arr.size < w:
        return np.asarray([], dtype=float)
    rolled = pd.Series(arr).rolling(window=w, min_periods=1).median().to_numpy(dtype=float)
    return rolled[w - 1 :]


def _make_step_bin_edges(n_steps: int, n_bins: int) -> np.ndarray:
    n = int(max(0, n_steps))
    b = int(max(1, n_bins))
    return np.linspace(0.0, float(max(1, n)), b + 1)


def _binned_curve_from_positions(
    values: np.ndarray,
    positions: np.ndarray,
    *,
    total_steps: int,
    n_bins: int,
    metric: str,
    agg: str = "mean",
) -> pd.DataFrame:
    vals = np.asarray(values, dtype=float).ravel()
    pos = np.asarray(positions, dtype=float).ravel()
    b = int(max(1, n_bins))
    if vals.size == 0 or pos.size == 0:
        return pd.DataFrame(
            {
                "metric": [metric] * b,
                "bin_index": np.arange(b, dtype=int),
                "value": np.full(b, np.nan, dtype=float),
                "n_points": np.zeros(b, dtype=int),
            }
        )
    edges = _make_step_bin_edges(total_steps, b)
    out_val = np.full(b, np.nan, dtype=float)
    out_n = np.zeros(b, dtype=int)
    for bi in range(b):
        lo = edges[bi]
        hi = edges[bi + 1]
        if bi == b - 1:
            m = (pos >= lo) & (pos <= hi)
        else:
            m = (pos >= lo) & (pos < hi)
        seg = vals[m]
        seg = seg[np.isfinite(seg)]
        out_n[bi] = int(seg.size)
        if seg.size == 0:
            continue
        if agg == "median":
            out_val[bi] = float(np.nanmedian(seg))
        else:
            out_val[bi] = float(np.nanmean(seg))
    return pd.DataFrame(
        {
            "metric": [metric] * b,
            "bin_index": np.arange(b, dtype=int),
            "value": out_val,
            "n_points": out_n,
        }
    )


def _curve_summary(df: pd.DataFrame, *, eps: float = 1e-9) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(
            columns=[
                "metric",
                "early_mean",
                "late_mean",
                "delta",
                "ratio",
                "slope_theilsen",
            ]
        )
    rows = []
    for metric, sub in df.groupby("metric"):
        ss = sub.sort_values("bin_index")
        y = ss["value"].to_numpy(dtype=float)
        x = ss["bin_index"].to_numpy(dtype=float)
        ok = np.isfinite(y) & np.isfinite(x)
        y = y[ok]
        x = x[ok]
        if y.size == 0:
            rows.append(
                {
                    "metric": metric,
                    "early_mean": np.nan,
                    "late_mean": np.nan,
                    "delta": np.nan,
                    "ratio": np.nan,
                    "slope_theilsen": np.nan,
                }
            )
            continue
        q = max(1, int(np.ceil(0.25 * y.size)))
        early = float(np.nanmean(y[:q]))
        late = float(np.nanmean(y[-q:]))
        try:
            slope = float(stats.theilslopes(y, x).slope)
        except Exception:
            slope = np.nan
        rows.append(
            {
                "metric": metric,
                "early_mean": early,
                "late_mean": late,
                "delta": late - early,
                "ratio": float(late / (early + eps)),
                "slope_theilsen": slope,
            }
        )
    return pd.DataFrame(rows)


def extract_explore_endnode_sequence(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    end_level: int = 6,
    return_frames: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    if cl.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_parts: list[np.ndarray] = []
    frame_parts: list[np.ndarray] = []
    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep])
        if seg.ndim != 2 or seg.shape[1] < 2:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        abs_frames = seg[:, 1].astype(int, copy=False) + int(tf.fr[bout, 0])
        nodes_parts.append(nodes)
        frame_parts.append(abs_frames)

    if not nodes_parts:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_all = np.concatenate(nodes_parts).astype(int, copy=False)
    frames_all = np.concatenate(frame_parts).astype(int, copy=False)
    keep = np.isin(nodes_all, end_level_nodes(end_level))
    nodes_keep = nodes_all[keep]
    frames_keep = frames_all[keep]
    if return_frames:
        return nodes_keep, frames_keep
    return nodes_keep


def extract_explore_node_sequence(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    return_frames: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    if cl.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_parts: list[np.ndarray] = []
    frame_parts: list[np.ndarray] = []
    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep + 1])
        if seg.ndim != 2 or seg.shape[1] < 2:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        abs_frames = seg[:, 1].astype(int, copy=False) + int(tf.fr[bout, 0])
        nodes_parts.append(nodes)
        frame_parts.append(abs_frames)

    if not nodes_parts:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_all = np.concatenate(nodes_parts).astype(int, copy=False)
    frames_all = np.concatenate(frame_parts).astype(int, copy=False)
    if return_frames:
        return nodes_all, frames_all
    return nodes_all


def _turning_bias_event_table(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    fps: float = FPS,
) -> pd.DataFrame:
    nodes, abs_frames = extract_explore_node_sequence(
        tf,
        ma,
        split_mode_clips_fn=split_mode_clips_fn,
        explore_idx=explore_idx,
        return_frames=True,
    )
    seq = np.asarray(nodes, dtype=int).ravel()
    frames = np.asarray(abs_frames, dtype=float).ravel()
    cols = [
        "step_index",
        "abs_frame",
        "maze_seconds",
        "progression_frac",
        "prev_node",
        "current_node",
        "next_node",
        "entry_step_type",
        "exit_step_type",
        "Bf",
        "Ba",
        "Lf",
        "Lo",
    ]
    if seq.size < 3 or frames.size != seq.size:
        return pd.DataFrame(columns=cols)

    prev_nodes = seq[:-2]
    cur_nodes = seq[1:-1]
    next_nodes = seq[2:]
    step_index = np.arange(1, seq.size - 1, dtype=int)
    abs_frame = frames[1:-1]
    maze_seconds = _frame_to_maze_seconds(abs_frame, tf, fps=fps)
    progression_denom = float(max(1, seq.size - 1))
    progression_frac = step_index.astype(float) / progression_denom

    st = np.asarray(ma.st, dtype=int)
    in_bounds = (
        (prev_nodes >= 0)
        & (prev_nodes < st.shape[0])
        & (cur_nodes >= 0)
        & (cur_nodes < st.shape[0])
        & (next_nodes >= 0)
        & (next_nodes < st.shape[1])
    )
    entry_step_type = np.full(step_index.shape, -1, dtype=int)
    exit_step_type = np.full(step_index.shape, -1, dtype=int)
    if np.any(in_bounds):
        ii = np.where(in_bounds)[0]
        entry_step_type[ii] = st[prev_nodes[ii], cur_nodes[ii]]
        exit_step_type[ii] = st[cur_nodes[ii], next_nodes[ii]]

    max_internal = int(2**int(ma.le) - 2)
    valid_center = (cur_nodes >= 1) & (cur_nodes <= max_internal)
    valid_event = valid_center & (entry_step_type >= 0) & (exit_step_type >= 0)

    Bf = np.full(step_index.shape, np.nan, dtype=float)
    Ba = np.full(step_index.shape, np.nan, dtype=float)
    Lf = np.full(step_index.shape, np.nan, dtype=float)
    Lo = np.full(step_index.shape, np.nan, dtype=float)

    bottom = valid_event & np.isin(entry_step_type, np.array([0, 1], dtype=int))
    if np.any(bottom):
        Bf[bottom] = np.isin(exit_step_type[bottom], np.array([0, 1], dtype=int)).astype(float)
        bottom_forward = bottom & (Bf == 1.0)
        alt_exit = np.where(entry_step_type == 0, 1, 0)
        Ba[bottom_forward] = (exit_step_type[bottom_forward] == alt_exit[bottom_forward]).astype(float)

    side = valid_event & np.isin(entry_step_type, np.array([2, 3], dtype=int))
    if np.any(side):
        reverse_exit = np.where(entry_step_type == 2, 0, 1)
        Lf[side] = (exit_step_type[side] != reverse_exit[side]).astype(float)
        side_forward = side & (Lf == 1.0)
        Lo[side_forward] = np.isin(exit_step_type[side_forward], np.array([2, 3], dtype=int)).astype(float)

    return pd.DataFrame(
        {
            "step_index": step_index,
            "abs_frame": abs_frame,
            "maze_seconds": maze_seconds,
            "progression_frac": progression_frac,
            "prev_node": prev_nodes,
            "current_node": cur_nodes,
            "next_node": next_nodes,
            "entry_step_type": entry_step_type,
            "exit_step_type": exit_step_type,
            "Bf": Bf,
            "Ba": Ba,
            "Lf": Lf,
            "Lo": Lo,
        }
    )


def _neighbor_table(ma: Any) -> np.ndarray:
    n = int(len(ma.ru))
    out = np.full((n, 3), -1, dtype=int)
    out[:, 0] = np.asarray(ma.pa, dtype=int)
    ch = np.asarray(ma.ch, dtype=int)
    if ch.ndim == 2 and ch.shape[1] >= 2:
        st = np.asarray(ma.st, dtype=int)
        for node in range(n):
            c0 = int(ch[node, 0])
            c1 = int(ch[node, 1])
            if c0 < 0 or c1 < 0:
                continue
            if int(st[node, c0]) == 0:
                out[node, 1] = c0
                out[node, 2] = c1
            else:
                out[node, 1] = c1
                out[node, 2] = c0
    if n:
        out[0, 0] = n
    return out


def _turning_bias_counts_by_node(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    max_maze_seconds: float | None = None,
    fps: float = FPS,
) -> tuple[np.ndarray, int]:
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    counts = np.zeros((len(ma.ru), 3, 3), dtype=float)
    if cl.size == 0:
        return counts, 0
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        return counts, 0

    neighbors = _neighbor_table(ma)
    n_events = 0
    cutoff = None if max_maze_seconds is None or not np.isfinite(max_maze_seconds) else float(max_maze_seconds)
    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep + 1])
        if seg.ndim != 2 or seg.shape[1] < 2 or seg.shape[0] < 3:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        abs_frames = seg[:, 1].astype(float, copy=False) + float(tf.fr[bout, 0])
        if cutoff is None:
            maze_seconds = None
        else:
            maze_seconds = _frame_to_maze_seconds(abs_frames[1:-1], tf, fps=fps)
        for idx in range(1, nodes.size - 1):
            if maze_seconds is not None and float(maze_seconds[idx - 1]) > cutoff:
                continue
            prev_node = int(nodes[idx - 1])
            cur_node = int(nodes[idx])
            next_node = int(nodes[idx + 1])
            if cur_node < 0 or cur_node >= neighbors.shape[0]:
                continue
            sta = neighbors[cur_node]
            j = np.where(sta == prev_node)[0]
            k = np.where(sta == next_node)[0]
            if j.size == 0 or k.size == 0:
                continue
            counts[cur_node, int(j[0]), int(k[0])] += 1.0
            n_events += 1
    return counts, int(n_events)


def compute_turning_bias_timecurves(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    axes: Sequence[str] | None = ("fixed_step", "fixed_time"),
    n_bins: int = 20,
    step_bin_size: float = 100.0,
    time_bin_seconds: float = 30.0,
    step_horizon: float | None = None,
    time_horizon_seconds: float | None = None,
    reward_align_pre_seconds: float = 300.0,
    reward_align_post_seconds: float = 900.0,
    variant: str = "full_session",
    fps: float = FPS,
) -> dict[str, pd.DataFrame]:
    event_df = _turning_bias_event_table(
        tf,
        ma,
        split_mode_clips_fn=split_mode_clips_fn,
        explore_idx=explore_idx,
        fps=fps,
    )
    empty_curves = pd.DataFrame(
        columns=[
            "metric",
            "axis_bin",
            "axis_start",
            "axis_end",
            "value",
            "n_points",
            "time_axis",
            "axis_unit",
            "variant",
        ]
    )
    if event_df.empty:
        return {
            "curves_df": empty_curves,
            "summary_df": pd.DataFrame(columns=["metric", "early_mean", "late_mean", "delta", "ratio", "slope_theilsen", "time_axis", "variant"]),
            "event_df": event_df,
        }

    ax_list = list(axes) if axes is not None else ["fixed_step", "fixed_time"]
    axis_configs = []
    for ax in ax_list:
        if ax == "explore_node_bin":
            axis_configs.append(AxisConfig(axis_name=ax, bin_width=1.0 / float(max(1, n_bins)), horizon=1.0))
        elif ax == "fixed_step":
            axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(step_bin_size), horizon=step_horizon))
        elif ax == "fixed_time":
            axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(time_bin_seconds), horizon=time_horizon_seconds))
        elif ax == "reward_aligned_time":
            axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(time_bin_seconds), horizon=None))

    curves_all = []
    for cfg in axis_configs:
        axis_name = str(cfg.axis_name)
        if axis_name == "explore_node_bin":
            axis_values = event_df["progression_frac"].to_numpy(dtype=float)
            axis_unit = "fraction"
        elif axis_name == "fixed_step":
            axis_values = event_df["step_index"].to_numpy(dtype=float)
            axis_unit = "step"
        elif axis_name == "fixed_time":
            axis_values = event_df["maze_seconds"].to_numpy(dtype=float)
            axis_unit = "second"
        else:
            continue
        edges = _axis_edges(
            axis_name,
            axis_values=axis_values,
            cfg=cfg,
            n_bins=n_bins,
            reward_align_pre_seconds=reward_align_pre_seconds,
            reward_align_post_seconds=reward_align_post_seconds,
        )
        if edges.size < 2:
            continue
        for metric in ("Bf", "Ba", "Lf", "Lo"):
            dfm = _bin_metric_by_axis(
                metric,
                event_df[metric].to_numpy(dtype=float),
                axis_values,
                edges=edges,
                agg="mean",
                axis_name=axis_name,
                axis_unit=axis_unit,
                variant=variant,
            )
            curves_all.append(dfm)

    curves_df = pd.concat(curves_all, ignore_index=True) if curves_all else empty_curves
    if curves_df.empty:
        summary_df = pd.DataFrame(columns=["metric", "early_mean", "late_mean", "delta", "ratio", "slope_theilsen", "time_axis", "variant"])
    else:
        srows = []
        for (ax, vr, metric), sub in curves_df.groupby(["time_axis", "variant", "metric"]):
            summ = _curve_summary(sub.rename(columns={"axis_bin": "bin_index"})[["metric", "bin_index", "value"]].copy())
            if summ.empty:
                continue
            row = summ.iloc[0].to_dict()
            row["time_axis"] = ax
            row["variant"] = vr
            row["metric"] = metric
            srows.append(row)
        summary_df = pd.DataFrame(srows)
    return {"curves_df": curves_df, "summary_df": summary_df, "event_df": event_df}


def compute_cross_visit_alternation(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    min_visits: int = 2,
) -> dict[str, float]:
    """Cross-visit spatial alternation at decision nodes during exploration.

    For each internal node, tracks the sequence of left/right choices across
    successive from-parent forward visits and measures how often the animal
    alternates direction compared to its previous visit to the same node.

    Returns dict with keys: CVSA, n_qualifying_nodes, n_total_decisions,
    mean_visits_per_node.
    """
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    out: dict[str, float] = {
        "CVSA": np.nan,
        "n_qualifying_nodes": 0,
        "n_total_decisions": 0,
        "mean_visits_per_node": np.nan,
    }
    if cl.size == 0:
        return out
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        return out

    neighbors = _neighbor_table(ma)
    max_internal = int(2 ** int(ma.le) - 1)

    # choice_seqs[node] = list of 0 (left) / 1 (right) choices across visits
    choice_seqs: dict[int, list[int]] = {}

    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep + 1])
        if seg.ndim != 2 or seg.shape[1] < 2 or seg.shape[0] < 3:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        for idx in range(1, nodes.size - 1):
            cur_node = int(nodes[idx])
            # Root (node 0) included here: its virtual parent (127) never
            # appears in real trajectories, so the from-parent check below
            # filters it out naturally.
            if cur_node < 0 or cur_node >= max_internal:
                continue
            prev_node = int(nodes[idx - 1])
            next_node = int(nodes[idx + 1])
            # Must arrive from parent
            if prev_node != int(neighbors[cur_node, 0]):
                continue
            # Must exit to a child (forward), not back to parent
            if next_node == int(neighbors[cur_node, 1]):
                choice = 0  # left
            elif next_node == int(neighbors[cur_node, 2]):
                choice = 1  # right
            else:
                continue
            choice_seqs.setdefault(cur_node, []).append(choice)

    # Compute per-node alternation rate
    alt_rates: list[float] = []
    total_decisions = 0
    total_visits = 0
    for node, choices in choice_seqs.items():
        n_vis = len(choices)
        if n_vis < int(min_visits):
            continue
        alternations = sum(1 for k in range(1, n_vis) if choices[k] != choices[k - 1])
        alt_rates.append(float(alternations) / float(n_vis - 1))
        total_decisions += n_vis
        total_visits += n_vis

    n_qual = len(alt_rates)
    out["n_qualifying_nodes"] = float(n_qual)
    out["n_total_decisions"] = float(total_decisions)
    if n_qual > 0:
        out["CVSA"] = float(np.mean(alt_rates))
        out["mean_visits_per_node"] = float(total_visits) / float(n_qual)
    return out


def compute_depth_stratified_lo(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    max_maze_seconds: float | None = None,
    fps: float = FPS,
) -> dict[str, float]:
    """P_BS (Lo) stratified by tree depth of the decision node.

    Splits internal nodes into shallow (depths 1-2), mid (3-4), and deep (5).
    Also computes depth-weighted P_BS where each event is weighted by the
    sub-tree size (2^(le - depth)).

    Returns dict with Lo_shallow, Lo_mid, Lo_deep, Lo_depth_weighted, and
    event counts for each stratum.
    """
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    out: dict[str, float] = {
        "Lo_shallow": np.nan, "Lo_mid": np.nan, "Lo_deep": np.nan,
        "Lo_depth_weighted": np.nan,
        "n_Lo_shallow": 0, "n_Lo_mid": 0, "n_Lo_deep": 0,
    }
    if cl.size == 0:
        return out
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        return out

    neighbors = _neighbor_table(ma)
    le = int(ma.le)
    max_internal = int(2 ** le - 1)

    # Precompute depth for each internal node (avoids per-event log2)
    node_depth = np.zeros(max_internal, dtype=int)
    for i in range(1, max_internal):
        node_depth[i] = int(np.floor(np.log2(i + 1)))

    # Per-depth Lo accumulators: {depth: [outward_count, total_forward_from_child]}
    depth_counts: dict[int, list[float]] = {d: [0.0, 0.0] for d in range(le + 1)}

    cutoff = (
        None
        if max_maze_seconds is None or not np.isfinite(max_maze_seconds)
        else float(max_maze_seconds)
    )
    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep + 1])
        if seg.ndim != 2 or seg.shape[1] < 2 or seg.shape[0] < 3:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        if cutoff is None:
            maze_seconds = None
        else:
            abs_frames = seg[:, 1].astype(float, copy=False) + float(tf.fr[bout, 0])
            maze_seconds = _frame_to_maze_seconds(abs_frames[1:-1], tf, fps=fps)
        for idx in range(1, nodes.size - 1):
            if maze_seconds is not None and float(maze_seconds[idx - 1]) > cutoff:
                continue
            cur_node = int(nodes[idx])
            if cur_node < 1 or cur_node >= max_internal:
                continue
            prev_node = int(nodes[idx - 1])
            next_node = int(nodes[idx + 1])
            parent = int(neighbors[cur_node, 0])
            left_child = int(neighbors[cur_node, 1])
            right_child = int(neighbors[cur_node, 2])
            if left_child < 0:
                continue
            # Must arrive from a child (not parent)
            if prev_node != left_child and prev_node != right_child:
                continue
            # Must go forward (not reverse back to same child)
            if next_node == prev_node:
                continue
            # Forward from child: exit to parent (outward) or to sibling (inward)
            depth = int(node_depth[cur_node])
            outward = 1.0 if next_node == parent else 0.0
            depth_counts[depth][0] += outward
            depth_counts[depth][1] += 1.0

    # Aggregate into strata. Depths deeper than this maze have no decision
    # nodes at all, so they are absent from depth_counts and contribute nothing.
    def _stratum_lo(depths: list[int]) -> tuple[float, int]:
        present = [depth_counts[d] for d in depths if d in depth_counts]
        num = sum(p[0] for p in present)
        den = sum(p[1] for p in present)
        return (float(num / den) if den > 0 else np.nan), int(den)

    out["Lo_shallow"], out["n_Lo_shallow"] = _stratum_lo([1, 2])
    out["Lo_mid"], out["n_Lo_mid"] = _stratum_lo([3, 4])
    out["Lo_deep"], out["n_Lo_deep"] = _stratum_lo([5])

    # Depth-weighted Lo: weight = 2^(le - depth)
    w_num, w_den = 0.0, 0.0
    for d in range(1, le + 1):
        weight = float(2 ** (le - d))
        w_num += depth_counts[d][0] * weight
        w_den += depth_counts[d][1] * weight
    out["Lo_depth_weighted"] = float(w_num / w_den) if w_den > 0 else np.nan

    return out


def _subtree_leaves(node: int, ma: Any) -> set[int]:
    """Return the set of leaf (endpoint) run-node indices under *node*."""
    le = int(ma.le)
    leaf_start = 2 ** le - 1
    leaves: set[int] = set()
    ch = np.asarray(ma.ch, dtype=int)
    stack = [node]
    while stack:
        n = stack.pop()
        if n >= leaf_start:
            leaves.add(n)
        elif ch.ndim == 2 and ch.shape[1] >= 2:
            c0, c1 = int(ch[n, 0]), int(ch[n, 1])
            if c0 >= 0:
                stack.append(c0)
            if c1 >= 0:
                stack.append(c1)
    return leaves


def compute_conditional_lo(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
) -> dict[str, float]:
    """Lo (P_BS) conditioned on whether the sibling sub-tree is explored.

    Decomposes from-child forward decisions into two contexts:
    - sibling sub-tree has unvisited endpoints -> optimal action is go INWARD
    - sibling sub-tree fully explored -> optimal action is go OUTWARD
    Lo_sensitivity = Lo_sib_explored - Lo_sib_unexplored measures
    context-appropriate backtracking (memory-guided navigation).
    """
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    out: dict[str, float] = {
        "Lo_sib_unexplored": np.nan,
        "Lo_sib_explored": np.nan,
        "Lo_sensitivity": np.nan,
        "n_sib_unexplored": 0,
        "n_sib_explored": 0,
    }
    if cl.size == 0:
        return out
    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        return out

    neighbors = _neighbor_table(ma)
    le = int(ma.le)
    max_internal = int(2 ** le - 1)
    leaf_start = 2 ** le - 1

    # Precompute subtree leaf sets for all internal nodes
    sib_leaves_cache: dict[int, set[int]] = {}
    for node in range(max_internal):
        left_child = int(neighbors[node, 1])
        right_child = int(neighbors[node, 2])
        if left_child >= 0:
            sib_leaves_cache[(node, left_child)] = _subtree_leaves(right_child, ma)
            sib_leaves_cache[(node, right_child)] = _subtree_leaves(left_child, ma)

    visited_leaves: set[int] = set()
    outward_unexplored, total_unexplored = 0.0, 0.0
    outward_explored, total_explored = 0.0, 0.0

    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep + 1])
        if seg.ndim != 2 or seg.shape[1] < 2 or seg.shape[0] < 3:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        for idx in range(nodes.size):
            n = int(nodes[idx])
            if n >= leaf_start:
                visited_leaves.add(n)

            if idx < 1 or idx >= nodes.size - 1:
                continue
            cur_node = int(nodes[idx])
            if cur_node < 1 or cur_node >= max_internal:
                continue
            prev_node = int(nodes[idx - 1])
            next_node = int(nodes[idx + 1])
            parent = int(neighbors[cur_node, 0])
            left_child = int(neighbors[cur_node, 1])
            right_child = int(neighbors[cur_node, 2])
            if left_child < 0:
                continue
            # Must arrive from a child
            if prev_node != left_child and prev_node != right_child:
                continue
            # Must go forward (not reverse)
            if next_node == prev_node:
                continue

            # Sibling sub-tree leaf set
            sib_key = (cur_node, prev_node)
            if sib_key not in sib_leaves_cache:
                continue
            sib_leaves = sib_leaves_cache[sib_key]
            sib_all_explored = sib_leaves.issubset(visited_leaves)

            outward = 1.0 if next_node == parent else 0.0

            if sib_all_explored:
                outward_explored += outward
                total_explored += 1.0
            else:
                outward_unexplored += outward
                total_unexplored += 1.0

    lo_unexp = float(outward_unexplored / total_unexplored) if total_unexplored > 0 else np.nan
    lo_exp = float(outward_explored / total_explored) if total_explored > 0 else np.nan
    out["Lo_sib_unexplored"] = lo_unexp
    out["Lo_sib_explored"] = lo_exp
    out["n_sib_unexplored"] = int(total_unexplored)
    out["n_sib_explored"] = int(total_explored)
    if total_unexplored > 0 and total_explored > 0:
        out["Lo_sensitivity"] = lo_exp - lo_unexp
    return out


def compute_turning_bias_summary(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    max_maze_seconds: float | None = None,
    fps: float = FPS,
) -> dict[str, float]:
    counts, n_events = _turning_bias_counts_by_node(
        tf,
        ma,
        split_mode_clips_fn=split_mode_clips_fn,
        explore_idx=explore_idx,
        max_maze_seconds=max_maze_seconds,
        fps=fps,
    )
    out = {"Bf": np.nan, "Ba": np.nan, "Lf": np.nan, "Lo": np.nan, "n_events": int(n_events)}
    if n_events <= 0:
        return out

    st = np.asarray(ma.st, dtype=int)
    max_internal = int(2**int(ma.le) - 1)
    bf_vals: list[float] = []
    ba_vals: list[float] = []
    lf_vals: list[float] = []
    lo_vals: list[float] = []
    rf_vals: list[float] = []
    ro_vals: list[float] = []
    for node in range(1, max_internal):
        tr = counts[node]
        b = float(np.sum(tr[0]))
        if b > 0:
            bf = float((tr[0, 1] + tr[0, 2]) / b)
            bf_vals.append(bf)
            if bf > 0:
                if int(st[int(ma.pa[node]), node]) == 0:
                    ba_vals.append(float(tr[0, 2] / (tr[0, 1] + tr[0, 2])))
                else:
                    ba_vals.append(float(tr[0, 1] / (tr[0, 1] + tr[0, 2])))
        l = float(np.sum(tr[1]))
        if l > 0:
            lf = float((tr[1, 0] + tr[1, 2]) / l)
            lf_vals.append(lf)
            if lf > 0:
                lo_vals.append(float(tr[1, 0] / (tr[1, 0] + tr[1, 2])))
        r = float(np.sum(tr[2]))
        if r > 0:
            rf = float((tr[2, 0] + tr[2, 1]) / r)
            rf_vals.append(rf)
            if rf > 0:
                ro_vals.append(float(tr[2, 0] / (tr[2, 0] + tr[2, 1])))

    out["Bf"] = float(np.nanmean(np.asarray(bf_vals, dtype=float))) if bf_vals else np.nan
    out["Ba"] = float(np.nanmean(np.asarray(ba_vals, dtype=float))) if ba_vals else np.nan
    side_forward = np.asarray(lf_vals + rf_vals, dtype=float)
    side_out = np.asarray(lo_vals + ro_vals, dtype=float)
    out["Lf"] = float(np.nanmean(side_forward)) if side_forward.size else np.nan
    out["Lo"] = float(np.nanmean(side_out)) if side_out.size else np.nan
    out["n_Bf"] = int(len(bf_vals))
    out["n_Ba"] = int(len(ba_vals))
    out["n_Lf"] = int(side_forward.size)
    out["n_Lo"] = int(side_out.size)
    return out


def safe_cover_efficiency(ns: np.ndarray, *, num_states: int = 32) -> float:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size == 0:
        return 0.0
    ct = cover_time(seq, num_states=int(num_states))
    if ct is None or ct == 0:
        # If coverage target is never reached, define efficiency as 0 (failed cover).
        return 0.0
    return float(num_states) / float(ct)


def sliding_unique_efficiency(ns: np.ndarray, *, window_size: int = 100) -> np.ndarray:
    seq = np.asarray(ns, dtype=int).ravel()
    w = int(window_size)
    if w <= 0 or seq.size < w:
        return np.asarray([], dtype=float)
    vals = np.empty(seq.size - w + 1, dtype=float)
    counts = Counter(seq[:w].tolist())
    vals[0] = len(counts) / float(w)
    for i in range(1, vals.size):
        left = int(seq[i - 1])
        counts[left] -= 1
        if counts[left] <= 0:
            del counts[left]
        right = int(seq[i + w - 1])
        counts[right] = counts.get(right, 0) + 1
        vals[i] = len(counts) / float(w)
    return vals


def new_node_rate_curve(ns: np.ndarray, *, window_size: int = 100) -> np.ndarray:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size == 0:
        return np.asarray([], dtype=float)
    seen = set()
    first_flags = np.zeros(seq.size, dtype=float)
    for i, x in enumerate(seq):
        xx = int(x)
        if xx not in seen:
            first_flags[i] = 1.0
            seen.add(xx)
    return _rolling_mean(first_flags, int(window_size))


def normalized_unique_auc(ns: np.ndarray, *, num_states: int = 32) -> float:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size == 0 or num_states <= 0:
        return np.nan
    seen = set()
    u = np.empty(seq.size, dtype=float)
    for i, x in enumerate(seq):
        seen.add(int(x))
        u[i] = min(float(len(seen)), float(num_states)) / float(num_states)
    x = np.linspace(0.0, 1.0, seq.size)
    trapz_fn = getattr(np, "trapezoid", None)
    if trapz_fn is None:
        trapz_fn = np.trapz
    return float(trapz_fn(u, x))


def fit_new_nodes_curve(ns: np.ndarray, *, fpn: float = 1.0) -> tuple[float, float]:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size < 10:
        return np.nan, np.nan
    wcn = np.asarray(NewNodes4(seq, float(max(fpn, 1e-12))), dtype=float)
    if wcn.ndim != 2 or wcn.shape[0] < 3:
        return np.nan, np.nan
    x = np.asarray(wcn[1], dtype=float)
    y = np.asarray(wcn[2], dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]
    if x.size < 5:
        return np.nan, np.nan

    def func(xx, a, b):
        z = xx / a
        return 64.0 * (1.0 - 1.0 / (1.0 + (z + b * z**3) / (1.0 + b)))

    try:
        popt, _ = curve_fit(func, x, y, p0=[70.0, 0.1], maxfev=50000)
        return float(popt[0]), float(popt[1])
    except Exception:
        return np.nan, np.nan


def compute_revisit_metrics(
    ns: np.ndarray,
    *,
    window_size: int = 100,
    min_separation: int = 1,
) -> dict[str, np.ndarray]:
    seq = np.asarray(ns, dtype=int).ravel()
    n = seq.size
    revisit_flags = np.zeros(n, dtype=float)
    recurrence_lags = np.full(n, np.nan, dtype=float)
    last_seen: dict[int, int] = {}
    min_sep = int(max(1, min_separation))
    for i, x in enumerate(seq):
        xx = int(x)
        if xx in last_seen:
            lag = i - last_seen[xx]
            if i > 0 and seq[i] != seq[i - 1] and lag >= min_sep:
                revisit_flags[i] = 1.0
                recurrence_lags[i] = float(lag)
        last_seen[xx] = i

    revisit_frac = _rolling_mean(revisit_flags, int(window_size))
    revisit_eff = 1.0 - revisit_frac if revisit_frac.size else np.asarray([], dtype=float)
    recurrence_med = _rolling_nanmedian(recurrence_lags, int(window_size))
    return {
        "revisit_flags": revisit_flags,
        "recurrence_lags": recurrence_lags,
        "revisit_fraction_curve": revisit_frac,
        "revisit_eff_curve": revisit_eff,
        "recurrence_lag_curve": recurrence_med,
    }


def _state_ids_from_sequence(seq: np.ndarray, n_states: int) -> np.ndarray:
    seq_u = np.unique(np.asarray(seq, dtype=int).ravel())
    n = int(max(1, n_states))
    if seq_u.size >= n:
        return seq_u
    lo = int(np.min(seq_u)) if seq_u.size else 0
    return np.arange(lo, lo + n, dtype=int)


def compute_entropy_evenness_metrics(
    ns: np.ndarray,
    *,
    n_bins: int = 20,
    n_states: int = 32,
) -> dict[str, Any]:
    seq = np.asarray(ns, dtype=int).ravel()
    b = int(max(1, n_bins))
    if seq.size == 0:
        empty_curve = pd.DataFrame(
            {
                "metric": np.repeat(["entropy_bits", "entropy_norm", "gini"], b),
                "bin_index": np.tile(np.arange(b, dtype=int), 3),
                "value": np.nan,
                "n_points": 0,
            }
        )
        return {
            "curve_df": empty_curve,
            "entropy_norm_mean": np.nan,
            "gini_mean": np.nan,
        }

    edges = _make_step_bin_edges(seq.size, b)
    states = _state_ids_from_sequence(seq, n_states=n_states)
    idx_map = {int(s): i for i, s in enumerate(states.tolist())}
    ent = np.full(b, np.nan, dtype=float)
    ent_norm = np.full(b, np.nan, dtype=float)
    gini = np.full(b, np.nan, dtype=float)
    n_pts = np.zeros(b, dtype=int)
    denom = np.log2(max(int(n_states), 2))
    mapped = np.array([idx_map.get(int(x), -1) for x in seq], dtype=int)
    for bi in range(b):
        lo = int(np.floor(edges[bi]))
        hi = int(np.floor(edges[bi + 1]))
        seg = mapped[lo:hi]
        n_pts[bi] = int(seg.size)
        if seg.size == 0:
            continue
        seg = seg[seg >= 0]
        counts = np.bincount(seg, minlength=states.size).astype(float)
        p = counts[counts > 0]
        p = p / np.sum(p)
        h = float(-np.sum(p * np.log2(p))) if p.size else np.nan
        ent[bi] = h
        if np.isfinite(h):
            ent_norm[bi] = min(1.0, float(h / denom)) if denom > 0 else np.nan
        gini[bi] = float(compute_gini_coefficient(counts))

    curve_df = pd.concat(
        [
            pd.DataFrame({"metric": "entropy_bits", "bin_index": np.arange(b), "value": ent, "n_points": n_pts}),
            pd.DataFrame({"metric": "entropy_norm", "bin_index": np.arange(b), "value": ent_norm, "n_points": n_pts}),
            pd.DataFrame({"metric": "gini", "bin_index": np.arange(b), "value": gini, "n_points": n_pts}),
        ],
        ignore_index=True,
    )
    return {
        "curve_df": curve_df,
        "entropy_norm_mean": _safe_series_mean(ent_norm),
        "gini_mean": _safe_series_mean(gini),
    }


def compute_inner_outer_preference_metrics(
    ns: np.ndarray,
    *,
    inner_nodes: np.ndarray | None = None,
    outer_nodes: np.ndarray | None = None,
    window_size: int = 100,
    n_bins: int = 20,
    eps: float = 1e-9,
) -> dict[str, Any]:
    seq = np.asarray(ns, dtype=int).ravel()
    b = int(max(1, n_bins))
    inner = np.asarray(DEFAULT_INNER_NODES if inner_nodes is None else inner_nodes, dtype=int).ravel()
    outer = np.asarray(DEFAULT_OUTER_NODES if outer_nodes is None else outer_nodes, dtype=int).ravel()
    if seq.size == 0:
        empty_curve = pd.DataFrame(
            {
                "metric": np.repeat(["outer_frac", "inner_frac", "outer_inner_ratio", "log_outer_inner_ratio", "outer_inner_preference"], b),
                "bin_index": np.tile(np.arange(b, dtype=int), 5),
                "value": np.nan,
                "n_points": 0,
            }
        )
        return {
            "curve_df": empty_curve,
            "outer_inner_ratio_mean": np.nan,
            "outer_inner_preference_mean": np.nan,
        }

    f_in = np.isin(seq, inner).astype(float)
    f_out = np.isin(seq, outer).astype(float)
    in_curve = _rolling_mean(f_in, int(window_size))
    out_curve = _rolling_mean(f_out, int(window_size))
    if in_curve.size and out_curve.size:
        ratio = np.full(in_curve.shape, np.nan, dtype=float)
        valid_ratio = in_curve > 0
        ratio[valid_ratio] = out_curve[valid_ratio] / in_curve[valid_ratio]

        log_ratio = np.full(in_curve.shape, np.nan, dtype=float)
        valid_log = (in_curve > 0) & (out_curve > 0)
        log_ratio[valid_log] = np.log(out_curve[valid_log] / in_curve[valid_log])

        denom = out_curve + in_curve
        pref = np.full(in_curve.shape, np.nan, dtype=float)
        valid_pref = denom > 0
        pref[valid_pref] = (out_curve[valid_pref] - in_curve[valid_pref]) / denom[valid_pref]
        pos = np.arange(int(window_size) - 1, int(window_size) - 1 + in_curve.size, dtype=float)
    else:
        ratio = np.asarray([], dtype=float)
        log_ratio = np.asarray([], dtype=float)
        pref = np.asarray([], dtype=float)
        pos = np.asarray([], dtype=float)

    dfi = _binned_curve_from_positions(in_curve, pos, total_steps=seq.size, n_bins=b, metric="inner_frac")
    dfo = _binned_curve_from_positions(out_curve, pos, total_steps=seq.size, n_bins=b, metric="outer_frac")
    dfr = _binned_curve_from_positions(ratio, pos, total_steps=seq.size, n_bins=b, metric="outer_inner_ratio")
    dfl = _binned_curve_from_positions(log_ratio, pos, total_steps=seq.size, n_bins=b, metric="log_outer_inner_ratio")
    dfp = _binned_curve_from_positions(pref, pos, total_steps=seq.size, n_bins=b, metric="outer_inner_preference")
    curve_df = pd.concat([dfo, dfi, dfr, dfl, dfp], ignore_index=True)
    return {
        "curve_df": curve_df,
        "outer_inner_ratio_mean": _safe_series_mean(ratio),
        "outer_inner_preference_mean": _safe_series_mean(pref),
    }


def compute_scalar_efficiency_metrics(
    ns: np.ndarray,
    *,
    num_states: int = 32,
    window_size: int = 100,
    n_bins: int = 20,
    min_separation: int = 1,
    inner_nodes: np.ndarray | None = None,
    outer_nodes: np.ndarray | None = None,
    include_model_summary: bool = False,
) -> dict[str, Any]:
    seq = np.asarray(ns, dtype=int).ravel()
    cover = safe_cover_efficiency(seq, num_states=num_states)
    seq_late = seq[int(seq.size / 2) :] if seq.size else seq
    late = safe_cover_efficiency(seq_late, num_states=num_states)
    cover_reached = cover_time(seq, num_states=num_states) is not None
    late_cover_reached = cover_time(seq_late, num_states=num_states) is not None if seq_late.size else False
    auc = normalized_unique_auc(seq, num_states=num_states)
    suniq = sliding_unique_efficiency(seq, window_size=window_size)
    newr = new_node_rate_curve(seq, window_size=window_size)
    rv = compute_revisit_metrics(seq, window_size=window_size, min_separation=min_separation)
    ent = compute_entropy_evenness_metrics(seq, n_bins=n_bins, n_states=num_states)
    pref = compute_inner_outer_preference_metrics(
        seq,
        inner_nodes=inner_nodes,
        outer_nodes=outer_nodes,
        window_size=window_size,
        n_bins=n_bins,
    )
    fit_eff = np.nan
    if include_model_summary:
        a, _ = fit_new_nodes_curve(seq, fpn=1.0)
        fit_eff = float(num_states / a) if np.isfinite(a) and a != 0 else np.nan

    return {
        "n_explore_endnodes": int(seq.size),
        "cover_target_states": int(num_states),
        "cover_reached": bool(cover_reached),
        "late_cover_reached": bool(late_cover_reached),
        "half_cover_eff": float(cover),
        "late_cover_eff": float(late),
        "late_minus_early": float(late - cover),
        "late_over_early": float(late / (cover + 1e-9)) if np.isfinite(cover) else np.nan,
        "auc_unique_norm": float(auc),
        "sliding_unique_mean": _safe_series_mean(suniq),
        "new_node_rate_mean": _safe_series_mean(newr),
        "revisit_eff_mean": _safe_series_mean(rv["revisit_eff_curve"]),
        "recurrence_lag_median": _safe_series_median(rv["recurrence_lags"]),
        "entropy_norm_mean": float(ent["entropy_norm_mean"]),
        "gini_mean": float(ent["gini_mean"]),
        "outer_inner_ratio_mean": float(pref["outer_inner_ratio_mean"]),
        "outer_inner_preference_mean": float(pref["outer_inner_preference_mean"]),
        "fit_eff_numstates_over_a": float(fit_eff),
    }


def _rolling_entropy_gini_curve(
    ns: np.ndarray,
    *,
    window_size: int,
    n_states: int = 32,
) -> dict[str, np.ndarray]:
    seq = np.asarray(ns, dtype=int).ravel()
    w = int(max(1, window_size))
    if seq.size < w:
        return {
            "entropy_norm_curve": np.asarray([], dtype=float),
            "gini_curve": np.asarray([], dtype=float),
        }
    states = _state_ids_from_sequence(seq, n_states=n_states)
    idx_map = {int(s): i for i, s in enumerate(states.tolist())}
    mapped = np.array([idx_map.get(int(x), -1) for x in seq], dtype=int)
    denom = np.log2(max(int(n_states), 2))
    ent_norm = np.full(seq.size - w + 1, np.nan, dtype=float)
    gini = np.full(seq.size - w + 1, np.nan, dtype=float)
    for i in range(ent_norm.size):
        seg = mapped[i : i + w]
        seg = seg[seg >= 0]
        counts = np.bincount(seg, minlength=states.size).astype(float)
        p = counts[counts > 0]
        p = p / np.sum(p) if p.size else p
        h = float(-np.sum(p * np.log2(p))) if p.size else np.nan
        ent_norm[i] = min(1.0, float(h / denom)) if np.isfinite(h) and denom > 0 else np.nan
        gini[i] = float(compute_gini_coefficient(counts))
    return {"entropy_norm_curve": ent_norm, "gini_curve": gini}


def _metric_series_by_step(
    ns: np.ndarray,
    *,
    window_steps: int,
    num_states: int,
    min_separation: int,
    inner_nodes: np.ndarray | None = None,
    outer_nodes: np.ndarray | None = None,
) -> dict[str, dict[str, Any]]:
    seq = np.asarray(ns, dtype=int).ravel()
    n = int(seq.size)
    out: dict[str, dict[str, Any]] = {}
    if n == 0:
        return out
    seen = set()
    cov = np.empty(n, dtype=float)
    for i, x in enumerate(seq):
        seen.add(int(x))
        cov[i] = min(float(len(seen)), float(num_states)) / float(max(1, num_states))
    out["coverage_frac"] = {"step_index": np.arange(n, dtype=int), "value": cov, "agg": "mean"}

    suniq = sliding_unique_efficiency(seq, window_size=window_steps)
    newr = new_node_rate_curve(seq, window_size=window_steps)
    rv = compute_revisit_metrics(seq, window_size=window_steps, min_separation=min_separation)
    entg = _rolling_entropy_gini_curve(seq, window_size=window_steps, n_states=num_states)
    pos_roll = np.arange(window_steps - 1, window_steps - 1 + suniq.size, dtype=int) if suniq.size else np.asarray([], dtype=int)

    out["sliding_unique_eff"] = {"step_index": pos_roll, "value": suniq, "agg": "mean"}
    out["new_node_rate"] = {"step_index": pos_roll, "value": newr, "agg": "mean"}
    out["revisit_eff"] = {"step_index": pos_roll, "value": rv["revisit_eff_curve"], "agg": "mean"}
    out["recurrence_lag"] = {"step_index": pos_roll, "value": rv["recurrence_lag_curve"], "agg": "median"}
    out["entropy_norm"] = {"step_index": pos_roll, "value": entg["entropy_norm_curve"], "agg": "mean"}
    out["gini"] = {"step_index": pos_roll, "value": entg["gini_curve"], "agg": "mean"}

    inner = np.asarray(DEFAULT_INNER_NODES if inner_nodes is None else inner_nodes, dtype=int).ravel()
    outer = np.asarray(DEFAULT_OUTER_NODES if outer_nodes is None else outer_nodes, dtype=int).ravel()
    f_in = np.isin(seq, inner).astype(float)
    f_out = np.isin(seq, outer).astype(float)
    in_curve = _rolling_mean(f_in, window_steps)
    out_curve = _rolling_mean(f_out, window_steps)
    ratio = np.full(in_curve.shape, np.nan, dtype=float) if in_curve.size else np.asarray([], dtype=float)
    if in_curve.size:
        m = in_curve > 0
        ratio[m] = out_curve[m] / in_curve[m]
        pref = np.full(in_curve.shape, np.nan, dtype=float)
        d = out_curve + in_curve
        mp = d > 0
        pref[mp] = (out_curve[mp] - in_curve[mp]) / d[mp]
    else:
        pref = np.asarray([], dtype=float)
    out["outer_inner_ratio"] = {"step_index": pos_roll, "value": ratio, "agg": "mean"}
    out["outer_inner_preference"] = {"step_index": pos_roll, "value": pref, "agg": "mean"}
    return out


def _axis_edges(
    axis_name: str,
    *,
    axis_values: np.ndarray,
    cfg: AxisConfig,
    n_bins: int,
    reward_align_pre_seconds: float,
    reward_align_post_seconds: float,
) -> np.ndarray:
    vals = np.asarray(axis_values, dtype=float)
    vals = vals[np.isfinite(vals)]
    if axis_name == "explore_node_bin":
        b = int(max(1, n_bins))
        return np.linspace(0.0, 1.0, b + 1)
    if axis_name == "reward_aligned_time":
        w = float(max(1e-9, cfg.bin_width))
        lo = -float(abs(reward_align_pre_seconds))
        hi = float(abs(reward_align_post_seconds))
        n = int(max(1, np.ceil((hi - lo) / w)))
        edges = lo + w * np.arange(n + 1, dtype=float)
        if edges[-1] < hi:
            edges = np.append(edges, hi)
        return edges
    w = float(max(1e-9, cfg.bin_width))
    vmax = float(np.nanmax(vals)) if vals.size else 0.0
    h = float(cfg.horizon) if cfg.horizon is not None else vmax
    h = float(max(0.0, h))
    n = int(max(1, np.ceil(h / w)))
    edges = w * np.arange(n + 1, dtype=float)
    if edges[-1] < h:
        edges = np.append(edges, h)
    return edges


def _bin_metric_by_axis(
    metric: str,
    value: np.ndarray,
    axis_value: np.ndarray,
    *,
    edges: np.ndarray,
    agg: str,
    axis_name: str,
    axis_unit: str,
    variant: str,
) -> pd.DataFrame:
    vals = np.asarray(value, dtype=float).ravel()
    pos = np.asarray(axis_value, dtype=float).ravel()
    if vals.size == 0 or pos.size == 0:
        nb = int(max(0, edges.size - 1))
        return pd.DataFrame(
            {
                "metric": [metric] * nb,
                "axis_bin": np.arange(nb, dtype=int),
                "axis_start": edges[:-1] if nb else np.asarray([], dtype=float),
                "axis_end": edges[1:] if nb else np.asarray([], dtype=float),
                "value": np.full(nb, np.nan, dtype=float),
                "n_points": np.zeros(nb, dtype=int),
                "time_axis": [axis_name] * nb,
                "axis_unit": [axis_unit] * nb,
                "variant": [variant] * nb,
            }
        )
    out = []
    for bi in range(edges.size - 1):
        lo = float(edges[bi])
        hi = float(edges[bi + 1])
        if bi == edges.size - 2:
            m = (pos >= lo) & (pos <= hi)
        else:
            m = (pos >= lo) & (pos < hi)
        seg = vals[m]
        seg = seg[np.isfinite(seg)]
        if seg.size == 0:
            v = np.nan
            npt = 0
        elif agg == "median":
            v = float(np.nanmedian(seg))
            npt = int(seg.size)
        else:
            v = float(np.nanmean(seg))
            npt = int(seg.size)
        out.append(
            {
                "metric": metric,
                "axis_bin": int(bi),
                "axis_start": lo,
                "axis_end": hi,
                "value": v,
                "n_points": npt,
                "time_axis": axis_name,
                "axis_unit": axis_unit,
                "variant": variant,
            }
        )
    return pd.DataFrame(out)


def _add_time_smoothed_fixed_time_metrics(curves_df: pd.DataFrame, *, window_seconds: float) -> pd.DataFrame:
    if curves_df.empty:
        return curves_df
    sub = curves_df[curves_df["time_axis"] == "fixed_time"].copy()
    if sub.empty:
        return curves_df
    rows = []
    for metric in ("sliding_unique_eff", "new_node_rate", "revisit_eff"):
        msub = sub[sub["metric"] == metric].sort_values("axis_bin")
        if msub.empty:
            continue
        bin_width = float(np.nanmedian(msub["axis_end"].to_numpy(dtype=float) - msub["axis_start"].to_numpy(dtype=float)))
        w = int(max(1, round(float(window_seconds) / max(bin_width, 1e-9))))
        twin = _safe_rolling_nanmean(msub["value"].to_numpy(dtype=float), w)
        df = msub.copy()
        df["metric"] = f"{metric}_twin"
        df["value"] = twin
        rows.append(df)
    if not rows:
        return curves_df
    return pd.concat([curves_df, *rows], ignore_index=True)


def compute_timecurve_efficiency_metrics_multi_axis(
    ns: np.ndarray,
    *,
    axis_table: pd.DataFrame | None = None,
    ns_frames: np.ndarray | None = None,
    tf: Any | None = None,
    n_bins: int = 20,
    window_steps: int = 100,
    window_seconds: float = 60.0,
    num_states: int = 32,
    min_separation: int = 1,
    axis_configs: Sequence[AxisConfig] | None = None,
    axes: Sequence[str] | None = None,
    step_bin_size: float = 100.0,
    time_bin_seconds: float = 30.0,
    step_horizon: float | None = 2000.0,
    time_horizon_seconds: float | None = 1800.0,
    reward_events: np.ndarray | None = None,
    reward_align_pre_seconds: float = 300.0,
    reward_align_post_seconds: float = 900.0,
    variant: str = "full_session",
) -> dict[str, pd.DataFrame]:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size == 0:
        empty = pd.DataFrame(
            columns=[
                "metric",
                "axis_bin",
                "axis_start",
                "axis_end",
                "value",
                "n_points",
                "time_axis",
                "axis_unit",
                "variant",
            ]
        )
        return {"curves_df": empty, "summary_df": empty.copy(), "axis_table": pd.DataFrame()}

    if axis_table is None:
        if ns_frames is None:
            ns_frames = np.arange(seq.size, dtype=float)
        axis_table = build_exploration_axis_table(np.asarray(ns_frames), tf=tf)
    axis_table = axis_table.copy().reset_index(drop=True)
    if len(axis_table) != seq.size:
        m = int(min(len(axis_table), seq.size))
        seq = seq[:m]
        axis_table = axis_table.iloc[:m].copy()

    if axis_configs is None:
        ax_list = list(axes) if axes is not None else ["explore_node_bin", "fixed_step", "fixed_time", "reward_aligned_time"]
        axis_configs = []
        for ax in ax_list:
            if ax == "explore_node_bin":
                axis_configs.append(AxisConfig(axis_name=ax, bin_width=1.0 / float(max(1, n_bins)), horizon=1.0, window_steps=window_steps, window_seconds=window_seconds))
            elif ax == "fixed_step":
                axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(step_bin_size), horizon=step_horizon, window_steps=window_steps, window_seconds=window_seconds))
            elif ax == "fixed_time":
                axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(time_bin_seconds), horizon=time_horizon_seconds, window_steps=window_steps, window_seconds=window_seconds))
            elif ax == "reward_aligned_time":
                axis_configs.append(AxisConfig(axis_name=ax, bin_width=float(time_bin_seconds), horizon=None, window_steps=window_steps, window_seconds=window_seconds))

    metric_map = _metric_series_by_step(
        seq,
        window_steps=int(max(1, window_steps)),
        num_states=int(max(1, num_states)),
        min_separation=int(max(1, min_separation)),
    )
    reward_events_arr = np.asarray([] if reward_events is None else reward_events, dtype=float).ravel()
    reward_maze_time = np.nan
    if reward_events_arr.size:
        reward_maze = _frame_to_maze_seconds(np.asarray([np.nanmin(reward_events_arr)]), tf=tf) if tf is not None else np.asarray([np.nanmin(reward_events_arr) / FPS], dtype=float)
        reward_maze_time = float(reward_maze[0]) if reward_maze.size else np.nan

    curves_all = []
    for cfg in axis_configs:
        axis_name = str(cfg.axis_name)
        if axis_name == "explore_node_bin":
            axis_values = axis_table["progression_frac"].to_numpy(dtype=float)
            axis_unit = "fraction"
        elif axis_name == "fixed_step":
            axis_values = axis_table["step_index"].to_numpy(dtype=float)
            axis_unit = "step"
        elif axis_name == "fixed_time":
            axis_values = axis_table["maze_seconds"].to_numpy(dtype=float)
            axis_unit = "second"
        elif axis_name == "reward_aligned_time":
            if not np.isfinite(reward_maze_time):
                continue
            axis_values = axis_table["maze_seconds"].to_numpy(dtype=float) - reward_maze_time
            axis_unit = "second"
        else:
            continue

        edges = _axis_edges(
            axis_name,
            axis_values=axis_values,
            cfg=cfg,
            n_bins=n_bins,
            reward_align_pre_seconds=reward_align_pre_seconds,
            reward_align_post_seconds=reward_align_post_seconds,
        )
        if edges.size < 2:
            continue
        for metric, spec in metric_map.items():
            si = np.asarray(spec["step_index"], dtype=int)
            v = np.asarray(spec["value"], dtype=float)
            agg = str(spec.get("agg", "mean"))
            if si.size == 0 or v.size == 0:
                dfm = _bin_metric_by_axis(metric, np.asarray([], dtype=float), np.asarray([], dtype=float), edges=edges, agg=agg, axis_name=axis_name, axis_unit=axis_unit, variant=variant)
            else:
                ok = (si >= 0) & (si < axis_values.size)
                si = si[ok]
                vv = v[ok] if v.size == ok.size else v[: si.size]
                av = axis_values[si] if si.size else np.asarray([], dtype=float)
                dfm = _bin_metric_by_axis(metric, vv, av, edges=edges, agg=agg, axis_name=axis_name, axis_unit=axis_unit, variant=variant)
            curves_all.append(dfm)

    curves_df = pd.concat(curves_all, ignore_index=True) if curves_all else pd.DataFrame()
    curves_df = _add_time_smoothed_fixed_time_metrics(curves_df, window_seconds=window_seconds)
    if curves_df.empty:
        summary_df = pd.DataFrame(columns=["metric", "early_mean", "late_mean", "delta", "ratio", "slope_theilsen", "time_axis", "variant"])
    else:
        srows = []
        for (ax, vr, metric), sub in curves_df.groupby(["time_axis", "variant", "metric"]):
            summ = _curve_summary(sub.rename(columns={"axis_bin": "bin_index"})[["metric", "bin_index", "value"]].copy())
            if summ.empty:
                continue
            row = summ.iloc[0].to_dict()
            row["time_axis"] = ax
            row["variant"] = vr
            row["metric"] = metric
            srows.append(row)
        summary_df = pd.DataFrame(srows)
    return {"curves_df": curves_df, "summary_df": summary_df, "axis_table": axis_table}


def aggregate_curves_common_horizon(
    curves_df: pd.DataFrame,
    *,
    horizon_by_axis: dict[str, float | None] | None = None,
    common_horizon_quantile: float = 0.75,
    session_col: str = "nickname",
) -> pd.DataFrame:
    df = curves_df.copy()
    required = {"group", "time_axis", "variant", "metric", "axis_bin", "axis_start", "axis_end", "value", session_col}
    if df.empty or not required.issubset(df.columns):
        return pd.DataFrame(
            columns=[
                "group",
                "time_axis",
                "variant",
                "metric",
                "axis_bin",
                "axis_value_start",
                "axis_value_end",
                "value",
                "coverage_n",
                "coverage_frac",
                "n_sessions",
                "effective_horizon",
            ]
        )
    horizon_by_axis = {} if horizon_by_axis is None else dict(horizon_by_axis)
    max_per_session = (
        df.groupby(["group", "time_axis", "variant", session_col])["axis_end"].max().reset_index().rename(columns={"axis_end": "axis_max"})
    )
    hs = []
    for (g, ax, vr), sub in max_per_session.groupby(["group", "time_axis", "variant"]):
        mx = sub["axis_max"].to_numpy(dtype=float)
        mx = mx[np.isfinite(mx)]
        qh = float(np.nanquantile(mx, float(common_horizon_quantile))) if mx.size else np.nan
        user_h = horizon_by_axis.get(str(ax), None)
        if user_h is not None and np.isfinite(user_h):
            eff = min(float(user_h), qh) if np.isfinite(qh) else float(user_h)
        else:
            eff = qh
        hs.append({"group": g, "time_axis": ax, "variant": vr, "effective_horizon": eff, "n_sessions": int(sub[session_col].nunique())})
    hdf = pd.DataFrame(hs)
    if hdf.empty:
        return pd.DataFrame()
    out = []
    for _, hh in hdf.iterrows():
        g = hh["group"]
        ax = hh["time_axis"]
        vr = hh["variant"]
        eff = hh["effective_horizon"]
        n_sessions = int(hh["n_sessions"])
        sub = df[(df["group"] == g) & (df["time_axis"] == ax) & (df["variant"] == vr)].copy()
        if np.isfinite(eff):
            sub = sub[sub["axis_end"] <= float(eff) + 1e-9]
        if sub.empty:
            continue
        grp = sub.groupby(["group", "time_axis", "variant", "metric", "axis_bin", "axis_start", "axis_end"], as_index=False)
        agg = grp.agg(
            value=("value", "mean"),
            coverage_n=("value", lambda x: int(np.sum(np.isfinite(np.asarray(x, dtype=float))))),
        )
        agg["coverage_frac"] = agg["coverage_n"].astype(float) / float(max(1, n_sessions))
        agg["n_sessions"] = int(n_sessions)
        agg["effective_horizon"] = float(eff) if np.isfinite(eff) else np.nan
        agg["axis_value_start"] = agg["axis_start"].astype(float)
        agg["axis_value_end"] = agg["axis_end"].astype(float)
        agg["curve_level"] = "group_common_horizon"
        out.append(agg)
    if not out:
        return pd.DataFrame()
    out_df = pd.concat(out, ignore_index=True)
    return out_df[
        [
            "group",
            "time_axis",
            "variant",
            "metric",
            "axis_bin",
            "axis_value_start",
            "axis_value_end",
            "value",
            "coverage_n",
            "coverage_frac",
            "n_sessions",
            "effective_horizon",
            "curve_level",
        ]
    ]


def compute_timecurve_efficiency_metrics(
    ns: np.ndarray,
    *,
    n_bins: int = 20,
    window_size: int = 100,
    num_states: int = 32,
    min_separation: int = 1,
) -> dict[str, pd.DataFrame]:
    out = compute_timecurve_efficiency_metrics_multi_axis(
        ns,
        n_bins=n_bins,
        window_steps=window_size,
        num_states=num_states,
        min_separation=min_separation,
        axes=("explore_node_bin",),
        variant="full_session",
    )
    curves = out["curves_df"].copy()
    if curves.empty:
        empty = pd.DataFrame(columns=["metric", "bin_index", "value", "n_points", "time_axis"])
        return {"curves_df": empty, "summary_df": empty.copy()}
    curves["bin_index"] = curves["axis_bin"].astype(int)
    curves = curves[["metric", "bin_index", "value", "n_points", "time_axis", "axis_unit", "axis_start", "axis_end", "variant"]]
    summary = out["summary_df"].copy()
    return {"curves_df": curves, "summary_df": summary}


def _extract_reward_event_frames(tf: Any) -> np.ndarray:
    out = []
    re_all = getattr(tf, "re", [])
    fr = np.asarray(getattr(tf, "fr", []))
    if len(re_all) == 0 or fr.size == 0:
        return np.asarray([], dtype=float)
    for i, re in enumerate(re_all):
        arr = np.asarray(re)
        if arr.size == 0:
            continue
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        if arr.ndim != 2 or arr.shape[1] < 1:
            continue
        abs_start = arr[:, 0].astype(float) + float(fr[i, 0])
        out.extend(abs_start.tolist())
    if not out:
        return np.asarray([], dtype=float)
    return np.sort(np.asarray(out, dtype=float))


def compute_reward_shift_metrics(
    ns: np.ndarray,
    reward_events: np.ndarray,
    *,
    ns_frames: np.ndarray | None = None,
    num_states: int = 32,
    window_size: int = 100,
    n_bins: int = 20,
) -> dict[str, Any]:
    seq = np.asarray(ns, dtype=int).ravel()
    rf = np.asarray(reward_events, dtype=float).ravel()
    out: dict[str, Any] = {
        "valid_reward_shift": False,
        "first_reward_frame": np.nan,
        "reward_split_index": np.nan,
    }
    fields = [
        "half_cover_eff",
        "auc_unique_norm",
        "sliding_unique_mean",
        "new_node_rate_mean",
        "revisit_eff_mean",
        "entropy_norm_mean",
        "outer_inner_ratio_mean",
    ]
    for k in fields:
        out[f"pre_{k}"] = np.nan
        out[f"post_{k}"] = np.nan
        out[f"delta_{k}"] = np.nan
        out[f"ratio_{k}"] = np.nan

    if seq.size < 4 or rf.size == 0 or ns_frames is None:
        return out
    frames = np.asarray(ns_frames, dtype=float).ravel()
    if frames.size != seq.size:
        return out

    first_r = float(np.nanmin(rf))
    split_idx = int(np.searchsorted(frames, first_r, side="left"))
    out["first_reward_frame"] = first_r
    out["reward_split_index"] = split_idx
    if split_idx <= 1 or split_idx >= seq.size - 1:
        return out

    pre = compute_scalar_efficiency_metrics(
        seq[:split_idx],
        num_states=num_states,
        window_size=window_size,
        n_bins=n_bins,
        include_model_summary=False,
    )
    post = compute_scalar_efficiency_metrics(
        seq[split_idx:],
        num_states=num_states,
        window_size=window_size,
        n_bins=n_bins,
        include_model_summary=False,
    )
    out["valid_reward_shift"] = True
    for k in fields:
        pv = float(pre.get(k, np.nan))
        qv = float(post.get(k, np.nan))
        out[f"pre_{k}"] = pv
        out[f"post_{k}"] = qv
        out[f"delta_{k}"] = qv - pv if np.isfinite(pv) and np.isfinite(qv) else np.nan
        out[f"ratio_{k}"] = float(qv / (pv + 1e-9)) if np.isfinite(pv) and np.isfinite(qv) else np.nan
    return out


def _concat_nodes_from_traj(tf: Any) -> np.ndarray:
    parts = []
    for b in getattr(tf, "no", []):
        arr = np.asarray(b)
        if arr.ndim == 2 and arr.shape[1] >= 1:
            parts.append(arr[:, 0].astype(int, copy=False))
    if not parts:
        return np.asarray([], dtype=int)
    return np.concatenate(parts).astype(int, copy=False)


def _simulate_null_endnodes(
    observed_ns: np.ndarray,
    ma: Any,
    *,
    mode: str,
    target_len: int,
    end_level: int = 6,
    seed: int = 0,
    make_2nd_markov_fn: Callable[..., Any] = Make2ndMarkov,
    fit_four_bias_model_fn: Callable[..., Any] = fit_four_bias_model,
    predict_four_bias_walk_fn: Callable[..., Any] = predict_four_bias_walk,
) -> np.ndarray:
    end_nodes = end_level_nodes(end_level)
    n_target = int(max(1, target_len))
    mode_l = str(mode).lower()
    if mode_l == "random":
        n_steps = max(1000, 6 * n_target)
        best = np.asarray([], dtype=int)
        for k in range(4):
            tr = make_2nd_markov_fn(ma, n=n_steps, rs=int(seed + k))
            seq = _concat_nodes_from_traj(tr)
            ns = seq[np.isin(seq, end_nodes)]
            if ns.size > best.size:
                best = ns
            if ns.size >= n_target:
                return ns[:n_target]
            n_steps *= 2
        return best[:n_target]

    if mode_l in ("4bias", "four_bias", "fourbias"):
        if observed_ns.size == 0:
            return np.asarray([], dtype=int)
        model = fit_four_bias_model_fn(observed_ns, ma)
        n_steps = max(2000, 8 * n_target)
        best = np.asarray([], dtype=int)
        start = int(observed_ns[0])
        for k in range(4):
            run_seq = predict_four_bias_walk_fn(start, n_steps, ma, model, seed=int(seed + k))
            ns = np.asarray(run_seq, dtype=int).ravel()
            ns = ns[np.isin(ns, end_nodes)]
            if ns.size > best.size:
                best = ns
            if ns.size >= n_target:
                return ns[:n_target]
            n_steps *= 2
        return best[:n_target]

    raise ValueError(f"Unknown null mode: {mode}")


def compute_null_relative_metrics(
    ns: np.ndarray,
    ma: Any,
    *,
    num_states: int = 32,
    window_size: int = 100,
    n_bins: int = 20,
    null_modes: tuple[str, ...] = ("random", "4bias"),
    n_repeats: int = 200,
    seed: int = 0,
) -> pd.DataFrame:
    seq = np.asarray(ns, dtype=int).ravel()
    if seq.size == 0:
        return pd.DataFrame(
            columns=[
                "kind",
                "null_mode",
                "metric",
                "bin_index",
                "obs",
                "null_mean",
                "null_std",
                "gap",
                "ratio",
                "n_repeats_valid",
            ]
        )
    obs_scalar = compute_scalar_efficiency_metrics(
        seq,
        num_states=num_states,
        window_size=window_size,
        n_bins=n_bins,
        include_model_summary=False,
    )
    obs_curves = compute_timecurve_efficiency_metrics(
        seq,
        n_bins=n_bins,
        window_size=window_size,
        num_states=num_states,
    )["curves_df"]
    obs_piv = obs_curves.pivot_table(index="bin_index", columns="metric", values="value", aggfunc="mean")

    scalar_metrics = ["half_cover_eff", "auc_unique_norm", "sliding_unique_mean", "new_node_rate_mean", "revisit_eff_mean"]
    curve_metrics = ["coverage_frac", "sliding_unique_eff", "new_node_rate", "revisit_eff"]
    rows = []
    for mode in null_modes:
        sc = {m: [] for m in scalar_metrics}
        cv = {m: [] for m in curve_metrics}
        for r in range(int(max(1, n_repeats))):
            mode_offset = _MODE_OFFSETS.get(mode, int(abs(int.from_bytes(mode.encode(), "little")) % 10000))
            seed_r = int(seed + mode_offset + r)
            try:
                nseq = _simulate_null_endnodes(seq, ma, mode=mode, target_len=seq.size, seed=seed_r)
                if nseq.size < max(8, int(0.25 * seq.size)):
                    continue
                nsc = compute_scalar_efficiency_metrics(
                    nseq,
                    num_states=num_states,
                    window_size=window_size,
                    n_bins=n_bins,
                    include_model_summary=False,
                )
                for m in scalar_metrics:
                    sc[m].append(float(nsc.get(m, np.nan)))
                ncv = compute_timecurve_efficiency_metrics(
                    nseq,
                    n_bins=n_bins,
                    window_size=window_size,
                    num_states=num_states,
                )["curves_df"]
                npiv = ncv.pivot_table(index="bin_index", columns="metric", values="value", aggfunc="mean")
                for m in curve_metrics:
                    arr = np.full(int(max(1, n_bins)), np.nan, dtype=float)
                    if m in npiv.columns:
                        vals = npiv[m]
                        idx = np.asarray(vals.index, dtype=int)
                        idx = idx[(idx >= 0) & (idx < arr.size)]
                        arr[idx] = vals.loc[idx].to_numpy(dtype=float)
                    cv[m].append(arr)
            except Exception:
                continue

        for m in scalar_metrics:
            arr = np.asarray(sc[m], dtype=float)
            arr = arr[np.isfinite(arr)]
            obs = float(obs_scalar.get(m, np.nan))
            mu = float(np.nanmean(arr)) if arr.size else np.nan
            sd = float(np.nanstd(arr)) if arr.size else np.nan
            rows.append(
                {
                    "kind": "scalar",
                    "null_mode": mode,
                    "metric": m,
                    "bin_index": np.nan,
                    "obs": obs,
                    "null_mean": mu,
                    "null_std": sd,
                    "gap": obs - mu if np.isfinite(obs) and np.isfinite(mu) else np.nan,
                    "ratio": obs / (mu + 1e-9) if np.isfinite(obs) and np.isfinite(mu) else np.nan,
                    "n_repeats_valid": int(arr.size),
                }
            )

        for m in curve_metrics:
            arrs = np.asarray(cv[m], dtype=float) if cv[m] else np.zeros((0, int(max(1, n_bins))), dtype=float)
            for bi in range(int(max(1, n_bins))):
                obs = np.nan
                if m in obs_piv.columns and bi in obs_piv.index:
                    obs = float(obs_piv.loc[bi, m])
                if arrs.shape[0] > 0:
                    vals = arrs[:, bi]
                    vals = vals[np.isfinite(vals)]
                else:
                    vals = np.asarray([], dtype=float)
                mu = float(np.nanmean(vals)) if vals.size else np.nan
                sd = float(np.nanstd(vals)) if vals.size else np.nan
                rows.append(
                    {
                        "kind": "curve",
                        "null_mode": mode,
                        "metric": m,
                        "bin_index": int(bi),
                        "obs": obs,
                        "null_mean": mu,
                        "null_std": sd,
                        "gap": obs - mu if np.isfinite(obs) and np.isfinite(mu) else np.nan,
                        "ratio": obs / (mu + 1e-9) if np.isfinite(obs) and np.isfinite(mu) else np.nan,
                        "n_repeats_valid": int(vals.size),
                    }
                )
    return pd.DataFrame(rows)


def compute_exploration_cycles(
    ns: np.ndarray,
    *,
    num_states: int = 32,
    complete_only: bool = True,
    nickname: str | None = None,
    group: str | None = None,
) -> pd.DataFrame:
    seq = np.asarray(ns, dtype=int).ravel()
    k = int(max(1, num_states))
    rows: list[dict[str, Any]] = []
    if seq.size == 0:
        return pd.DataFrame(
            columns=[
                "cycle_index",
                "steps_in_cycle",
                "cum_steps_end",
                "efficiency_32_over_steps",
                "cover_target_states",
                "states_covered",
                "complete_cycle",
                "nickname",
                "group",
            ]
        )

    cycle_start = 0
    seen: set[int] = set()
    cycle_index = 0
    for i, x in enumerate(seq):
        seen.add(int(x))
        if len(seen) >= k:
            cycle_index += 1
            steps = int(i - cycle_start + 1)
            rows.append(
                {
                    "cycle_index": cycle_index,
                    "steps_in_cycle": steps,
                    "cum_steps_end": int(i + 1),
                    "efficiency_32_over_steps": float(k / float(max(1, steps))),
                    "cover_target_states": k,
                    "states_covered": k,
                    "complete_cycle": True,
                }
            )
            cycle_start = i + 1
            seen = set()

    if not complete_only and cycle_start < seq.size:
        cycle_index += 1
        steps = int(seq.size - cycle_start)
        rows.append(
            {
                "cycle_index": cycle_index,
                "steps_in_cycle": steps,
                "cum_steps_end": int(seq.size),
                "efficiency_32_over_steps": float(k / float(max(1, steps))),
                "cover_target_states": k,
                "states_covered": int(len(seen)),
                "complete_cycle": False,
            }
        )

    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(
            columns=[
                "cycle_index",
                "steps_in_cycle",
                "cum_steps_end",
                "efficiency_32_over_steps",
                "cover_target_states",
                "states_covered",
                "complete_cycle",
            ]
        )
    if nickname is not None:
        out["nickname"] = str(nickname)
    if group is not None:
        out["group"] = str(group)
    return out


def build_session_metric_curves(curves_df: pd.DataFrame) -> pd.DataFrame:
    required = [
        "nickname",
        "group",
        "metric",
        "time_axis",
        "variant",
        "axis_bin",
        "axis_start",
        "axis_end",
        "value",
        "curve_level",
        "n_points",
    ]
    if curves_df.empty:
        return pd.DataFrame(columns=required)

    df = curves_df.copy()
    if "curve_level" in df.columns:
        df = df[df["curve_level"] == "session"].copy()
    if df.empty:
        return pd.DataFrame(columns=required)

    df["curve_level"] = "session"
    if "variant" not in df.columns:
        df["variant"] = "full_session"
    if "axis_bin" not in df.columns and "bin_index" in df.columns:
        df["axis_bin"] = df["bin_index"].astype(int)
    if "n_points" not in df.columns:
        df["n_points"] = np.nan
    for c in ["nickname", "group", "metric", "time_axis", "variant", "axis_start", "axis_end", "value"]:
        if c not in df.columns:
            df[c] = np.nan

    ordered = required + [c for c in df.columns if c not in required]
    return df[ordered].reset_index(drop=True)


def paginate_animals(nicknames: Sequence[str], *, per_page: int = 12) -> pd.DataFrame:
    names = sorted({str(n) for n in nicknames if str(n).strip()})
    rows = []
    p = int(max(1, per_page))
    for i, n in enumerate(names):
        rows.append({"nickname": n, "page": int(i // p + 1), "slot": int(i % p)})
    return pd.DataFrame(rows)


def build_animal_summary_table(
    scalars_df: pd.DataFrame,
    cycles_df: pd.DataFrame,
    *,
    num_states: int = 32,
) -> pd.DataFrame:
    if scalars_df.empty:
        cols = ["nickname", "group", "median_steps_to_32", "n_complete_cycles", "cycles_per_1000_steps"]
        return pd.DataFrame(columns=cols)
    out = scalars_df.copy()
    keep_cycles = cycles_df.copy()
    if not keep_cycles.empty:
        if "complete_cycle" in keep_cycles.columns:
            keep_cycles = keep_cycles[keep_cycles["complete_cycle"] == True].copy()
        agg = (
            keep_cycles.groupby(["nickname", "group"], as_index=False)
            .agg(
                median_steps_to_32=("steps_in_cycle", "median"),
                n_complete_cycles=("cycle_index", "count"),
            )
            .reset_index(drop=True)
        )
    else:
        agg = pd.DataFrame(columns=["nickname", "group", "median_steps_to_32", "n_complete_cycles"])
    out = out.merge(agg, on=["nickname", "group"], how="left")
    if "median_steps_to_32" not in out.columns:
        out["median_steps_to_32"] = np.nan
    if "n_complete_cycles" not in out.columns:
        out["n_complete_cycles"] = 0
    out["n_complete_cycles"] = out["n_complete_cycles"].fillna(0).astype(int)

    denom = out["n_explore_endnodes"].to_numpy(dtype=float) if "n_explore_endnodes" in out.columns else np.full(len(out), np.nan)
    num = out["n_complete_cycles"].to_numpy(dtype=float)
    cps = np.where(np.isfinite(denom) & (denom > 0), (1000.0 * num) / denom, np.nan)
    out["cycles_per_1000_steps"] = cps.astype(float, copy=False)
    out["cover_target_states"] = out.get("cover_target_states", int(max(1, num_states)))
    return out


def _infer_reward_context(group_label: str | None) -> str:
    g = str(group_label or "").lower()
    if "unrewarded_no_port" in g:
        return "unrewarded_no_port"
    if "unrewarded_reward_return" in g:
        return "unrewarded_reward_return"
    if "unrewarded" in g:
        return "unrewarded"
    if "ltm" in g:
        return "rewarded_ltm"
    if "rewarded" in g:
        return "rewarded"
    return "mixed"


def assemble_exploration_report_for_group(
    nicknames: list[str],
    *,
    group_label: str = "group",
    reward_context: str | None = None,
    ma: Any | None = None,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    end_level: int = 6,
    num_states: int = 32,
    n_bins: int = 20,
    window_size: int = 100,
    window_seconds: float = 60.0,
    axes: Sequence[str] = ("explore_node_bin",),
    step_bin_size: float = 100.0,
    time_bin_seconds: float = 30.0,
    step_horizon: float | None = 2000.0,
    time_horizon_seconds: float | None = 1800.0,
    common_horizon_quantile: float = 0.75,
    reward_align_pre_seconds: float = 300.0,
    reward_align_post_seconds: float = 900.0,
    min_separation: int = 1,
    null_modes: tuple[str, ...] = ("random", "4bias"),
    n_null_repeats: int = 200,
    null_seed: int = 0,
    return_skipped: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame] | tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    list[dict[str, str]],
]:
    if ma is None:
        ma = NewMaze(6)
    rc = reward_context or _infer_reward_context(group_label)
    scalars_rows: list[dict[str, Any]] = []
    curves_rows: list[pd.DataFrame] = []
    reward_rows: list[dict[str, Any]] = []
    null_rows: list[pd.DataFrame] = []
    pref_rows: list[pd.DataFrame] = []
    skipped: list[dict[str, str]] = []

    for i, nick in enumerate(nicknames):
        nickname = str(nick)
        try:
            tf = load_traj_fn(f"{nickname}-tf")
            ns, ns_frames = extract_explore_endnode_sequence(
                tf,
                ma,
                split_mode_clips_fn=split_mode_clips_fn,
                explore_idx=explore_idx,
                end_level=end_level,
                return_frames=True,
            )
            if ns.size == 0:
                raise ValueError("empty exploration end-node sequence")

            scal = compute_scalar_efficiency_metrics(
                ns,
                num_states=num_states,
                window_size=window_size,
                n_bins=n_bins,
                min_separation=min_separation,
                include_model_summary=False,
            )
            scal.update(
                {
                    "nickname": nickname,
                    "group": group_label,
                    "reward_context": rc,
                    "time_axis": "explore_node_bin",
                }
            )
            scalars_rows.append(scal)

            reward_events = _extract_reward_event_frames(tf)
            axis_table = build_exploration_axis_table(ns_frames, tf=tf)
            variant_frames: list[tuple[str, np.ndarray, np.ndarray, pd.DataFrame]] = [
                ("full_session", ns, ns_frames, axis_table)
            ]
            if step_horizon is not None and np.isfinite(step_horizon):
                k = int(min(ns.size, max(0, int(step_horizon))))
                if k >= 4 and k < ns.size:
                    variant_frames.append(("first_n_steps", ns[:k], ns_frames[:k], axis_table.iloc[:k].reset_index(drop=True)))
            if time_horizon_seconds is not None and np.isfinite(time_horizon_seconds):
                ms = axis_table["maze_seconds"].to_numpy(dtype=float)
                k_t = int(np.searchsorted(ms, float(time_horizon_seconds), side="right"))
                if k_t >= 4 and k_t < ns.size:
                    variant_frames.append(("first_t_seconds", ns[:k_t], ns_frames[:k_t], axis_table.iloc[:k_t].reset_index(drop=True)))

            variant_curve_parts = []
            for vname, vseq, vframes, vtable in variant_frames:
                axes_for_variant = tuple(a for a in axes if not (vname != "full_session" and a == "reward_aligned_time"))
                cv = compute_timecurve_efficiency_metrics_multi_axis(
                    vseq,
                    axis_table=vtable,
                    tf=tf,
                    n_bins=n_bins,
                    window_steps=window_size,
                    window_seconds=window_seconds,
                    num_states=num_states,
                    min_separation=min_separation,
                    axes=axes_for_variant,
                    step_bin_size=step_bin_size,
                    time_bin_seconds=time_bin_seconds,
                    step_horizon=step_horizon,
                    time_horizon_seconds=time_horizon_seconds,
                    reward_events=reward_events,
                    reward_align_pre_seconds=reward_align_pre_seconds,
                    reward_align_post_seconds=reward_align_post_seconds,
                    variant=vname,
                )["curves_df"].copy()
                if cv.empty:
                    continue
                cv["nickname"] = nickname
                cv["group"] = group_label
                cv["reward_context"] = rc
                cv["curve_level"] = "session"
                cv["coverage_n"] = 1
                cv["coverage_frac"] = 1.0
                variant_curve_parts.append(cv)
            curves = pd.concat(variant_curve_parts, ignore_index=True) if variant_curve_parts else pd.DataFrame()
            if not curves.empty:
                curves["bin_index"] = curves["axis_bin"].astype(int)
                curves_rows.append(curves)

            rew = compute_reward_shift_metrics(
                ns,
                reward_events,
                ns_frames=ns_frames,
                num_states=num_states,
                window_size=window_size,
                n_bins=n_bins,
            )
            rew.update(
                {
                    "nickname": nickname,
                    "group": group_label,
                    "reward_context": rc,
                }
            )
            reward_rows.append(rew)

            null_df = compute_null_relative_metrics(
                ns,
                ma,
                num_states=num_states,
                window_size=window_size,
                n_bins=n_bins,
                null_modes=null_modes,
                n_repeats=n_null_repeats,
                seed=int(null_seed + i * 1000),
            ).copy()
            null_df["nickname"] = nickname
            null_df["group"] = group_label
            null_df["reward_context"] = rc
            null_rows.append(null_df)

            pref = compute_inner_outer_preference_metrics(
                ns,
                window_size=window_size,
                n_bins=n_bins,
            )["curve_df"].copy()
            pref["nickname"] = nickname
            pref["group"] = group_label
            pref["reward_context"] = rc
            pref["time_axis"] = "explore_node_bin"
            pref_rows.append(pref)
        except Exception as exc:
            skipped.append({"nickname": nickname, "error": str(exc)})

    scalars_df = pd.DataFrame(scalars_rows)
    curves_df = pd.concat(curves_rows, ignore_index=True) if curves_rows else pd.DataFrame(
        columns=[
            "metric",
            "bin_index",
            "axis_bin",
            "axis_start",
            "axis_end",
            "axis_unit",
            "value",
            "n_points",
            "time_axis",
            "variant",
            "curve_level",
            "coverage_n",
            "coverage_frac",
            "nickname",
            "group",
            "reward_context",
        ]
    )
    if not curves_df.empty:
        session_curves_df = curves_df.copy()
        agg = aggregate_curves_common_horizon(
            session_curves_df,
            horizon_by_axis={
                "fixed_step": step_horizon,
                "fixed_time": time_horizon_seconds,
                "reward_aligned_time": reward_align_post_seconds,
                "explore_node_bin": 1.0,
            },
            common_horizon_quantile=float(common_horizon_quantile),
            session_col="nickname",
        )
        if not agg.empty:
            axis_units = session_curves_df[["time_axis", "axis_unit"]].drop_duplicates()
            agg = agg.merge(axis_units, on="time_axis", how="left")
            agg = agg.rename(
                columns={
                    "axis_value_start": "axis_start",
                    "axis_value_end": "axis_end",
                }
            )
            agg["bin_index"] = agg["axis_bin"].astype(int)
            agg["nickname"] = "__group__"
            agg["reward_context"] = rc
            agg["n_points"] = np.nan
            curves_df = pd.concat([session_curves_df, agg[session_curves_df.columns]], ignore_index=True)
    reward_df = pd.DataFrame(reward_rows)
    null_df = pd.concat(null_rows, ignore_index=True) if null_rows else pd.DataFrame(
        columns=["kind", "null_mode", "metric", "bin_index", "obs", "null_mean", "null_std", "gap", "ratio", "n_repeats_valid", "nickname", "group", "reward_context"]
    )
    preference_df = pd.concat(pref_rows, ignore_index=True) if pref_rows else pd.DataFrame(
        columns=["metric", "bin_index", "value", "n_points", "nickname", "group", "reward_context", "time_axis"]
    )

    if return_skipped:
        return scalars_df, curves_df, reward_df, null_df, preference_df, skipped
    return scalars_df, curves_df, reward_df, null_df, preference_df


# Backward-compatible wrappers used by previous scripts/notebooks.
def compute_animal_metrics(
    nickname: str,
    *,
    ma: Any | None = None,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    end_level: int = 6,
    num_states: int = 32,
    n_bins: int = 20,
    window_size: int = 100,
    min_separation: int = 1,
) -> ExplorationMetricSet:
    if ma is None:
        ma = NewMaze(6)
    tf = load_traj_fn(f"{nickname}-tf")
    ns = extract_explore_endnode_sequence(
        tf,
        ma,
        split_mode_clips_fn=split_mode_clips_fn,
        explore_idx=explore_idx,
        end_level=end_level,
    )
    scal = compute_scalar_efficiency_metrics(
        ns,
        num_states=num_states,
        window_size=window_size,
        n_bins=n_bins,
        min_separation=min_separation,
        include_model_summary=True,
    )
    return ExplorationMetricSet(
        nickname=str(nickname),
        n_explore_endnodes=int(scal["n_explore_endnodes"]),
        half_cover_eff=float(scal["half_cover_eff"]),
        late_cover_eff=float(scal["late_cover_eff"]),
        late_minus_early=float(scal["late_minus_early"]),
        late_over_early=float(scal["late_over_early"]),
        auc_unique_norm=float(scal["auc_unique_norm"]),
        sliding_unique_mean=float(scal["sliding_unique_mean"]),
        new_node_rate_mean=float(scal["new_node_rate_mean"]),
        revisit_eff_mean=float(scal["revisit_eff_mean"]),
        recurrence_lag_median=float(scal["recurrence_lag_median"]),
        entropy_norm_mean=float(scal["entropy_norm_mean"]),
        gini_mean=float(scal["gini_mean"]),
        outer_inner_ratio_mean=float(scal["outer_inner_ratio_mean"]),
        outer_inner_preference_mean=float(scal.get("outer_inner_preference_mean", np.nan)),
        fit_eff_numstates_over_a=float(scal["fit_eff_numstates_over_a"]),
    )


def compute_group_table(
    nicknames: list[str],
    *,
    ma: Any | None = None,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    end_level: int = 6,
    num_states: int = 32,
    n_bins: int = 20,
    window_size: int = 100,
    min_separation: int = 1,
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    rows: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []
    if ma is None:
        ma = NewMaze(6)
    for nickname in nicknames:
        try:
            m = compute_animal_metrics(
                str(nickname),
                ma=ma,
                load_traj_fn=load_traj_fn,
                split_mode_clips_fn=split_mode_clips_fn,
                explore_idx=explore_idx,
                end_level=end_level,
                num_states=num_states,
                n_bins=n_bins,
                window_size=window_size,
                min_separation=min_separation,
            )
            rows.append(m.__dict__.copy())
        except Exception as exc:
            skipped.append({"nickname": str(nickname), "error": str(exc)})
    return rows, skipped
