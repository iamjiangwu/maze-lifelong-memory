from __future__ import annotations

from typing import Any, Callable, Sequence

import numpy as np
import pandas as pd

from .exploration import end_level_nodes
from .trajectory import SplitModeClips


def extract_explore_node_walk(
    tf: Any,
    ma: Any,
    *,
    split_mode_clips_fn: Callable[..., Any] = SplitModeClips,
    explore_idx: int = 2,
    return_frames: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    if cl.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    ce = cl[np.where(cl[:, 3] == int(explore_idx))]
    if ce.size == 0:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_parts: list[np.ndarray] = []
    frame_parts: list[np.ndarray] = []
    for c in ce:
        bout = int(c[0])
        start = int(c[1])
        nstep = int(c[2])
        seg = np.asarray(tf.no[bout][start : start + nstep])
        if seg.ndim != 2 or seg.shape[1] < 2:
            continue
        nodes = seg[:, 0].astype(int, copy=False)
        abs_frames = seg[:, 1].astype(int, copy=False) + int(tf.fr[bout, 0])
        nodes_parts.append(nodes)
        frame_parts.append(abs_frames)

    if not nodes_parts:
        empty_i = np.asarray([], dtype=int)
        return (empty_i, empty_i.copy()) if return_frames else empty_i

    nodes_all = np.concatenate(nodes_parts).astype(int, copy=False)
    frames_all = np.concatenate(frame_parts).astype(int, copy=False)
    if return_frames:
        return nodes_all, frames_all
    return nodes_all


def extract_endnode_events(
    node_walk: np.ndarray,
    *,
    end_level: int = 6,
    node_frames: np.ndarray | None = None,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    nodes = np.asarray(node_walk, dtype=int).ravel()
    keep = np.isin(nodes, end_level_nodes(end_level))
    node_end = nodes[keep]
    if node_frames is None:
        return node_end
    fr = np.asarray(node_frames, dtype=int).ravel()
    return node_end, fr[keep]


def frequent_nonreward_endnodes(
    endnode_seq: np.ndarray,
    *,
    reward_node: int = 94,
    min_visits: int = 20,
) -> pd.DataFrame:
    seq = np.asarray(endnode_seq, dtype=int).ravel()
    if seq.size == 0:
        return pd.DataFrame(columns=["end_node", "visit_count", "visit_fraction", "rank"])

    counts = pd.Series(seq, dtype=int).value_counts().rename_axis("end_node").reset_index(name="visit_count")
    counts = counts[counts["end_node"] != int(reward_node)].copy()
    counts = counts[counts["visit_count"] >= int(min_visits)].copy()
    if counts.empty:
        return pd.DataFrame(columns=["end_node", "visit_count", "visit_fraction", "rank"])

    counts["visit_fraction"] = counts["visit_count"].to_numpy(dtype=float) / float(max(1, seq.size))
    counts = counts.sort_values(["visit_count", "end_node"], ascending=[False, True]).reset_index(drop=True)
    counts["rank"] = np.arange(1, len(counts) + 1, dtype=int)
    return counts[["end_node", "visit_count", "visit_fraction", "rank"]]


def build_endnode_accumulation_curves(
    endnode_seq: np.ndarray,
    target_nodes: Sequence[int],
    *,
    n_bins: int = 100,
) -> pd.DataFrame:
    seq = np.asarray(endnode_seq, dtype=int).ravel()
    nodes = [int(x) for x in target_nodes]
    if seq.size == 0 or len(nodes) == 0:
        return pd.DataFrame(
            columns=[
                "end_node",
                "axis_bin",
                "step_index",
                "progress",
                "cum_visits",
                "cum_visits_norm",
            ]
        )

    n = int(seq.size)
    x = np.arange(1, n + 1, dtype=float)
    b = int(max(5, n_bins))
    step_bins = np.linspace(1.0, float(n), b)

    rows: list[dict[str, float | int]] = []
    for node in nodes:
        hit = (seq == int(node)).astype(float)
        y = np.cumsum(hit)
        yb = np.interp(step_bins, x, y)
        ymax = float(np.nanmax(yb)) if yb.size else 0.0
        for bi, (s, c) in enumerate(zip(step_bins, yb)):
            rows.append(
                {
                    "end_node": int(node),
                    "axis_bin": int(bi),
                    "step_index": float(s),
                    "progress": float(bi / max(1, b - 1)),
                    "cum_visits": float(c),
                    "cum_visits_norm": float(c / ymax) if ymax > 0 else np.nan,
                }
            )
    return pd.DataFrame(rows)


def summarize_accumulation_dynamics(
    curves_df: pd.DataFrame,
    *,
    early_fraction: float = 0.3,
    late_fraction: float = 0.3,
    eps: float = 1e-9,
) -> pd.DataFrame:
    if curves_df is None or curves_df.empty:
        return pd.DataFrame(
            columns=[
                "end_node",
                "early_slope",
                "late_slope",
                "late_over_early",
                "trend_class",
            ]
        )

    ef = float(np.clip(early_fraction, 0.05, 0.8))
    lf = float(np.clip(late_fraction, 0.05, 0.8))
    rows: list[dict[str, Any]] = []
    for end_node, sub in curves_df.groupby("end_node"):
        ss = sub.sort_values("axis_bin")
        x = ss["progress"].to_numpy(dtype=float)
        y = ss["cum_visits"].to_numpy(dtype=float)
        ok = np.isfinite(x) & np.isfinite(y)
        x = x[ok]
        y = y[ok]
        if x.size < 4:
            rows.append(
                {
                    "end_node": int(end_node),
                    "early_slope": np.nan,
                    "late_slope": np.nan,
                    "late_over_early": np.nan,
                    "trend_class": "insufficient_points",
                }
            )
            continue

        m_early = x <= ef
        m_late = x >= (1.0 - lf)
        if int(np.sum(m_early)) < 2 or int(np.sum(m_late)) < 2:
            rows.append(
                {
                    "end_node": int(end_node),
                    "early_slope": np.nan,
                    "late_slope": np.nan,
                    "late_over_early": np.nan,
                    "trend_class": "insufficient_segment",
                }
            )
            continue

        early_slope = float(np.polyfit(x[m_early], y[m_early], 1)[0])
        late_slope = float(np.polyfit(x[m_late], y[m_late], 1)[0])
        ratio = float(late_slope / (early_slope + eps))
        if ratio < 0.67:
            trend = "initially_fast_then_slow"
        elif ratio > 1.5:
            trend = "accelerating_late"
        else:
            trend = "similar_speed"
        rows.append(
            {
                "end_node": int(end_node),
                "early_slope": early_slope,
                "late_slope": late_slope,
                "late_over_early": ratio,
                "trend_class": trend,
            }
        )
    return pd.DataFrame(rows).sort_values("end_node").reset_index(drop=True)


def count_pre_endnode_sequences(
    node_walk: np.ndarray,
    target_endnodes: Sequence[int],
    *,
    k: int = 4,
    include_endnode: bool = True,
    min_count: int = 1,
    require_unique_nodes: bool = False,
) -> pd.DataFrame:
    walk = np.asarray(node_walk, dtype=int).ravel()
    targets = {int(x) for x in target_endnodes}
    kk = int(max(1, k))
    if walk.size == 0 or len(targets) == 0:
        return pd.DataFrame(columns=["end_node", "k", "sequence", "sequence_str", "n_occurrences", "within_endnode_fraction"])

    rows: list[dict[str, Any]] = []
    end_hits: dict[int, int] = {int(n): 0 for n in targets}
    for i, node in enumerate(walk):
        node_i = int(node)
        if node_i not in targets:
            continue
        end_hits[node_i] = end_hits.get(node_i, 0) + 1

        if include_endnode:
            lo = i - kk + 1
            hi = i + 1
        else:
            lo = i - kk
            hi = i
        if lo < 0 or hi > walk.size:
            continue
        seq = tuple(int(x) for x in walk[lo:hi].tolist())
        if bool(require_unique_nodes) and len(set(seq)) != len(seq):
            continue
        rows.append({"end_node": node_i, "k": kk, "sequence": seq})

    if not rows:
        return pd.DataFrame(columns=["end_node", "k", "sequence", "sequence_str", "n_occurrences", "within_endnode_fraction"])

    out = pd.DataFrame(rows)
    out = out.groupby(["end_node", "k", "sequence"], as_index=False).size().rename(columns={"size": "n_occurrences"})
    out = out[out["n_occurrences"] >= int(min_count)].copy()
    if out.empty:
        return pd.DataFrame(columns=["end_node", "k", "sequence", "sequence_str", "n_occurrences", "within_endnode_fraction"])

    out["sequence_str"] = out["sequence"].apply(lambda t: "->".join(str(int(x)) for x in t))
    out["within_endnode_fraction"] = out.apply(
        lambda r: float(r["n_occurrences"]) / float(max(1, end_hits.get(int(r["end_node"]), 0))),
        axis=1,
    )
    out = out.sort_values(["end_node", "n_occurrences", "sequence_str"], ascending=[True, False, True]).reset_index(drop=True)
    return out[["end_node", "k", "sequence", "sequence_str", "n_occurrences", "within_endnode_fraction"]]


def build_short_sequence_report(
    node_walk: np.ndarray,
    frequent_endnodes_df: pd.DataFrame,
    *,
    k_values: Sequence[int] = (3, 4, 5),
    per_endnode_top_n: int = 10,
    include_endnode: bool = True,
    min_count: int = 2,
    require_unique_nodes: bool = False,
) -> pd.DataFrame:
    if frequent_endnodes_df is None or frequent_endnodes_df.empty:
        return pd.DataFrame(
            columns=[
                "end_node",
                "k",
                "sequence",
                "sequence_str",
                "n_occurrences",
                "within_endnode_fraction",
                "rank_within_endnode_k",
            ]
        )

    target_nodes = frequent_endnodes_df["end_node"].astype(int).tolist()
    parts = []
    for k in k_values:
        d = count_pre_endnode_sequences(
            node_walk,
            target_nodes,
            k=int(k),
            include_endnode=bool(include_endnode),
            min_count=int(min_count),
            require_unique_nodes=bool(require_unique_nodes),
        )
        if d.empty:
            continue
        d["rank_within_endnode_k"] = d.groupby(["end_node", "k"])["n_occurrences"].rank(method="first", ascending=False).astype(int)
        d = d[d["rank_within_endnode_k"] <= int(max(1, per_endnode_top_n))].copy()
        parts.append(d)

    if not parts:
        return pd.DataFrame(
            columns=[
                "end_node",
                "k",
                "sequence",
                "sequence_str",
                "n_occurrences",
                "within_endnode_fraction",
                "rank_within_endnode_k",
            ]
        )
    return pd.concat(parts, ignore_index=True)


def build_node_level_lookup(ma: Any) -> dict[int, int]:
    run_parent = np.asarray(ma.pa, dtype=int).ravel()
    run_level = np.full(run_parent.shape[0], -1, dtype=int)
    for run_idx in range(run_parent.shape[0]):
        lvl = 0
        cur = int(run_idx)
        guard = 0
        while cur >= 0 and guard <= run_parent.shape[0] + 2:
            cur = int(run_parent[cur])
            if cur >= 0:
                lvl += 1
            guard += 1
        run_level[run_idx] = int(lvl)

    node_runs = np.asarray(ma.rc, dtype=int).ravel()
    out: dict[int, int] = {}
    for node_idx, run_idx in enumerate(node_runs):
        if 0 <= int(run_idx) < run_level.shape[0]:
            out[int(node_idx)] = int(run_level[int(run_idx)])
        else:
            out[int(node_idx)] = -1
    return out


def _sequence_level_pattern(levels_from_end: tuple[int, ...]) -> str:
    if len(levels_from_end) < 3:
        return "other"
    a, b, c = int(levels_from_end[0]), int(levels_from_end[1]), int(levels_from_end[2])
    if (a, b, c) == (6, 5, 4):
        return "descending_cross_level"
    if (a, b, c) == (6, 5, 6):
        return "bounce_back"
    return "other"


def classify_level_pattern_family(levels_from_end: tuple[int, ...]) -> str:
    if len(levels_from_end) < 2:
        return "other"
    p = _sequence_level_pattern(levels_from_end)
    if p in ("descending_cross_level", "bounce_back"):
        return p
    lv = np.asarray(levels_from_end, dtype=float)
    if lv.size >= 3 and np.all(np.diff(lv[:3]) <= 0) and np.any(np.diff(lv[:3]) < 0):
        return "descending_like"
    return "other"


def annotate_sequence_level_patterns(seq_df: pd.DataFrame, ma: Any) -> pd.DataFrame:
    if seq_df is None or seq_df.empty:
        return pd.DataFrame(
            columns=[
                "end_node",
                "k",
                "sequence",
                "sequence_str",
                "n_occurrences",
                "within_endnode_fraction",
                "rank_within_endnode_k",
                "sequence_levels",
                "levels_from_end",
                "pattern_triplet",
                "pattern_family",
            ]
        )

    lut = build_node_level_lookup(ma)
    out = seq_df.copy()

    def _levs(seq: Any) -> tuple[int, ...]:
        return tuple(int(lut.get(int(x), -1)) for x in tuple(seq))

    out["sequence_levels"] = out["sequence"].apply(_levs)
    out["levels_from_end"] = out["sequence_levels"].apply(lambda t: tuple(reversed(t)))
    out["pattern_triplet"] = out["levels_from_end"].apply(_sequence_level_pattern)
    out["pattern_family"] = out["levels_from_end"].apply(classify_level_pattern_family)
    return out


def extract_pre_endnode_sequence_events(
    node_walk: np.ndarray,
    target_endnodes: Sequence[int],
    *,
    k: int,
    include_endnode: bool = True,
    require_unique_nodes: bool = False,
) -> pd.DataFrame:
    walk = np.asarray(node_walk, dtype=int).ravel()
    targets = {int(x) for x in target_endnodes}
    kk = int(max(1, k))
    if walk.size == 0 or len(targets) == 0:
        return pd.DataFrame(columns=["event_index", "hit_index", "end_node", "k", "sequence", "sequence_str"])

    rows: list[dict[str, Any]] = []
    event_idx = 0
    for i, node in enumerate(walk):
        node_i = int(node)
        if node_i not in targets:
            continue
        if include_endnode:
            lo, hi = i - kk + 1, i + 1
        else:
            lo, hi = i - kk, i
        if lo < 0 or hi > walk.size:
            continue
        seq = tuple(int(x) for x in walk[lo:hi].tolist())
        if bool(require_unique_nodes) and len(set(seq)) != len(seq):
            continue
        event_idx += 1
        rows.append(
            {
                "event_index": int(event_idx),
                "hit_index": int(i),
                "end_node": int(node_i),
                "k": int(kk),
                "sequence": seq,
                "sequence_str": "->".join(str(int(x)) for x in seq),
            }
        )
    return pd.DataFrame(rows)


def build_motif_accumulation_curves(
    sequence_events_df: pd.DataFrame,
    *,
    motif_col: str = "sequence_str",
    min_count: int = 1,
    n_bins: int = 100,
) -> pd.DataFrame:
    if sequence_events_df is None or sequence_events_df.empty:
        return pd.DataFrame(columns=["motif", "axis_bin", "progress", "event_index", "cum_count", "cum_count_norm", "n_total"])

    df = sequence_events_df.copy()
    counts = df[motif_col].astype(str).value_counts()
    keep = counts[counts >= int(max(1, min_count))].index.astype(str)
    df = df[df[motif_col].astype(str).isin(set(keep))].copy()
    if df.empty:
        return pd.DataFrame(columns=["motif", "axis_bin", "progress", "event_index", "cum_count", "cum_count_norm", "n_total"])

    rows: list[dict[str, Any]] = []
    for motif, sub in df.groupby(motif_col):
        ss = sub.sort_values("event_index")
        x = ss["event_index"].to_numpy(dtype=float)
        if x.size == 0:
            continue
        y = np.arange(1, x.size + 1, dtype=float)
        b = int(max(5, n_bins))
        xb = np.linspace(float(np.nanmin(x)), float(np.nanmax(x)), b)
        yb = np.interp(xb, x, y)
        ymax = float(np.nanmax(yb)) if yb.size else 0.0
        for bi, (xx, yy) in enumerate(zip(xb, yb)):
            rows.append(
                {
                    "motif": str(motif),
                    "axis_bin": int(bi),
                    "progress": float(bi / max(1, b - 1)),
                    "event_index": float(xx),
                    "cum_count": float(yy),
                    "cum_count_norm": float(yy / ymax) if ymax > 0 else np.nan,
                    "n_total": int(x.size),
                }
            )
    return pd.DataFrame(rows)


def _aicc(n: int, k_params: int, sse: float) -> float:
    n_eff = int(max(1, n))
    k_eff = int(max(1, k_params))
    sse_eff = float(max(sse, 1e-12))
    aic = n_eff * np.log(sse_eff / n_eff) + 2.0 * k_eff
    denom = max(1.0, n_eff - k_eff - 1.0)
    return float(aic + (2.0 * k_eff * (k_eff + 1.0)) / denom)


def fit_accumulation_curve_models(
    x: np.ndarray,
    y: np.ndarray,
    *,
    min_break_progress: float = 0.15,
    max_break_progress: float = 0.85,
    exp_k_grid: np.ndarray | None = None,
) -> dict[str, Any]:
    xx = np.asarray(x, dtype=float).ravel()
    yy = np.asarray(y, dtype=float).ravel()
    ok = np.isfinite(xx) & np.isfinite(yy)
    xx = xx[ok]
    yy = yy[ok]
    if xx.size < 6:
        return {"status": "insufficient_points"}

    order = np.argsort(xx)
    xx = xx[order]
    yy = yy[order]
    xmin, xmax = float(np.nanmin(xx)), float(np.nanmax(xx))
    xr = max(1e-9, xmax - xmin)
    x01 = (xx - xmin) / xr
    n = int(xx.size)

    m, b = np.polyfit(x01, yy, 1)
    yhat_lin = m * x01 + b
    sse_lin = float(np.nansum((yy - yhat_lin) ** 2))
    linear = {
        "family": "linear",
        "sse": sse_lin,
        "aicc": _aicc(n, 2, sse_lin),
        "params": {"slope": float(m), "intercept": float(b)},
        "slope_early": float(m),
        "slope_late": float(m),
        "breakpoint": np.nan,
    }

    piece_best = None
    q = np.linspace(float(min_break_progress), float(max_break_progress), 21)
    for tau in q:
        left = x01 <= float(tau)
        right = x01 >= float(tau)
        if int(np.sum(left)) < 3 or int(np.sum(right)) < 3:
            continue
        m1, b1 = np.polyfit(x01[left], yy[left], 1)
        m2, b2 = np.polyfit(x01[right], yy[right], 1)
        yhat = np.empty_like(yy)
        yhat[left] = m1 * x01[left] + b1
        yhat[right] = m2 * x01[right] + b2
        sse = float(np.nansum((yy - yhat) ** 2))
        rec = {
            "family": "piecewise",
            "sse": sse,
            "aicc": _aicc(n, 5, sse),
            "params": {"m1": float(m1), "b1": float(b1), "m2": float(m2), "b2": float(b2)},
            "slope_early": float(m1),
            "slope_late": float(m2),
            "breakpoint": float(tau),
        }
        if piece_best is None or rec["aicc"] < piece_best["aicc"]:
            piece_best = rec

    if exp_k_grid is None:
        exp_k_grid = np.logspace(-1.5, 2.0, 50)
    exp_best = None
    for kk in np.asarray(exp_k_grid, dtype=float):
        feat = 1.0 - np.exp(-float(kk) * x01)
        X = np.column_stack([np.ones_like(feat), feat])
        coef, _, _, _ = np.linalg.lstsq(X, yy, rcond=None)
        a0, a1 = float(coef[0]), float(coef[1])
        yhat = a0 + a1 * feat
        sse = float(np.nansum((yy - yhat) ** 2))
        s_early = float(a1 * kk * np.exp(-kk * 0.2))
        s_late = float(a1 * kk * np.exp(-kk * 0.8))
        rec = {
            "family": "exponential",
            "sse": sse,
            "aicc": _aicc(n, 3, sse),
            "params": {"a0": a0, "a1": a1, "k": float(kk)},
            "slope_early": s_early,
            "slope_late": s_late,
            "breakpoint": np.nan,
        }
        if exp_best is None or rec["aicc"] < exp_best["aicc"]:
            exp_best = rec

    models = [linear]
    if piece_best is not None:
        models.append(piece_best)
    if exp_best is not None:
        models.append(exp_best)
    models = sorted(models, key=lambda d: float(d["aicc"]))
    best = models[0]
    second = models[1] if len(models) > 1 else None
    delta = float(second["aicc"] - best["aicc"]) if second is not None else np.nan
    return {
        "status": "ok",
        "n_points": n,
        "best": best,
        "second": second,
        "delta_aicc": delta,
        "all_models": models,
    }


def classify_accumulation_shape_multimodel(
    x: np.ndarray,
    y: np.ndarray,
    *,
    ratio_low: float = 0.75,
    ratio_high: float = 1.33,
    bootstrap_repeats: int = 200,
    bootstrap_seed: int = 0,
) -> dict[str, Any]:
    fit = fit_accumulation_curve_models(x, y)
    if fit.get("status") != "ok":
        return {
            "status": fit.get("status", "failed"),
            "best_family": "unknown",
            "shape_label": "insufficient_points",
            "slope_ratio": np.nan,
            "bootstrap_agreement": np.nan,
            "bootstrap_best_family": "unknown",
        }

    best = fit["best"]
    se = float(best.get("slope_early", np.nan))
    sl = float(best.get("slope_late", np.nan))
    ratio = float(sl / (se + 1e-9)) if np.isfinite(se) and np.isfinite(sl) else np.nan

    if not np.isfinite(ratio):
        direction = "similar_speed"
    elif ratio < float(ratio_low):
        direction = "fast_to_slow"
    elif ratio > float(ratio_high):
        direction = "slow_to_fast"
    else:
        direction = "similar_speed"

    family = str(best.get("family", "unknown"))
    if family == "piecewise" and direction != "similar_speed":
        shape_label = f"abrupt_{direction}"
    elif family in ("exponential",) and direction != "similar_speed":
        shape_label = f"gradual_{direction}"
    elif direction == "similar_speed":
        shape_label = "similar_speed"
    else:
        shape_label = f"{family}_{direction}"

    rng = np.random.default_rng(int(bootstrap_seed))
    xx = np.asarray(x, dtype=float).ravel()
    yy = np.asarray(y, dtype=float).ravel()
    ok = np.isfinite(xx) & np.isfinite(yy)
    xx = xx[ok]
    yy = yy[ok]
    n = int(xx.size)
    family_hits = []
    direction_hits = []
    b = int(max(0, bootstrap_repeats))
    for _ in range(b):
        idx = rng.integers(0, n, size=n)
        bf = fit_accumulation_curve_models(xx[idx], yy[idx])
        if bf.get("status") != "ok":
            continue
        bb = bf["best"]
        fam = str(bb.get("family", "unknown"))
        se_b = float(bb.get("slope_early", np.nan))
        sl_b = float(bb.get("slope_late", np.nan))
        rr = float(sl_b / (se_b + 1e-9)) if np.isfinite(se_b) and np.isfinite(sl_b) else np.nan
        if not np.isfinite(rr):
            d = "similar_speed"
        elif rr < float(ratio_low):
            d = "fast_to_slow"
        elif rr > float(ratio_high):
            d = "slow_to_fast"
        else:
            d = "similar_speed"
        family_hits.append(fam)
        direction_hits.append(d)

    if len(family_hits) == 0:
        fam_mode = "unknown"
        fam_agree = np.nan
        dir_mode = "unknown"
        dir_agree = np.nan
    else:
        fam_s = pd.Series(family_hits)
        dir_s = pd.Series(direction_hits)
        fam_mode = str(fam_s.value_counts().index[0])
        dir_mode = str(dir_s.value_counts().index[0])
        fam_agree = float(np.mean(fam_s.to_numpy() == fam_mode))
        dir_agree = float(np.mean(dir_s.to_numpy() == dir_mode))

    return {
        "status": "ok",
        "best_family": family,
        "shape_label": shape_label,
        "slope_ratio": ratio,
        "slope_early": se,
        "slope_late": sl,
        "breakpoint": float(best.get("breakpoint", np.nan)),
        "delta_aicc": float(fit.get("delta_aicc", np.nan)),
        "bootstrap_best_family": fam_mode,
        "bootstrap_family_agreement": fam_agree,
        "bootstrap_direction_mode": dir_mode,
        "bootstrap_direction_agreement": dir_agree,
    }


__all__ = [
    "extract_explore_node_walk",
    "extract_endnode_events",
    "frequent_nonreward_endnodes",
    "build_endnode_accumulation_curves",
    "summarize_accumulation_dynamics",
    "count_pre_endnode_sequences",
    "build_short_sequence_report",
    "build_node_level_lookup",
    "annotate_sequence_level_patterns",
    "extract_pre_endnode_sequence_events",
    "build_motif_accumulation_curves",
    "fit_accumulation_curve_models",
    "classify_accumulation_shape_multimodel",
]
