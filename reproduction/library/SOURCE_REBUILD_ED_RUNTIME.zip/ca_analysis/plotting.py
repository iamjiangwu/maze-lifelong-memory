import itertools

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from .stats import holm_correction


def significance_label(p):
    if not np.isfinite(p):
        return 'n.s.'
    if p < 0.001:
        return '***'
    if p < 0.01:
        return '**'
    if p < 0.05:
        return '*'
    return 'n.s.'


def _holm_correction(pvals):
    _, p_adj = holm_correction(pvals, alpha=0.05)
    return p_adj


def _to_numeric_groups(df, group_col, value_col):
    d = df[[group_col, value_col]].copy()
    d[value_col] = pd.to_numeric(d[value_col], errors='coerce')
    d = d[np.isfinite(d[value_col])]
    groups = []
    for key, sub in d.groupby(group_col):
        vals = sub[value_col].to_numpy(dtype=float)
        if vals.size:
            groups.append((key, vals))
    return groups


def bar_scatter_plot(
    df,
    group_col,
    value_col,
    *,
    title='',
    xlabel=None,
    ylabel=None,
    colors=None,
    annotate_significance=True,
    stat_test='kruskal',
    correction='holm',
    pairs=None,
    figsize=(8, 6),
    jitter_std=0.04,
    marker_size=35,
):
    groups = _to_numeric_groups(df, group_col, value_col)
    if not groups:
        raise ValueError(f'No valid values for {value_col}')

    labels = [g[0] for g in groups]
    vals = [g[1] for g in groups]
    means = [np.nanmean(v) for v in vals]
    sems = [stats.sem(v, nan_policy='omit') if v.size > 1 else 0.0 for v in vals]

    if colors is None:
        colors = {}
    bar_colors = [colors.get(k, '#8BBDEB') for k in labels]

    fig, ax = plt.subplots(figsize=figsize)
    x = np.arange(len(labels))
    ax.bar(x, means, yerr=sems, color=bar_colors, edgecolor='black', linewidth=1.0, alpha=0.75, capsize=4)

    rng = np.random.default_rng(0)
    for i, v in enumerate(vals):
        jitter = rng.normal(0.0, jitter_std, size=v.size)
        ax.scatter(np.full(v.size, i) + jitter, v, s=marker_size, alpha=0.85, color=bar_colors[i], edgecolors='none')

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha='right')
    if xlabel:
        ax.set_xlabel(xlabel)
    if ylabel:
        ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)

    global_result = {}
    if len(vals) >= 2:
        if str(stat_test).lower() == 'anova':
            stat, p = stats.f_oneway(*vals)
            global_result = {'test': 'anova', 'stat': float(stat), 'p': float(p)}
        else:
            stat, p = stats.kruskal(*vals)
            global_result = {'test': 'kruskal', 'stat': float(stat), 'p': float(p)}

    pair_rows = []
    if pairs is None:
        pairs = list(itertools.combinations(labels, 2))
    for a, b in pairs:
        if a not in labels or b not in labels:
            continue
        va = vals[labels.index(a)]
        vb = vals[labels.index(b)]
        if va.size and vb.size:
            u, p = stats.mannwhitneyu(va, vb, alternative='two-sided')
            pair_rows.append({'group_a': a, 'group_b': b, 'u': float(u), 'p': float(p)})

    if pair_rows and str(correction).lower() == 'holm':
        corrected = _holm_correction([r['p'] for r in pair_rows])
        for r, cp in zip(pair_rows, corrected):
            r['p_adj'] = float(cp)
    else:
        for r in pair_rows:
            r['p_adj'] = float(r['p'])

    if annotate_significance and pair_rows:
        ymax = max(np.nanmax(v) for v in vals)
        base = ymax * 1.05 if np.isfinite(ymax) else 1.0
        step = max(abs(ymax) * 0.08, 0.1)
        for i, r in enumerate(pair_rows):
            xa = labels.index(r['group_a'])
            xb = labels.index(r['group_b'])
            y = base + i * step
            ax.plot([xa, xa, xb, xb], [y, y + step * 0.25, y + step * 0.25, y], color='black', linewidth=1)
            ax.text((xa + xb) / 2.0, y + step * 0.3, significance_label(r['p_adj']), ha='center', va='bottom')

    result = {
        'global': global_result,
        'pairs': pair_rows,
        'group_sizes': {k: int(len(v)) for k, v in groups},
    }
    return ax, result


def plot_similarity_hist(values, *, bins=30, ax=None, title='', xlabel='Similarity', ylabel='Count'):
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 4))
    ax.hist(x, bins=bins, alpha=0.8)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    return ax


def plot_pair_scatter(x, y, *, ax=None, title='', xlabel='x', ylabel='y'):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]
    if ax is None:
        _, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(x, y, alpha=0.7, s=20)
    if x.size >= 2:
        r = np.corrcoef(x, y)[0, 1]
        ax.text(0.03, 0.97, f'r={r:.3f}', transform=ax.transAxes, va='top')
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    return ax


def plot_si_groups(df, group_col='group', value_col='si', **kwargs):
    return bar_scatter_plot(df, group_col, value_col, **kwargs)


def plot_similarity_curve(y, *, x=None, sem_values=None, ax=None, title='', xlabel='Index', ylabel='Similarity'):
    y = np.asarray(y, dtype=float)
    if x is None:
        x = np.arange(y.size)
    else:
        x = np.asarray(x, dtype=float)
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 4))
    ax.plot(x, y, linewidth=2.0)
    if sem_values is not None:
        s = np.asarray(sem_values, dtype=float)
        if s.shape == y.shape:
            ax.fill_between(x, y - s, y + s, alpha=0.2)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    return ax
