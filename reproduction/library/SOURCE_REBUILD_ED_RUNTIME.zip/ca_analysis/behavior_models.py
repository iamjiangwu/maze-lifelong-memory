from __future__ import annotations

import bz2
import lzma
from dataclasses import dataclass

import numpy as np

from .maze import Maze
from .maze_behavior import tally_step_types


@dataclass
class FourBiasModel:
    probs: np.ndarray
    labels: tuple[str, str, str, str] = ("in_left", "in_right", "out_left", "out_right")


def fit_four_bias_model(node_ids, ma: Maze, *, pseudocount: float = 1.0) -> FourBiasModel:
    da = as_run_nodes(node_ids, ma)
    mk = np.ones(len(da), dtype=int)
    if len(mk) > 0:
        mk[0] = 0
    be = four_bias_fit5(da, mk, ma, pseudocount=float(pseudocount))
    probs = np.asarray(be, dtype=float)
    probs = np.clip(probs, 1e-12, 1.0)
    return FourBiasModel(probs=probs)


def _next_run_candidates(run_id: int, ma: Maze) -> list[tuple[int, int]]:
    """
    Return candidate next runs as (next_run, step_type).
    """
    out = []
    st = np.asarray(ma.st, dtype=int)
    for nxt in range(st.shape[1]):
        step = int(st[int(run_id), int(nxt)])
        if 0 <= step < 4:
            out.append((int(nxt), step))
    return out


def as_run_nodes(node_ids, ma: Maze) -> np.ndarray:
    x = np.asarray(node_ids).astype(int).ravel()
    if x.size == 0:
        return np.zeros(0, dtype=int)
    if np.nanmax(x) < len(ma.ru):
        return x
    rc = np.asarray(ma.rc, dtype=int)
    ok = (x >= 0) & (x < len(rc))
    out = np.full(x.shape, -1, dtype=int)
    out[ok] = rc[x[ok]]
    return out[out >= 0]


def _step_type(a: int, b: int, ma: Maze) -> int:
    st = np.asarray(ma.st, dtype=int)
    if a < 0 or b < 0 or a >= st.shape[0] or b >= st.shape[1]:
        return -1
    return int(st[a, b])


def _step_type2(a: int, b: int, ma: Maze) -> int:
    st = _step_type(a, b, ma)
    if st in (0, 2):
        return 0  # left/in-left style
    if st in (1, 3):
        return 1  # right/in-right style
    return 2  # out/illegal fallback


def four_bias_fit5(da, mk, ma: Maze, pseudocount: float = 0.0):
    """
    Legacy-equivalent FourBiasFit5 from Maze_Analysis_3D.
    """
    da = as_run_nodes(da, ma)
    mk = np.asarray(mk, dtype=int).ravel()
    if mk.size != da.size:
        mk = np.ones(da.size, dtype=int)
    tr = np.zeros((4, 4), dtype=float)
    st = np.array([-1] + [_step_type(int(da[j - 1]), int(da[j]), ma) for j in range(1, len(da))], dtype=int)
    for i in range(1, len(st) - 1):
        if mk[i + 1] == 1 and st[i] >= 0 and st[i + 1] >= 0:
            tr[st[i], st[i + 1]] += 1.0
    tr += float(pseudocount)

    def ratio(x, y):
        return float(x / y) if y != 0 else 0.0

    bf = ratio(tr[0, 0] + tr[0, 1] + tr[1, 0] + tr[1, 1], np.sum(tr[0, :]) + np.sum(tr[1, :]))
    ba = ratio(tr[0, 1] + tr[1, 0], tr[0, 0] + tr[0, 1] + tr[1, 0] + tr[1, 1])
    lf = ratio(tr[2, 1] + tr[2, 2] + tr[2, 3] + tr[3, 0] + tr[3, 2] + tr[3, 3], np.sum(tr[2, :]) + np.sum(tr[3, :]))
    lo = ratio(tr[2, 2] + tr[2, 3] + tr[3, 2] + tr[3, 3], tr[2, 1] + tr[2, 2] + tr[2, 3] + tr[3, 0] + tr[3, 2] + tr[3, 3])
    return [bf, ba, lf, lo]


def four_bias_predict5(be, da, ma: Maze):
    da = as_run_nodes(da, ma)
    bf, ba, lf, lo = np.asarray(be, dtype=float).tolist()
    pro = np.array(
        [
            [bf * (1 - ba), bf * ba, 1 - bf],
            [bf * ba, bf * (1 - ba), 1 - bf],
            [1 - lf, lf * (1 - lo), lf * lo],
            [lf * (1 - lo), 1 - lf, lf * lo],
        ],
        dtype=float,
    )
    hi = 2**ma.le - 2
    st = np.array([-1] + [_step_type(int(da[j - 1]), int(da[j]), ma) for j in range(1, len(da))], dtype=int)
    pr = np.zeros((len(da), 3), dtype=float)
    for i in range(1, len(st) - 1):
        if da[i] == 0:
            pr[i + 1] = [0.5, 0.5, 0.0]
        elif 1 <= da[i] <= hi and 0 <= st[i] < 4:
            pr[i + 1] = pro[st[i]]
        else:
            pr[i + 1] = [0.0, 0.0, 1.0]
    return pr


def cross_entropy5(p, s):
    p = np.asarray(p, dtype=float)
    s = np.asarray(s, dtype=int).ravel()
    if len(s) == 0:
        return np.nan
    eps = 1e-12
    rows = np.arange(len(s), dtype=int)
    cols = np.clip(s, 0, p.shape[1] - 1).astype(int)
    vals = np.log(np.maximum(eps, p[rows, cols]))
    return float(-np.mean(vals) / np.log(2.0))


def predict_four_bias_walk(
    start_node: int,
    steps: int,
    ma: Maze,
    model: FourBiasModel,
    *,
    seed: int = 0,
) -> np.ndarray:
    rng = np.random.default_rng(int(seed))
    run = int(as_run_nodes([start_node], ma)[0]) if len(as_run_nodes([start_node], ma)) else 0
    da = [int(run)]
    be = np.asarray(model.probs, dtype=float)
    if be.size != 4:
        be = np.array([0.8, 0.5, 0.7, 0.5], dtype=float)
    be = np.clip(be, 1e-6, 1 - 1e-6)
    hi = 2**ma.le - 2
    for _ in range(int(max(0, steps))):
        cur = int(da[-1])
        if cur == 0:
            action_probs = np.array([0.5, 0.5, 0.0], dtype=float)
        elif 1 <= cur <= hi:
            if len(da) >= 2:
                st_last = _step_type(int(da[-2]), int(da[-1]), ma)
            else:
                st_last = -1
            pro = np.array(
                [
                    [be[0] * (1 - be[1]), be[0] * be[1], 1 - be[0]],
                    [be[0] * be[1], be[0] * (1 - be[1]), 1 - be[0]],
                    [1 - be[2], be[2] * (1 - be[3]), be[2] * be[3]],
                    [be[2] * (1 - be[3]), 1 - be[2], be[2] * be[3]],
                ],
                dtype=float,
            )
            if 0 <= st_last < 4:
                action_probs = pro[st_last].astype(float)
            else:
                action_probs = np.array([1 / 3, 1 / 3, 1 / 3], dtype=float)
        else:
            action_probs = np.array([0.0, 0.0, 1.0], dtype=float)

        action_probs = np.clip(action_probs, 1e-12, np.inf)
        action_probs /= np.sum(action_probs)
        action = int(rng.choice(3, p=action_probs))

        st_row = np.asarray(ma.st[int(cur), :], dtype=int)
        cands = []
        for nxt, st_val in enumerate(st_row.tolist()):
            if st_val < 0:
                continue
            if _step_type2(int(cur), int(nxt), ma) == action:
                cands.append(int(nxt))
        if not cands:
            cands = [int(nxt) for nxt, st_val in enumerate(st_row.tolist()) if st_val >= 0]
        if not cands:
            break
        run = int(rng.choice(cands))
        da.append(run)
    return np.asarray(da, dtype=int)


def string_entropy(node_ids, *, k: int = 1) -> float:
    x = np.asarray(node_ids).astype(int).ravel()
    k = max(1, int(k))
    if x.size < k:
        return np.nan
    if k == 1:
        _, counts = np.unique(x, return_counts=True)
    else:
        grams = np.lib.stride_tricks.sliding_window_view(x, k)
        if grams.size == 0:
            return np.nan
        # Preserve legacy semantics from object-array unique on tuple-grams:
        # it effectively counts flattened gram elements.
        _, counts = np.unique(np.ravel(grams), return_counts=True)
    p = counts.astype(float) / np.sum(counts)
    return float(-np.sum(p * np.log2(np.clip(p, 1e-12, 1.0))))


def _to_bytes(node_ids) -> bytes:
    x = np.asarray(node_ids).astype(np.int32).ravel()
    return x.tobytes()


def compression_ratio(node_ids, *, method: str = "bz2") -> float:
    raw = _to_bytes(node_ids)
    if len(raw) == 0:
        return np.nan
    method = str(method).lower()
    if method == "bz2":
        comp = bz2.compress(raw)
    elif method == "lzma":
        comp = lzma.compress(raw)
    else:
        raise ValueError(f"unknown compression method: {method}")
    return float(len(comp) / len(raw))
