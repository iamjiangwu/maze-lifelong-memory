import os
import re
from collections import namedtuple
from itertools import combinations
from typing import Any, Callable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from .config import FPS, REWARD_NODE
from .stats import holm_correction as _holm_correction_canonical, sem

GroupResult = namedtuple('GroupResult', ['half1', 'half2', 'ff', 'meta'])

_SESSION_PATTERN = re.compile(
    r'^([0-9]+(?:[a-z](?!day\d))*)'
    r'([RL]*)'
    r'(?:-(\d+))?'
    r'([RL]*)'
    r'(?:day(\d+))?$',
    re.IGNORECASE,
)


def process_behav_data(df):
    if isinstance(df, pd.DataFrame):
        return df.copy()
    return pd.DataFrame(df)


def extract_info(session_name):
    s = os.path.splitext(os.path.basename(str(session_name).strip()))[0]
    m = _SESSION_PATTERN.match(s)
    if not m:
        return None
    base, rl1, exp, rl2, day = m.groups()
    return {
        'session_name': s,
        'animal_id': f"{base}{rl1 or ''}{rl2 or ''}",
        'experiment_type': int(exp) if exp else 0,
        'experiment_day': int(day) if day else 1,
    }


def process_selected_df(df):
    return process_behav_data(df)


def process_mouse_positions(xy):
    arr = np.asarray(xy)
    if arr.ndim != 2 or arr.shape[1] < 2:
        raise ValueError('positions must be shape (T,2+)')
    return arr[:, :2]


def correct_nose_position(xy):
    return process_mouse_positions(xy)


def frames_to_time(frames, fps):
    return np.asarray(frames) / float(fps)


def time_to_frames(seconds, fps):
    return np.asarray(seconds) * float(fps)


def default_behavior_groups_260113():
    """Return the historical cohort snapshot captured from the 260113 notebook.

    This compatibility snapshot is not the authority for current+new12 cohort
    membership. Use the maintained analysis manifests for current analyses.
    """
    # Cohort lists copied from 260113_behaviormeasures.ipynb with explicit
    # legacy + readable alias keys.
    rewarded_day1 = [
        '1603', '1608', '202Lday1', '1616day1', '163RLday1', '1632Lday1', '355RLday1',
        '418RRday1', '434RRday1', '451Rday1', '488Rday1', '489Lday1', '579RLday1',
        '468Lday1', '609day1', '618day1', '597day1', '644day1', '646day1', '640day1',
        '624day1', '628day1', '15strday1',
    ]
    rewarded_day2 = [
        '1616day2', '163RLday2', '1632Lday2', '355RLday2', '418RRday2', '434RRday2',
        '451Rday2', '488Rday2', '489Lday2', '579RLday2', '468Lday2', '609day2',
        '618day2', '597day2', '644day2', '646day2', '640day2', '624day2',
    ]

    # First unrewarded cohort (day1 unrewarded, day2 rewarded).
    unrewarded_cohort1_day1 = ['1639RRday1', '1636Rday1', '347RLday1', '422RRday1', '1637Lday1', '325RLday1']
    unrewarded_cohort1_day2 = ['1639RRday2', '1636Rday2', '347RLday2', '422RRday2', '1637Lday2', '325RLday2']

    # Chemogenetic cohorts (BI = behavior + calcium imaging).
    chemo_bi_day1 = ['755day1', '753day1', '779day1', '781day1', '763day1', '788day1', '791day1', '786day1', '787day1', '814day1', '816day1', '796day1', '860day1']
    chemo_bi_day2 = ['755day2', '753day2', '779day2', '781day2', '763day2', '788day2', '791day2', '786day2', '787day2', '814day2', '816day2', '796day2', '860day2']
    chemo_ctrl_bi_day1 = ['782day1', '757day1', '799day1', '806day1', '777day1', '840day1']
    chemo_ctrl_bi_day2 = ['782day2', '757day2', '799day2', '806day2', '777day2', '840day2']
    # ChemoU: silencing occurs on day2.
    chemo_u_bi_day1 = ['794day1', '761day1', '798day1', '795day1', '812day1', '813day1', '785day1', '818day1', '828day1', '858day1', '861day1']
    chemo_u_bi_day2 = ['794day2', '761day2', '798day2', '795day2', '812day2', '813day2', '785day2', '818day2', '828day2', '858day2', '861day2']
    chemo_u_ctrl_bi_day1 = ['769day1', '838day1', '837day1', '839day1', '841day1', '842day1', '862day1']
    chemo_u_ctrl_bi_day2 = ['769day2', '838day2', '837day2', '839day2', '841day2', '842day2', '862day2']

    # Combined unrewarded cohort (first cohort + chemoU control), n=13.
    unrewarded_day1 = unrewarded_cohort1_day1 + chemo_u_ctrl_bi_day1
    unrewarded_day2 = unrewarded_cohort1_day2 + chemo_u_ctrl_bi_day2

    # Second unrewarded case: symmetric maze/no water-port branch.
    all_unrewarded_day1 = chemo_u_ctrl_bi_day1 + ['1636Rday1', '325RLday1']
    all_unrewarded_day2 = chemo_u_ctrl_bi_day2 + ['1636Rday2', '325RLday2']

    ltm_three_day1 = [
        '418-3day1', '434-3day1', '451-3day1', '488-3day1', '489-3day1', '579-3day1',
        '468-3day1', '618-3day1', '646-3day1', '640-3day1', '644-3day1',
        '837-3day1', '838-3day1', '862-3day1', '839-3day1', '842-3day1',
        '422-3day1',
        # '840-3day1', '841-3day1',
    ]
    ltm_three_day2 = [
        '418-3day2', '434-3day2', '451-3day2', '488-3day2', '489-3day2', '579-3day2',
        '468-3day2', '618-3day2', '646-3day2', '640-3day2', '644-3day2',
        '837-3day2', '838-3day2', '862-3day2', '839-3day2', '842-3day2',
        '422-3day2',
        # '840-3day2', '841-3day2',
    ]
    ltm_six_day1 = [
        '418-6day1', '434-6day1', '451-6day1', '488-6day1', '489-6day1', '579-6day1',
        '468-6day1', '618-6day1', '646-6day1', '640-6day1', '644-6day1',
        '837-6day1', '838-6day1', '862-6day1', '839-6day1', '842-6day1',
        '422-6day1',
        # '840-6day1', '841-6day1',
    ]
    ltm_six_day2 = [
        '418-6day2', '434-6day2', '451-6day2', '488-6day2', '489-6day2', '579-6day2',
        '468-6day2', '618-6day2', '646-6day2', '640-6day2', '644-6day2',
        '837-6day2', '838-6day2', '862-6day2', '839-6day2', '842-6day2',
        '422-6day2',
        # '840-6day2', '841-6day2',
    ]
    # 862-9 excluded (animal was medicated at 9-month timepoint).
    ltm_nine_day1 = ['418-9day1', '451-9day1', '488-9day1', '579-9day1', '468-9day1', '646-9day1', '644-9day1', '640-9day1', '837-9day1', '838-9day1', '839-9day1', '842-9day1']
    ltm_nine_day2 = ['418-9day2', '451-9day2', '488-9day2', '579-9day2', '468-9day2', '646-9day2', '644-9day2', '640-9day2', '837-9day2', '838-9day2', '839-9day2', '842-9day2']
    ltm_twelve_day1 = ['451-12day1', '468-12day1', '418-12day1', '644-12day1', '646-12day1', '640-12day1', '618-12day1']
    ltm_twelve_day2 = ['451-12day2', '468-12day2', '418-12day2', '644-12day2', '646-12day2', '640-12day2', '618-12day2']

    return {
        'RewardedDay1': rewarded_day1,
        'RewardedDay2': rewarded_day2,

        # Canonical unrewarded groups (n=13; first-day unrewarded, day2 rewarded).
        'UnrewardedDay1': unrewarded_day1,
        'UnrewardedDay2': unrewarded_day2,
        # Backward-compatible first cohort keys (n=6).
        'UnrewardedCohort1Day1': unrewarded_cohort1_day1,
        'UnrewardedCohort1Day2': unrewarded_cohort1_day2,

        # Symmetric/no-water-port branch.
        'AllUnrewardedDay1': all_unrewarded_day1,
        'AllUnrewardedDay2': all_unrewarded_day2,
        'UnrewardedSym': all_unrewarded_day2,

        'LTMThreeDay1': ltm_three_day1,
        'LTMThreeDay2': ltm_three_day2,
        'LTMSixDay1': ltm_six_day1,
        'LTMSixDay2': ltm_six_day2,
        'LTMNineDay1': ltm_nine_day1,
        'LTMNineDay2': ltm_nine_day2,
        'LTMTwelveDay1': ltm_twelve_day1,
        'LTMTwelveDay2': ltm_twelve_day2,

        # Legacy LTM shorthand retained for migration compatibility.
        'LTMDay1': ['418RRday1', '434RRday1', '451Rday1', '488Rday1', '489Lday1', '579RLday1', '468Lday1', '618day1', '646day1', '640day1', '644day1'],
        'LTMDay2': ['418RRday2', '434RRday2', '451Rday2', '488Rday2', '489Lday2', '579RLday2', '468Lday2', '618day2', '646day2', '640day2', '644day2'],
        'LTM_all': ['418-9day1', '451-9day1', '488-9day1', '579-9day1', '468-9day1', '646-9day1', '644-9day1', '640-9day1', '451-12day1', '468-12day1', '418-12day1', '644-12day1', '646-12day1', '640-12day1'],

        # Legacy chemo keys.
        'ChemoBIday1': chemo_bi_day1,
        'ChemoBIday2': chemo_bi_day2,
        'ChemoCBIday1': chemo_ctrl_bi_day1,
        'ChemoCBIday2': chemo_ctrl_bi_day2,
        'ChemoUBIday1': chemo_u_bi_day1,
        'ChemoUBIday2': chemo_u_bi_day2,
        'ChemoUCBIday1': chemo_u_ctrl_bi_day1,
        'ChemoUCBIday2': chemo_u_ctrl_bi_day2,
        'ChemoBO': ['22pfc-PSAM-1stdose', '21pfc-hM4D', '24pfc-PSAM', '26pfc-PSAM', '20hip-PSAM-1stdose', '20hip-PSAM-2nddose', '23hip-PSAM', '25hip-PSAM', '19hip-hM4D'],

        # Readable chemo aliases.
        'ChemoSilencingDay1BI': chemo_bi_day1,
        'ChemoSilencingDay2BI': chemo_bi_day2,
        'ChemoControlDay1BI': chemo_ctrl_bi_day1,
        'ChemoControlDay2BI': chemo_ctrl_bi_day2,
        'ChemoUSilencingDay1BI': chemo_u_bi_day1,
        'ChemoUSilencingDay2BI': chemo_u_bi_day2,
        'ChemoUControlDay1BI': chemo_u_ctrl_bi_day1,
        'ChemoUControlDay2BI': chemo_u_ctrl_bi_day2,

        # ULTM split cohorts.
        'ULTMSixDay1_1': ['1639-6day1-1', '1636-6day1-1', '347-6day1-1', '1637-6day1-1', '325-6day1-1'],
        'ULTMSixDay2_1': ['1639-6day2-1', '1636-6day2-1', '347-6day2-1', '1637-6day2-1', '325-6day2-1'],
        'ULTMSixDay1_2': ['1639-6day1-2', '1636-6day1-2', '347-6day1-2', '1637-6day1-2', '325-6day1-2'],
        'ULTMSixDay2_2': ['1639-6day2-2', '1636-6day2-2', '347-6day2-2', '1637-6day2-2', '325-6day2-2'],
    }


def behavior_group_meanings_260113() -> dict[str, str]:
    return {
        'RewardedDay1': 'Rewarded cohort, day 1.',
        'RewardedDay2': 'Rewarded cohort, day 2.',
        'UnrewardedDay1': 'Combined unrewarded cohort (first cohort + chemoU control), day 1 (unrewarded day).',
        'UnrewardedDay2': 'Combined unrewarded cohort (first cohort + chemoU control), day 2 (reward-return day).',
        'UnrewardedCohort1Day1': 'Original first unrewarded cohort only, day 1.',
        'UnrewardedCohort1Day2': 'Original first unrewarded cohort only, day 2.',
        'AllUnrewardedDay2': 'No-water-port/symmetric unrewarded branch used for day-2 comparisons (n=9).',
        'ChemoCBIday1': 'Chemogenetic control (behavior+imaging), day 1 control cohort.',
        'ChemoCBIday2': 'Chemogenetic control (behavior+imaging), day 2 control cohort.',
        'ChemoBIday1': 'Chemogenetic silencing-on-day1 cohort (behavior+imaging), day 1.',
        'ChemoBIday2': 'Chemogenetic silencing-on-day1 cohort (behavior+imaging), day 2.',
        'ChemoUBIday1': 'ChemoU cohort (silencing on day 2), behavior+imaging, day 1 baseline.',
        'ChemoUBIday2': 'ChemoU cohort (silencing on day 2), behavior+imaging, day 2 silenced.',
        'ChemoUCBIday1': 'ChemoU control cohort, behavior+imaging, day 1 baseline.',
        'ChemoUCBIday2': 'ChemoU control cohort, behavior+imaging, day 2 control.',
        'ChemoBO': 'Chemogenetic behavior-only cohorts (no calcium imaging).',
        'LTMThreeDay1': 'LTM rewarded cohort, ~3-month retention, day 1.',
        'LTMSixDay1': 'LTM rewarded cohort, ~6-month retention, day 1.',
        'LTMNineDay1': 'LTM rewarded cohort, ~9-month retention, day 1.',
        'LTMTwelveDay1': 'LTM rewarded cohort, ~12-month retention, day 1.',
    }


def build_behav_measure_design(groups: dict[str, list[str]]):
    rows = []
    spec = [
        ('RewardedDay1', 0, 1, 1, 0),
        ('RewardedDay2', 0, 2, 1, 1),
        ('LTMThreeDay1', 3, 1, 1, 2),
        ('LTMThreeDay2', 3, 2, 1, 3),
        ('LTMSixDay1', 6, 1, 1, 4),
        ('LTMSixDay2', 6, 2, 1, 5),
        ('LTMNineDay1', 9, 1, 1, 6),
        ('LTMNineDay2', 9, 2, 1, 7),
        ('LTMTwelveDay1', 12, 1, 1, 8),
        ('LTMTwelveDay2', 12, 2, 1, 9),
    ]
    for key, month, day, init_reward, visits in spec:
        for nickname in groups.get(key, []):
            rows.append(
                {
                    'nickname': nickname,
                    'month': month,
                    'day': day,
                    'init_reward': init_reward,
                    'visits': visits,
                }
            )
    return pd.DataFrame(rows)


def _flatten_reward_frames(tf):
    vals = [y[0] + tf.fr[i, 0] for i, r in enumerate(tf.re) for y in r]
    return np.asarray(vals, dtype=float)


def _safe_max_diff(x):
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return np.nan
    if x.size == 1:
        return float(x[0])
    return float(max(float(x[0]), float(np.nanmax(np.diff(x)))))


def compute_reward_metrics_from_traj(
    tf,
    *,
    fps=FPS,
    time_in_maze_fn: Callable[[Any, Any], float] | None = None,
    find_paths_to_node_fn: Callable[..., Any] | None = None,
    ma=None,
    water_node=REWARD_NODE,
    reward_state=143,
    long_path_min=7,
    inner_nodes=None,
):
    """Compute per-session reward-performance metrics along three axes.

    Triple-axis design (2026-04-17):
      - Time axis (seconds): `ti1`, `ti10`, `lg`, `mri`, `wd`, `lb0`, `lbmax`
      - Step axis (node runs or state transitions): `dn0`, `dn10`, `dnmax`,
        `st0`, `st10`, `stmax`, `slb0`, `slbmax`
      - Decision axis (entries into inner bifurcation nodes): `de0`, `de10`,
        `demax`, `decisions_per_reward`, `total_decisions`

    An "inner node" is any non-leaf, non-root bifurcation node the animal can
    reach mid-path; default set is `DEFAULT_INNER_NODES` from exploration.py
    (nodes 75-114 for the 6-level binary tree). Each run entry into such a
    node is counted as one decision event.
    """
    # Lazy-import the canonical inner-node set to avoid circular imports at
    # package load; this makes the decision axis testable without a full env.
    if inner_nodes is None:
        try:
            from .exploration import DEFAULT_INNER_NODES
            inner_nodes = DEFAULT_INNER_NODES
        except Exception:
            inner_nodes = np.array([], dtype=int)
    inner_set = set(int(x) for x in np.asarray(inner_nodes).ravel().tolist())

    out = {
        # Time axis
        'ti1': np.nan, 'ti10': np.nan, 'lg': np.nan, 'mri': np.nan,
        'wd': np.nan, 'lb0': np.nan, 'lbmax': np.nan,
        # Step axis (node runs)
        'dn0': np.nan, 'dn10': np.nan, 'dnmax': np.nan,
        # Step axis (state transitions)
        'st0': np.nan, 'st10': np.nan, 'stmax': np.nan,
        # Step axis (long-bout path length in tree steps)
        'slb0': np.nan, 'slbmax': np.nan,
        # Decision axis
        'de0': np.nan, 'de10': np.nan, 'demax': np.nan,
        'total_decisions': np.nan, 'decisions_per_reward': np.nan,
        # Count
        'n_rewards': 0,
    }

    re = _flatten_reward_frames(tf)
    out['n_rewards'] = int(re.size)
    if re.size and time_in_maze_fn is not None:
        ti = np.asarray([time_in_maze_fn(r, tf) for r in re], dtype=float)
    else:
        ti = re / float(fps) if re.size else np.array([], dtype=float)

    if ti.size:
        out['ti1'] = float(ti[0])
        out['ti10'] = float(ti[9]) if ti.size > 9 else np.nan
        out['lg'] = _safe_max_diff(ti)
        if ti.size > 1:
            out['mri'] = float(np.nanmean(np.diff(ti)))

    wd = []
    no_all = []
    for b in tf.no:
        b = np.asarray(b)
        if b.ndim != 2 or b.shape[1] < 2:
            continue
        no_all.append(b[:, 0])
        wk = np.where(b[:, 0] == water_node)[0]
        if wk.size:
            wd.append(float(b[wk[0], 1]) / float(fps))
    if wd:
        out['wd'] = float(np.nanmax(wd))

    if no_all:
        no_all = np.concatenate(no_all).astype(int, copy=False)
        # Decision axis: inner-node entries in the deduped node-run sequence.
        # Each entry in `no_all` is one run (contiguous occupancy at a node),
        # so `is_inner` marks each run that lands on a bifurcation node.
        if inner_set:
            is_inner = np.fromiter(
                (int(x) in inner_set for x in no_all), dtype=bool,
                count=no_all.size,
            )
        else:
            is_inner = np.zeros(no_all.size, dtype=bool)
        total_dec = int(is_inner.sum())
        out['total_decisions'] = float(total_dec)
        if out['n_rewards'] > 0:
            out['decisions_per_reward'] = float(total_dec) / float(out['n_rewards'])

        ri = np.where(no_all == water_node)[0]
        if ri.size:
            st = np.append(ri[0], np.diff(ri)).astype(float)
            out['dn0'] = float(st[0])
            out['dnmax'] = float(np.nanmax(st))
            if ri.size > 9:
                out['dn10'] = float(ri[9])

            # Decision counts anchored on water-node visits. Convention:
            # `de0` counts inner entries in the prefix *up to and including*
            # run index ri[0] (i.e., inclusive of the first water-node run).
            # Pairs with dn0 = ri[0], which counts one-based position.
            cum_inner = np.concatenate([[0], np.cumsum(is_inner)])  # len = N+1
            de0 = int(cum_inner[ri[0] + 1])
            out['de0'] = float(de0)
            if ri.size > 9:
                out['de10'] = float(int(cum_inner[ri[9] + 1]))
            # demax: largest decision-count gap between consecutive water-node
            # visits (and before the first). Matches dnmax semantics.
            starts = np.concatenate([[0], ri[:-1] + 1])
            ends = ri + 1
            gaps = cum_inner[ends] - cum_inner[starts]
            out['demax'] = float(np.nanmax(gaps))

    ce_all = []
    for ce in getattr(tf, 'ce', []):
        temp = np.asarray(ce).ravel()
        if temp.size:
            ce_all.append(temp[np.insert(np.diff(temp) != 0, 0, True)])
    if ce_all:
        ce_cat = np.concatenate(ce_all).astype(int, copy=False)
        ri = np.where(ce_cat == reward_state)[0]
        if ri.size:
            st = np.append(ri[0], np.diff(ri)).astype(float)
            out['st0'] = float(st[0])
            out['stmax'] = float(np.nanmax(st))
            if ri.size > 9:
                out['st10'] = float(ri[9])

    if find_paths_to_node_fn is not None and time_in_maze_fn is not None and ma is not None:
        try:
            ptn = np.asarray(find_paths_to_node_fn(water_node, tf, ma))
            if ptn.ndim == 2 and ptn.shape[1] >= 4:
                ptn = ptn[np.where(ptn[:, 2] >= long_path_min)]
                x = [time_in_maze_fn(p, tf) for p in ptn[:, 3]]
                x = np.asarray(x, dtype=float)
                if x.size:
                    bg = np.append(x[0], np.diff(x))
                    out['lb0'] = float(bg[0])
                    out['lbmax'] = float(np.nanmax(bg))
                    # Step axis for long bouts: path length in tree steps.
                    # ptn[:, 2] is the post-filter path length (>= long_path_min).
                    lens = np.asarray(ptn[:, 2], dtype=float)
                    out['slb0'] = float(lens[0])
                    out['slbmax'] = float(np.nanmax(lens))
        except Exception:
            pass

    return out


def build_behavior_measure_table(
    design_df: pd.DataFrame,
    *,
    load_traj_fn: Callable[[str], Any],
    fps=FPS,
    time_in_maze_fn: Callable[[Any, Any], float] | None = None,
    find_paths_to_node_fn: Callable[..., Any] | None = None,
    ma=None,
):
    metric_cols = [
        # Time axis
        'ti1', 'ti10', 'lg', 'mri', 'wd', 'lb0', 'lbmax',
        # Step axis (node runs / state transitions / path length)
        'dn0', 'dn10', 'dnmax', 'st0', 'st10', 'stmax', 'slb0', 'slbmax',
        # Decision axis
        'de0', 'de10', 'demax', 'total_decisions', 'decisions_per_reward',
        # Count
        'n_rewards',
    ]
    rows = []
    skipped = []
    for _, row in design_df.iterrows():
        nick = str(row['nickname'])
        try:
            tf = load_traj_fn(f'{nick}-tf')
            m = compute_reward_metrics_from_traj(
                tf,
                fps=fps,
                time_in_maze_fn=time_in_maze_fn,
                find_paths_to_node_fn=find_paths_to_node_fn,
                ma=ma,
            )
            rows.append({**row.to_dict(), **m})
        except Exception as exc:
            skipped.append({'nickname': nick, 'error': str(exc)})
    if rows:
        out = pd.DataFrame(rows)
    else:
        out = pd.DataFrame(columns=list(design_df.columns) + metric_cols)
    return out, skipped


def summarize_metric_by_month(df: pd.DataFrame, metric: str, *, day=1):
    if metric not in df.columns:
        return pd.DataFrame(columns=['month', 'n', 'mean', 'median', 'sem'])
    sub = df.loc[df['day'] == day, ['month', metric]].copy()
    sub[metric] = pd.to_numeric(sub[metric], errors='coerce')
    sub = sub[np.isfinite(sub[metric])]
    if sub.empty:
        return pd.DataFrame(columns=['month', 'n', 'mean', 'median', 'sem'])
    g = sub.groupby('month')[metric]
    out = g.agg(['count', 'mean', 'median']).reset_index().rename(columns={'count': 'n'})
    out['sem'] = g.apply(sem).values
    return out.sort_values('month').reset_index(drop=True)


def cover_time(seq, num_states=64):
    seen = set()
    for idx, state in enumerate(seq, start=1):
        seen.add(state)
        if len(seen) == num_states:
            return idx
    return None


def exploration_chunks(ns, k_new=32, include_boundary=False, keep_incomplete_last=False):
    if k_new <= 0:
        raise ValueError('k_new must be positive')
    N = len(ns)
    segments = []
    per_step_eff = [float('nan')] * N
    i = 0
    while i < N:
        seen = set()
        start = i
        j = i
        while j < N and len(seen) < k_new:
            seen.add(ns[j])
            j += 1
        unique_found = len(seen)
        if unique_found < k_new:
            if keep_incomplete_last and j > start:
                steps = j - start
                eff = unique_found / steps
                segments.append({'start': start, 'end': j, 'steps': steps, 'unique_found': unique_found, 'efficiency': eff})
                for t in range(start, j):
                    per_step_eff[t] = eff
            break
        steps = j - start
        eff = k_new / steps
        segments.append({'start': start, 'end': j, 'steps': steps, 'unique_found': k_new, 'efficiency': eff})
        for t in range(start, j):
            per_step_eff[t] = eff
        i = j if include_boundary else min(j + 1, N)
    return {'segments': segments, 'per_step_efficiency': per_step_eff, 'k_new': k_new}


def _end_level_nodes(level=6):
    return np.arange(2 ** level - 1, 2 ** (level + 1) - 1, dtype=int)


def _safe_cover_efficiency(ns, num_states=32):
    if ns is None or len(ns) == 0:
        return 0.0
    ct = cover_time(ns, num_states=num_states)
    if ct is None or ct == 0:
        return 0.0
    return float(num_states) / float(ct)


def safe_cover_efficiency(ns, num_states=32):
    return _safe_cover_efficiency(ns, num_states=num_states)


def compute_exploration_efficiency_for_group(
    nicknames,
    *,
    load_traj_fn: Callable[[str], Any],
    split_mode_clips_fn: Callable[..., Any],
    ma,
    mode_indices=(0, 1, 2),
    end_level=6,
    num_states=32,
    k_new=32,
):
    _, _, explore_idx = mode_indices
    half1 = []
    half2 = []
    ff = []
    included = []
    excluded = []
    end_nodes = _end_level_nodes(end_level)

    for nickname in nicknames:
        try:
            tf = load_traj_fn(f'{nickname}-tf')
            cl = np.asarray(split_mode_clips_fn(tf, ma))
            ce = cl[np.where(cl[:, 3] == explore_idx)]
            ne = np.concatenate([tf.no[c[0]][c[1]:c[1] + c[2], 0] for c in ce])
            ns = ne[np.isin(ne, end_nodes)]
            h1 = _safe_cover_efficiency(ns, num_states=num_states)
            ns2 = ns[int(len(ns) / 2):] if len(ns) else ns
            h2 = _safe_cover_efficiency(ns2, num_states=num_states)
            et = exploration_chunks(ns, k_new=k_new)
            ff_list = [seg['efficiency'] for seg in et['segments']]
            half1.append(h1)
            half2.append(h2)
            ff.append(ff_list)
            included.append(nickname)
        except Exception as exc:
            excluded.append({'nickname': nickname, 'error': str(exc)})
    return {
        'half1': np.asarray(half1, dtype=float),
        'half2': np.asarray(half2, dtype=float),
        'ff': ff,
        'included': included,
        'excluded': excluded,
    }


def process_one_animal(
    nickname,
    ma,
    mode_indices,
    *,
    load_traj_fn: Callable[[str], Any],
    split_mode_clips_fn: Callable[..., Any],
    end_level=6,
    num_states=32,
    k_new=32,
):
    leave_idx, drink_idx, explore_idx = mode_indices
    _ = leave_idx, drink_idx
    tf = load_traj_fn(f'{nickname}-tf')
    cl = np.asarray(split_mode_clips_fn(tf, ma))
    ce = cl[np.where(cl[:, 3] == explore_idx)]
    if ce.size == 0:
        return 0.0, 0.0, []
    ne = np.concatenate([tf.no[c[0]][c[1]:c[1] + c[2], 0] for c in ce])
    ns = ne[np.isin(ne, _end_level_nodes(end_level))]
    h1 = _safe_cover_efficiency(ns, num_states=num_states)
    ns2 = ns[int(len(ns) / 2):] if len(ns) else ns
    h2 = _safe_cover_efficiency(ns2, num_states=num_states)
    et = exploration_chunks(ns, k_new=k_new)
    ff = [seg['efficiency'] for seg in et.get('segments', [])]
    return h1, h2, ff


def end_level_nodes(level=6):
    return _end_level_nodes(level)


def flexible_mean_sem(curves):
    if len(curves) == 0:
        return np.array([]), np.array([])
    max_len = max(len(c) for c in curves)
    means, sems = [], []
    for i in range(max_len):
        vals = [c[i] for c in curves if len(c) > i]
        if len(vals) == 0:
            means.append(np.nan)
            sems.append(np.nan)
        else:
            arr = np.asarray(vals, dtype=float)
            means.append(np.mean(arr))
            sems.append(np.std(arr, ddof=1) / np.sqrt(len(arr)) if len(arr) > 1 else 0.0)
    return np.array(means), np.array(sems)


def compute_group_metrics(
    nicknames,
    ma,
    mode_indices,
    *,
    load_traj_fn: Callable[[str], Any],
    split_mode_clips_fn: Callable[..., Any],
    end_level=6,
    num_states=32,
    k_new=32,
    group_name=None,
):
    out = compute_exploration_efficiency_for_group(
        nicknames,
        load_traj_fn=load_traj_fn,
        split_mode_clips_fn=split_mode_clips_fn,
        ma=ma,
        mode_indices=mode_indices,
        end_level=end_level,
        num_states=num_states,
        k_new=k_new,
    )
    meta = {
        'group_name': group_name or 'Group',
        'n_animals': int(len(nicknames)),
        'end_level': int(end_level),
        'num_states': int(num_states),
        'k_new': int(k_new),
        'included': out['included'],
        'excluded': out['excluded'],
    }
    return GroupResult(
        half1=list(np.asarray(out['half1'], dtype=float)),
        half2=list(np.asarray(out['half2'], dtype=float)),
        ff=out['ff'],
        meta=meta,
    )


def compute_multiple_groups(
    groups_dict,
    ma,
    mode_indices,
    *,
    load_traj_fn: Callable[[str], Any],
    split_mode_clips_fn: Callable[..., Any],
    end_level=6,
    num_states=32,
    k_new=32,
):
    results = {}
    for label, nicks in groups_dict.items():
        results[label] = compute_group_metrics(
            nicks,
            ma,
            mode_indices,
            load_traj_fn=load_traj_fn,
            split_mode_clips_fn=split_mode_clips_fn,
            end_level=end_level,
            num_states=num_states,
            k_new=k_new,
            group_name=label,
        )
    return results


def plot_group_ff(
    results_dict,
    *,
    colors=None,
    show_individual=True,
    alpha=0.06,
    linewidth=2.5,
    linestyle='--',
    xlabel='Chunk index',
    ylabel='Exploration efficiency',
):
    plt.figure(figsize=(7, 4))
    default_colors = [
        'tab:green', 'tab:orange', 'tab:blue', 'tab:red',
        'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan',
    ]
    labels = list(results_dict.keys())
    for i, label in enumerate(labels):
        color = colors.get(label) if isinstance(colors, dict) and label in colors else default_colors[i % len(default_colors)]
        curves = list(results_dict[label].ff)
        if show_individual:
            for c in curves:
                plt.plot(c, color=color, alpha=alpha)
        mean_flex, sem_flex = flexible_mean_sem(curves)
        x = np.arange(len(mean_flex))
        plt.plot(mean_flex, linewidth=linewidth, color=color, linestyle=linestyle, label=label)
        plt.fill_between(x, mean_flex - sem_flex, mean_flex + sem_flex, alpha=0.20, color=color)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.tight_layout()
    plt.show()


def _as_1d(a):
    a = np.asarray(a, dtype=float).ravel()
    return a[np.isfinite(a)]


def descriptives(x):
    x = _as_1d(x)
    if x.size == 0:
        return {'n': 0, 'median': np.nan, 'q1': np.nan, 'q3': np.nan, 'iqr': np.nan, 'mean': np.nan, 'std': np.nan}
    q1, q2, q3 = np.percentile(x, [25, 50, 75])
    return {
        'n': int(len(x)),
        'median': float(q2),
        'q1': float(q1),
        'q3': float(q3),
        'iqr': float(q3 - q1),
        'mean': float(np.mean(x)),
        'std': float(np.std(x, ddof=1)) if len(x) > 1 else float('nan'),
    }


def cliffs_delta(x, y, *, random_state=0, n_boot=3000):
    x = _as_1d(x)
    y = _as_1d(y)
    nx, ny = len(x), len(y)
    if nx == 0 or ny == 0:
        return np.nan, (np.nan, np.nan)
    greater = 0
    lesser = 0
    for xi in x:
        greater += np.sum(xi > y)
        lesser += np.sum(xi < y)
    delta = (greater - lesser) / (nx * ny)
    rng = np.random.default_rng(random_state)
    boots = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        xb = rng.choice(x, size=nx, replace=True)
        yb = rng.choice(y, size=ny, replace=True)
        g = 0
        l = 0
        for xi in xb:
            g += np.sum(xi > yb)
            l += np.sum(xi < yb)
        boots[i] = (g - l) / (nx * ny)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return float(delta), (float(lo), float(hi))


def _rank_biserial_from_u(u, nx, ny):
    return 2.0 * float(u) / float(nx * ny) - 1.0


def rank_biserial_from_U(U, nx, ny):
    return _rank_biserial_from_u(U, nx, ny)


def mann_whitney_with_effect(x, y, *, alternative='two-sided'):
    x = _as_1d(x)
    y = _as_1d(y)
    if len(x) == 0 or len(y) == 0:
        return {'U': np.nan, 'p': np.nan, 'rank_biserial_r': np.nan, 'cliffs_delta': np.nan, 'cliffs_delta_CI95': (np.nan, np.nan)}
    res = stats.mannwhitneyu(x, y, alternative=alternative)
    rb = _rank_biserial_from_u(res.statistic, len(x), len(y))
    d, d_ci = cliffs_delta(x, y)
    return {
        'U': float(res.statistic),
        'p': float(res.pvalue),
        'rank_biserial_r': float(rb),
        'cliffs_delta': float(d),
        'cliffs_delta_CI95': d_ci,
    }


def permutation_test_diff_medians(x, y, *, n_perm=10000, random_state=0):
    x = _as_1d(x)
    y = _as_1d(y)
    if len(x) == 0 or len(y) == 0:
        return {'median_diff': np.nan, 'p_perm_two_sided': np.nan}
    obs = float(np.median(x) - np.median(y))
    pooled = np.concatenate([x, y]).copy()
    nx = len(x)
    rng = np.random.default_rng(random_state)
    count = 0
    for _ in range(n_perm):
        rng.shuffle(pooled)
        d = np.median(pooled[:nx]) - np.median(pooled[nx:])
        if abs(d) >= abs(obs):
            count += 1
    p = (count + 1) / (n_perm + 1)
    return {'median_diff': obs, 'p_perm_two_sided': float(p)}


def bootstrap_ci_diff_medians(x, y, *, n_boot=5000, random_state=0):
    x = _as_1d(x)
    y = _as_1d(y)
    if len(x) == 0 or len(y) == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(random_state)
    nx, ny = len(x), len(y)
    boots = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        xb = rng.choice(x, size=nx, replace=True)
        yb = rng.choice(y, size=ny, replace=True)
        boots[i] = np.median(xb) - np.median(yb)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return float(lo), float(hi)


def analyze_two_groups(
    g1,
    g2,
    *,
    group_names=('G1', 'G2'),
    n_perm=10000,
    show_plots=False,
    random_state=0,
):
    g1 = _as_1d(g1)
    g2 = _as_1d(g2)
    out = {
        'descriptives': {
            group_names[0]: descriptives(g1),
            group_names[1]: descriptives(g2),
        },
        'mann_whitney': mann_whitney_with_effect(g1, g2),
        'permutation_test': permutation_test_diff_medians(g1, g2, n_perm=n_perm, random_state=random_state),
    }
    lo, hi = bootstrap_ci_diff_medians(g1, g2, random_state=random_state)
    out['median_diff_CI95'] = (float(lo), float(hi))
    med1 = out['descriptives'][group_names[0]]['median']
    med2 = out['descriptives'][group_names[1]]['median']
    U = out['mann_whitney']['U']
    p_mw = out['mann_whitney']['p']
    d = out['mann_whitney']['cliffs_delta']
    d_lo, d_hi = out['mann_whitney']['cliffs_delta_CI95']
    p_perm = out['permutation_test']['p_perm_two_sided']
    mdiff = out['permutation_test']['median_diff']
    out['formatted_summary'] = (
        f"{group_names[0]} vs {group_names[1]}: medians {med1:.3f} vs {med2:.3f}; "
        f"median difference = {mdiff:.3f} (boot 95% CI [{lo:.3f}, {hi:.3f}]). "
        f"Mann-Whitney U = {U:.1f}, p = {p_mw:.4f}; "
        f"Cliff's delta = {d:.3f} (95% CI [{d_lo:.3f}, {d_hi:.3f}]); "
        f"Permutation p (medians, two-sided) = {p_perm:.4f}."
    )
    if show_plots:
        _plot_two_group_dots(g1, g2, group_names=group_names)
    return out


def _plot_two_group_dots(g1, g2, *, group_names=('G1', 'G2')):
    fig, ax = plt.subplots(figsize=(6, 4))
    rng = np.random.default_rng(0)
    j = 0.08
    x1 = np.ones(len(g1))
    x2 = np.ones(len(g2)) * 2.0
    ax.plot(x1 + rng.uniform(-j, j, size=len(g1)), g1, 'o', alpha=0.8)
    ax.plot(x2 + rng.uniform(-j, j, size=len(g2)), g2, 'o', alpha=0.8)
    for i, data in enumerate([g1, g2], start=1):
        if len(data):
            q1, med, q3 = np.percentile(data, [25, 50, 75])
            ax.plot([i - 0.2, i + 0.2], [med, med], lw=3, c='k')
            ax.plot([i, i], [q1, q3], lw=3, c='k')
    ax.set_xticks([1, 2])
    ax.set_xticklabels(list(group_names))
    ax.set_ylabel('Value')
    ax.set_title('Individual values with median and IQR')
    plt.tight_layout()
    plt.show()
    return fig, ax


def plot_dots_with_median_iqr(x, y, labels=('G1', 'G2')):
    x = _as_1d(x)
    y = _as_1d(y)
    fig, ax = plt.subplots(figsize=(6, 4))
    rng = np.random.default_rng(0)
    jitter = 0.08
    ax.plot(np.full_like(x, 1.0) + rng.uniform(-jitter, jitter, size=len(x)), x, 'o', alpha=0.8)
    ax.plot(np.full_like(y, 2.0) + rng.uniform(-jitter, jitter, size=len(y)), y, 'o', alpha=0.8)
    for i, data in enumerate([x, y], start=1):
        if len(data) == 0:
            continue
        q1, med, q3 = np.percentile(data, [25, 50, 75])
        ax.plot([i - 0.2, i + 0.2], [med, med], lw=3)
        ax.plot([i, i], [q1, q3], lw=3)
        ax.plot([i - 0.1, i + 0.1], [q1, q1], lw=2)
        ax.plot([i - 0.1, i + 0.1], [q3, q3], lw=2)
    ax.set_xticks([1, 2])
    ax.set_xticklabels(list(labels))
    ax.set_ylabel('Value')
    ax.set_title('Individual values with median and IQR')
    plt.tight_layout()
    return fig, ax


def plot_rank_order_overlay(x, y, labels=('G1', 'G2')):
    x = np.sort(_as_1d(x))
    y = np.sort(_as_1d(y))
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(np.arange(1, len(x) + 1), x, marker='o', label=labels[0])
    ax.plot(np.arange(1, len(y) + 1), y, marker='o', label=labels[1])
    ax.set_xlabel('Rank')
    ax.set_ylabel('Value')
    ax.set_title('Rank-order overlay')
    ax.legend()
    plt.tight_layout()
    return fig, ax


def _stars(p):
    if not np.isfinite(p):
        return 'n.s.'
    return '****' if p < 1e-4 else ('***' if p < 1e-3 else ('**' if p < 1e-2 else ('*' if p < 0.05 else 'n.s.')))


def _holm_correction(pvals, alpha=0.05):
    return _holm_correction_canonical(pvals, alpha=alpha)


def _dunnett_correction(pvals, alpha=0.05):
    pvals = np.asarray(pvals, float)
    m = len(pvals)
    if m == 0:
        return np.array([], dtype=bool), np.array([], dtype=float)
    adj_pvals = 1.0 - np.power(1.0 - np.minimum(pvals, 1.0), m)
    adj_pvals = np.minimum(adj_pvals, 1.0)
    return adj_pvals < alpha, adj_pvals


def _annotate_pair(ax, x1, x2, y, h, text, lw=1.2):
    ax.plot([x1, x1, x2, x2], [y, y + h * 0.3, y + h * 0.3, y], lw=lw, c='k')
    ax.text((x1 + x2) / 2.0, y + h * 0.35, text, ha='center', va='bottom')
    return y + h * 1.2


def _resolve_color(spec, label, i, fallback=None):
    if spec is None:
        return fallback
    if isinstance(spec, dict):
        return spec.get(label, fallback)
    if isinstance(spec, (list, tuple)) and not isinstance(spec, (str, bytes)):
        return spec[i % len(spec)]
    return spec


def barplot_with_points_and_stats(
    group_data,
    *,
    selected_labels=None,
    test='nonparametric',
    pairs='all',
    correction='dunnett',
    control_group=None,
    alpha=0.05,
    title='',
    ylabel='Value',
    figsize=(8, 6),
    bar_colors=None,
    point_colors=None,
    bar_alpha=0.3,
    point_alpha=0.55,
    point_size=30,
    point_jitter=0.12,
    capsize=4,
    seed=0,
):
    labels_all = list(group_data.keys())
    labels = labels_all if selected_labels is None else list(selected_labels)
    data = []
    keep_labels = []
    for l in labels:
        x = _as_1d(group_data.get(l, []))
        if x.size:
            data.append(x)
            keep_labels.append(l)
    labels = keep_labels
    if len(labels) == 0:
        fig, ax = plt.subplots(figsize=figsize)
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.text(0.5, 0.5, 'No data', ha='center', va='center', transform=ax.transAxes)
        return ax, {'omnibus': None, 'pairs': []}

    means = np.array([np.nanmean(d) for d in data], dtype=float)
    sems = np.array([stats.sem(d, nan_policy='omit') if len(d) > 1 else 0.0 for d in data], dtype=float)
    x = np.arange(len(labels), dtype=float)

    fig, ax = plt.subplots(figsize=figsize)
    for i, l in enumerate(labels):
        bc = _resolve_color(bar_colors, l, i, fallback='#8BBDEB')
        pc = _resolve_color(point_colors, l, i, fallback=bc)
        ax.bar(x[i], means[i], yerr=sems[i], width=0.6, color=bc, alpha=bar_alpha, capsize=capsize, edgecolor='black')
        rng = np.random.default_rng(seed + i)
        jitter = rng.uniform(-point_jitter, point_jitter, size=len(data[i]))
        ax.scatter(np.full(len(data[i]), x[i]) + jitter, data[i], color=pc, alpha=point_alpha, s=point_size, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)

    if len(data) >= 2:
        if str(test).lower() == 'parametric':
            stat, p = stats.f_oneway(*data)
            omnibus = {'test': 'anova', 'stat': float(stat), 'p': float(p)}
        else:
            stat, p = stats.kruskal(*data)
            omnibus = {'test': 'kruskal', 'stat': float(stat), 'p': float(p)}
    else:
        omnibus = None

    if pairs == 'all':
        pair_labels = list(combinations(labels, 2))
    else:
        pair_labels = list(pairs)
    if correction == 'dunnett' and len(labels) > 1:
        ctrl = control_group if control_group in labels else labels[0]
        pair_labels = [(ctrl, l) for l in labels if l != ctrl]

    pair_rows = []
    raw_p = []
    for a, b in pair_labels:
        if a not in labels or b not in labels:
            continue
        xa = data[labels.index(a)]
        xb = data[labels.index(b)]
        if str(test).lower() == 'parametric':
            _, p = stats.ttest_ind(xa, xb, equal_var=False, nan_policy='omit')
        else:
            _, p = stats.mannwhitneyu(xa, xb, alternative='two-sided')
        raw_p.append(float(p))
        pair_rows.append({'group_a': a, 'group_b': b, 'p_raw': float(p)})

    if len(pair_rows):
        if correction == 'holm':
            reject, p_adj = _holm_correction(raw_p, alpha=alpha)
        else:
            reject, p_adj = _dunnett_correction(raw_p, alpha=alpha)
        ymax = np.nanmax([np.nanmax(d) if len(d) else np.nan for d in data])
        y = float(ymax * 1.05) if np.isfinite(ymax) else 1.0
        h = max(abs(y) * 0.08, 0.1)
        for i, row in enumerate(pair_rows):
            row['p_adj'] = float(p_adj[i])
            row['reject'] = bool(reject[i])
            xa = labels.index(row['group_a'])
            xb = labels.index(row['group_b'])
            y = _annotate_pair(ax, xa, xb, y, h, _stars(row['p_adj']))

    plt.tight_layout()
    return ax, {'omnibus': omnibus, 'pairs': pair_rows}


def pairwise_test(x, y, *, test='mannwhitney'):
    xa = _as_1d(x)
    ya = _as_1d(y)
    if len(xa) == 0 or len(ya) == 0:
        return {'test': test, 'stat': np.nan, 'p': np.nan}
    if str(test).lower().startswith('t'):
        stat, p = stats.ttest_ind(xa, ya, equal_var=False, nan_policy='omit')
        return {'test': 'ttest_ind', 'stat': float(stat), 'p': float(p)}
    stat, p = stats.mannwhitneyu(xa, ya, alternative='two-sided')
    return {'test': 'mannwhitneyu', 'stat': float(stat), 'p': float(p)}


def load_behav(session_name, *, behav_wd=None, neural_wd=None):
    from .io import load_behav_neural
    from pathlib import Path

    repo = Path(__file__).resolve().parents[2]
    if behav_wd is None:
        behav_wd = str(repo)
    if neural_wd is None:
        neural_wd = str(repo / "neuralData")

    return load_behav_neural(
        str(session_name),
        behav_wd=behav_wd,
        neural_wd=neural_wd,
    )


def find_which_comes_first(arr, value1, value2):
    arr = np.asarray(arr)
    ones = np.where(arr == value1)[0]
    twos = np.where(arr == value2)[0]
    if len(ones) == 0 and len(twos) == 0:
        return None
    if len(ones) == 0:
        return value2
    if len(twos) == 0:
        return value1
    return value1 if ones[0] < twos[0] else value2


def find_which_comes_first_binary(arr, value1, value2):
    arr = np.asarray(arr)
    ones = np.where(arr == value1)[0]
    twos = np.where(arr == value2)[0]
    if len(ones) == 0 and len(twos) == 0:
        return None
    if len(ones) == 0:
        return 1
    if len(twos) == 0:
        return 0
    return 0 if ones[0] < twos[0] else 1


def generate_triplets(start, end):
    triplets = []
    for a in range(start, end, 2):
        b = (a - 1) // 2
        triplets.append([a, b, a + 1])
    return triplets


def find_triplet_indices(array, triplets):
    arr = np.asarray(array)
    if arr.size < 3:
        return []
    windowed = np.lib.stride_tricks.sliding_window_view(arr, (3,))
    indices = []
    for triplet in triplets:
        t = np.asarray(triplet)
        rt = t[::-1]
        matches = np.all(windowed == t, axis=1) | np.all(windowed == rt, axis=1)
        indices.extend(np.where(matches)[0].tolist())
    return sorted(indices)


def func(x, a, b):
    z = np.asarray(x, dtype=float) / float(a)
    return 64.0 * (1.0 - 1.0 / (1.0 + (z + b * z**3) / (1.0 + b)))


def power_law(x, a, b, c):
    x = np.asarray(x, dtype=float)
    return a * np.power(x, -b) + c


def exponential(x, a, b, c):
    x = np.asarray(x, dtype=float)
    return a * np.exp(-b * x) + c


def exp_plus_linear(x, a, b, r, c):
    x = np.asarray(x, dtype=float)
    return a * (1.0 - np.exp(-b * x)) + r * x + c


def linear_only(x, r, c):
    x = np.asarray(x, dtype=float)
    return r * x + c


def log_plus_linear(x, a, b, r, c):
    x = np.asarray(x, dtype=float)
    return a * np.log(b * x + 1.0) + r * x + c
