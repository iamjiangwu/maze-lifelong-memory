from __future__ import annotations

# Auto-migrated local copy from source workspace module.

import numpy as np
from scipy.ndimage import gaussian_filter


def discretize_positions(positions, n_bins_x=15, n_bins_y=15):
    """
    Clip positions to [0,1] range and discretize into bin indices.

    Parameters
    ----------
    positions : array-like
        - 2D: shape (T, 2), interpreted as (x, y) in [0,1] (may contain <0 or >1)
        - 1D: shape (T,) or (T, 1), interpreted as x in [0,1] with a single
          degenerate y-bin (all samples in y-bin 0).
    n_bins_x : int
        Number of bins along x.
    n_bins_y : int
        Number of bins along y.

    Returns
    -------
    labels : (T,) int array
        Integer bin indices in [0 .. n_bins_x * n_bins_y - 1].
    x_edges : (n_bins_x+1,) float array
        Bin edges from 0 to 1 along x.
    y_edges : (n_bins_y+1,) float array
        Bin edges from 0 to 1 along y.
    """
    positions = np.asarray(positions, dtype=float)

    if positions.ndim == 1:
        x = np.clip(positions, 0.0, 1.0)
        y = np.zeros_like(x)
    elif positions.ndim == 2:
        clipped = np.clip(positions, 0.0, 1.0)
        x = clipped[:, 0]
        if clipped.shape[1] > 1:
            y = clipped[:, 1]
        else:
            y = np.zeros_like(x)
    else:
        raise ValueError("positions must be a 1D array (T,) or 2D array (T,1)/(T,2).")

    x_edges = np.linspace(0.0, 1.0, n_bins_x + 1)
    y_edges = np.linspace(0.0, 1.0, n_bins_y + 1)

    x_bin = np.clip(np.digitize(x, x_edges) - 1, 0, n_bins_x - 1)
    y_bin = np.clip(np.digitize(y, y_edges) - 1, 0, n_bins_y - 1)

    labels = y_bin * n_bins_x + x_bin
    return labels.astype(int), x_edges, y_edges


def compute_lifetime_sparsity(rates):
    """Treves & Rolls lifetime sparsity."""
    rates = np.array(rates)
    if rates.ndim == 2:
        mean_rate = np.nanmean(rates, axis=0)
        mean_sq_rate = np.nanmean(rates ** 2, axis=0)
        with np.errstate(divide='ignore', invalid='ignore'):
            sparsity = (mean_rate ** 2) / mean_sq_rate
            sparsity = np.where(mean_sq_rate > 0, sparsity, np.nan)
        n_neurons = rates.shape[0]
        sparsity = (1 - sparsity) / (1 - 1 / n_neurons)
    else:
        mean_rate = np.nanmean(rates)
        mean_sq_rate = np.nanmean(rates ** 2)
        if mean_sq_rate > 0:
            sparsity = (mean_rate ** 2) / mean_sq_rate
            n_neurons = len(rates)
            sparsity = (1 - sparsity) / (1 - 1 / n_neurons)
        else:
            sparsity = np.nan
    return sparsity


def compute_gini_coefficient(rates):
    rates = np.array(rates)
    if rates.ndim == 2:
        gini_vals = np.zeros(rates.shape[1])
        for i in range(rates.shape[1]):
            gini_vals[i] = compute_gini_coefficient(rates[:, i])
        return gini_vals
    rates = rates[~np.isnan(rates)]
    rates = rates[rates >= 0]
    if len(rates) == 0:
        return np.nan
    sorted_rates = np.sort(rates)
    n = len(sorted_rates)
    cumsum = np.cumsum(sorted_rates)
    gini = (2 * np.sum((np.arange(1, n + 1)) * sorted_rates)) / (n * cumsum[-1]) - (n + 1) / n
    return gini


def compute_activity_fraction(rates, threshold=0.1):
    rates = np.array(rates)
    if rates.ndim == 2:
        active = rates > threshold
        active_frac = np.nanmean(active, axis=0)
    else:
        active = rates > threshold
        active_frac = np.nanmean(active)
    return active_frac


def compute_effective_dimensionality(rate_matrix):
    """Robust participation ratio."""
    rate_matrix = np.asarray(rate_matrix)
    valid_idx = np.nanstd(rate_matrix, axis=1) > 0
    if np.sum(valid_idx) < 2:
        return np.nan

    clean_rates = rate_matrix[valid_idx, :].astype(float, copy=True)
    if not np.isfinite(clean_rates).any():
        return np.nan

    if np.any(~np.isfinite(clean_rates)):
        col_means = np.nanmean(clean_rates, axis=0)
        col_means = np.where(np.isfinite(col_means), col_means, 0.0)
        for i in range(clean_rates.shape[1]):
            bad = ~np.isfinite(clean_rates[:, i])
            if np.any(bad):
                clean_rates[bad, i] = col_means[i]

    if not np.isfinite(clean_rates).all():
        clean_rates = np.nan_to_num(clean_rates, nan=0.0, posinf=0.0, neginf=0.0)

    clean_rates = clean_rates - np.mean(clean_rates, axis=1, keepdims=True)
    try:
        cov = np.cov(clean_rates)
        if not np.isfinite(cov).all():
            return np.nan
        eigenvalues = np.linalg.eigvalsh(cov)
    except np.linalg.LinAlgError:
        return np.nan

    eigenvalues = eigenvalues[eigenvalues > 0]
    if len(eigenvalues) == 0:
        return np.nan

    eff_dim = (np.sum(eigenvalues) ** 2) / np.sum(eigenvalues ** 2)
    return eff_dim


def find_matched_spatial_bins(occupancy1, occupancy2, min_time=1.0):
    visited1 = occupancy1 >= min_time
    visited2 = occupancy2 >= min_time
    matched_bins = visited1 & visited2
    return matched_bins


from .spatial import generate_level_list  # noqa: E402,F401
# NOTE: This module previously shipped a divergent copy of generate_level_list
# that only assigned 94 of 176 maze bins (dropping 82 bins concentrated in
# levels 4-7 / leaf regions). Every caller should get the canonical version
# from ca_analysis.spatial (which matches legacy jw_utils.generate_level_list).
# Fixed 2026-04-23.


def compute_windowed_rate_maps(
    spike_counts, positions, time_seconds,
    n_bins_x=15, n_bins_y=15,
    win_len_sec=600, pivot_step_sec=60,
    sigma=0.0, min_occupancy=0.5,
    smooth_separately=False,
    dtype=np.float32
):
    spike_counts = np.asarray(spike_counts)
    positions = np.asarray(positions)
    time_seconds = np.asarray(time_seconds)

    n_frames, n_neurons = spike_counts.shape
    K = n_bins_x * n_bins_y

    if n_frames >= 2:
        dt = float(np.median(np.diff(time_seconds)))
    else:
        dt = 0.0

    t_start = float(time_seconds[0])
    t_end = float(time_seconds[-1])
    pivot_times = np.arange(
        t_start + win_len_sec / 2,
        t_end - win_len_sec / 2 + pivot_step_sec,
        pivot_step_sec,
        dtype=float
    )
    n_windows = len(pivot_times)

    labels_pos, x_edges, y_edges = discretize_positions(
        positions, n_bins_x=n_bins_x, n_bins_y=n_bins_y
    )
    labels_pos = np.asarray(labels_pos, dtype=np.int64)

    rate_maps = np.zeros((n_windows, n_neurons, n_bins_x, n_bins_y), dtype=dtype)
    occupancy_maps = np.zeros((n_windows, n_bins_x, n_bins_y), dtype=dtype)
    valid_masks = np.zeros((n_windows, n_bins_x, n_bins_y), dtype=bool)

    half = win_len_sec / 2
    t_lows = pivot_times - half
    t_highs = pivot_times + half

    starts = np.searchsorted(time_seconds, t_lows, side="left")
    ends = np.searchsorted(time_seconds, t_highs, side="left")

    for i_win in range(n_windows):
        s = starts[i_win]
        e = ends[i_win]
        if e <= s:
            continue

        win_bins = labels_pos[s:e]
        win_spikes = spike_counts[s:e, :]

        occ_counts = np.bincount(win_bins, minlength=K).astype(np.float64, copy=False)
        occ_map = (occ_counts * dt).reshape(n_bins_y, n_bins_x).T
        occupancy_maps[i_win] = occ_map.astype(dtype, copy=False)

        valid_mask = occ_map >= float(min_occupancy)
        valid_masks[i_win] = valid_mask

        spike_sums = np.zeros((K, n_neurons), dtype=np.float64)
        np.add.at(spike_sums, win_bins, win_spikes)
        spike_map = spike_sums.T.reshape(n_neurons, n_bins_y, n_bins_x).transpose(0, 2, 1)

        if smooth_separately and sigma > 0:
            spike_sm = gaussian_filter(spike_map, sigma=(0.0, sigma, sigma))
            occ_sm = gaussian_filter(occ_map, sigma=sigma)
            rate_map = np.divide(
                spike_sm, occ_sm[None, :, :],
                out=np.zeros_like(spike_sm, dtype=np.float64),
                where=occ_sm[None, :, :] > 0
            )
        else:
            rate_map = np.divide(
                spike_map, occ_map[None, :, :],
                out=np.zeros_like(spike_map, dtype=np.float64),
                where=occ_map[None, :, :] > 0
            )
            if sigma > 0:
                rate_map = gaussian_filter(rate_map, sigma=(0.0, sigma, sigma))

        rate_map = rate_map.astype(np.float32 if dtype == np.float32 else np.float64, copy=False)
        rate_map[:, ~valid_mask] = np.nan
        rate_maps[i_win] = rate_map.astype(dtype, copy=False)

    return {
        "rate_maps": rate_maps,
        "occupancy_maps": occupancy_maps,
        "pivot_times": pivot_times,
        "valid_masks": valid_masks,
        "n_spatial_bins": K,
        "n_bins_x": n_bins_x,
        "n_bins_y": n_bins_y,
    }


def compute_neuron_quality_metrics(spike_counts, positions, rate_maps=None, dt=0.04):
    """
    Compute quality metrics for each neuron to identify outliers.

    Parameters
    ----------
    spike_counts : array, shape (n_timepoints, n_neurons)
        Deconvolved spike counts.
    positions : array, shape (n_timepoints, 2)
        x, y positions.
    rate_maps : array, optional, shape (n_neurons, n_bins_x, n_bins_y)
        Spatial rate maps (if already computed).
    dt : float
        Time step per frame (seconds).

    Returns
    -------
    metrics : dict
        Dictionary with quality metrics for each neuron.
    """
    spike_counts = np.asarray(spike_counts)
    n_neurons = spike_counts.shape[1]

    mean_rate = np.mean(spike_counts, axis=0) / float(dt)
    max_rate = np.max(spike_counts, axis=0) / float(dt)
    cv = np.std(spike_counts, axis=0) / (np.mean(spike_counts, axis=0) + 1e-10)
    activity_frac = np.mean(spike_counts > 0, axis=0)

    if rate_maps is not None:
        spatial_coverage = np.zeros(n_neurons)
        spatial_info = np.zeros(n_neurons)
        for i_neuron in range(n_neurons):
            rate_map = rate_maps[i_neuron]
            valid_bins = ~np.isnan(rate_map)

            active_bins = rate_map > 0.1
            spatial_coverage[i_neuron] = (
                np.sum(active_bins) / np.sum(valid_bins)
                if np.sum(valid_bins) > 0 else 0
            )

            if np.sum(valid_bins) > 0:
                rate_flat = rate_map[valid_bins]
                mean_r = np.nanmean(rate_flat)
                if mean_r > 0:
                    p_i = 1.0 / np.sum(valid_bins)
                    si = 0
                    for r in rate_flat:
                        if r > 0:
                            si += p_i * (r / mean_r) * np.log2(r / mean_r)
                    spatial_info[i_neuron] = si
    else:
        spatial_coverage = None
        spatial_info = None

    return {
        "mean_rate": mean_rate,
        "max_rate": max_rate,
        "cv": cv,
        "activity_frac": activity_frac,
        "spatial_coverage": spatial_coverage,
        "spatial_info": spatial_info,
    }


def filter_neurons(quality_metrics, criteria):
    """
    Filter neurons based on quality criteria.

    Parameters
    ----------
    quality_metrics : dict
        Output from compute_neuron_quality_metrics.
    criteria : dict
        Filtering thresholds.

    Returns
    -------
    keep_mask : array of bool
        Mask indicating which neurons to keep.
    """
    n_neurons = len(quality_metrics["mean_rate"])
    keep_mask = np.ones(n_neurons, dtype=bool)

    if "min_mean_rate" in criteria:
        keep_mask &= quality_metrics["mean_rate"] >= criteria["min_mean_rate"]
    if "max_mean_rate" in criteria:
        keep_mask &= quality_metrics["mean_rate"] <= criteria["max_mean_rate"]
    if "max_peak_rate" in criteria:
        keep_mask &= quality_metrics["max_rate"] <= criteria["max_peak_rate"]
    if "max_cv" in criteria:
        keep_mask &= quality_metrics["cv"] <= criteria["max_cv"]
    if "min_activity_frac" in criteria:
        keep_mask &= quality_metrics["activity_frac"] >= criteria["min_activity_frac"]

    if quality_metrics.get("spatial_coverage") is not None:
        if "min_spatial_coverage" in criteria:
            keep_mask &= quality_metrics["spatial_coverage"] >= criteria["min_spatial_coverage"]
        if "max_spatial_coverage" in criteria:
            keep_mask &= quality_metrics["spatial_coverage"] <= criteria["max_spatial_coverage"]

    return keep_mask


DEFAULT_FILTER_CRITERIA = {
    "min_mean_rate": 0.00,
    "max_mean_rate": 2.0,
    "max_peak_rate": 50.0,
    "min_activity_frac": 0.00,
}


def apply_quality_filter_with_ratemap(spike_counts, positions, rate_map_results, criteria=None, dt=0.04):
    keep = np.ones(spike_counts.shape[1], dtype=bool)
    quality_metrics = None
    if criteria is None:
        criteria = DEFAULT_FILTER_CRITERIA
    try:
        rate_maps = rate_map_results.get("rate_maps") if rate_map_results is not None else None
        mean_rate_map = np.nanmean(rate_maps, axis=0) if rate_maps is not None else None
        quality_metrics = compute_neuron_quality_metrics(
            spike_counts, positions, rate_maps=mean_rate_map, dt=dt
        )
        if criteria:
            keep = filter_neurons(quality_metrics, criteria)
    except Exception as e:
        print(f"[filter] skipped: {e}")
    return keep, quality_metrics


def smooth_nan(x, window=9):
    x = np.asarray(x, dtype=float)
    if window <= 1:
        return x.copy()
    half = window // 2
    y = np.full_like(x, np.nan, dtype=float)
    for i in range(len(x)):
        lo = max(0, i - half)
        hi = min(len(x), i + half + 1)
        seg = x[lo:hi]
        seg = seg[np.isfinite(seg)]
        if seg.size > 0:
            y[i] = np.mean(seg)
    return y


def compute_shannon_entropy(pv):
    pv = np.asarray(pv, dtype=float)
    if pv.size == 0:
        return np.nan
    n = pv.size
    pv = np.nan_to_num(pv, nan=0.0, posinf=0.0, neginf=0.0)
    total = np.sum(pv)
    if total <= 0:
        return np.nan
    p = pv / total
    p = p[p > 0]
    if n <= 1:
        return 0.0
    h = -np.sum(p * np.log(p))
    return h / np.log(n)


def compute_level_combined(
    level_idx,
    spike_counts_use,
    selected_df,
    level_list,
    ma,
    min_visits_per_cluster=5,
    min_frames_per_visit=5,
    gap_frames=10,
):
    if spike_counts_use.shape[1] == 0:
        return (
            np.full(0, np.nan),
            np.full(0, np.nan),
            np.full(0, np.nan),
            np.full(0, np.nan),
            np.full(0, np.nan),
        )

    level_mask = level_list[level_idx].astype(bool)
    idx_to_coord = {idx: coord for coord, idx in ma.ce.items()}

    level_coords = []
    for idx in range(len(level_mask)):
        if level_mask[idx]:
            coord = idx_to_coord.get(idx)
            if coord is not None:
                level_coords.append(coord)

    level_coord_set = set(level_coords)

    visited = set()
    clusters = []
    for coord in level_coords:
        if coord in visited:
            continue
        stack = [coord]
        visited.add(coord)
        comp = []
        while stack:
            i, j = stack.pop()
            comp.append((i, j))
            for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ni, nj = i + di, j + dj
                ncoord = (ni, nj)
                if ncoord in level_coord_set and ncoord not in visited:
                    visited.add(ncoord)
                    stack.append(ncoord)
        clusters.append(comp)

    n_frames = len(selected_df)
    frame_cluster = np.full(n_frames, -1, dtype=int)

    bx = selected_df["mass_bx"].to_numpy()
    by = selected_df["mass_by"].to_numpy()
    frame_idx = selected_df["frame"].to_numpy().astype(int)

    coord_to_cluster = {}
    for ci, comp in enumerate(clusters):
        for coord in comp:
            coord_to_cluster[coord] = ci

    for t in range(n_frames):
        coord = (int(by[t]), int(bx[t]))
        if coord in coord_to_cluster:
            frame_cluster[t] = coord_to_cluster[coord]

    cluster_visit_sparsity = []
    cluster_visit_gini = []
    cluster_visit_total = []
    cluster_visit_entropy = []
    cluster_visit_frac = []
    cluster_visit_weights = []
    cluster_visit_counts = []

    for ci, comp in enumerate(clusters):
        rows_in_cluster = np.where(frame_cluster == ci)[0]
        if len(rows_in_cluster) == 0:
            cluster_visit_sparsity.append(np.array([]))
            cluster_visit_gini.append(np.array([]))
            cluster_visit_total.append(np.array([]))
            cluster_visit_entropy.append(np.array([]))
            cluster_visit_frac.append(np.array([]))
            cluster_visit_weights.append(np.array([]))
            cluster_visit_counts.append(0)
            continue
        frames_in_cluster = frame_idx[rows_in_cluster]

        visit_spans = []
        start = frames_in_cluster[0]
        prev = frames_in_cluster[0]
        for f in frames_in_cluster[1:]:
            if f - prev > gap_frames:
                visit_spans.append((start, prev))
                start = f
            prev = f
        visit_spans.append((start, prev))

        visit_spans = [v for v in visit_spans if (v[1] - v[0] + 1) >= min_frames_per_visit]

        visit_spars = []
        visit_gini = []
        visit_total = []
        visit_entropy = []
        visit_frac = []
        visit_w = []
        for s, e in visit_spans:
            if e < s:
                continue
            mask = (frames_in_cluster >= s) & (frames_in_cluster <= e)
            rows = rows_in_cluster[mask]
            if rows.size == 0:
                continue
            seg = spike_counts_use[rows]
            if seg.size == 0 or not np.isfinite(seg).any():
                visit_spars.append(np.nan)
                visit_gini.append(np.nan)
                visit_total.append(0.0)
                visit_entropy.append(np.nan)
                visit_frac.append(np.nan)
                visit_w.append(rows.size)
                continue
            pv = np.nanmean(seg, axis=0)
            if pv.size == 0 or np.nansum(pv) == 0:
                visit_spars.append(np.nan)
                visit_gini.append(np.nan)
                visit_total.append(0.0)
                visit_entropy.append(np.nan)
                visit_frac.append(0.0)
                visit_w.append(rows.size)
                continue
            visit_spars.append(compute_lifetime_sparsity(pv))
            visit_gini.append(compute_gini_coefficient(pv))
            visit_total.append(np.nansum(pv))
            visit_entropy.append(compute_shannon_entropy(pv))
            visit_frac.append(float(np.mean(pv > 0)))
            visit_w.append(rows.size)

        visit_spars = np.array(visit_spars, dtype=float)
        visit_gini = np.array(visit_gini, dtype=float)
        visit_total = np.array(visit_total, dtype=float)
        visit_entropy = np.array(visit_entropy, dtype=float)
        visit_frac = np.array(visit_frac, dtype=float)
        visit_w = np.array(visit_w, dtype=float)

        cluster_visit_sparsity.append(visit_spars)
        cluster_visit_gini.append(visit_gini)
        cluster_visit_total.append(visit_total)
        cluster_visit_entropy.append(visit_entropy)
        cluster_visit_frac.append(visit_frac)
        cluster_visit_weights.append(visit_w)
        cluster_visit_counts.append(len(visit_spars))

    max_visits = max(cluster_visit_counts) if len(cluster_visit_counts) > 0 else 0
    combined_s = []
    combined_g = []
    combined_t = []
    combined_e = []
    combined_f = []

    for k in range(max_visits):
        vals_s = []
        vals_g = []
        vals_t = []
        vals_e = []
        vals_f = []
        weights = []
        for ci in range(len(clusters)):
            vs = cluster_visit_sparsity[ci]
            vg = cluster_visit_gini[ci]
            vt = cluster_visit_total[ci]
            ve = cluster_visit_entropy[ci]
            vf = cluster_visit_frac[ci]
            vw = cluster_visit_weights[ci]
            if len(vs) <= k:
                continue
            if len(vs) < min_visits_per_cluster:
                continue
            vals_s.append(vs[k])
            vals_g.append(vg[k])
            vals_t.append(vt[k])
            vals_e.append(ve[k])
            vals_f.append(vf[k])
            weights.append(vw[k])

        if len(vals_s) == 0:
            combined_s.append(np.nan)
            combined_g.append(np.nan)
            combined_t.append(np.nan)
            combined_e.append(np.nan)
            combined_f.append(np.nan)
            continue

        weights = np.array(weights, dtype=float)
        combined_s.append(np.average(vals_s, weights=weights))
        combined_g.append(np.average(vals_g, weights=weights))
        combined_t.append(np.average(vals_t, weights=weights))
        combined_e.append(np.average(vals_e, weights=weights))
        combined_f.append(np.average(vals_f, weights=weights))

    return (
        np.array(combined_s, dtype=float),
        np.array(combined_g, dtype=float),
        np.array(combined_t, dtype=float),
        np.array(combined_e, dtype=float),
        np.array(combined_f, dtype=float),
    )
