import numpy as np
from scipy.ndimage import binary_erosion


def filter_nan_frames(df, c_matrix):
    """Drop selected-frame rows whose calcium matrix frame contains NaNs."""
    if c_matrix is None:
        return df.reset_index(drop=True)
    matrix = np.asarray(c_matrix, dtype=float)
    if matrix.ndim != 2 or matrix.size == 0 or "frame" not in df.columns:
        return df.reset_index(drop=True)
    frames = df["frame"].to_numpy(dtype=int)
    if frames.size == 0:
        return df.reset_index(drop=True)
    max_frame = int(np.nanmax(frames))
    if matrix.shape[1] > max_frame:
        frame_has_nan = np.any(np.isnan(matrix[:, frames]), axis=0)
    elif matrix.shape[0] > max_frame:
        frame_has_nan = np.any(np.isnan(matrix[frames, :]), axis=1)
    else:
        nan_idx = np.unique(np.where(np.isnan(matrix.T))[0]).astype(int)
        frame_has_nan = np.isin(frames, nan_idx)
    return df.loc[~frame_has_nan].reset_index(drop=True)


def compute_activity_fraction(rates, threshold=0.1):
    x = np.asarray(rates, dtype=float)
    return np.nanmean(x > threshold, axis=0) if x.ndim == 2 else float(np.nanmean(x > threshold))


def compute_neuron_quality_metrics(rates, *, threshold=0.1):
    x = np.asarray(rates, dtype=float)
    if x.ndim != 2:
        raise ValueError('rates must be 2D (T x N)')
    activity_fraction = compute_activity_fraction(x, threshold=threshold)
    mean_rate = np.nanmean(x, axis=0)
    std_rate = np.nanstd(x, axis=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        cv = np.where(mean_rate > 0, std_rate / mean_rate, np.nan)
    silent_fraction = np.nanmean(x <= 0, axis=0)
    return {
        'activity_fraction': np.asarray(activity_fraction, dtype=float),
        'mean_rate': np.asarray(mean_rate, dtype=float),
        'std_rate': np.asarray(std_rate, dtype=float),
        'cv': np.asarray(cv, dtype=float),
        'silent_fraction': np.asarray(silent_fraction, dtype=float),
        'n_neurons': int(x.shape[1]),
        'n_frames': int(x.shape[0]),
    }


def filter_neurons(
    rates,
    *,
    threshold=0.1,
    min_activity_fraction=0.01,
    max_silent_fraction=0.99,
    min_mean_rate=0.0,
):
    x = np.asarray(rates, dtype=float)
    if x.ndim != 2:
        raise ValueError('rates must be 2D (T x N)')
    metrics = compute_neuron_quality_metrics(x, threshold=threshold)
    mask = (
        (metrics['activity_fraction'] >= float(min_activity_fraction))
        & (metrics['silent_fraction'] <= float(max_silent_fraction))
        & (metrics['mean_rate'] >= float(min_mean_rate))
    )
    return x[:, mask], mask, metrics


def footprint_area(footprints, *, threshold=0.0):
    """
    footprints: array [H, W, N] or [N, H, W]
    """
    A = np.asarray(footprints, dtype=float)
    if A.ndim != 3:
        raise ValueError("footprints must be 3D")
    if A.shape[0] < 8 and A.shape[-1] > 8:
        A = np.moveaxis(A, 0, -1)
    mask = A > float(threshold)
    return np.sum(mask, axis=(0, 1)).astype(float)


def footprint_circularity(footprints, *, threshold=0.0):
    """
    Approximate circularity per neuron: 4*pi*area / perimeter^2.
    """
    A = np.asarray(footprints, dtype=float)
    if A.ndim != 3:
        raise ValueError("footprints must be 3D")
    if A.shape[0] < 8 and A.shape[-1] > 8:
        A = np.moveaxis(A, 0, -1)
    out = np.full(A.shape[-1], np.nan, dtype=float)
    for i in range(A.shape[-1]):
        m = A[:, :, i] > float(threshold)
        area = float(np.sum(m))
        if area <= 0:
            continue
        er = binary_erosion(m)
        perimeter = float(np.sum(m & (~er)))
        if perimeter <= 0:
            continue
        out[i] = float((4.0 * np.pi * area) / (perimeter**2))
    return out


def peak_to_noise_ratio(trace_raw, trace_filt):
    raw = np.asarray(trace_raw, dtype=float)
    filt = np.asarray(trace_filt, dtype=float)
    if raw.shape != filt.shape:
        raise ValueError("raw and filtered traces must have same shape")
    if raw.ndim != 2:
        raise ValueError("traces must be 2D (T x N)")
    noise = raw - filt
    peak = np.nanmax(filt, axis=0)
    noise_std = np.nanstd(noise, axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(noise_std > 0, peak / noise_std, np.nan)
