"""Neural-code helpers for the rapid structure/reward-learning analysis.

The module deliberately stops at reusable geometry, support, decoder-adapter,
and difference-in-differences bookkeeping.  It never loads cohort data.  The
neural interfaces are explicitly C-primary: callers pass the same calcium
count representation used by the maintained tree-depth decoder.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Callable, Mapping, Protocol, Sequence

import numpy as np
import pandas as pd

from .config import REWARD_NODE
from .maze import NewMaze


PRIMARY_SUBTREE_PAIRS = ((3, 6), (4, 5))
RESCUE_SUBTREE_PAIRS = ((1, 2),)
POSTHOC_INTERIOR_DEPTHS = (2, 3, 4, 5)
POSTHOC_INTERIOR_RESCUE_TIER = "posthoc_support_rescue_interior_depths_2_5"


class DecoderAdapter(Protocol):
    """Backend contract used by :func:`run_topology_fold_backends`."""

    def __call__(
        self,
        train_x: np.ndarray,
        train_y: np.ndarray,
        test_x: np.ndarray,
        *,
        n_classes: int,
        metadata: Mapping[str, Any],
    ) -> Sequence[int] | Mapping[str, Any]:
        ...


@dataclass(frozen=True)
class TopologyFold:
    name: str
    train_root: int
    test_root: int
    tier: str
    global_depths: tuple[int, ...]
    train_runs: tuple[int, ...]
    test_runs: tuple[int, ...]
    centroid_distance: float
    minimum_cell_distance: float


@dataclass(frozen=True)
class TopologySupport:
    fold_name: str
    status: str
    supported: bool
    min_frames_per_depth: int
    min_visits_per_depth: int
    train_frames_by_depth: tuple[tuple[int, int], ...]
    test_frames_by_depth: tuple[tuple[int, int], ...]
    train_visits_by_depth: tuple[tuple[int, int], ...]
    test_visits_by_depth: tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class TopologyComparison:
    fold_name: str
    support_status: str
    topology_balanced_accuracy: float
    position_to_depth_balanced_accuracy: float
    xy_behavior_balanced_accuracy: float
    shuffle_q95_balanced_accuracy: float
    topology_minus_position: float
    topology_minus_xy_behavior: float
    topology_minus_shuffle_q95: float
    classification: str


@dataclass(frozen=True)
class RewardVisitSpec:
    k_visits: int = 4
    min_frames_per_visit: int = 15
    primary_post_window_s: float = 30.0 * 60.0
    rescue_post_window_s: float = 60.0 * 60.0
    min_primary_controls: int = 5
    min_controls: int = 3
    primary_caliper_fraction: float = 0.20
    rescue_caliper_fraction: float = 0.35


@dataclass(frozen=True)
class RewardVisitSupport:
    target_node: int
    status: str
    supported: bool
    first_reward_visit_id: Any
    pre_visit_ids: tuple[Any, ...]
    post_visit_ids: tuple[Any, ...]
    n_pre_eligible: int
    n_post_primary_eligible: int
    n_post_rescue_eligible: int
    post_window_s_used: float | None


@dataclass(frozen=True)
class PseudoControlMatch:
    status: str
    supported: bool
    matched_nodes: tuple[int, ...]
    caliper_fraction_used: float | None
    orientation_matched: bool
    per_node_visit_ids: Mapping[int, Mapping[str, tuple[Any, ...]]]


def _descendant_runs(maze: Any, root: int) -> tuple[int, ...]:
    root = int(root)
    children = np.asarray(maze.ch, dtype=int)
    if root < 0 or root >= children.shape[0]:
        raise ValueError(f"subtree root {root} is out of range")
    out: list[int] = []
    stack = [root]
    while stack:
        current = int(stack.pop())
        out.append(current)
        for child in reversed(children[current].tolist()):
            if int(child) >= 0:
                stack.append(int(child))
    return tuple(sorted(out))


def _run_depths(maze: Any) -> np.ndarray:
    children = np.asarray(maze.ch, dtype=int)
    depth = np.full(children.shape[0], -1, dtype=int)
    depth[0] = 0
    for parent in range(children.shape[0]):
        if depth[parent] < 0:
            continue
        for child in children[parent]:
            if int(child) >= 0:
                depth[int(child)] = depth[parent] + 1
    if np.any(depth < 0):
        raise ValueError("maze run tree is disconnected")
    return depth


def _subtree_cells(maze: Any, runs: Sequence[int]) -> np.ndarray:
    cells = [np.asarray(maze.ru[int(run)], dtype=int).ravel() for run in runs]
    return np.unique(np.concatenate(cells)) if cells else np.asarray([], dtype=int)


def _fold_geometry(
    maze: Any, train_root: int, test_root: int, tier: str
) -> TopologyFold:
    train_runs = _descendant_runs(maze, train_root)
    test_runs = _descendant_runs(maze, test_root)
    if set(train_runs).intersection(test_runs):
        raise ValueError("train and test subtrees overlap")
    train_cells = _subtree_cells(maze, train_runs)
    test_cells = _subtree_cells(maze, test_runs)
    train_xy = np.column_stack(
        [np.asarray(maze.xc)[train_cells], np.asarray(maze.yc)[train_cells]]
    ).astype(float)
    test_xy = np.column_stack(
        [np.asarray(maze.xc)[test_cells], np.asarray(maze.yc)[test_cells]]
    ).astype(float)
    centroid_distance = float(
        np.linalg.norm(np.mean(train_xy, axis=0) - np.mean(test_xy, axis=0))
    )
    minimum_distance = float(
        np.min(np.linalg.norm(train_xy[:, None, :] - test_xy[None, :, :], axis=2))
    )
    depths = _run_depths(maze)
    shared_depths = tuple(
        sorted(set(depths[list(train_runs)]).intersection(depths[list(test_runs)]))
    )
    return TopologyFold(
        name=f"{tier}_r{int(train_root)}_to_r{int(test_root)}",
        train_root=int(train_root),
        test_root=int(test_root),
        tier=str(tier),
        global_depths=shared_depths,
        train_runs=train_runs,
        test_runs=test_runs,
        centroid_distance=centroid_distance,
        minimum_cell_distance=minimum_distance,
    )


def fixed_topology_folds(maze: Any | None = None) -> tuple[TopologyFold, ...]:
    """Return the frozen physical-generalization folds.

    The four primary directions are the maximally separated diagonal depth-2
    subtree comparisons ``3<->6`` and ``4<->5``.  The less stringent
    top-level ``1<->2`` directions are explicitly marked as rescue folds.
    """

    maze = NewMaze(6) if maze is None else maze
    folds: list[TopologyFold] = []
    for tier, pairs in (
        ("primary", PRIMARY_SUBTREE_PAIRS),
        ("rescue", RESCUE_SUBTREE_PAIRS),
    ):
        for left, right in pairs:
            folds.append(_fold_geometry(maze, left, right, tier))
            folds.append(_fold_geometry(maze, right, left, tier))
    return tuple(folds)


def posthoc_interior_depth_folds(
    maze: Any | None = None,
) -> tuple[TopologyFold, ...]:
    """Return the one frozen support rescue for diagonal primary geometries.

    The rescue changes only the analyzed depth support: terminal depth 6 is
    excluded and all four interior depths 2--5 remain required.  It never
    substitutes the less-separated top-level rescue folds and is explicitly
    labeled post hoc so it cannot enter primary-fold inference.
    """

    maze = NewMaze(6) if maze is None else maze
    run_depth = _run_depths(maze)
    rescued: list[TopologyFold] = []
    for fold in fixed_topology_folds(maze):
        if fold.tier != "primary":
            continue
        train_runs = tuple(
            run
            for run in fold.train_runs
            if int(run_depth[run]) in POSTHOC_INTERIOR_DEPTHS
        )
        test_runs = tuple(
            run
            for run in fold.test_runs
            if int(run_depth[run]) in POSTHOC_INTERIOR_DEPTHS
        )
        train_cells = np.unique(
            np.concatenate([np.asarray(maze.ru[run]).ravel() for run in train_runs])
        )
        test_cells = np.unique(
            np.concatenate([np.asarray(maze.ru[run]).ravel() for run in test_runs])
        )
        train_xy = np.column_stack(
            [np.asarray(maze.xc)[train_cells], np.asarray(maze.yc)[train_cells]]
        ).astype(float)
        test_xy = np.column_stack(
            [np.asarray(maze.xc)[test_cells], np.asarray(maze.yc)[test_cells]]
        ).astype(float)
        rescued.append(
            TopologyFold(
                name=(
                    f"{POSTHOC_INTERIOR_RESCUE_TIER}_"
                    f"r{fold.train_root}_to_r{fold.test_root}"
                ),
                train_root=fold.train_root,
                test_root=fold.test_root,
                tier=POSTHOC_INTERIOR_RESCUE_TIER,
                global_depths=POSTHOC_INTERIOR_DEPTHS,
                train_runs=train_runs,
                test_runs=test_runs,
                centroid_distance=float(
                    np.linalg.norm(np.mean(train_xy, axis=0) - np.mean(test_xy, axis=0))
                ),
                minimum_cell_distance=float(
                    np.min(
                        np.linalg.norm(
                            train_xy[:, None, :] - test_xy[None, :, :], axis=2
                        )
                    )
                ),
            )
        )
    return tuple(rescued)


def topology_fold_masks(
    run_indices: Sequence[int], fold: TopologyFold
) -> tuple[np.ndarray, np.ndarray]:
    runs = np.asarray(run_indices, dtype=int)
    if runs.ndim != 1:
        raise ValueError("run_indices must be one-dimensional")
    return np.isin(runs, fold.train_runs), np.isin(runs, fold.test_runs)


def assess_topology_support(
    depth_labels: Sequence[int],
    visit_ids: Sequence[Any],
    train_mask: Sequence[bool],
    test_mask: Sequence[bool],
    fold: TopologyFold,
    *,
    min_frames_per_depth: int = 50,
    min_visits_per_depth: int = 2,
) -> TopologySupport:
    depth = np.asarray(depth_labels, dtype=int)
    visits = np.asarray(visit_ids, dtype=object)
    train = np.asarray(train_mask, dtype=bool)
    test = np.asarray(test_mask, dtype=bool)
    if not (depth.ndim == visits.ndim == train.ndim == test.ndim == 1):
        raise ValueError("support inputs must be one-dimensional")
    if len({depth.size, visits.size, train.size, test.size}) != 1:
        raise ValueError("support inputs must have equal length")

    def counts(
        mask: np.ndarray,
    ) -> tuple[tuple[tuple[int, int], ...], tuple[tuple[int, int], ...]]:
        frames = []
        visit_counts = []
        for value in fold.global_depths:
            selected = mask & (depth == int(value))
            frames.append((int(value), int(np.sum(selected))))
            visit_counts.append((int(value), int(np.unique(visits[selected]).size)))
        return tuple(frames), tuple(visit_counts)

    train_frames, train_visits = counts(train)
    test_frames, test_visits = counts(test)
    all_frames = [value for _, value in (*train_frames, *test_frames)]
    all_visits = [value for _, value in (*train_visits, *test_visits)]
    if any(value == 0 for value in all_frames):
        status = "missing_depth_support"
    elif any(value < int(min_visits_per_depth) for value in all_visits):
        status = "insufficient_visits_per_depth"
    elif any(value < int(min_frames_per_depth) for value in all_frames):
        status = "insufficient_frames_per_depth"
    else:
        if fold.tier == "primary":
            status = "ok_primary"
        elif fold.tier == POSTHOC_INTERIOR_RESCUE_TIER:
            status = f"ok_{POSTHOC_INTERIOR_RESCUE_TIER}"
        else:
            status = "ok_rescue"
    return TopologySupport(
        fold_name=fold.name,
        status=status,
        supported=status.startswith("ok_"),
        min_frames_per_depth=int(min_frames_per_depth),
        min_visits_per_depth=int(min_visits_per_depth),
        train_frames_by_depth=train_frames,
        test_frames_by_depth=test_frames,
        train_visits_by_depth=train_visits,
        test_visits_by_depth=test_visits,
    )


def balanced_accuracy(true: Sequence[int], pred: Sequence[int]) -> float:
    true_arr = np.asarray(true, dtype=int)
    pred_arr = np.asarray(pred, dtype=int)
    if true_arr.ndim != 1 or pred_arr.ndim != 1 or true_arr.size != pred_arr.size:
        raise ValueError("true and predicted labels must be equal-length vectors")
    if true_arr.size == 0:
        return np.nan
    recalls = [
        np.mean(pred_arr[true_arr == value] == value) for value in np.unique(true_arr)
    ]
    return float(np.mean(recalls))


def balance_topology_masks(
    depth_labels: Sequence[int],
    train_mask: Sequence[bool],
    test_mask: Sequence[bool],
    depths: Sequence[int],
    *,
    seed: int = 0,
) -> tuple[np.ndarray, np.ndarray]:
    """Subsample equal frame counts per depth separately in train and test."""

    depth = np.asarray(depth_labels, dtype=int)
    train = np.asarray(train_mask, dtype=bool)
    test = np.asarray(test_mask, dtype=bool)
    if not (depth.ndim == train.ndim == test.ndim == 1):
        raise ValueError("depth_labels and masks must be one-dimensional")
    if len({depth.size, train.size, test.size}) != 1:
        raise ValueError("depth_labels and masks must have equal length")
    rng_train, rng_test = [
        np.random.default_rng(child)
        for child in np.random.SeedSequence(int(seed)).spawn(2)
    ]

    def one(mask: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        indices = [np.flatnonzero(mask & (depth == int(value))) for value in depths]
        if not indices or any(values.size == 0 for values in indices):
            raise ValueError("cannot balance a fold with a missing depth")
        target = min(values.size for values in indices)
        selected = np.zeros(depth.size, dtype=bool)
        for values in indices:
            keep = (
                values
                if values.size == target
                else rng.choice(values, size=target, replace=False)
            )
            selected[np.sort(keep)] = True
        return selected

    return one(train, rng_train), one(test, rng_test)


def _extract_prediction(result: Sequence[int] | Mapping[str, Any]) -> np.ndarray:
    if isinstance(result, Mapping):
        if "pred" not in result:
            raise KeyError("decoder result mapping must contain 'pred'")
        result = result["pred"]
    pred = np.asarray(result, dtype=int)
    if pred.ndim != 1:
        raise ValueError("decoder prediction must be one-dimensional")
    return pred


def poisson_decoder_adapter(
    train_x: np.ndarray,
    train_y: np.ndarray,
    test_x: np.ndarray,
    *,
    n_classes: int,
    metadata: Mapping[str, Any],
) -> np.ndarray:
    """Thin adapter around the maintained Poisson decoder.

    ``metadata`` may contain ``dt``, ``min_time``, and ``prior_mode``.  The
    wrapper intentionally does not rebuild tuning maps or decoding math.
    """

    from .decoding import poisson_decode_train_test

    result = poisson_decode_train_test(
        train_x,
        train_y,
        test_x,
        n_bins=int(n_classes),
        dt=float(metadata.get("dt", 1.0)),
        min_time=float(metadata.get("min_time", 0.0)),
        prior_mode=str(metadata.get("prior_mode", "uniform")),
        return_posterior=False,
    )
    return np.asarray(result["pred"], dtype=int)


def _map_position_prediction_to_depth(
    predicted_position: np.ndarray,
    train_position: np.ndarray,
    train_depth: np.ndarray,
) -> np.ndarray:
    mapping: dict[int, int] = {}
    for label in np.unique(train_position):
        values = train_depth[train_position == label]
        unique, counts = np.unique(values, return_counts=True)
        mapping[int(label)] = int(unique[np.argmax(counts)])
    return np.asarray(
        [mapping.get(int(value), -1) for value in predicted_position], dtype=int
    )


def run_topology_fold_backends(
    activity_c: Any,
    depth_labels: Sequence[int],
    spatial_labels: Sequence[int],
    xy_behavior_features: Any,
    run_indices: Sequence[int],
    visit_ids: Sequence[Any],
    fold: TopologyFold,
    *,
    topology_backend: DecoderAdapter,
    position_backend: DecoderAdapter,
    xy_behavior_backend: DecoderAdapter,
    shuffle_accuracies: Sequence[float],
    min_frames_per_depth: int = 50,
    min_visits_per_depth: int = 2,
    balance_seed: int = 0,
    metadata: Mapping[str, Any] | None = None,
) -> tuple[TopologyComparison, dict[str, Any]]:
    """Run backend adapters and retain auditable comparison bookkeeping."""

    c = np.asarray(activity_c, dtype=float)
    depth = np.asarray(depth_labels, dtype=int)
    spatial = np.asarray(spatial_labels, dtype=int)
    xy = np.asarray(xy_behavior_features, dtype=float)
    if c.ndim != 2 or xy.ndim != 2:
        raise ValueError("activity_c and xy_behavior_features must be 2D")
    if not (c.shape[0] == xy.shape[0] == depth.size == spatial.size):
        raise ValueError("all topology arrays must share the frame dimension")
    train, test = topology_fold_masks(run_indices, fold)
    support = assess_topology_support(
        depth,
        visit_ids,
        train,
        test,
        fold,
        min_frames_per_depth=min_frames_per_depth,
        min_visits_per_depth=min_visits_per_depth,
    )
    if not support.supported:
        comparison = TopologyComparison(
            fold_name=fold.name,
            support_status=support.status,
            topology_balanced_accuracy=np.nan,
            position_to_depth_balanced_accuracy=np.nan,
            xy_behavior_balanced_accuracy=np.nan,
            shuffle_q95_balanced_accuracy=np.nan,
            topology_minus_position=np.nan,
            topology_minus_xy_behavior=np.nan,
            topology_minus_shuffle_q95=np.nan,
            classification="geometry_support_unresolved",
        )
        return comparison, {"support": asdict(support)}

    train, test = balance_topology_masks(
        depth,
        train,
        test,
        fold.global_depths,
        seed=int(balance_seed),
    )

    meta = dict(metadata or {})
    meta.update(
        {
            "fold_name": fold.name,
            "signal": "C",
            "support_status": support.status,
            "frame_balance_policy": "equal_frames_per_depth_separately_within_train_test",
            "frame_balance_seed": int(balance_seed),
        }
    )
    unique_depths = np.asarray(fold.global_depths, dtype=int)
    encode_depth = {int(value): idx for idx, value in enumerate(unique_depths)}
    decode_depth = {idx: int(value) for value, idx in encode_depth.items()}
    train_depth_encoded = np.asarray(
        [encode_depth[int(value)] for value in depth[train]], dtype=int
    )
    topology_encoded = _extract_prediction(
        topology_backend(
            c[train],
            train_depth_encoded,
            c[test],
            n_classes=len(unique_depths),
            metadata=meta,
        )
    )
    topology_pred = np.asarray(
        [decode_depth.get(int(value), -1) for value in topology_encoded]
    )

    spatial_values = np.unique(spatial[train])
    spatial_encode = {int(value): idx for idx, value in enumerate(spatial_values)}
    spatial_decode = {idx: int(value) for value, idx in spatial_encode.items()}
    train_spatial_encoded = np.asarray(
        [spatial_encode[int(value)] for value in spatial[train]]
    )
    position_encoded = _extract_prediction(
        position_backend(
            c[train],
            train_spatial_encoded,
            c[test],
            n_classes=len(spatial_values),
            metadata=meta,
        )
    )
    position_pred = np.asarray(
        [spatial_decode.get(int(value), -1) for value in position_encoded]
    )
    position_depth_pred = _map_position_prediction_to_depth(
        position_pred, spatial[train], depth[train]
    )
    xy_encoded = _extract_prediction(
        xy_behavior_backend(
            xy[train],
            train_depth_encoded,
            xy[test],
            n_classes=len(unique_depths),
            metadata=meta,
        )
    )
    xy_depth_pred = np.asarray(
        [decode_depth.get(int(value), -1) for value in xy_encoded]
    )

    true_depth = depth[test]
    topology_accuracy = balanced_accuracy(true_depth, topology_pred)
    position_accuracy = balanced_accuracy(true_depth, position_depth_pred)
    xy_accuracy = balanced_accuracy(true_depth, xy_depth_pred)
    shuffles = np.asarray(shuffle_accuracies, dtype=float)
    shuffles = shuffles[np.isfinite(shuffles)]
    shuffle_q95 = float(np.quantile(shuffles, 0.95)) if shuffles.size else np.nan
    margins = (
        topology_accuracy - position_accuracy,
        topology_accuracy - xy_accuracy,
        topology_accuracy - shuffle_q95,
    )
    if all(np.isfinite(margins)) and all(value > 0 for value in margins):
        classification = (
            "spatially_nontrivial_topology_generalization"
            if fold.tier == "primary"
            else "support_rescued_topology_generalization"
        )
    elif np.isfinite(margins[2]) and margins[2] > 0:
        classification = "cross_subtree_depth_decoding_without_abstract_specificity"
    else:
        classification = "no_supported_cross_subtree_generalization"
    comparison = TopologyComparison(
        fold_name=fold.name,
        support_status=support.status,
        topology_balanced_accuracy=topology_accuracy,
        position_to_depth_balanced_accuracy=position_accuracy,
        xy_behavior_balanced_accuracy=xy_accuracy,
        shuffle_q95_balanced_accuracy=shuffle_q95,
        topology_minus_position=margins[0],
        topology_minus_xy_behavior=margins[1],
        topology_minus_shuffle_q95=margins[2],
        classification=classification,
    )
    audit = {
        "support": asdict(support),
        "metadata": meta,
        "n_train_frames": int(np.sum(train)),
        "n_test_frames": int(np.sum(test)),
        "train_frame_indices": np.flatnonzero(train).tolist(),
        "test_frame_indices": np.flatnonzero(test).tolist(),
        "true_depth": true_depth.tolist(),
        "topology_prediction": topology_pred.tolist(),
        "position_to_depth_prediction": position_depth_pred.tolist(),
        "xy_behavior_prediction": xy_depth_pred.tolist(),
    }
    return comparison, audit


def _require_visit_columns(visits: pd.DataFrame, columns: Sequence[str]) -> None:
    missing = [column for column in columns if column not in visits.columns]
    if missing:
        raise KeyError(f"visit table is missing columns: {missing}")


def _first_reward_visit_id(
    day2_visits: pd.DataFrame,
    first_reward_time: float,
    *,
    visit_id_col: str,
    start_col: str,
    end_col: str,
) -> Any:
    containing = day2_visits.loc[
        (day2_visits[start_col].astype(float) <= float(first_reward_time))
        & (day2_visits[end_col].astype(float) >= float(first_reward_time))
    ]
    if not containing.empty:
        return containing.sort_values(start_col).iloc[0][visit_id_col]
    after = day2_visits.loc[
        day2_visits[start_col].astype(float) >= float(first_reward_time)
    ]
    if after.empty:
        return None
    return after.sort_values(start_col).iloc[0][visit_id_col]


def select_reward_target_visits(
    visits: pd.DataFrame,
    first_reward_time: float,
    *,
    target_node: int = REWARD_NODE,
    spec: RewardVisitSpec = RewardVisitSpec(),
    node_col: str = "node",
    day_col: str = "day",
    visit_id_col: str = "visit_id",
    start_col: str = "start_time_s",
    end_col: str = "end_time_s",
    n_frames_col: str = "n_c_frames",
) -> RewardVisitSupport:
    """Select fixed pre/post target visits and exclude the first reward visit."""

    _require_visit_columns(
        visits,
        (node_col, day_col, visit_id_col, start_col, end_col, n_frames_col),
    )
    target = visits.loc[
        visits[node_col].astype(int).eq(int(target_node))
        & (visits[n_frames_col].astype(float) >= int(spec.min_frames_per_visit))
    ].copy()
    day1 = target.loc[target[day_col].astype(str).str.lower().eq("day1")].sort_values(
        start_col
    )
    day2 = target.loc[target[day_col].astype(str).str.lower().eq("day2")].sort_values(
        start_col
    )
    reward_visit = _first_reward_visit_id(
        day2,
        first_reward_time,
        visit_id_col=visit_id_col,
        start_col=start_col,
        end_col=end_col,
    )
    if reward_visit is None:
        return RewardVisitSupport(
            target_node=int(target_node),
            status="first_reward_visit_unresolved",
            supported=False,
            first_reward_visit_id=None,
            pre_visit_ids=tuple(day1.tail(int(spec.k_visits))[visit_id_col].tolist()),
            post_visit_ids=(),
            n_pre_eligible=int(len(day1)),
            n_post_primary_eligible=0,
            n_post_rescue_eligible=0,
            post_window_s_used=None,
        )
    post = day2.loc[day2[start_col].astype(float) > float(first_reward_time)].copy()
    post = post.loc[~post[visit_id_col].eq(reward_visit)]
    primary = post.loc[
        post[start_col].astype(float)
        <= float(first_reward_time) + float(spec.primary_post_window_s)
    ]
    rescue = post.loc[
        post[start_col].astype(float)
        <= float(first_reward_time) + float(spec.rescue_post_window_s)
    ]
    k = int(spec.k_visits)
    pre_ids = tuple(day1.tail(k)[visit_id_col].tolist())
    if len(day1) < k:
        status = "insufficient_pre_visits"
        post_ids: tuple[Any, ...] = ()
        window = None
    elif len(primary) >= k:
        status = "ok_primary"
        post_ids = tuple(primary.head(k)[visit_id_col].tolist())
        window = float(spec.primary_post_window_s)
    elif len(rescue) >= k:
        status = "ok_extended_post"
        post_ids = tuple(rescue.head(k)[visit_id_col].tolist())
        window = float(spec.rescue_post_window_s)
    else:
        status = "insufficient_post_visits"
        post_ids = tuple(rescue.head(k)[visit_id_col].tolist())
        window = None
    return RewardVisitSupport(
        target_node=int(target_node),
        status=status,
        supported=status.startswith("ok_"),
        first_reward_visit_id=reward_visit,
        pre_visit_ids=pre_ids,
        post_visit_ids=post_ids,
        n_pre_eligible=int(len(day1)),
        n_post_primary_eligible=int(len(primary)),
        n_post_rescue_eligible=int(len(rescue)),
        post_window_s_used=window,
    )


def _relative_match(value: float, target: float, fraction: float) -> bool:
    scale = max(abs(float(target)), np.finfo(float).eps)
    return abs(float(value) - float(target)) <= float(fraction) * scale


def match_pseudo_terminal_controls(
    visits: pd.DataFrame,
    target_support: RewardVisitSupport,
    first_reward_time: float,
    *,
    spec: RewardVisitSpec = RewardVisitSpec(),
    node_col: str = "node",
    day_col: str = "day",
    visit_id_col: str = "visit_id",
    start_col: str = "start_time_s",
    n_frames_col: str = "n_c_frames",
    orientation_col: str = "orientation",
    speed_col: str = "approach_speed",
    dwell_col: str = "dwell_s",
) -> PseudoControlMatch:
    """Match pseudo-terminal nodes with an explicit support/caliper ladder."""

    _require_visit_columns(
        visits,
        (
            node_col,
            day_col,
            visit_id_col,
            start_col,
            n_frames_col,
            orientation_col,
            speed_col,
            dwell_col,
        ),
    )
    if not target_support.supported:
        return PseudoControlMatch(
            status="target_support_unresolved",
            supported=False,
            matched_nodes=(),
            caliper_fraction_used=None,
            orientation_matched=False,
            per_node_visit_ids={},
        )
    k = int(spec.k_visits)
    eligible = visits.loc[
        visits[n_frames_col].astype(float) >= int(spec.min_frames_per_visit)
    ].copy()
    target_rows = eligible.loc[
        eligible[node_col].astype(int).eq(int(target_support.target_node))
    ]
    target_selected = target_rows.loc[
        target_rows[visit_id_col].isin(
            (*target_support.pre_visit_ids, *target_support.post_visit_ids)
        )
    ]
    if target_selected.empty:
        raise ValueError("target visit IDs are absent from the visit table")
    target_orientation = str(target_selected[orientation_col].mode().iloc[0])
    target_speed = float(target_selected[speed_col].median())
    target_dwell = float(target_selected[dwell_col].median())

    candidates: dict[int, dict[str, Any]] = {}
    for node, group in eligible.groupby(node_col, sort=True):
        node = int(node)
        if node == int(target_support.target_node):
            continue
        pre = group.loc[group[day_col].astype(str).str.lower().eq("day1")].sort_values(
            start_col
        )
        post = group.loc[
            group[day_col].astype(str).str.lower().eq("day2")
            & (group[start_col].astype(float) > float(first_reward_time))
            & (
                group[start_col].astype(float)
                <= float(first_reward_time) + float(target_support.post_window_s_used)
            )
        ].sort_values(start_col)
        if len(pre) < k or len(post) < k:
            continue
        pre = pre.tail(k)
        post = post.head(k)
        selected = pd.concat([pre, post], ignore_index=True)
        candidates[node] = {
            "orientation": str(selected[orientation_col].mode().iloc[0]),
            "speed": float(selected[speed_col].median()),
            "dwell": float(selected[dwell_col].median()),
            "pre": tuple(pre[visit_id_col].tolist()),
            "post": tuple(post[visit_id_col].tolist()),
        }

    def choose(fraction: float, require_orientation: bool) -> list[int]:
        return [
            node
            for node, values in candidates.items()
            if (not require_orientation or values["orientation"] == target_orientation)
            and _relative_match(values["speed"], target_speed, fraction)
            and _relative_match(values["dwell"], target_dwell, fraction)
        ]

    matched = choose(spec.primary_caliper_fraction, True)
    if len(matched) >= int(spec.min_primary_controls):
        status = "ok_primary"
        fraction = float(spec.primary_caliper_fraction)
        orientation_matched = True
    else:
        matched = choose(spec.rescue_caliper_fraction, True)
        if len(matched) >= int(spec.min_primary_controls):
            status = "ok_relaxed_caliper"
            fraction = float(spec.rescue_caliper_fraction)
            orientation_matched = True
        else:
            matched = choose(spec.rescue_caliper_fraction, False)
            if len(matched) >= int(spec.min_controls):
                status = "ok_control_match_rescued"
                fraction = float(spec.rescue_caliper_fraction)
                orientation_matched = False
            else:
                status = "insufficient_pseudo_controls"
                fraction = None
                orientation_matched = False
    matched = tuple(sorted(int(node) for node in matched))
    per_node = {
        node: {"pre": candidates[node]["pre"], "post": candidates[node]["post"]}
        for node in matched
    }
    return PseudoControlMatch(
        status=status,
        supported=status.startswith("ok_"),
        matched_nodes=matched,
        caliper_fraction_used=fraction,
        orientation_matched=orientation_matched,
        per_node_visit_ids=per_node,
    )


def compute_pseudo_target_did(
    scores: pd.DataFrame,
    *,
    animal_col: str = "animal_id",
    node_col: str = "node",
    epoch_col: str = "epoch",
    score_col: str = "score",
    pre_label: str = "pre",
    post_label: str = "post",
    target_node: int = REWARD_NODE,
    controls_by_animal: Mapping[Any, Sequence[int]] | None = None,
    min_controls: int = 3,
) -> pd.DataFrame:
    """Compute target and pseudo-target DiDs plus within-animal ranks."""

    _require_visit_columns(scores, (animal_col, node_col, epoch_col, score_col))
    rows: list[dict[str, Any]] = []
    for animal, group in scores.groupby(animal_col, sort=False):
        summary = (
            group.groupby([node_col, epoch_col], dropna=False)[score_col]
            .mean()
            .unstack(epoch_col)
        )
        if pre_label not in summary.columns or post_label not in summary.columns:
            rows.append(
                {
                    animal_col: animal,
                    node_col: int(target_node),
                    "status": "missing_pre_or_post_score",
                }
            )
            continue
        summary = summary.dropna(subset=[pre_label, post_label]).copy()
        summary["delta"] = summary[post_label] - summary[pre_label]
        allowed = (
            set(int(value) for value in controls_by_animal.get(animal, ()))
            if controls_by_animal is not None
            else set(
                int(value) for value in summary.index if int(value) != int(target_node)
            )
        )
        available = [int(value) for value in summary.index if int(value) in allowed]
        if int(target_node) not in set(int(value) for value in summary.index):
            rows.append(
                {
                    animal_col: animal,
                    node_col: int(target_node),
                    "status": "missing_target_score",
                }
            )
            continue
        if len(available) < int(min_controls):
            rows.append(
                {
                    animal_col: animal,
                    node_col: int(target_node),
                    "status": "insufficient_control_scores",
                    "n_controls": int(len(available)),
                }
            )
            continue
        node_set = [int(target_node), *available]
        delta = {node: float(summary.loc[node, "delta"]) for node in node_set}
        pseudo_values: dict[int, float] = {}
        for node in node_set:
            references = [delta[other] for other in node_set if other != node]
            pseudo_values[node] = float(delta[node] - np.median(references))
        ordered = sorted(pseudo_values, key=lambda node: (-pseudo_values[node], node))
        ranks = {node: idx + 1 for idx, node in enumerate(ordered)}
        for node in node_set:
            rows.append(
                {
                    animal_col: animal,
                    node_col: node,
                    "is_target_node": bool(node == int(target_node)),
                    "pre_score": float(summary.loc[node, pre_label]),
                    "post_score": float(summary.loc[node, post_label]),
                    "delta_post_minus_pre": delta[node],
                    "pseudo_target_did": pseudo_values[node],
                    "rank_descending": int(ranks[node]),
                    "rank_percentile_descending": float(
                        (ranks[node] - 1) / max(1, len(node_set) - 1)
                    ),
                    "n_controls": int(len(available)),
                    "status": "ok",
                }
            )
    return pd.DataFrame(rows)


def classify_node94_interpretation(
    *,
    support_status: str,
    target_change_supported: bool,
    target_rank_percentile: float | None,
    explore_only_supported: bool = False,
    goal_approach_supported: bool = False,
    outcome_inclusive_supported: bool = False,
    distributed_reward_supported: bool = False,
    exceptional_rank_threshold: float = 0.10,
) -> str:
    """Apply the prespecified reward-code interpretation ladder."""

    if not str(support_status).startswith("ok_"):
        return "node94_support_unresolved"
    exceptional = bool(
        target_rank_percentile is not None
        and np.isfinite(float(target_rank_percentile))
        and float(target_rank_percentile) <= float(exceptional_rank_threshold)
    )
    if target_change_supported and exceptional and explore_only_supported:
        return "reward_location_specific_code"
    if target_change_supported and exceptional and goal_approach_supported:
        return "goal_approach_state_code"
    if target_change_supported and exceptional and outcome_inclusive_supported:
        return "reward_consumption_state"
    if target_change_supported and not exceptional:
        return "generic_terminal_reorganization"
    if distributed_reward_supported:
        return "distributed_reward_coordinate_code"
    return "no_supported_reward_specific_code"


__all__ = [
    "DecoderAdapter",
    "PRIMARY_SUBTREE_PAIRS",
    "POSTHOC_INTERIOR_DEPTHS",
    "POSTHOC_INTERIOR_RESCUE_TIER",
    "RESCUE_SUBTREE_PAIRS",
    "PseudoControlMatch",
    "RewardVisitSpec",
    "RewardVisitSupport",
    "TopologyComparison",
    "TopologyFold",
    "TopologySupport",
    "assess_topology_support",
    "balanced_accuracy",
    "balance_topology_masks",
    "classify_node94_interpretation",
    "compute_pseudo_target_did",
    "fixed_topology_folds",
    "match_pseudo_terminal_controls",
    "poisson_decoder_adapter",
    "posthoc_interior_depth_folds",
    "run_topology_fold_backends",
    "select_reward_target_visits",
    "topology_fold_masks",
]
