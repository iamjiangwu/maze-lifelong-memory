"""Read-only helpers for the rapid-learning audit notebook suite.

The notebooks generated for this project are provenance companions.  They read
the frozen phase artifacts, expose every transformation stage, and verify saved
hashes; they never rerun or overwrite the underlying analysis bundles.
"""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PROJECT_BUNDLE = Path("docs/rapid_learning_structure_reward_2026-07-15")


def find_repo_root(start: str | Path | None = None) -> Path:
    """Find the repository root without mutating ``sys.path``."""

    current = Path.cwd() if start is None else Path(start)
    current = current.resolve()
    for candidate in (current, *current.parents):
        if (candidate / "src" / "ca_analysis").is_dir() and (
            candidate / "scripts"
        ).is_dir():
            return candidate
    raise FileNotFoundError(f"Could not locate repository root from {current}")


def bundle_root(repo_root: str | Path) -> Path:
    return Path(repo_root) / PROJECT_BUNDLE


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_csv(path: str | Path, **kwargs: Any) -> pd.DataFrame:
    return pd.read_csv(Path(path), **kwargs)


def resolve_bundle_path(repo_root: str | Path, value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return bundle_root(repo_root) / path


def load_attempt_registry(repo_root: str | Path) -> pd.DataFrame:
    return pd.read_csv(bundle_root(repo_root) / "final_existing_data_attempt_registry.csv")


def registry_phase_rows(
    repo_root: str | Path, analysis_ids: Iterable[str]
) -> pd.DataFrame:
    registry = load_attempt_registry(repo_root)
    wanted = {str(value) for value in analysis_ids}
    return registry.loc[registry["analysis_id"].astype(str).isin(wanted)].reset_index(
        drop=True
    )


def _flatten_scalars(value: Any, prefix: str = "") -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            label = f"{prefix}.{key}" if prefix else str(key)
            if str(key) in {"outputs", "inputs"}:
                continue
            rows.extend(_flatten_scalars(child, label))
    elif isinstance(value, (list, tuple)):
        if all(not isinstance(item, (Mapping, list, tuple)) for item in value):
            rows.append({"manifest_field": prefix, "value": json.dumps(value)})
        else:
            for index, child in enumerate(value):
                rows.extend(_flatten_scalars(child, f"{prefix}[{index}]"))
    else:
        rows.append({"manifest_field": prefix, "value": value})
    return rows


def manifest_parameter_table(
    repo_root: str | Path, manifest_paths: Iterable[str]
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for relative in manifest_paths:
        path = resolve_bundle_path(repo_root, relative)
        if not path.exists():
            rows.append(
                {
                    "manifest": str(relative),
                    "manifest_field": "<missing>",
                    "value": np.nan,
                }
            )
            continue
        for row in _flatten_scalars(read_json(path)):
            rows.append({"manifest": str(relative), **row})
    return pd.DataFrame(rows)


def _manifest_output_path(
    manifest_path: Path, output_name: str, output_info: Any
) -> Path:
    if isinstance(output_info, Mapping) and output_info.get("path"):
        candidate = Path(str(output_info["path"]))
        return candidate if candidate.is_absolute() else manifest_path.parent / candidate
    if isinstance(output_info, (str, Path)) and str(output_info):
        candidate = Path(str(output_info))
        return candidate if candidate.is_absolute() else manifest_path.parent / candidate
    return manifest_path.parent / output_name


def manifest_output_audit(
    repo_root: str | Path, manifest_paths: Iterable[str]
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for relative in manifest_paths:
        manifest_path = resolve_bundle_path(repo_root, relative)
        if not manifest_path.exists():
            rows.append(
                {
                    "manifest": str(relative),
                    "output": "<manifest missing>",
                    "path": str(manifest_path),
                    "exists": False,
                    "hash_matches": False,
                }
            )
            continue
        manifest = read_json(manifest_path)
        for name, info in manifest.get("outputs", {}).items():
            path = _manifest_output_path(manifest_path, str(name), info)
            expected = info.get("sha256") if isinstance(info, Mapping) else None
            exists = path.exists()
            actual = sha256_file(path) if exists else None
            hash_matches: bool | None
            if expected is None:
                hash_matches = None
            else:
                hash_matches = bool(
                    exists and str(expected).lower() == str(actual).lower()
                )
            rows.append(
                {
                    "manifest": str(relative),
                    "output": str(name),
                    "path": str(path),
                    "exists": exists,
                    "expected_sha256": expected,
                    "actual_sha256": actual,
                    "hash_matches": hash_matches,
                }
            )
    return pd.DataFrame(rows)


def source_symbol_table(
    repo_root: str | Path, source_paths: Iterable[str]
) -> pd.DataFrame:
    """List top-level source symbols with exact line spans."""

    rows: list[dict[str, Any]] = []
    root = Path(repo_root)
    for relative in source_paths:
        path = root / relative
        if not path.exists():
            rows.append(
                {
                    "source": str(relative),
                    "symbol": "<missing>",
                    "kind": "missing",
                    "start_line": np.nan,
                    "end_line": np.nan,
                }
            )
            continue
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                rows.append(
                    {
                        "source": str(relative),
                        "symbol": node.name,
                        "kind": type(node).__name__,
                        "start_line": int(node.lineno),
                        "end_line": int(getattr(node, "end_lineno", node.lineno)),
                    }
                )
    return pd.DataFrame(rows)


def artifact_overview(
    repo_root: str | Path, artifacts: Iterable[Mapping[str, Any]]
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for artifact in artifacts:
        relative = str(artifact["path"])
        path = resolve_bundle_path(repo_root, relative)
        row: dict[str, Any] = {
            "stage": artifact.get("stage", ""),
            "role": artifact.get("role", ""),
            "artifact": relative,
            "exists": path.exists(),
            "sha256": sha256_file(path) if path.exists() else None,
        }
        if path.suffix.lower() == ".csv" and path.exists():
            frame = pd.read_csv(path)
            row.update(
                {
                    "rows": int(len(frame)),
                    "columns": int(frame.shape[1]),
                    "animal_count": int(frame["animal_id"].nunique())
                    if "animal_id" in frame
                    else np.nan,
                    "session_count": int(frame["session_id"].nunique())
                    if "session_id" in frame
                    else np.nan,
                }
            )
            key_columns = artifact.get("key_columns", [])
            missing = [column for column in key_columns if column not in frame.columns]
            row["missing_key_columns"] = ", ".join(missing)
        rows.append(row)
    return pd.DataFrame(rows)


def artifact_preview(
    repo_root: str | Path,
    artifact: Mapping[str, Any],
    *,
    n_rows: int = 8,
) -> pd.DataFrame:
    path = resolve_bundle_path(repo_root, str(artifact["path"]))
    if path.suffix.lower() != ".csv":
        return pd.DataFrame({"path": [str(path)], "preview": ["non-CSV artifact"]})
    frame = pd.read_csv(path)
    columns = [
        column for column in artifact.get("preview_columns", []) if column in frame
    ]
    if not columns:
        columns = list(frame.columns[: min(12, frame.shape[1])])
    return frame.loc[:, columns].head(int(n_rows))


def cohort_selection_table(
    repo_root: str | Path, artifact: Mapping[str, Any]
) -> pd.DataFrame:
    path = resolve_bundle_path(repo_root, str(artifact["path"]))
    frame = pd.read_csv(path)
    requested = list(
        artifact.get(
            "columns",
            ["animal_id", "session_id", "cohort_group", "status", "reason"],
        )
    )
    missing = [column for column in requested if column not in frame.columns]
    if missing:
        raise KeyError(
            f"Selection artifact {path} is missing declared columns: {missing}"
        )
    columns = requested
    if not columns:
        return frame.head(0)
    return frame.loc[:, columns].drop_duplicates().reset_index(drop=True)


def _numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def _panel_missing(ax: plt.Axes, title: str, message: str) -> None:
    ax.axis("off")
    ax.set_title(title, loc="left", fontweight="bold")
    ax.text(0.02, 0.75, message, transform=ax.transAxes, va="top", wrap=True)


def _readable_category_labels(labels: Iterable[Any]) -> list[str]:
    """Keep audit-category labels legible without changing their values."""

    readable: list[str] = []
    for value in labels:
        text = str(value).replace("_", " ")
        if len(text) > 24:
            text = text[:21] + "..."
        readable.append(text)
    return readable


def panel_plottable_row_count(
    repo_root: str | Path, panel: Mapping[str, Any]
) -> int:
    """Return rows that can contribute a visible mark under the panel contract."""

    path = resolve_bundle_path(repo_root, str(panel["path"]))
    if not path.exists():
        return 0
    frame = pd.read_csv(path)
    if panel.get("query"):
        frame = frame.query(str(panel["query"]))
    kind = str(panel.get("kind", "counts"))
    x = panel.get("x")
    y = panel.get("y")
    if frame.empty:
        return 0
    if kind in {"counts", "animal_counts"}:
        required = [column for column in [x, panel.get("hue")] if column]
        return int(frame[required].notna().all(axis=1).sum()) if required else len(frame)
    if kind == "paired":
        columns = [str(panel.get("id", "animal_id")), str(panel["left"]), str(panel["right"])]
        work = frame[columns].drop_duplicates(columns[0])
        finite = np.isfinite(work[columns[1:]].apply(pd.to_numeric, errors="coerce")).all(axis=1)
        return int(finite.sum())
    if kind == "scatter":
        work = frame[[x, y]].apply(pd.to_numeric, errors="coerce")
        return int(np.isfinite(work).all(axis=1).sum())
    if kind == "strip":
        finite_y = np.isfinite(pd.to_numeric(frame[y], errors="coerce"))
        return int((finite_y & frame[x].notna()).sum())
    if kind == "hist":
        return int(np.isfinite(pd.to_numeric(frame[x], errors="coerce")).sum())
    return 0


def _plot_panel(
    ax: plt.Axes,
    repo_root: str | Path,
    panel: Mapping[str, Any],
) -> None:
    title = str(panel.get("title", "Audit panel"))
    path = resolve_bundle_path(repo_root, str(panel["path"]))
    if not path.exists():
        _panel_missing(ax, title, f"Missing artifact: {path}")
        return
    frame = pd.read_csv(path)
    query = panel.get("query")
    if query:
        try:
            frame = frame.query(str(query))
        except Exception as exc:  # pragma: no cover - visible notebook diagnostic
            _panel_missing(ax, title, f"Query failed: {exc}")
            return
    kind = str(panel.get("kind", "counts"))
    x = panel.get("x")
    y = panel.get("y")
    hue = panel.get("hue")
    if x and x not in frame:
        _panel_missing(ax, title, f"Column {x!r} not present")
        return
    if y and y not in frame:
        _panel_missing(ax, title, f"Column {y!r} not present")
        return

    if kind == "counts":
        if hue and hue in frame:
            table = frame.groupby([x, hue], dropna=False).size().unstack(fill_value=0)
            table.plot(kind="bar", stacked=True, ax=ax, width=0.8)
            ax.legend(fontsize=7, title=str(hue))
        else:
            frame[x].astype(str).value_counts(dropna=False).sort_index().plot.bar(ax=ax)
        ax.set_ylabel("rows")
    elif kind == "animal_counts":
        if "animal_id" not in frame:
            _panel_missing(ax, title, "animal_id is absent")
            return
        if hue and hue in frame:
            table = (
                frame.groupby([x, hue], dropna=False)["animal_id"]
                .nunique()
                .unstack(fill_value=0)
            )
            table.plot(kind="bar", stacked=True, ax=ax, width=0.8)
            ax.legend(fontsize=7, title=str(hue))
        else:
            frame.groupby(x, dropna=False)["animal_id"].nunique().plot.bar(ax=ax)
        ax.set_ylabel("unique animals")
    elif kind == "paired":
        id_col = str(panel.get("id", "animal_id"))
        left = str(panel["left"])
        right = str(panel["right"])
        if any(column not in frame for column in [id_col, left, right]):
            _panel_missing(ax, title, "paired columns are absent")
            return
        work = frame[[id_col, left, right]].drop_duplicates(id_col)
        for _, row in work.iterrows():
            values = [_numeric(pd.Series([row[left]])).iloc[0], _numeric(pd.Series([row[right]])).iloc[0]]
            ax.plot([0, 1], values, color="#7a7a7a", alpha=0.55, marker="o", ms=3)
        ax.set_xticks([0, 1], [panel.get("left_label", left), panel.get("right_label", right)])
        ax.axhline(0, color="#bbbbbb", lw=0.8)
    elif kind == "scatter":
        work = frame.copy()
        work[x] = _numeric(work[x])
        work[y] = _numeric(work[y])
        if hue and hue in work:
            for label, group in work.groupby(hue, dropna=False):
                ax.scatter(group[x], group[y], label=str(label), s=28, alpha=0.8)
            ax.legend(fontsize=7, title=str(hue))
        else:
            ax.scatter(work[x], work[y], s=28, alpha=0.8)
        ax.axhline(0, color="#bbbbbb", lw=0.8)
        ax.axvline(0, color="#bbbbbb", lw=0.8)
    elif kind == "strip":
        groups = list(frame.groupby(x, dropna=False))
        rng = np.random.default_rng(17)
        hue_levels = list(frame[hue].drop_duplicates()) if hue and hue in frame else []
        color_map = {
            level: plt.get_cmap("tab10")(index % 10)
            for index, level in enumerate(hue_levels)
        }
        for index, (label, group) in enumerate(groups):
            subgroups = list(group.groupby(hue, dropna=False)) if hue_levels else [(None, group)]
            for hue_index, (hue_label, subgroup) in enumerate(subgroups):
                values = _numeric(subgroup[y]).dropna().to_numpy()
                offset = 0.0 if len(subgroups) == 1 else (hue_index - (len(subgroups) - 1) / 2) * 0.16
                jitter = rng.uniform(-0.045, 0.045, size=values.size)
                ax.scatter(
                    index + offset + jitter,
                    values,
                    s=24,
                    alpha=0.8,
                    color=color_map.get(hue_label),
                    label=str(hue_label) if index == 0 and hue_levels else None,
                )
                if values.size:
                    ax.hlines(
                        np.median(values),
                        index + offset - 0.07,
                        index + offset + 0.07,
                        color=color_map.get(hue_label, "black"),
                    )
        ax.set_xticks(
            range(len(groups)),
            _readable_category_labels(label for label, _ in groups),
            rotation=35,
            ha="right",
        )
        ax.axhline(0, color="#bbbbbb", lw=0.8)
        if hue_levels:
            ax.legend(fontsize=7, title=str(hue))
    elif kind == "hist":
        values = _numeric(frame[x]).dropna()
        ax.hist(values, bins=min(30, max(5, int(np.sqrt(max(1, len(values)))))))
        if "observed" in panel:
            ax.axvline(float(panel["observed"]), color="#b2182b", lw=1.5)
    else:
        _panel_missing(ax, title, f"Unsupported panel kind: {kind}")
        return
    ax.set_title(title, loc="left", fontweight="bold", fontsize=10)
    if x and kind not in {"paired", "hist"}:
        ax.set_xlabel(str(panel.get("xlabel", x)))
    if y and kind in {"paired", "scatter", "strip"}:
        ax.set_ylabel(str(panel.get("ylabel", y)))
    ax.spines[["top", "right"]].set_visible(False)
    if kind in {"counts", "animal_counts"}:
        ax.set_xticklabels(
            _readable_category_labels(tick.get_text() for tick in ax.get_xticklabels()),
            rotation=35,
            ha="right",
            fontsize=7,
        )


def render_intermediate_panels(
    repo_root: str | Path,
    panels: Iterable[Mapping[str, Any]],
    *,
    title: str,
    save_path: str | Path | None = None,
) -> plt.Figure:
    panel_list = list(panels)
    n_panels = max(1, len(panel_list))
    n_cols = 2
    n_rows = int(np.ceil(n_panels / n_cols))
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(11, 4.0 * n_rows))
    axes_array = np.atleast_1d(axes).ravel()
    for ax, panel in zip(axes_array, panel_list):
        _plot_panel(ax, repo_root, panel)
    for ax in axes_array[len(panel_list) :]:
        ax.axis("off")
    fig.suptitle(title, y=1.01, fontweight="bold")
    fig.tight_layout()
    if save_path is not None:
        output = Path(save_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(output, dpi=180, bbox_inches="tight")
    return fig


def existing_figure_paths(
    repo_root: str | Path, figure_paths: Iterable[str]
) -> list[Path]:
    return [
        resolve_bundle_path(repo_root, relative)
        for relative in figure_paths
        if resolve_bundle_path(repo_root, relative).exists()
    ]


def phase_file_inventory(
    repo_root: str | Path, spec: Mapping[str, Any]
) -> pd.DataFrame:
    """Inventory every file in the phase directories named by a specification.

    This is deliberately broader than ``artifacts``: the curated artifacts show
    the conversion chain, while this table prevents an uncurated sensitivity,
    exclusion ledger, or failed-attempt output from disappearing from view.
    """

    root = Path(repo_root)
    directories: set[Path] = set()
    phase_name = str(spec.get("phase", ""))
    bundle = bundle_root(root)
    if bundle.exists() and phase_name:
        prefix = f"{phase_name}_"
        directories.update(
            path
            for path in bundle.iterdir()
            if path.is_dir() and (path.name == phase_name or path.name.startswith(prefix))
        )
    for value in spec.get("manifests", []):
        directories.add(resolve_bundle_path(root, str(value)).parent)
    for artifact in spec.get("artifacts", []):
        directories.add(resolve_bundle_path(root, str(artifact["path"])).parent)
    rows: list[dict[str, Any]] = []
    seen_files: set[Path] = set()
    for directory in sorted(directories):
        if not directory.exists():
            rows.append(
                {
                    "directory": str(directory),
                    "file": "<directory missing>",
                    "suffix": "",
                    "bytes": 0,
                    "sha256": None,
                    "rows": np.nan,
                    "columns": np.nan,
                }
            )
            continue
        for path in sorted(candidate for candidate in directory.rglob("*") if candidate.is_file()):
            if path in seen_files:
                continue
            seen_files.add(path)
            row: dict[str, Any] = {
                "directory": str(directory.relative_to(root)),
                "file": path.name,
                "suffix": path.suffix.lower(),
                "bytes": int(path.stat().st_size),
                "sha256": sha256_file(path),
                "rows": np.nan,
                "columns": np.nan,
            }
            if path.suffix.lower() == ".csv":
                try:
                    frame = pd.read_csv(path)
                    row["rows"] = int(len(frame))
                    row["columns"] = int(frame.shape[1])
                except Exception as exc:
                    row["csv_read_error"] = repr(exc)
            rows.append(row)
    return pd.DataFrame(rows)


def spec_coverage_table(specs: Iterable[Mapping[str, Any]]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for spec in specs:
        for analysis_id in spec.get("analysis_ids", []):
            rows.append(
                {
                    "phase": spec["phase"],
                    "analysis_id": analysis_id,
                    "title": spec["title"],
                }
            )
    return pd.DataFrame(rows)


__all__ = [
    "PROJECT_BUNDLE",
    "artifact_overview",
    "artifact_preview",
    "bundle_root",
    "cohort_selection_table",
    "existing_figure_paths",
    "find_repo_root",
    "load_attempt_registry",
    "manifest_output_audit",
    "manifest_parameter_table",
    "phase_file_inventory",
    "read_csv",
    "read_json",
    "registry_phase_rows",
    "render_intermediate_panels",
    "resolve_bundle_path",
    "sha256_file",
    "source_symbol_table",
    "spec_coverage_table",
]
