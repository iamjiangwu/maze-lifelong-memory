from dataclasses import dataclass
from typing import Literal

Timebase = Literal['absolute', 'maze', 'run']

@dataclass
class AlignmentReport:
    session_matching_source: str
    included_sessions: list
    excluded_sessions: list
    timebase: Timebase
    continuity_assumptions: str

def validate_alignment(report: AlignmentReport):
    if report.timebase not in {'absolute', 'maze', 'run'}:
        raise ValueError('invalid timebase')
    if not report.session_matching_source:
        raise ValueError('session_matching_source is required')
    return True
