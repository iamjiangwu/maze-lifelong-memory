"""Conditional-choice models for rapid structural learning.

The public scoring API consumes an alternative-long decision table.  Each
decision must have at least two candidate rows and exactly one chosen row.
This keeps the model valid for variable out-degree while allowing the primary
binary-tree analysis to use left/right alternatives without a special case.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Sequence

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logsumexp

from .maze import Maze


@dataclass(frozen=True)
class TopologyPolicySpec:
    local_features: tuple[str, ...]
    topology_features: tuple[str, ...] = ("q_frontier", "q_route")
    l2_penalty: float = 1.0
    max_iter: int = 500
    tolerance: float = 1e-8
    seed: int = 0


@dataclass(frozen=True)
class RapidLearningEpochSpec:
    candidate_k: tuple[int, ...] = (100, 75, 50, 40, 30, 25)
    primary_max_minutes: float = 60.0
    rescue_max_minutes: float = 90.0
    min_total_sessions: int = 18
    min_by_context: tuple[tuple[str, int], ...] = (
        ("unrewarded_no_water", 6),
        ("rewarded", 8),
        ("unrewarded_dry_waterport", 3),
    )


DEFAULT_LOCAL_FEATURES: tuple[str, ...] = (
    "alt_is_left",
    "alt_seen_before",
    "alt_visit_count_log1p",
    "alt_matches_alternation",
    "alt_matches_perseveration",
    "alt_left_x_depth",
)

DEFAULT_TOPOLOGY_FEATURES: tuple[str, ...] = ("q_frontier", "q_route")

ALL_NEIGHBOR_HISTORY_FEATURES: tuple[str, ...] = (
    "alt_is_left_child",
    "alt_seen_before",
    "alt_visit_count_log1p",
    "alt_exit_seen_before",
    "alt_exit_count_log1p",
    "alt_was_previous_exit_from_node",
    "alt_left_x_depth",
)

# Arrival-stratified utilities matching the maintained four-policy semantics.
# Parent/backtrack/sibling indicators remain exported audits, not M1 proxies.
ALL_NEIGHBOR_GRAPH_POLICY_FEATURES: tuple[str, ...] = (
    "alt_is_forward_from_parent",
    "alt_is_spatial_alternate_from_parent",
    "alt_is_forward_from_child",
    "alt_is_outward_from_child",
)

ALL_NEIGHBOR_STATIC_GEOMETRY_FEATURES: tuple[str, ...] = (
    "component_terminal_count_log1p",
    "static_route_to_nearest_terminal",
)

ALL_NEIGHBOR_LOCAL_FEATURES: tuple[str, ...] = (
    *ALL_NEIGHBOR_HISTORY_FEATURES,
    *ALL_NEIGHBOR_GRAPH_POLICY_FEATURES,
)


@dataclass(frozen=True)
class ConditionalChoiceFit:
    feature_names: tuple[str, ...]
    feature_scales: np.ndarray
    coefficients: np.ndarray
    converged: bool
    objective: float
    n_decisions: int
    n_rows: int
    message: str


def _decision_key_columns(
    decision_col: str,
    *,
    epoch_col: str | None = None,
) -> list[str]:
    return ([epoch_col] if epoch_col else []) + [decision_col]


def validate_alternative_table(
    rows: pd.DataFrame,
    *,
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
    key_prefix: Sequence[str] = (),
) -> pd.DataFrame:
    """Validate and return a copy of an alternative-long choice table."""

    required = {*key_prefix, decision_col, chosen_col}
    missing = sorted(required.difference(rows.columns))
    if missing:
        raise ValueError(f"missing choice-table columns: {missing}")
    out = rows.copy()
    out[chosen_col] = out[chosen_col].astype(bool)
    keys = [*key_prefix, decision_col]
    grouped = out.groupby(keys, sort=False, dropna=False)[chosen_col].agg(
        ["size", "sum"]
    )
    bad = grouped[(grouped["size"] < 2) | (grouped["sum"] != 1)]
    if len(bad):
        raise ValueError(
            "each decision must have at least two alternatives and exactly one chosen row; "
            f"invalid decisions={len(bad)}"
        )
    return out


def _subtree_terminal_runs(node: int, ma: Maze) -> frozenset[int]:
    terminal_start = 2 ** int(ma.le) - 1
    found: set[int] = set()
    stack = [int(node)]
    while stack:
        current = int(stack.pop())
        if current < 0 or current >= len(ma.ru):
            continue
        if current >= terminal_start:
            found.add(current)
            continue
        children = np.asarray(ma.ch[current], dtype=int).ravel()
        stack.extend(int(child) for child in children if int(child) >= 0)
    return frozenset(found)


def _run_graph_distances(ma: Maze) -> np.ndarray:
    n = len(ma.ru)
    adjacency: list[list[int]] = [[] for _ in range(n)]
    for node in range(n):
        parent = int(ma.pa[node]) if node < len(ma.pa) else -1
        if parent >= 0:
            adjacency[node].append(parent)
            adjacency[parent].append(node)
    distances = np.full((n, n), np.inf, dtype=float)
    for source in range(n):
        distances[source, source] = 0.0
        queue = [source]
        for current in queue:
            for nxt in adjacency[current]:
                if not np.isfinite(distances[source, nxt]):
                    distances[source, nxt] = distances[source, current] + 1.0
                    queue.append(nxt)
    return distances


def _run_graph_neighbors(ma: Maze) -> tuple[tuple[int, ...], ...]:
    """Return valid parent/children neighbors for every maze run node."""

    neighbors: list[tuple[int, ...]] = []
    for node in range(len(ma.ru)):
        values: list[int] = []
        parent = int(ma.pa[node]) if node < len(ma.pa) else -1
        if parent >= 0:
            values.append(parent)
        if node < len(ma.ch):
            values.extend(
                int(child)
                for child in np.asarray(ma.ch[node], dtype=int).ravel()
                if int(child) >= 0
            )
        neighbors.append(tuple(dict.fromkeys(values)))
    return tuple(neighbors)


def _component_terminals_after_cut(
    current: int,
    neighbor: int,
    graph_neighbors: Sequence[Sequence[int]],
    terminal_nodes: frozenset[int],
) -> frozenset[int]:
    """Find terminals reached through ``neighbor`` after removing ``current``."""

    found: set[int] = set()
    seen = {int(current)}
    queue = [int(neighbor)]
    while queue:
        node = int(queue.pop())
        if node in seen:
            continue
        seen.add(node)
        if node in terminal_nodes:
            found.add(node)
        queue.extend(int(value) for value in graph_neighbors[node] if value not in seen)
    return frozenset(found)


def build_all_neighbor_topology_choice_table(
    transitions: pd.DataFrame,
    ma: Maze,
    *,
    return_support_audit: bool = False,
) -> pd.DataFrame | tuple[pd.DataFrame, pd.DataFrame]:
    """Expand every non-forced graph-junction transition into alternatives.

    Unlike :func:`build_topology_choice_table`, this table is not restricted to
    entries from the parent followed by a child exit.  Candidates are exactly
    the current run node's valid parent/children graph neighbors.  Root choices
    are therefore binary, internal choices are ternary, and terminal/dead-end
    transitions are audited and excluded because they have fewer than two
    alternatives.

    For each alternative, the component frontier is defined by removing the
    current node and finding terminal nodes reachable through that neighbor.
    ``q_route`` uses the nearest still-unvisited terminal in that same component,
    so parent, child, root, and backtracking alternatives share one definition.
    """

    required = {
        "session_id",
        "animal_id",
        "cohort_group",
        "transition_id",
        "abs_frame_start",
        "prev_node",
        "current_node",
        "next_node",
    }
    missing = sorted(required.difference(transitions.columns))
    if missing:
        raise ValueError(
            f"missing transition columns for all-neighbor topology choices: {missing}"
        )

    graph_neighbors = _run_graph_neighbors(ma)
    run_distance = _run_graph_distances(ma)
    finite_distances = run_distance[np.isfinite(run_distance)]
    distance_normalizer = max(
        1.0,
        float(np.max(finite_distances)) if finite_distances.size else 1.0,
    )
    terminal_start = 2 ** int(ma.le) - 1
    terminal_nodes = frozenset(range(terminal_start, len(ma.ru)))
    component_cache = {
        (current, neighbor): _component_terminals_after_cut(
            current,
            neighbor,
            graph_neighbors,
            terminal_nodes,
        )
        for current, neighbors in enumerate(graph_neighbors)
        for neighbor in neighbors
    }

    records: list[dict[str, Any]] = []
    audit_records: list[dict[str, Any]] = []
    for session_id, session in transitions.groupby("session_id", sort=False):
        sort_columns = ["abs_frame_start"]
        if "transition_index_session" in session:
            sort_columns.append("transition_index_session")
        session = session.sort_values(sort_columns, kind="stable")
        visited_terminals: set[int] = set()
        run_visits: dict[int, int] = {}
        exit_counts: dict[tuple[int, int], int] = {}
        last_exit_by_node: dict[int, int] = {}
        active_bout: Any = object()
        decision_counter = 0

        for row in session.itertuples(index=False):
            current = int(row.current_node)
            previous = int(row.prev_node)
            nxt = int(row.next_node)
            bout = getattr(row, "bout", None)
            if bout != active_bout:
                active_bout = bout
                if 0 <= current < len(ma.ru):
                    run_visits[current] = run_visits.get(current, 0) + 1
                    if current in terminal_nodes:
                        visited_terminals.add(current)

            if 0 <= current < len(ma.ru):
                neighbors = graph_neighbors[current]
                parent = int(ma.pa[current]) if current < len(ma.pa) else -1
                children = tuple(
                    int(child)
                    for child in np.asarray(ma.ch[current], dtype=int).ravel()
                    if int(child) >= 0
                )
                if current == 0 and previous in {-1, len(ma.ru)}:
                    arrival_relation = "from_external_root"
                elif previous == parent and parent >= 0:
                    arrival_relation = "from_parent"
                elif previous in children:
                    arrival_relation = "from_child"
                else:
                    arrival_relation = "unknown"
            else:
                neighbors = ()
                parent = -1
                children = ()
                arrival_relation = "outside_graph"

            if not (0 <= current < len(ma.ru)):
                support_status = "invalid_current_outside_graph"
                node_type = "outside_graph"
            elif len(neighbors) < 2:
                support_status = "forced_degree_lt_2"
                node_type = "terminal" if current in terminal_nodes else "dead_end"
            elif nxt not in neighbors:
                support_status = "invalid_next_not_graph_neighbor"
                node_type = "root" if current == 0 else "internal_junction"
            else:
                support_status = "eligible_all_neighbor_choice"
                node_type = "root" if current == 0 else "internal_junction"

            chosen_relation = "not_applicable"
            if support_status == "eligible_all_neighbor_choice":
                all_unvisited = terminal_nodes.difference(visited_terminals)
                depth = int(getattr(row, "tree_depth", -1))
                speed = float(getattr(row, "speed", np.nan))
                dwell = float(getattr(row, "anchor_total_dwell_s", np.nan))
                alternate_child = -1
                if arrival_relation == "from_parent" and len(children) == 2:
                    current_is_left = current == 2 * parent + 1
                    alternate_child = int(
                        children[1] if current_is_left else children[0]
                    )

                for alternative in neighbors:
                    alternative = int(alternative)
                    if alternative == parent:
                        alternative_relation = "parent"
                    elif children and alternative == int(children[0]):
                        alternative_relation = "left_child"
                    elif len(children) >= 2 and alternative == int(children[1]):
                        alternative_relation = "right_child"
                    else:
                        alternative_relation = "other_graph_neighbor"
                    component = component_cache[(current, alternative)]
                    unvisited_component = component.difference(visited_terminals)
                    component_exhausted = not unvisited_component
                    if component:
                        static_route_steps = float(
                            np.min(run_distance[alternative, list(component)])
                        )
                        static_route = -static_route_steps / distance_normalizer
                    else:
                        static_route_steps = np.nan
                        static_route = -1.0
                    if unvisited_component:
                        route_steps = float(
                            np.min(run_distance[alternative, list(unvisited_component)])
                        )
                        q_route = -route_steps / distance_normalizer
                    else:
                        route_steps = np.nan
                        q_route = -1.0
                    q_frontier = (
                        float(len(unvisited_component) / len(component))
                        if component
                        else 0.0
                    )
                    exit_count = exit_counts.get((current, alternative), 0)
                    is_backtrack = alternative == previous and previous in neighbors
                    is_sibling = bool(
                        arrival_relation == "from_child"
                        and alternative in children
                        and alternative != previous
                    )
                    is_forward_from_parent = bool(
                        arrival_relation == "from_parent" and alternative != previous
                    )
                    is_forward_from_child = bool(
                        arrival_relation == "from_child" and alternative != previous
                    )
                    is_outward_from_child = bool(
                        arrival_relation == "from_child" and alternative == parent
                    )
                    is_spatial_alternate = bool(
                        arrival_relation == "from_parent"
                        and alternative == alternate_child
                    )
                    chosen = alternative == nxt
                    if chosen:
                        chosen_relation = alternative_relation
                    records.append(
                        {
                            "session_id": str(session_id),
                            "animal_id": str(row.animal_id),
                            "cohort_group": str(row.cohort_group),
                            "pair_id": str(getattr(row, "pair_id", "")),
                            "day_index": int(getattr(row, "day_index", 1)),
                            "mode_label": str(getattr(row, "mode_label", "unknown")),
                            "reward_epoch": str(
                                getattr(row, "reward_epoch", "unknown")
                            ),
                            "decision_id": str(row.transition_id),
                            "decision_index": int(decision_counter),
                            "abs_frame_start": float(row.abs_frame_start),
                            "maze_seconds_start": float(
                                getattr(row, "maze_seconds_start", np.nan)
                            ),
                            "alternative_id": alternative,
                            "alternative_relation": alternative_relation,
                            "chosen": bool(chosen),
                            "prev_node": previous,
                            "current_node": current,
                            "next_node": nxt,
                            "tree_depth": depth,
                            "junction_type": node_type,
                            "n_valid_neighbors": int(len(neighbors)),
                            "arrival_relation": arrival_relation,
                            "alt_is_parent": float(alternative == parent),
                            "alt_is_left_child": float(
                                bool(children) and alternative == int(children[0])
                            ),
                            "alt_is_right_child": float(
                                len(children) >= 2 and alternative == int(children[1])
                            ),
                            "alt_is_backtrack": float(is_backtrack),
                            "alt_is_sibling_of_arrival": float(is_sibling),
                            "alt_is_forward_from_parent": float(is_forward_from_parent),
                            "alt_is_forward_from_child": float(is_forward_from_child),
                            "alt_is_outward_from_child": float(is_outward_from_child),
                            "alt_is_spatial_alternate_from_parent": float(
                                is_spatial_alternate
                            ),
                            "alt_seen_before": float(alternative in run_visits),
                            "alt_visit_count_log1p": float(
                                np.log1p(run_visits.get(alternative, 0))
                            ),
                            "alt_exit_seen_before": float(exit_count > 0),
                            "alt_exit_count_log1p": float(np.log1p(exit_count)),
                            "alt_was_previous_exit_from_node": float(
                                last_exit_by_node.get(current) == alternative
                            ),
                            "alt_left_x_depth": float(
                                alternative_relation == "left_child"
                            )
                            * depth,
                            "alt_left_x_speed": (
                                float(alternative_relation == "left_child") * speed
                                if np.isfinite(speed)
                                else 0.0
                            ),
                            "alt_left_x_dwell": (
                                float(alternative_relation == "left_child") * dwell
                                if np.isfinite(dwell)
                                else 0.0
                            ),
                            "component_terminal_count": int(len(component)),
                            "component_terminal_count_log1p": float(
                                np.log1p(len(component))
                            ),
                            "component_unvisited_terminal_count": int(
                                len(unvisited_component)
                            ),
                            "component_exhausted": bool(component_exhausted),
                            "static_route_to_nearest_terminal_steps": static_route_steps,
                            "static_route_to_nearest_terminal": static_route,
                            "route_to_nearest_unvisited_steps": route_steps,
                            "q_frontier": q_frontier,
                            "q_route": q_route,
                            "n_visited_terminals_before": int(len(visited_terminals)),
                            "n_unvisited_terminals_before": int(len(all_unvisited)),
                            "frontier_exhausted": bool(not all_unvisited),
                            "decision_scope": "all_graph_neighbors_variable_outdegree",
                        }
                    )
                decision_counter += 1

            audit_records.append(
                {
                    "session_id": str(session_id),
                    "animal_id": str(row.animal_id),
                    "cohort_group": str(row.cohort_group),
                    "transition_id": str(row.transition_id),
                    "day_index": int(getattr(row, "day_index", 1)),
                    "mode_label": str(getattr(row, "mode_label", "unknown")),
                    "maze_seconds_start": float(
                        getattr(row, "maze_seconds_start", np.nan)
                    ),
                    "prev_node": previous,
                    "current_node": current,
                    "next_node": nxt,
                    "node_type": node_type,
                    "arrival_relation": arrival_relation,
                    "n_valid_neighbors": int(len(neighbors)),
                    "support_status": support_status,
                    "chosen_relation": chosen_relation,
                }
            )

            if 0 <= current < len(ma.ru) and nxt in graph_neighbors[current]:
                exit_counts[(current, nxt)] = exit_counts.get((current, nxt), 0) + 1
                last_exit_by_node[current] = nxt
            if 0 <= nxt < len(ma.ru):
                run_visits[nxt] = run_visits.get(nxt, 0) + 1
                if nxt in terminal_nodes:
                    visited_terminals.add(nxt)

    choices = pd.DataFrame(records)
    support_audit = pd.DataFrame(audit_records)
    if return_support_audit:
        return choices, support_audit
    return choices


def summarize_all_neighbor_local_policies(
    assigned_choices: pd.DataFrame,
) -> dict[str, pd.DataFrame]:
    """Summarize exact maintained local-policy semantics on all-neighbor events.

    The mapping is ``Bf -> P_SF`` (from-parent forward), ``Ba -> P_SA``
    (spatial alternation conditional on from-parent forward), ``Lf -> P_BF``
    (from-child forward rather than reversing to the arrival child), and
    ``Lo -> P_BS`` (outward to the parent conditional on from-child forward).
    Probabilities are first computed per current node and then averaged within
    animal/epoch, matching the maintained node-balanced interpretation.
    """

    required = {
        "animal_id",
        "cohort_group",
        "epoch",
        "decision_id",
        "current_node",
        "arrival_relation",
        "chosen",
        "alt_is_forward_from_parent",
        "alt_is_spatial_alternate_from_parent",
        "alt_is_forward_from_child",
        "alt_is_outward_from_child",
    }
    missing = sorted(required.difference(assigned_choices.columns))
    if missing:
        raise ValueError(f"missing all-neighbor local-policy columns: {missing}")
    chosen = assigned_choices.loc[assigned_choices["chosen"].astype(bool)].copy()
    chosen = chosen.drop_duplicates(["animal_id", "epoch", "decision_id"])
    chosen["is_from_parent"] = chosen["arrival_relation"].eq("from_parent")
    chosen["is_from_child"] = chosen["arrival_relation"].eq("from_child")
    chosen["Bf_event"] = pd.to_numeric(
        chosen["alt_is_forward_from_parent"], errors="coerce"
    )
    chosen["Ba_event"] = pd.to_numeric(
        chosen["alt_is_spatial_alternate_from_parent"], errors="coerce"
    )
    chosen["Lf_event"] = pd.to_numeric(
        chosen["alt_is_forward_from_child"], errors="coerce"
    )
    chosen["Lo_event"] = pd.to_numeric(
        chosen["alt_is_outward_from_child"], errors="coerce"
    )
    chosen.loc[~chosen["is_from_parent"], ["Bf_event", "Ba_event"]] = np.nan
    chosen.loc[
        ~(chosen["is_from_parent"] & chosen["Bf_event"].eq(1)), "Ba_event"
    ] = np.nan
    chosen.loc[~chosen["is_from_child"], ["Lf_event", "Lo_event"]] = np.nan
    chosen.loc[
        ~(
            chosen["is_from_child"]
            & chosen["Lf_event"].eq(1)
            & pd.to_numeric(chosen["current_node"], errors="coerce").gt(0)
        ),
        "Lo_event",
    ] = np.nan

    grouping = ["animal_id", "cohort_group", "epoch", "current_node"]
    per_node = chosen.groupby(grouping, as_index=False).agg(
        n_decisions=("decision_id", "nunique"),
        n_from_parent=("is_from_parent", "sum"),
        n_from_child=("is_from_child", "sum"),
        Bf=("Bf_event", "mean"),
        Ba=("Ba_event", "mean"),
        Lf=("Lf_event", "mean"),
        Lo=("Lo_event", "mean"),
    )
    animal_grouping = ["animal_id", "cohort_group", "epoch"]
    per_animal = per_node.groupby(animal_grouping, as_index=False).agg(
        n_nodes=("current_node", "nunique"),
        n_decisions=("n_decisions", "sum"),
        n_from_parent=("n_from_parent", "sum"),
        n_from_child=("n_from_child", "sum"),
        Bf=("Bf", "mean"),
        Ba=("Ba", "mean"),
        Lf=("Lf", "mean"),
        Lo=("Lo", "mean"),
    )
    per_animal = per_animal.rename(
        columns={
            "Bf": "P_SF_Bf_from_parent_forward",
            "Ba": "P_SA_Ba_from_parent_spatial_alternation",
            "Lf": "P_BF_Lf_from_child_forward",
            "Lo": "P_BS_Lo_from_child_outward_given_forward",
        }
    )
    return {
        "events": chosen,
        "per_node": per_node,
        "per_animal_epoch": per_animal,
    }


def build_topology_choice_table(
    transitions: pd.DataFrame,
    ma: Maze,
    *,
    decision_mask_col: str = "is_primary_decision",
) -> pd.DataFrame:
    """Expand real primary decisions into left/right alternative rows.

    Frontier features are computed from all prior transitions in the same
    session, including terminal visits that are not themselves decisions.
    This prevents the late-epoch score from mechanically ignoring accrued
    exploration history.
    """

    required = {
        "session_id",
        "animal_id",
        "cohort_group",
        "transition_id",
        "abs_frame_start",
        "current_node",
        "next_node",
        decision_mask_col,
    }
    missing = sorted(required.difference(transitions.columns))
    if missing:
        raise ValueError(f"missing transition columns for topology choices: {missing}")
    terminal_start = 2 ** int(ma.le) - 1
    subtree_cache = {
        node: _subtree_terminal_runs(node, ma) for node in range(len(ma.ru))
    }
    run_distance = _run_graph_distances(ma)
    normalizer = max(1.0, 2.0 * float(ma.le))
    records: list[dict[str, Any]] = []

    for session_id, session in transitions.groupby("session_id", sort=False):
        session = session.sort_values(
            ["abs_frame_start", "transition_index_session"], kind="stable"
        )
        visited_terminals: set[int] = set()
        run_visits: dict[int, int] = {}
        previous_primary_side: str | None = None
        decision_counter = 0
        for row in session.itertuples(index=False):
            current = int(row.current_node)
            nxt = int(row.next_node)
            if current >= terminal_start:
                visited_terminals.add(current)
            if bool(getattr(row, decision_mask_col)):
                children = np.asarray(ma.ch[current], dtype=int).ravel()
                children = children[children >= 0]
                if children.size >= 2 and nxt in set(children.tolist()):
                    all_unvisited = set(range(terminal_start, len(ma.ru))).difference(
                        visited_terminals
                    )
                    depth = int(getattr(row, "tree_depth", -1))
                    speed = float(getattr(row, "speed", np.nan))
                    dwell = float(getattr(row, "anchor_total_dwell_s", np.nan))
                    chosen_side = "left" if nxt == int(children[0]) else "right"
                    for alt_index, alternative in enumerate(children.tolist()):
                        subtree = subtree_cache[int(alternative)]
                        unvisited_subtree = subtree.difference(visited_terminals)
                        q_frontier = (
                            float(len(unvisited_subtree) / len(subtree))
                            if subtree
                            else 0.0
                        )
                        if all_unvisited:
                            q_route = -float(
                                np.min(
                                    run_distance[int(alternative), list(all_unvisited)]
                                )
                                / normalizer
                            )
                        else:
                            q_route = -1.0
                        alt_side = "left" if alt_index == 0 else "right"
                        seen = int(alternative) in run_visits
                        record = {
                            "session_id": str(session_id),
                            "animal_id": str(row.animal_id),
                            "cohort_group": str(row.cohort_group),
                            "pair_id": str(getattr(row, "pair_id", "")),
                            "day_index": int(getattr(row, "day_index", 1)),
                            "mode_label": str(getattr(row, "mode_label", "unknown")),
                            "reward_epoch": str(
                                getattr(row, "reward_epoch", "unknown")
                            ),
                            "decision_id": str(row.transition_id),
                            "decision_index": int(decision_counter),
                            "abs_frame_start": float(row.abs_frame_start),
                            "maze_seconds_start": float(
                                getattr(row, "maze_seconds_start", np.nan)
                            ),
                            "alternative_id": int(alternative),
                            "alternative_side": alt_side,
                            "chosen": bool(int(alternative) == nxt),
                            "current_node": current,
                            "tree_depth": depth,
                            "alt_is_left": float(alt_side == "left"),
                            "alt_seen_before": float(seen),
                            "alt_visit_count_log1p": float(
                                np.log1p(run_visits.get(int(alternative), 0))
                            ),
                            "alt_matches_alternation": float(
                                previous_primary_side is not None
                                and alt_side != previous_primary_side
                            ),
                            "alt_matches_perseveration": float(
                                previous_primary_side is not None
                                and alt_side == previous_primary_side
                            ),
                            "alt_left_x_depth": float((alt_side == "left") * depth),
                            "alt_left_x_speed": float((alt_side == "left") * speed)
                            if np.isfinite(speed)
                            else 0.0,
                            "alt_left_x_dwell": float((alt_side == "left") * dwell)
                            if np.isfinite(dwell)
                            else 0.0,
                            "q_frontier": q_frontier,
                            "q_route": q_route,
                            "n_visited_terminals_before": int(len(visited_terminals)),
                            "n_unvisited_terminals_before": int(len(all_unvisited)),
                            "frontier_exhausted": bool(not all_unvisited),
                        }
                        records.append(record)
                    decision_counter += 1
                    previous_primary_side = chosen_side
            run_visits[nxt] = run_visits.get(nxt, 0) + 1
            if nxt >= terminal_start:
                visited_terminals.add(nxt)
    return pd.DataFrame(records)


def choose_shared_structure_k(
    decision_counts: pd.DataFrame,
    spec: RapidLearningEpochSpec = RapidLearningEpochSpec(),
    *,
    count_col: str = "n_eligible_decisions",
    context_col: str = "cohort_group",
) -> dict[str, Any]:
    """Choose the largest prespecified K satisfying pooled/context support."""

    required = {count_col, context_col}
    missing = sorted(required.difference(decision_counts.columns))
    if missing:
        raise ValueError(f"missing K-selection columns: {missing}")
    counts = decision_counts.copy()
    counts[count_col] = pd.to_numeric(counts[count_col], errors="coerce").fillna(0)
    audits: list[dict[str, Any]] = []
    chosen: int | None = None
    context_requirements = dict(spec.min_by_context)
    for k in spec.candidate_k:
        eligible = counts[count_col].ge(3 * int(k))
        by_context = (
            counts.loc[eligible, context_col].astype(str).value_counts().to_dict()
        )
        passes = int(eligible.sum()) >= int(spec.min_total_sessions) and all(
            int(by_context.get(context, 0)) >= int(minimum)
            for context, minimum in context_requirements.items()
        )
        audits.append(
            {
                "k": int(k),
                "n_sessions": int(eligible.sum()),
                "counts_by_context": by_context,
                "passes": bool(passes),
            }
        )
        if passes and chosen is None:
            chosen = int(k)
    return {
        "status": "ok" if chosen is not None else "support_unresolved",
        "chosen_k": chosen,
        "audit": audits,
    }


def assign_structure_epochs(
    decisions: pd.DataFrame,
    *,
    k: int,
    spec: RapidLearningEpochSpec = RapidLearningEpochSpec(),
    time_col: str = "maze_seconds_start",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Assign exposure-indexed B and C epochs with a K-decision buffer."""

    required = {"session_id", "decision_id", time_col}
    missing = sorted(required.difference(decisions.columns))
    if missing:
        raise ValueError(f"missing epoch-assignment columns: {missing}")
    k = int(k)
    if k < 1:
        raise ValueError("k must be positive")
    assigned: list[pd.DataFrame] = []
    audits: list[dict[str, Any]] = []
    unique_decisions = decisions.drop_duplicates(["session_id", "decision_id"]).copy()
    for session_id, session_decisions in unique_decisions.groupby(
        "session_id", sort=False
    ):
        session_decisions = session_decisions.sort_values(time_col, kind="stable")
        chosen_window = None
        supported = pd.DataFrame()
        for minutes, label in (
            (float(spec.primary_max_minutes), "primary_60min"),
            (float(spec.rescue_max_minutes), "rescue_90min"),
        ):
            candidate = session_decisions[
                pd.to_numeric(session_decisions[time_col], errors="coerce").le(
                    minutes * 60
                )
            ]
            if len(candidate) >= 3 * k:
                supported = candidate
                chosen_window = label
                break
        if chosen_window is None:
            audits.append(
                {
                    "session_id": session_id,
                    "status": "support_unresolved",
                    "k": k,
                    "n_primary_60min": int(
                        pd.to_numeric(session_decisions[time_col], errors="coerce")
                        .le(float(spec.primary_max_minutes) * 60)
                        .sum()
                    ),
                    "n_rescue_90min": int(
                        pd.to_numeric(session_decisions[time_col], errors="coerce")
                        .le(float(spec.rescue_max_minutes) * 60)
                        .sum()
                    ),
                }
            )
            continue
        b_ids = set(supported.iloc[:k]["decision_id"].astype(str))
        c_ids = set(supported.iloc[-k:]["decision_id"].astype(str))
        selected = decisions[decisions["session_id"].eq(session_id)].copy()
        selected["epoch"] = np.where(
            selected["decision_id"].astype(str).isin(b_ids),
            "B",
            np.where(selected["decision_id"].astype(str).isin(c_ids), "C", "buffer"),
        )
        selected = selected[selected["epoch"].isin(["B", "C"])]
        assigned.append(selected)
        audits.append(
            {
                "session_id": session_id,
                "status": "ok",
                "k": k,
                "window": chosen_window,
                "n_supported": int(len(supported)),
                "n_buffer": int(len(supported) - 2 * k),
            }
        )
    return (
        pd.concat(assigned, ignore_index=True) if assigned else pd.DataFrame(),
        pd.DataFrame(audits),
    )


def _choice_blocks(
    rows: pd.DataFrame,
    feature_names: Sequence[str],
    *,
    decision_col: str,
    chosen_col: str,
    key_prefix: Sequence[str] = (),
) -> list[tuple[Any, np.ndarray, int]]:
    clean = validate_alternative_table(
        rows,
        decision_col=decision_col,
        chosen_col=chosen_col,
        key_prefix=key_prefix,
    )
    features = list(feature_names)
    missing = sorted(set(features).difference(clean.columns))
    if missing:
        raise ValueError(f"missing model features: {missing}")
    values = clean[features].apply(pd.to_numeric, errors="coerce")
    if not np.all(np.isfinite(values.to_numpy(dtype=float))):
        raise ValueError("all model features must be finite")
    clean.loc[:, features] = values
    keys = [*key_prefix, decision_col]
    blocks: list[tuple[Any, np.ndarray, int]] = []
    for key, group in clean.groupby(keys, sort=False, dropna=False):
        x = group[features].to_numpy(dtype=float)
        chosen = int(np.flatnonzero(group[chosen_col].to_numpy(dtype=bool))[0])
        blocks.append((key, x, chosen))
    return blocks


def fit_conditional_logit(
    rows: pd.DataFrame,
    feature_names: Sequence[str],
    *,
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
    key_prefix: Sequence[str] = (),
    l2_penalty: float = 1.0,
    max_iter: int = 500,
    tolerance: float = 1e-8,
) -> ConditionalChoiceFit:
    """Fit a ridge-regularized conditional multinomial logit model."""

    features = tuple(str(v) for v in feature_names)
    if not features:
        raise ValueError("at least one alternative-specific feature is required")
    blocks = _choice_blocks(
        rows,
        features,
        decision_col=decision_col,
        chosen_col=chosen_col,
        key_prefix=key_prefix,
    )
    if not blocks:
        raise ValueError("no valid decisions")
    feature_values = (
        rows[list(features)].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    )
    feature_scales = np.nanstd(feature_values, axis=0, ddof=0)
    feature_scales[~np.isfinite(feature_scales) | (feature_scales <= 0)] = 1.0
    blocks = [(key, x / feature_scales[None, :], chosen) for key, x, chosen in blocks]

    binary_differences: np.ndarray | None = None
    if all(x.shape[0] == 2 for _, x, _ in blocks):
        binary_differences = np.vstack(
            [x[chosen] - x[1 - chosen] for _, x, chosen in blocks]
        )

    def objective(beta: np.ndarray) -> tuple[float, np.ndarray]:
        if binary_differences is not None:
            margin = binary_differences @ beta
            loss = float(np.mean(np.logaddexp(0.0, -margin)))
            grad = -np.mean(binary_differences * expit(-margin)[:, None], axis=0)
            penalty = 0.5 * float(l2_penalty) * float(np.dot(beta, beta))
            return loss + penalty, grad + float(l2_penalty) * beta
        loss = 0.0
        grad = np.zeros_like(beta)
        for _, x, chosen in blocks:
            utility = x @ beta
            log_denom = logsumexp(utility)
            loss += float(log_denom - utility[chosen])
            prob = np.exp(utility - log_denom)
            grad += prob @ x - x[chosen]
        scale = 1.0 / len(blocks)
        penalty = 0.5 * float(l2_penalty) * float(np.dot(beta, beta))
        return loss * scale + penalty, grad * scale + float(l2_penalty) * beta

    result = minimize(
        lambda beta: objective(beta),
        np.zeros(len(features), dtype=float),
        method="L-BFGS-B",
        jac=True,
        options={"maxiter": int(max_iter), "ftol": float(tolerance)},
    )
    return ConditionalChoiceFit(
        feature_names=features,
        feature_scales=feature_scales,
        coefficients=np.asarray(result.x, dtype=float),
        converged=bool(result.success),
        objective=float(result.fun),
        n_decisions=len(blocks),
        n_rows=int(len(rows)),
        message=str(result.message),
    )


def score_conditional_logit(
    rows: pd.DataFrame,
    fit: ConditionalChoiceFit,
    *,
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
    key_prefix: Sequence[str] = (),
) -> pd.DataFrame:
    """Return chosen log probability and entropy for every decision."""

    blocks = _choice_blocks(
        rows,
        fit.feature_names,
        decision_col=decision_col,
        chosen_col=chosen_col,
        key_prefix=key_prefix,
    )
    records: list[dict[str, Any]] = []
    keys = [*key_prefix, decision_col]
    for key, x, chosen in blocks:
        key_tuple = key if isinstance(key, tuple) else (key,)
        utility = (x / fit.feature_scales[None, :]) @ fit.coefficients
        log_prob = utility - logsumexp(utility)
        prob = np.exp(log_prob)
        record = dict(zip(keys, key_tuple))
        record.update(
            {
                "chosen_index": int(chosen),
                "n_alternatives": int(x.shape[0]),
                "chosen_log_probability": float(log_prob[chosen]),
                "chosen_probability": float(prob[chosen]),
                "choice_entropy": float(-np.sum(prob * log_prob)),
            }
        )
        records.append(record)
    return pd.DataFrame(records)


def fit_topology_policy_score(
    rows: pd.DataFrame,
    spec: TopologyPolicySpec,
    *,
    animal_col: str = "animal_id",
    epoch_col: str = "epoch",
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
) -> dict[str, pd.DataFrame]:
    """Compute leave-one-mouse-out local and topology policy scores.

    Models are fit separately within each epoch.  The held-out mouse never
    contributes either coefficients or feature scaling because features are
    expected to arrive already defined on an absolute, interpretable scale.
    """

    required = {animal_col, epoch_col, decision_col, chosen_col}
    missing = sorted(required.difference(rows.columns))
    if missing:
        raise ValueError(f"missing policy-score columns: {missing}")
    clean = validate_alternative_table(
        rows,
        decision_col=decision_col,
        chosen_col=chosen_col,
        key_prefix=(animal_col, epoch_col),
    )
    local_features = tuple(spec.local_features)
    full_features = tuple(spec.local_features) + tuple(spec.topology_features)
    decision_records: list[pd.DataFrame] = []
    fit_records: list[dict[str, Any]] = []

    for epoch, epoch_rows in clean.groupby(epoch_col, sort=True):
        animals = sorted(epoch_rows[animal_col].astype(str).unique().tolist())
        for held_out in animals:
            train = epoch_rows[epoch_rows[animal_col].astype(str) != held_out]
            test = epoch_rows[epoch_rows[animal_col].astype(str) == held_out]
            n_train_animals = int(train[animal_col].astype(str).nunique())
            if n_train_animals < 2 or test.empty:
                fit_records.append(
                    {
                        animal_col: held_out,
                        epoch_col: epoch,
                        "status": "insufficient_training_animals",
                        "n_train_animals": n_train_animals,
                    }
                )
                continue
            local_fit = fit_conditional_logit(
                train,
                local_features,
                decision_col=decision_col,
                chosen_col=chosen_col,
                key_prefix=(animal_col, epoch_col),
                l2_penalty=spec.l2_penalty,
                max_iter=spec.max_iter,
                tolerance=spec.tolerance,
            )
            full_fit = fit_conditional_logit(
                train,
                full_features,
                decision_col=decision_col,
                chosen_col=chosen_col,
                key_prefix=(animal_col, epoch_col),
                l2_penalty=spec.l2_penalty,
                max_iter=spec.max_iter,
                tolerance=spec.tolerance,
            )
            local_score = score_conditional_logit(
                test,
                local_fit,
                decision_col=decision_col,
                chosen_col=chosen_col,
                key_prefix=(animal_col, epoch_col),
            ).rename(columns={"chosen_log_probability": "local_log_probability"})
            full_score = score_conditional_logit(
                test,
                full_fit,
                decision_col=decision_col,
                chosen_col=chosen_col,
                key_prefix=(animal_col, epoch_col),
            ).rename(columns={"chosen_log_probability": "topology_log_probability"})
            keep = [animal_col, epoch_col, decision_col]
            merged = local_score[keep + ["local_log_probability"]].merge(
                full_score[keep + ["topology_log_probability"]],
                on=keep,
                how="inner",
                validate="one_to_one",
            )
            merged["psi_decision_raw"] = (
                merged["topology_log_probability"] - merged["local_log_probability"]
            )
            merged["held_out_animal"] = held_out
            decision_records.append(merged)
            fit_records.append(
                {
                    animal_col: held_out,
                    epoch_col: epoch,
                    "status": "ok"
                    if local_fit.converged and full_fit.converged
                    else "fit_warning",
                    "n_train_animals": n_train_animals,
                    "n_test_decisions": int(len(merged)),
                    "local_converged": bool(local_fit.converged),
                    "topology_converged": bool(full_fit.converged),
                    "local_coefficients": local_fit.coefficients.tolist(),
                    "local_feature_scales": local_fit.feature_scales.tolist(),
                    "topology_coefficients": full_fit.coefficients.tolist(),
                    "topology_feature_scales": full_fit.feature_scales.tolist(),
                }
            )

    per_decision = (
        pd.concat(decision_records, ignore_index=True)
        if decision_records
        else pd.DataFrame()
    )
    if per_decision.empty:
        per_animal = pd.DataFrame(
            columns=[animal_col, epoch_col, "psi_raw", "n_decisions"]
        )
    else:
        per_animal = per_decision.groupby([animal_col, epoch_col], as_index=False).agg(
            psi_raw=("psi_decision_raw", "mean"), n_decisions=(decision_col, "nunique")
        )
    return {
        "per_decision": per_decision,
        "per_animal_epoch": per_animal,
        "fit_audit": pd.DataFrame(fit_records),
    }


def simulate_choices_from_probabilities(
    rows: pd.DataFrame,
    probabilities: pd.DataFrame,
    *,
    rng: np.random.Generator,
    animal_col: str = "animal_id",
    epoch_col: str = "epoch",
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
) -> pd.DataFrame:
    """Generate one chosen alternative per decision from row probabilities."""

    keys = [animal_col, epoch_col, decision_col]
    prob_col = "choice_probability"
    if prob_col not in probabilities.columns:
        raise ValueError(f"probabilities must contain {prob_col}")
    merged = rows.merge(
        probabilities[keys + ["alternative_id", prob_col]],
        on=keys + ["alternative_id"],
        how="left",
        validate="one_to_one",
    )
    if merged[prob_col].isna().any():
        raise ValueError("missing simulated-choice probability")
    merged[chosen_col] = False
    for _, index in merged.groupby(keys, sort=False).groups.items():
        idx = np.asarray(list(index), dtype=int)
        p = merged.loc[idx, prob_col].to_numpy(dtype=float)
        p = np.clip(p, 0, np.inf)
        if not np.isfinite(p).all() or np.sum(p) <= 0:
            p = np.full(len(idx), 1 / len(idx), dtype=float)
        else:
            p /= np.sum(p)
        selected = int(rng.choice(idx, p=p))
        merged.loc[selected, chosen_col] = True
    return merged.drop(columns=[prob_col])


def fixed_policy_null_correct(
    rows: pd.DataFrame,
    spec: TopologyPolicySpec,
    *,
    n_null: int = 200,
    n_jobs: int = 1,
    simulator: Callable[[pd.DataFrame, np.random.Generator], pd.DataFrame]
    | None = None,
    animal_col: str = "animal_id",
    epoch_col: str = "epoch",
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
) -> dict[str, pd.DataFrame]:
    """Null-correct the LOMO topology score under a fixed local policy.

    A custom ``simulator`` should rebuild full trajectories and their dynamic
    frontier features.  Without one, the function performs the weaker
    fixed-support local-policy null and labels it explicitly so it cannot be
    mistaken for the confirmatory full-trajectory gate.
    """

    observed = fit_topology_policy_score(
        rows,
        spec,
        animal_col=animal_col,
        epoch_col=epoch_col,
        decision_col=decision_col,
        chosen_col=chosen_col,
    )
    n_iterations = max(1, int(n_null))
    n_jobs = int(n_jobs)
    if n_jobs < 1:
        raise ValueError("n_jobs must be at least 1")
    master_rng = np.random.default_rng(int(spec.seed) + 901)
    iteration_seeds = master_rng.integers(
        0,
        np.iinfo(np.uint64).max,
        size=n_iterations,
        dtype=np.uint64,
    )
    null_type = (
        str(getattr(simulator, "null_type", "full_trajectory_local_policy"))
        if simulator is not None
        else "fixed_support_local_policy"
    )

    if simulator is None:
        # One local model per epoch generates probabilities for every row.
        probability_pieces: list[pd.DataFrame] = []
        for epoch, epoch_rows in rows.groupby(epoch_col, sort=True):
            local_fit = fit_conditional_logit(
                epoch_rows,
                spec.local_features,
                decision_col=decision_col,
                chosen_col=chosen_col,
                key_prefix=(animal_col, epoch_col),
                l2_penalty=spec.l2_penalty,
                max_iter=spec.max_iter,
                tolerance=spec.tolerance,
            )
            features = epoch_rows[list(local_fit.feature_names)].to_numpy(dtype=float)
            utilities = (
                features / local_fit.feature_scales[None, :]
            ) @ local_fit.coefficients
            temp = epoch_rows[
                [animal_col, epoch_col, decision_col, "alternative_id"]
            ].copy()
            temp["utility"] = utilities
            pieces: list[pd.DataFrame] = []
            for _, group in temp.groupby(
                [animal_col, epoch_col, decision_col], sort=False
            ):
                u = group["utility"].to_numpy(dtype=float)
                group = group.copy()
                group["choice_probability"] = np.exp(u - logsumexp(u))
                pieces.append(group.drop(columns="utility"))
            probability_pieces.append(pd.concat(pieces, ignore_index=True))
        probabilities = pd.concat(probability_pieces, ignore_index=True)

    def score_null_iteration(item: tuple[int, np.uint64]) -> pd.DataFrame:
        iteration, iteration_seed = item
        rng = np.random.default_rng(int(iteration_seed))
        simulated = (
            simulator(rows.copy(), rng)
            if simulator is not None
            else simulate_choices_from_probabilities(
                rows,
                probabilities,
                rng=rng,
                animal_col=animal_col,
                epoch_col=epoch_col,
                decision_col=decision_col,
                chosen_col=chosen_col,
            )
        )
        scored = fit_topology_policy_score(
            simulated,
            spec,
            animal_col=animal_col,
            epoch_col=epoch_col,
            decision_col=decision_col,
            chosen_col=chosen_col,
        )["per_animal_epoch"]
        if len(scored):
            scored = scored.copy()
            scored["null_iteration"] = int(iteration)
        return scored

    items = list(enumerate(iteration_seeds))
    if n_jobs == 1 or n_iterations == 1:
        results = [score_null_iteration(item) for item in items]
    else:
        # joblib is an optional extra; only the parallel path needs it.
        from joblib import Parallel, delayed

        workers = min(n_jobs, n_iterations)
        results = Parallel(
            n_jobs=workers,
            backend="loky",
            prefer="processes",
            batch_size=1,
        )(delayed(score_null_iteration)(item) for item in items)
    null_records = [table for table in results if len(table)]

    null_scores = (
        pd.concat(null_records, ignore_index=True) if null_records else pd.DataFrame()
    )
    corrected = observed["per_animal_epoch"].copy()
    if len(corrected) and len(null_scores):
        null_summary = null_scores.groupby([animal_col, epoch_col], as_index=False).agg(
            psi_null_mean=("psi_raw", "mean"),
            psi_null_sd=("psi_raw", "std"),
            n_null=("null_iteration", "nunique"),
        )
        corrected = corrected.merge(
            null_summary,
            on=[animal_col, epoch_col],
            how="left",
            validate="one_to_one",
        )
        corrected["psi"] = corrected["psi_raw"] - corrected["psi_null_mean"]
        corrected["null_type"] = null_type
    return {
        **observed,
        "null_scores": null_scores,
        "null_corrected": corrected,
    }


def make_full_trajectory_local_policy_simulator(
    observed_choices: pd.DataFrame,
    ma: Maze,
    policy_spec: TopologyPolicySpec,
    *,
    k: int,
    epoch_spec: RapidLearningEpochSpec = RapidLearningEpochSpec(),
) -> Callable[[pd.DataFrame, np.random.Generator], pd.DataFrame]:
    """Build a fixed-policy trajectory null for the topology-score gate.

    One context-specific *time-invariant* local policy is fit using all
    observed Day-1 choices.  Synthetic animals repeatedly traverse from the
    root to a terminal node under that fixed policy.  Terminal coverage and
    therefore frontier-feature availability accrue normally, but the policy
    itself cannot learn.  The generated decisions reuse each session's
    observed exposure times before the standard B/buffer/C assignment.

    This null is intentionally more demanding than resampling choices on the
    observed support: it asks whether the measured early-to-late topology
    gain can be generated mechanically as unexplored terminals disappear.
    """

    required = {
        "session_id",
        "animal_id",
        "cohort_group",
        "decision_id",
        "maze_seconds_start",
        "alternative_id",
        "chosen",
        *policy_spec.local_features,
    }
    missing = sorted(required.difference(observed_choices.columns))
    if missing:
        raise ValueError(f"missing full-trajectory null columns: {missing}")

    choices = observed_choices.copy()
    choice_rows = choices.drop_duplicates(["session_id", "decision_id"]).copy()
    context_models: dict[str, ConditionalChoiceFit] = {}
    for context, context_rows in choices.groupby("cohort_group", sort=True):
        fit = fit_conditional_logit(
            context_rows,
            policy_spec.local_features,
            l2_penalty=policy_spec.l2_penalty,
            max_iter=policy_spec.max_iter,
            tolerance=policy_spec.tolerance,
        )
        context_models[str(context)] = fit

    depths = np.full(len(ma.ru), -1, dtype=int)
    for node in range(len(ma.ru)):
        current = int(node)
        depth = 0
        while current > 0 and depth <= len(ma.ru):
            current = int(ma.pa[current])
            depth += 1
        depths[node] = depth
    terminal_start = 2 ** int(ma.le) - 1

    def _feature_value(
        name: str,
        *,
        alt_is_left: bool,
        seen: bool,
        visit_count: int,
        previous_side: str | None,
        depth: int,
    ) -> float:
        values = {
            "alt_is_left": float(alt_is_left),
            "alt_seen_before": float(seen),
            "alt_visit_count_log1p": float(np.log1p(visit_count)),
            "alt_matches_alternation": float(
                previous_side is not None
                and ("left" if alt_is_left else "right") != previous_side
            ),
            "alt_matches_perseveration": float(
                previous_side is not None
                and ("left" if alt_is_left else "right") == previous_side
            ),
            "alt_left_x_depth": float(alt_is_left * depth),
            "alt_left_x_speed": 0.0,
            "alt_left_x_dwell": 0.0,
        }
        if name not in values:
            raise ValueError(f"unsupported local feature in trajectory null: {name}")
        return values[name]

    session_specs: list[dict[str, Any]] = []
    for session_id, session in choice_rows.groupby("session_id", sort=False):
        session = session.sort_values("maze_seconds_start", kind="stable")
        session_specs.append(
            {
                "session_id": str(session_id),
                "animal_id": str(session.iloc[0]["animal_id"]),
                "cohort_group": str(session.iloc[0]["cohort_group"]),
                "times": pd.to_numeric(
                    session["maze_seconds_start"], errors="coerce"
                ).to_numpy(dtype=float),
            }
        )

    def simulator(
        _observed_epoch_rows: pd.DataFrame,
        rng: np.random.Generator,
    ) -> pd.DataFrame:
        transition_records: list[dict[str, Any]] = []
        for session in session_specs:
            local_model = context_models[session["cohort_group"]]
            run_visits: dict[int, int] = {}
            previous_side: str | None = None
            current = 0
            for decision_index, maze_seconds in enumerate(session["times"]):
                if not np.isfinite(maze_seconds):
                    continue
                if current >= terminal_start:
                    current = 0
                children = np.asarray(ma.ch[current], dtype=int).ravel()
                children = children[children >= 0]
                if children.size < 2:
                    current = 0
                    children = np.asarray(ma.ch[current], dtype=int).ravel()
                    children = children[children >= 0]
                utilities: list[float] = []
                for alt_index, alternative in enumerate(children.tolist()):
                    feature_vector = np.asarray(
                        [
                            _feature_value(
                                feature,
                                alt_is_left=alt_index == 0,
                                seen=int(alternative) in run_visits,
                                visit_count=run_visits.get(int(alternative), 0),
                                previous_side=previous_side,
                                depth=int(depths[current]),
                            )
                            for feature in policy_spec.local_features
                        ],
                        dtype=float,
                    )
                    utilities.append(
                        float(
                            (feature_vector / local_model.feature_scales)
                            @ local_model.coefficients
                        )
                    )
                utility = np.asarray(utilities, dtype=float)
                probability = np.exp(utility - logsumexp(utility))
                chosen_index = int(rng.choice(len(children), p=probability))
                nxt = int(children[chosen_index])
                previous_side = "left" if chosen_index == 0 else "right"
                run_visits[nxt] = run_visits.get(nxt, 0) + 1
                transition_records.append(
                    {
                        "session_id": session["session_id"],
                        "animal_id": session["animal_id"],
                        "cohort_group": session["cohort_group"],
                        "transition_id": f"null:{session['session_id']}:{decision_index}",
                        "transition_index_session": int(decision_index),
                        "abs_frame_start": float(maze_seconds) * 25.0,
                        "maze_seconds_start": float(maze_seconds),
                        "prev_node": -1 if current == 0 else int(ma.pa[current]),
                        "current_node": int(current),
                        "next_node": nxt,
                        "tree_depth": int(depths[current]),
                        "is_primary_decision": True,
                    }
                )
                current = nxt
        synthetic_transitions = pd.DataFrame(transition_records)
        synthetic_choices = build_topology_choice_table(synthetic_transitions, ma)
        assigned, audit = assign_structure_epochs(
            synthetic_choices,
            k=int(k),
            spec=epoch_spec,
        )
        if (audit.get("status", pd.Series(dtype=str)) != "ok").any():
            raise RuntimeError("trajectory null lost required B/C decision support")
        return assigned

    simulator.null_type = "full_trajectory_local_policy"  # type: ignore[attr-defined]
    return simulator


def make_observed_support_local_policy_simulator(
    observed_choices: pd.DataFrame,
    policy_spec: TopologyPolicySpec,
    *,
    null_type: str = "conditional_observed_support_local_policy_rescue",
    model_group_cols: Sequence[str] = ("cohort_group",),
    fallback_group_cols: Sequence[str] | None = None,
) -> Callable[[pd.DataFrame, np.random.Generator], pd.DataFrame]:
    """Return a time-invariant local-policy null on exact observed support.

    This is the named rescue when a generative tree-walk simulator cannot
    reproduce the observed depth/frontier exposure distribution.  It holds
    current node, alternatives, and dynamic topology-feature availability
    fixed, then resamples choices from one time-invariant local-only policy per
    requested model group, pooled across B and C.  The result tests whether
    feature availability on the realized trajectory can create an apparent
    B-to-C gain, but it does not generate counterfactual full trajectories.
    """

    required = {
        "animal_id",
        "decision_id",
        "alternative_id",
        "chosen",
        *policy_spec.local_features,
        *model_group_cols,
        *(fallback_group_cols or ()),
    }
    missing = sorted(required.difference(observed_choices.columns))
    if missing:
        raise ValueError(f"missing observed-support null columns: {missing}")
    model_group_cols = tuple(str(value) for value in model_group_cols)
    if not model_group_cols:
        raise ValueError("model_group_cols must not be empty")
    fallback_group_cols = (
        tuple(str(value) for value in fallback_group_cols)
        if fallback_group_cols
        else ()
    )

    def normalize_key(value: Any) -> tuple[str, ...]:
        values = value if isinstance(value, tuple) else (value,)
        return tuple(str(item) for item in values)

    def fit_group(rows: pd.DataFrame) -> ConditionalChoiceFit:
        return fit_conditional_logit(
            rows,
            policy_spec.local_features,
            l2_penalty=policy_spec.l2_penalty,
            max_iter=policy_spec.max_iter,
            tolerance=policy_spec.tolerance,
        )

    fallback_models: dict[tuple[str, ...], ConditionalChoiceFit] = {}
    fit_audit: list[dict[str, Any]] = []
    if fallback_group_cols:
        for key, group in observed_choices.groupby(
            list(fallback_group_cols), sort=True
        ):
            normalized = normalize_key(key)
            fit = fit_group(group)
            fallback_models[normalized] = fit
            fit_audit.append(
                {
                    "fit_role": "fallback",
                    "model_group_cols": "|".join(fallback_group_cols),
                    "model_group": "|".join(normalized),
                    "n_decisions": int(group["decision_id"].nunique()),
                    "converged": bool(fit.converged),
                    "model_source": "fallback_group_fit",
                    "message": str(fit.message),
                }
            )

    models: dict[tuple[str, ...], ConditionalChoiceFit] = {}
    for key, group in observed_choices.groupby(list(model_group_cols), sort=True):
        normalized = normalize_key(key)
        primary_fit: ConditionalChoiceFit | None = None
        failure = ""
        try:
            primary_fit = fit_group(group)
        except Exception as exc:  # pragma: no cover - guarded fallback path
            failure = f"{type(exc).__name__}:{exc}"
        use_fallback = primary_fit is None or not bool(primary_fit.converged)
        model_source = "primary_group_fit"
        if use_fallback and fallback_group_cols:
            fallback_key = tuple(str(group.iloc[0][col]) for col in fallback_group_cols)
            if fallback_key in fallback_models:
                primary_fit = fallback_models[fallback_key]
                model_source = "fallback_group_fit"
        if primary_fit is None:
            raise RuntimeError(
                f"exact-support null could not fit model group {normalized}: {failure}"
            )
        models[normalized] = primary_fit
        fit_audit.append(
            {
                "fit_role": "primary",
                "model_group_cols": "|".join(model_group_cols),
                "model_group": "|".join(normalized),
                "n_decisions": int(group["decision_id"].nunique()),
                "converged": bool(primary_fit.converged),
                "model_source": model_source,
                "message": failure or str(primary_fit.message),
            }
        )

    def simulator(rows: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
        probability_pieces: list[pd.DataFrame] = []
        for key, group in rows.groupby(list(model_group_cols), sort=True):
            model = models[normalize_key(key)]
            feature_values = group[list(model.feature_names)].to_numpy(dtype=float)
            utilities = (
                feature_values / model.feature_scales[None, :]
            ) @ model.coefficients
            table = group[
                ["animal_id", "epoch", "decision_id", "alternative_id"]
            ].copy()
            table["utility"] = utilities
            normalized = []
            for _, decision in table.groupby(
                ["animal_id", "epoch", "decision_id"], sort=False
            ):
                decision = decision.copy()
                utility = decision["utility"].to_numpy(dtype=float)
                decision["choice_probability"] = np.exp(utility - logsumexp(utility))
                normalized.append(decision.drop(columns="utility"))
            probability_pieces.append(pd.concat(normalized, ignore_index=True))
        probabilities = pd.concat(probability_pieces, ignore_index=True)
        return simulate_choices_from_probabilities(rows, probabilities, rng=rng)

    simulator.null_type = str(null_type)  # type: ignore[attr-defined]
    simulator.model_group_cols = model_group_cols  # type: ignore[attr-defined]
    simulator.fallback_group_cols = fallback_group_cols  # type: ignore[attr-defined]
    simulator.model_fit_audit = pd.DataFrame(fit_audit)  # type: ignore[attr-defined]
    return simulator


__all__ = [
    "ConditionalChoiceFit",
    "ALL_NEIGHBOR_GRAPH_POLICY_FEATURES",
    "ALL_NEIGHBOR_HISTORY_FEATURES",
    "ALL_NEIGHBOR_LOCAL_FEATURES",
    "ALL_NEIGHBOR_STATIC_GEOMETRY_FEATURES",
    "DEFAULT_LOCAL_FEATURES",
    "DEFAULT_TOPOLOGY_FEATURES",
    "RapidLearningEpochSpec",
    "TopologyPolicySpec",
    "assign_structure_epochs",
    "build_all_neighbor_topology_choice_table",
    "build_topology_choice_table",
    "choose_shared_structure_k",
    "fit_conditional_logit",
    "fit_topology_policy_score",
    "fixed_policy_null_correct",
    "make_full_trajectory_local_policy_simulator",
    "make_observed_support_local_policy_simulator",
    "score_conditional_logit",
    "simulate_choices_from_probabilities",
    "summarize_all_neighbor_local_policies",
    "validate_alternative_table",
]
