"""Conventional population-dynamics estimators for rapid-learning audits.

These estimators are deliberately separate from ELPC and from either
distance-to-criticality definition.  They operate on contiguous population-S
segments, never bridge gaps, and expose measurement reliability before any
behavioral association is interpreted.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence

import numpy as np
from scipy.optimize import least_squares


@dataclass(frozen=True)
class ConventionalDynamicsSpec:
    sample_interval_s: float = 0.04
    max_lag_frames: int = 50
    split_block_frames: int = 250
    min_lag_pairs: int = 100
    min_mr_positive_lags: int = 5
    min_mr_r2: float = 0.2


def coerce_segments(value: Any) -> list[np.ndarray]:
    """Convert a MATLAB cell/scalar export to finite one-dimensional segments."""

    array = np.asarray(value)
    if array.dtype != object:
        candidates: Iterable[Any] = [array]
    else:
        candidates = array.ravel()
    segments: list[np.ndarray] = []
    for candidate in candidates:
        values = np.asarray(candidate, dtype=float).ravel()
        if values.size == 0:
            continue
        finite = np.isfinite(values)
        if finite.all():
            segments.append(values)
            continue
        # Preserve gaps introduced by nonfinite values rather than joining them.
        starts = np.flatnonzero(finite & np.r_[True, ~finite[:-1]])
        stops = np.flatnonzero(finite & np.r_[~finite[1:], True]) + 1
        segments.extend(values[start:stop] for start, stop in zip(starts, stops))
    return [segment for segment in segments if segment.size]


def coerce_subset_segments(value: Any, n_subsets: int) -> list[list[np.ndarray]]:
    """Resolve the subset-by-segment MATLAB export without joining segments."""

    array = np.asarray(value, dtype=object)
    if array.ndim == 1 and array.size == int(n_subsets):
        return [coerce_segments(item) for item in array]
    if array.ndim >= 2 and array.shape[0] == int(n_subsets):
        return [coerce_segments(array[index, ...]) for index in range(n_subsets)]
    raise ValueError(
        f"subset export shape {array.shape} is incompatible with n_subsets={n_subsets}"
    )


def alternating_block_split_segments(
    segments: Sequence[np.ndarray], block_frames: int
) -> tuple[list[np.ndarray], list[np.ndarray]]:
    """Assign contiguous blocks alternately while retaining every block boundary."""

    if int(block_frames) < 2:
        raise ValueError("block_frames must be at least two")
    halves: tuple[list[np.ndarray], list[np.ndarray]] = ([], [])
    block_index = 0
    for segment in segments:
        values = np.asarray(segment, dtype=float).ravel()
        for start in range(0, values.size, int(block_frames)):
            block = values[start : start + int(block_frames)]
            if block.size >= 2:
                halves[block_index % 2].append(block)
            block_index += 1
    return halves


def merge_half_open_intervals(
    intervals: Sequence[tuple[int, int]],
) -> list[tuple[int, int]]:
    """Merge overlapping or exactly contiguous frame intervals."""

    cleaned = sorted(
        (int(start), int(stop)) for start, stop in intervals if int(stop) > int(start)
    )
    merged: list[list[int]] = []
    for start, stop in cleaned:
        if not merged or start > merged[-1][1]:
            merged.append([start, stop])
        else:
            merged[-1][1] = max(merged[-1][1], stop)
    return [(start, stop) for start, stop in merged]


def partition_intervals_by_exposure(
    intervals: Sequence[tuple[int, int]], window_frames: int
) -> list[list[tuple[int, int]]]:
    """Partition segment exposure into fixed complete windows without gap joins."""

    target = int(window_frames)
    if target < 2:
        raise ValueError("window_frames must be at least two")
    windows: list[list[tuple[int, int]]] = []
    current: list[tuple[int, int]] = []
    remaining = target
    for interval_start, interval_stop in merge_half_open_intervals(intervals):
        cursor = interval_start
        while cursor < interval_stop:
            take = min(remaining, interval_stop - cursor)
            current.append((cursor, cursor + take))
            cursor += take
            remaining -= take
            if remaining == 0:
                windows.append(current)
                current = []
                remaining = target
    return windows


def bin_segments(segments: Sequence[np.ndarray], bin_frames: int) -> list[np.ndarray]:
    """Sum nonoverlapping bins within each segment and discard short tails."""

    width = int(bin_frames)
    if width < 1:
        raise ValueError("bin_frames must be positive")
    result = []
    for segment in segments:
        values = np.asarray(segment, dtype=float).ravel()
        usable = (values.size // width) * width
        if usable < width:
            continue
        result.append(values[:usable].reshape(-1, width).sum(axis=1))
    return result


def _lag_pairs(
    segments: Sequence[np.ndarray], lag: int
) -> tuple[np.ndarray, np.ndarray]:
    left = []
    right = []
    for segment in segments:
        values = np.asarray(segment, dtype=float).ravel()
        if values.size <= int(lag):
            continue
        left.append(values[: -int(lag)])
        right.append(values[int(lag) :])
    if not left:
        return np.empty(0, dtype=float), np.empty(0, dtype=float)
    return np.concatenate(left), np.concatenate(right)


def lag_regression_coefficients(
    segments: Sequence[np.ndarray], max_lag_frames: int, min_lag_pairs: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return segment-safe lag slope, correlation, and pair count."""

    slopes = np.full(int(max_lag_frames), np.nan, dtype=float)
    correlations = np.full(int(max_lag_frames), np.nan, dtype=float)
    counts = np.zeros(int(max_lag_frames), dtype=int)
    for lag in range(1, int(max_lag_frames) + 1):
        x, y = _lag_pairs(segments, lag)
        counts[lag - 1] = int(x.size)
        if x.size < int(min_lag_pairs):
            continue
        x_centered = x - np.mean(x)
        y_centered = y - np.mean(y)
        x_ss = float(np.dot(x_centered, x_centered))
        y_ss = float(np.dot(y_centered, y_centered))
        if x_ss <= 0 or y_ss <= 0:
            continue
        cross = float(np.dot(x_centered, y_centered))
        slopes[lag - 1] = cross / x_ss
        correlations[lag - 1] = cross / np.sqrt(x_ss * y_ss)
    return slopes, correlations, counts


def estimate_population_dynamics(
    segments: Sequence[np.ndarray],
    spec: ConventionalDynamicsSpec = ConventionalDynamicsSpec(),
) -> dict[str, Any]:
    """Estimate lag-1, positive-ACF-area, and multistep timescales."""

    clean = [
        np.asarray(segment, dtype=float).ravel()
        for segment in segments
        if np.asarray(segment).size >= 2
    ]
    n_frames = int(sum(segment.size for segment in clean))
    if n_frames < int(spec.min_lag_pairs) + 1:
        return {"status": "insufficient_frames", "n_frames": n_frames}
    slopes, correlations, counts = lag_regression_coefficients(
        clean, spec.max_lag_frames, spec.min_lag_pairs
    )
    lag1 = float(slopes[0]) if slopes.size and np.isfinite(slopes[0]) else np.nan
    lag1_tau = (
        float(-spec.sample_interval_s / np.log(lag1))
        if np.isfinite(lag1) and 0 < lag1 < 1
        else np.nan
    )

    positive = []
    for value in correlations:
        if not np.isfinite(value) or value <= 0:
            break
        positive.append(float(value))
    acf_positive_area = float(spec.sample_interval_s * (0.5 + np.sum(positive)))

    valid = np.flatnonzero(np.isfinite(slopes) & (slopes > 0) & (slopes < 1))
    mr_tau = np.nan
    mr_m = np.nan
    mr_r2 = np.nan
    mr_n_lags = int(valid.size)
    # A branching-like exponential requires one contiguous positive decay.
    # Later isolated positive oscillatory lobes are retained in the lag audit
    # but are not cherry-picked into the exponential fit.
    initial_valid = []
    for index, value in enumerate(slopes):
        if not np.isfinite(value) or not 0 < value < 1:
            break
        initial_valid.append(index)
    valid = np.asarray(initial_valid, dtype=int)
    mr_n_lags = int(valid.size)
    if valid.size >= int(spec.min_mr_positive_lags):
        lag_values = valid.astype(float) + 1.0
        observed_slopes = slopes[valid]
        weights = np.sqrt(counts[valid].astype(float))

        def residual(parameter: np.ndarray) -> np.ndarray:
            amplitude, coefficient = parameter
            return weights * (
                observed_slopes - amplitude * np.power(coefficient, lag_values)
            )

        fitted = least_squares(
            residual,
            x0=np.array([min(1.5, max(1e-6, lag1 / max(lag1, 0.5))), lag1]),
            bounds=(np.array([1e-8, 1e-8]), np.array([2.0, 0.999999])),
            max_nfev=10_000,
        )
        amplitude, mr_m = (float(value) for value in fitted.x)
        prediction = amplitude * np.power(mr_m, lag_values)
        residual_ss = float(np.sum(weights**2 * (observed_slopes - prediction) ** 2))
        weighted_mean = float(np.average(observed_slopes, weights=weights**2))
        total_ss = float(np.sum(weights**2 * (observed_slopes - weighted_mean) ** 2))
        mr_r2 = 1.0 - residual_ss / total_ss if total_ss > 0 else np.nan
        if 0 < mr_m < 1 and np.isfinite(mr_r2) and mr_r2 >= spec.min_mr_r2:
            mr_tau = float(-spec.sample_interval_s / np.log(mr_m))

    return {
        "status": "ok",
        "n_frames": n_frames,
        "n_segments": int(len(clean)),
        "n_lag1_pairs": int(counts[0]),
        "population_mean": float(
            np.sum([np.sum(segment) for segment in clean]) / n_frames
        ),
        "population_variance": float(np.var(np.concatenate(clean))),
        "lag1_slope": lag1,
        "lag1_tau_s": lag1_tau,
        "acf_positive_area_s": acf_positive_area,
        "acf_positive_lags": int(len(positive)),
        "mr_branching_m": mr_m,
        "mr_tau_s": mr_tau,
        "mr_log_slope_r2": mr_r2,
        "mr_n_positive_lags": mr_n_lags,
    }


def spearman_brown(rho: float) -> float:
    """Two-half Spearman-Brown correction with finite-boundary handling."""

    if not np.isfinite(rho) or rho <= -1:
        return np.nan
    return float((2.0 * rho) / (1.0 + rho))


def fit_logistic_irls(
    design: np.ndarray,
    outcome: Sequence[float],
    *,
    ridge: float = 1e-6,
    max_iterations: int = 100,
    tolerance: float = 1e-9,
) -> dict[str, Any]:
    """Fit a small audited logistic model without row-independence inference.

    The helper returns coefficients and fitted probabilities only.  Rapid-
    learning inference is performed by permuting animal-level predictors or
    block-resampling whole animals, never by treating decisions as independent.
    """

    x = np.asarray(design, dtype=float)
    y = np.asarray(outcome, dtype=float).ravel()
    if x.ndim != 2 or y.ndim != 1 or x.shape[0] != y.size:
        raise ValueError("design/outcome shapes are incompatible")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("design and outcome must be finite")
    if not np.all(np.isin(y, [0.0, 1.0])):
        raise ValueError("outcome must be binary")
    penalty = np.eye(x.shape[1], dtype=float) * float(ridge)
    penalty[0, 0] = 0.0
    coefficient = np.zeros(x.shape[1], dtype=float)
    converged = False
    for iteration in range(1, int(max_iterations) + 1):
        linear = np.clip(x @ coefficient, -35.0, 35.0)
        probability = 1.0 / (1.0 + np.exp(-linear))
        weight = np.clip(probability * (1.0 - probability), 1e-8, None)
        gradient = x.T @ (y - probability) - penalty @ coefficient
        hessian = (x.T * weight) @ x + penalty
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        coefficient += step
        if float(np.max(np.abs(step))) <= float(tolerance):
            converged = True
            break
    linear = np.clip(x @ coefficient, -35.0, 35.0)
    probability = 1.0 / (1.0 + np.exp(-linear))
    return {
        "coefficient": coefficient,
        "probability": probability,
        "converged": converged,
        "n_iterations": iteration,
    }


def binary_log_loss(outcome: Sequence[float], probability: Sequence[float]) -> float:
    """Mean binary log loss with deterministic clipping."""

    y = np.asarray(outcome, dtype=float).ravel()
    p = np.asarray(probability, dtype=float).ravel()
    if y.shape != p.shape or not np.all(np.isin(y, [0.0, 1.0])):
        raise ValueError("outcome and probability must be equal-length binary vectors")
    p = np.clip(p, 1e-12, 1.0 - 1e-12)
    return float(-np.mean(y * np.log(p) + (1.0 - y) * np.log(1.0 - p)))


def fit_binomial_irls(
    design: np.ndarray,
    successes: Sequence[float],
    trials: Sequence[float],
    *,
    ridge: float = 1e-6,
    max_iterations: int = 100,
    tolerance: float = 1e-9,
) -> dict[str, Any]:
    """Fit grouped binomial observations with the same audited IRLS core."""

    x = np.asarray(design, dtype=float)
    success = np.asarray(successes, dtype=float).ravel()
    total = np.asarray(trials, dtype=float).ravel()
    if x.ndim != 2 or x.shape[0] != success.size or success.shape != total.shape:
        raise ValueError("design/success/trial shapes are incompatible")
    if (
        not np.all(np.isfinite(x))
        or not np.all(np.isfinite(success))
        or not np.all(np.isfinite(total))
        or np.any(total <= 0)
        or np.any(success < 0)
        or np.any(success > total)
    ):
        raise ValueError("grouped binomial inputs are invalid")
    penalty = np.eye(x.shape[1], dtype=float) * float(ridge)
    penalty[0, 0] = 0.0
    coefficient = np.zeros(x.shape[1], dtype=float)
    converged = False
    for iteration in range(1, int(max_iterations) + 1):
        linear = np.clip(x @ coefficient, -35.0, 35.0)
        probability = 1.0 / (1.0 + np.exp(-linear))
        weight = np.clip(total * probability * (1.0 - probability), 1e-8, None)
        gradient = x.T @ (success - total * probability) - penalty @ coefficient
        hessian = (x.T * weight) @ x + penalty
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        coefficient += step
        if float(np.max(np.abs(step))) <= float(tolerance):
            converged = True
            break
    linear = np.clip(x @ coefficient, -35.0, 35.0)
    probability = 1.0 / (1.0 + np.exp(-linear))
    return {
        "coefficient": coefficient,
        "probability": probability,
        "converged": converged,
        "n_iterations": iteration,
    }


def grouped_binomial_log_loss(
    successes: Sequence[float], trials: Sequence[float], probability: Sequence[float]
) -> float:
    """Per-trial log loss for grouped binomial observations."""

    success = np.asarray(successes, dtype=float).ravel()
    total = np.asarray(trials, dtype=float).ravel()
    p = np.clip(np.asarray(probability, dtype=float).ravel(), 1e-12, 1.0 - 1e-12)
    if success.shape != total.shape or success.shape != p.shape or np.any(total <= 0):
        raise ValueError("grouped arrays must have equal shape and positive trials")
    loss = -(success * np.log(p) + (total - success) * np.log(1.0 - p))
    return float(np.sum(loss) / np.sum(total))


def participation_ratio(
    activity: np.ndarray, *, correlation: bool = True
) -> dict[str, float | int]:
    """Effective dimensionality of a time-by-cell activity matrix."""

    values = np.asarray(activity, dtype=float)
    if values.ndim != 2 or values.shape[0] < 3 or values.shape[1] < 2:
        raise ValueError("activity must be a time-by-cell matrix")
    values = values - np.mean(values, axis=0, keepdims=True)
    variance = np.var(values, axis=0, ddof=1)
    keep = np.isfinite(variance) & (variance > 0)
    values = values[:, keep]
    if values.shape[1] < 2:
        raise ValueError("fewer than two variable cells remain")
    if correlation:
        values = values / np.std(values, axis=0, ddof=1, keepdims=True)
    singular = np.linalg.svd(values, compute_uv=False, full_matrices=False)
    eigenvalues = np.square(singular) / max(1, values.shape[0] - 1)
    total = float(np.sum(eigenvalues))
    squared = float(np.sum(np.square(eigenvalues)))
    dimension = total**2 / squared if squared > 0 else np.nan
    return {
        "n_time_bins": int(values.shape[0]),
        "n_variable_cells": int(values.shape[1]),
        "participation_ratio": float(dimension),
        "normalized_participation_ratio": float(dimension / values.shape[1]),
    }


def segment_transition_pairs(
    segments: Sequence[np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    """Return one-step pairs without ever crossing a segment boundary."""

    left = []
    right = []
    for segment in segments:
        values = np.asarray(segment, dtype=float)
        if values.ndim != 2:
            raise ValueError("latent segments must be two-dimensional")
        if values.shape[0] < 2:
            continue
        left.append(values[:-1])
        right.append(values[1:])
    if not left:
        n_features = int(np.asarray(segments[0]).shape[1]) if segments else 0
        return np.empty((0, n_features)), np.empty((0, n_features))
    return np.vstack(left), np.vstack(right)


def fit_ridge_var(
    train_segments: Sequence[np.ndarray],
    test_segments: Sequence[np.ndarray],
    *,
    alpha: float,
) -> dict[str, Any]:
    """Fit a ridge VAR(1) and evaluate held-out one-step prediction."""

    train_x, train_y = segment_transition_pairs(train_segments)
    test_x, test_y = segment_transition_pairs(test_segments)
    if train_x.shape[0] < train_x.shape[1] + 2 or test_x.shape[0] < 2:
        return {"status": "insufficient_transition_pairs"}
    gram = train_x.T @ train_x + float(alpha) * np.eye(train_x.shape[1])
    coefficient = np.linalg.solve(gram, train_x.T @ train_y)
    prediction = test_x @ coefficient
    residual_ss = float(np.sum(np.square(test_y - prediction)))
    baseline_ss = float(np.sum(np.square(test_y)))
    heldout_r2 = 1.0 - residual_ss / baseline_ss if baseline_ss > 0 else np.nan
    eigenvalues = np.linalg.eigvals(coefficient.T)
    return {
        "status": "ok",
        "n_train_pairs": int(train_x.shape[0]),
        "n_test_pairs": int(test_x.shape[0]),
        "spectral_radius": float(np.max(np.abs(eigenvalues))),
        "heldout_r2_zero_baseline": heldout_r2,
        "eigenvalues_real": np.real(eigenvalues),
        "eigenvalues_imag": np.imag(eigenvalues),
    }


__all__ = [
    "ConventionalDynamicsSpec",
    "alternating_block_split_segments",
    "coerce_segments",
    "coerce_subset_segments",
    "bin_segments",
    "binary_log_loss",
    "estimate_population_dynamics",
    "fit_logistic_irls",
    "fit_binomial_irls",
    "fit_ridge_var",
    "grouped_binomial_log_loss",
    "lag_regression_coefficients",
    "merge_half_open_intervals",
    "partition_intervals_by_exposure",
    "participation_ratio",
    "segment_transition_pairs",
    "spearman_brown",
]
