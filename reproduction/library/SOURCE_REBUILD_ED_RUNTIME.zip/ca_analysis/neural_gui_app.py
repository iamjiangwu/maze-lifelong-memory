from __future__ import annotations

# Auto-migrated local copy from legacy source.
# This module is self-contained within the repository.

# neural_gui.py
# PyQt5 + pyqtgraph GUI for calcium + behavior + maze/trajectory panels
#
# Panels:
#   - Map: rate/firing/occupancy maps with smoothing, occupancy overlay alpha, traj overlay options, chunking
#   - Footprints: max projection + current neuron overlay, clickable jump-to-neuron
#   - ArrowMap (matplotlib): spike-triggered arrows + maze walls using MM_* utilities
#   - Trajectory Fig5 (matplotlib): cumulative paths/rewards plot from your snippet (MM_Traj_Utils)
#   - Video: placeholder synthetic video synced to time slider (real AVI hook provided)
#   - Bottom traces: overview + region zoom + detail trace + speed/head_dir (linked x-axis)
#
# Notes:
#   - Keypoints CSV expected columns: frame,x,y,mass_x,mass_y,(optional) bout,speed,dist,head_dir,head_cat
#   - Trajectory TF loaded via LoadTraj(nickname+'-tf') which reads outdata/<filename> (repo behavior)
#   - Calcium bundle: synthetic by default; MAT loader stub included (expects A,S,C,C_raw)

import sys
import os
import math
import re
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Any, Dict, Tuple, List

import numpy as np

from PyQt5 import QtCore, QtWidgets
import pyqtgraph as pg

# PyQt5 compat
if not hasattr(QtCore, "Signal"):
    QtCore.Signal = QtCore.pyqtSignal
if not hasattr(QtCore, "Slot"):
    QtCore.Slot = QtCore.pyqtSlot

# Optional deps
try:
    import pandas as pd
    HAVE_PANDAS = True
except Exception:
    HAVE_PANDAS = False

try:
    import cv2
    HAVE_CV2 = True
except Exception:
    HAVE_CV2 = False

try:
    import matplotlib
    matplotlib.use("Qt5Agg")
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False

try:
    from scipy.io import loadmat
    HAVE_LOADMAT = True
except Exception:
    HAVE_LOADMAT = False

try:
    from scipy.ndimage import gaussian_filter
    HAVE_GAUSS = True
except Exception:
    HAVE_GAUSS = False


# ----------------------------
# Data models
# ----------------------------
@dataclass
class CalciumBundle:
    A: np.ndarray      # (H,W,N)
    S: np.ndarray      # (T,N)
    C: np.ndarray      # (T,N)
    C_raw: np.ndarray  # (T,N)
    fs: float          # Hz


@dataclass
class KeypointsBundle:
    df: "pd.DataFrame"
    # aligned arrays length T (index = absolute frame)
    nose_xy: np.ndarray   # (T,2) in [0,1]
    body_xy: np.ndarray   # (T,2) in [0,1]
    speed: np.ndarray     # (T,)
    head_dir: np.ndarray  # (T,)
    bout: Optional[np.ndarray] = None  # (T,) float/int with NaNs where unknown


@dataclass
class DataBundle:
    calcium: CalciumBundle
    keypoints: Optional[KeypointsBundle] = None
    traj_obj: Optional[Any] = None   # optional directly-loaded object
    traj_nickname: Optional[str] = None
    traj_base_dir: Optional[str] = None
    video_path: Optional[str] = None


# ----------------------------
# Utils
# ----------------------------
def make_tint_alpha_lut(rgb=(80, 160, 255), n=256) -> np.ndarray:
    """
    Constant RGB tint; alpha ramps 0..255.
    Use with ImageItem where the image values index alpha.
    """
    lut = np.zeros((n, 4), dtype=np.ubyte)
    lut[:, 0] = np.uint8(rgb[0])
    lut[:, 1] = np.uint8(rgb[1])
    lut[:, 2] = np.uint8(rgb[2])
    lut[:, 3] = np.arange(n, dtype=np.ubyte)
    return lut

def nan_break_polyline(xs: np.ndarray, ys: np.ndarray, frames: np.ndarray, gap_frames: int = 50):
    """
    Insert NaNs between segments whenever frame-to-frame gap > gap_frames.
    This prevents drawing straight lines across gaps.
    """
    xs = np.asarray(xs)
    ys = np.asarray(ys)
    frames = np.asarray(frames)

    if xs.size == 0:
        return xs, ys
    if frames.size < 2 or gap_frames <= 0:
        return xs, ys

    d = np.diff(frames.astype(np.int64))
    breaks = np.where(d > int(gap_frames))[0]
    if breaks.size == 0:
        return xs, ys

    outx = []
    outy = []
    start = 0
    for b in breaks:
        end = b + 1
        outx.append(xs[start:end])
        outy.append(ys[start:end])
        outx.append(np.array([np.nan], dtype=xs.dtype))
        outy.append(np.array([np.nan], dtype=ys.dtype))
        start = end
    outx.append(xs[start:])
    outy.append(ys[start:])
    return np.concatenate(outx), np.concatenate(outy)

def robust_sigma(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 10:
        sd = float(np.nanstd(x)) if x.size else 1.0
        return sd if sd > 1e-12 else 1.0
    med = np.median(x)
    mad = np.median(np.abs(x - med))
    if mad < 1e-12:
        sd = float(np.std(x))
        return sd if sd > 1e-12 else 1.0
    return float(1.4826 * mad)

def detect_events_S_vs_Craw(S_col: np.ndarray, C_raw_col: np.ndarray,
                           std_mult: float = 5.0, thin_frames: int = 4) -> np.ndarray:
    sn = robust_sigma(C_raw_col)
    thr = float(std_mult) * sn
    sp = np.where(np.isfinite(S_col) & (S_col > thr))[0]
    if sp.size == 0 or thin_frames <= 0:
        return sp.astype(int)
    keep = [int(sp[0])]
    last = int(sp[0])
    for t in sp[1:]:
        t = int(t)
        if t - last >= thin_frames:
            keep.append(t)
            last = t
    return np.array(keep, dtype=int)

def downsample_minmax(t: np.ndarray, y: np.ndarray, max_points: int = 8000):
    n = len(y)
    if n <= max_points:
        return t, y
    k = int(np.ceil(n / max_points))
    m = (n // k) * k
    yt = y[:m].reshape(-1, k)
    tt = t[:m].reshape(-1, k)
    y_min = np.nanmin(yt, axis=1)
    y_max = np.nanmax(yt, axis=1)
    t_mid = np.nanmean(tt, axis=1)
    t2 = np.repeat(t_mid, 2).astype(np.float32)
    y2 = np.empty_like(t2, dtype=np.float32)
    y2[0::2] = y_min
    y2[1::2] = y_max
    return t2, y2

def segment_by_frame_gaps(frames: np.ndarray, gap_frames: int) -> List[Tuple[int,int]]:
    if frames.size < 2:
        return [(0, frames.size - 1)]
    if gap_frames <= 0:
        return [(0, frames.size - 1)]
    bounds = []
    start = 0
    for i in range(1, frames.size):
        if frames[i] - frames[i-1] > gap_frames:
            if i - 1 > start:
                bounds.append((start, i - 1))
            start = i
    if frames.size - 1 > start:
        bounds.append((start, frames.size - 1))
    return bounds

def scale_to_maze_xy(xy01: np.ndarray, scale: float = 15.0, yflip: bool = True, offset: float = -0.5):
    x = xy01[:, 0].astype(np.float32, copy=False)
    y = xy01[:, 1].astype(np.float32, copy=False)
    xs = x * scale + offset
    ys = ((1.0 - y) if yflip else y) * scale + offset
    return xs, ys

def gaussian_blur2d(a: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0:
        return a
    if HAVE_GAUSS:
        return gaussian_filter(a, sigma=float(sigma), mode="nearest")
    # fallback: tiny manual separable (OK for small maps)
    s = float(sigma)
    r = int(max(1, round(3*s)))
    x = np.arange(-r, r+1, dtype=np.float32)
    k = np.exp(-(x*x)/(2*s*s)).astype(np.float32)
    k /= (k.sum() + 1e-9)

    # convolve rows
    tmp = np.pad(a, ((r,r),(0,0)), mode="edge")
    out = np.empty_like(a, dtype=np.float32)
    for i in range(a.shape[0]):
        out[i,:] = (tmp[i:i+2*r+1,:] * k[:,None]).sum(axis=0)

    # convolve cols
    tmp2 = np.pad(out, ((0,0),(r,r)), mode="edge")
    out2 = np.empty_like(out, dtype=np.float32)
    for j in range(out.shape[1]):
        out2[:,j] = (tmp2[:,j:j+2*r+1] * k[None,:]).sum(axis=1)
    return out2

def compute_bincount_maps(xs: np.ndarray, ys: np.ndarray, w: Optional[np.ndarray],
                          nx: int, xmin: float, xmax: float, ymin: float, ymax: float):
    """
    Fast 2D binning with bincount. Returns occ, act (both shape (nx,nx)).
    xs,ys are in maze coords.
    """
    xs = xs.astype(np.float32, copy=False)
    ys = ys.astype(np.float32, copy=False)
    ok = np.isfinite(xs) & np.isfinite(ys)
    if w is not None:
        ok = ok & np.isfinite(w)
    if ok.sum() < 10:
        z = np.zeros((nx, nx), dtype=np.float32)
        return z, z

    x = xs[ok]; y = ys[ok]
    dx = (xmax - xmin) / nx
    dy = (ymax - ymin) / nx
    bx = np.floor((x - xmin) / dx).astype(np.int32)
    by = np.floor((y - ymin) / dy).astype(np.int32)
    inb = (bx >= 0) & (bx < nx) & (by >= 0) & (by < nx)
    bx = bx[inb]; by = by[inb]
    if bx.size == 0:
        z = np.zeros((nx, nx), dtype=np.float32)
        return z, z
    idx = bx + by * nx
    occ = np.bincount(idx, minlength=nx*nx).astype(np.float32).reshape(nx, nx)
    if w is None:
        act = np.zeros_like(occ)
    else:
        ww = w[ok][inb].astype(np.float32, copy=False)
        act = np.bincount(idx, weights=ww, minlength=nx*nx).astype(np.float32).reshape(nx, nx)
    return occ, act


# ----------------------------
# Loading
# ----------------------------
def load_keypoints_csv(csv_path: str, T: int) -> KeypointsBundle:
    if not HAVE_PANDAS:
        raise RuntimeError("pandas is required to load keypoints CSV: pip install pandas")

    df = pd.read_csv(csv_path)
    for c in ["frame", "x", "y", "mass_x", "mass_y"]:
        if c not in df.columns:
            raise ValueError(f"CSV missing column: {c}")

    df = df.sort_values("frame").reset_index(drop=True)
    fr = df["frame"].to_numpy(dtype=int)

    nose_xy = np.full((T,2), np.nan, dtype=np.float32)
    body_xy = np.full((T,2), np.nan, dtype=np.float32)
    speed = np.full((T,), np.nan, dtype=np.float32)
    head_dir = np.full((T,), np.nan, dtype=np.float32)
    bout = np.full((T,), np.nan, dtype=np.float32) if ("bout" in df.columns) else None

    valid = (fr >= 0) & (fr < T)
    frv = fr[valid]

    nose_xy[frv,0] = df.loc[valid, "x"].to_numpy(dtype=np.float32)
    nose_xy[frv,1] = df.loc[valid, "y"].to_numpy(dtype=np.float32)
    body_xy[frv,0] = df.loc[valid, "mass_x"].to_numpy(dtype=np.float32)
    body_xy[frv,1] = df.loc[valid, "mass_y"].to_numpy(dtype=np.float32)

    if "speed" in df.columns:
        speed[frv] = df.loc[valid, "speed"].to_numpy(dtype=np.float32)
    if "head_dir" in df.columns:
        head_dir[frv] = df.loc[valid, "head_dir"].to_numpy(dtype=np.float32)
    if bout is not None:
        bout[frv] = df.loc[valid, "bout"].to_numpy(dtype=np.float32)

    return KeypointsBundle(df=df, nose_xy=nose_xy, body_xy=body_xy, speed=speed, head_dir=head_dir, bout=bout)

def load_calcium_mat(mat_path: str, fs_default: float = 25.0) -> CalciumBundle:
    """
    Loads MATLAB .mat calcium bundle.
    - Tries v7.3 (HDF5) via h5py first
    - Falls back to <=v7.2 via scipy.io.loadmat

    Expected vars: A, S, C, C_raw (numeric arrays)
      A: (H,W,N) footprints
      S/C/C_raw: (T,N) or (N,T)
    """
    import numpy as np

    def _to_TN(x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=np.float32)
        if x.ndim != 2:
            raise ValueError(f"Trace must be 2D, got shape {x.shape}")
        # time is usually longer than neuron count
        return x if x.shape[0] >= x.shape[1] else x.T

    def _fix_h5_axes(arr: np.ndarray) -> np.ndarray:
        # MATLAB v7.3 arrays often appear transposed/reversed in h5py
        arr = np.asarray(arr)
        if arr.ndim >= 2:
            arr = np.transpose(arr, tuple(reversed(range(arr.ndim))))
        return arr

    # ---- Try HDF5 (MAT v7.3) first ----
    have_h5py = True
    try:
        import h5py
    except Exception:
        have_h5py = False

    if have_h5py:
        try:
            def _get_any(f: "h5py.File", name: str):
                if name in f:
                    return f[name]
                # shallow search under top-level groups
                for k in f.keys():
                    g = f[k]
                    if hasattr(g, "keys") and name in g:
                        return g[name]
                raise KeyError(f"Could not find variable '{name}' in file keys={list(f.keys())}")

            with h5py.File(mat_path, "r") as f:
                A = _fix_h5_axes(_get_any(f, "A")[()])
                S = _fix_h5_axes(_get_any(f, "S")[()])
                C = _fix_h5_axes(_get_any(f, "C")[()])
                C_raw = _fix_h5_axes(_get_any(f, "C_raw")[()])

                fs = fs_default
                if "fs" in f:
                    try:
                        fs = float(np.array(f["fs"][()]).squeeze())
                    except Exception:
                        fs = fs_default

            A = np.asarray(A, dtype=np.float32)
            S = _to_TN(S)
            C = _to_TN(C)
            C_raw = _to_TN(C_raw)

            if A.ndim != 3:
                raise ValueError(f"A must be 3D (H,W,N). Got {A.shape}")

            # Ensure A matches neuron count
            if A.shape[2] != S.shape[1]:
                if A.shape[0] == S.shape[1]:
                    A = np.transpose(A, (1, 2, 0))  # (N,H,W)->(H,W,N)
                elif A.shape[1] == S.shape[1]:
                    A = np.transpose(A, (0, 2, 1))  # (H,N,W)->(H,W,N)

            return CalciumBundle(A=A, S=S, C=C, C_raw=C_raw, fs=float(fs))

        except OSError:
            # Not an HDF5 file -> fall through to scipy
            pass
        except Exception:
            # For HDF5 parsing errors, do not mask the underlying issue.
            raise

    # ---- Fallback: older MAT via scipy ----
    if not HAVE_LOADMAT:
        raise RuntimeError("scipy is required to load .mat files without h5py support (pip install scipy)")

    from scipy.io import loadmat
    try:
        md = loadmat(mat_path)
    except Exception as e:
        if not have_h5py:
            raise RuntimeError("Failed to load .mat; install h5py for MATLAB v7.3 files.") from e
        raise

    A = md.get("A", None)
    S = md.get("S", None)
    C = md.get("C", None)
    C_raw = md.get("C_raw", None)
    fs = float(md.get("fs", fs_default)) if "fs" in md else fs_default
    if A is None or S is None or C is None or C_raw is None:
        raise ValueError("MAT missing one of: A, S, C, C_raw")

    A = np.asarray(A, dtype=np.float32)
    S = _to_TN(S)
    C = _to_TN(C)
    C_raw = _to_TN(C_raw)

    if A.ndim != 3:
        raise ValueError(f"A must be 3D (H,W,N). Got {A.shape}")
    if A.shape[2] != S.shape[1] and A.shape[0] == S.shape[1]:
        A = np.transpose(A, (1, 2, 0))

    return CalciumBundle(A=A, S=S, C=C, C_raw=C_raw, fs=float(fs))

# ----------------------------
# Synthetic demo
# ----------------------------
def make_synth_calcium(H=128, W=128, N=140, T=60*12*25, fs=25.0, seed=0) -> CalciumBundle:
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:H, 0:W]
    A = np.zeros((H, W, N), dtype=np.float32)
    for n in range(N):
        cx = rng.uniform(0.1*W, 0.9*W)
        cy = rng.uniform(0.1*H, 0.9*H)
        sx = rng.uniform(3, 9)
        sy = rng.uniform(3, 9)
        amp = rng.uniform(0.5, 1.2)
        blob = amp*np.exp(-((xx-cx)**2/(2*sx*sx) + (yy-cy)**2/(2*sy*sy))).astype(np.float32)
        blob[blob < 0.05] = 0
        A[..., n] = blob

    gap_mask = np.zeros(T, dtype=bool)
    for _ in range(10):
        st = int(rng.integers(0, T-500))
        L = int(rng.integers(200, 900))
        gap_mask[st:st+L] = True

    S = (rng.random((T, N)) < 0.0018).astype(np.float32) * rng.uniform(2, 9, size=(T, N)).astype(np.float32)
    tau = int(max(4, round(0.8*fs)))
    k = np.exp(-np.arange(0, 6*tau)/tau).astype(np.float32)
    k /= (k.sum() + 1e-9)
    C = np.zeros((T, N), dtype=np.float32)
    for n in range(N):
        C[:, n] = np.convolve(S[:, n], k, mode="same").astype(np.float32)
    drift = (0.12*np.sin(np.linspace(0, 10*np.pi, T))).astype(np.float32)[:, None]
    C_raw = C + drift + 0.05*rng.standard_normal((T, N)).astype(np.float32)

    for arr in (S, C, C_raw):
        arr[gap_mask, :] = np.nan

    return CalciumBundle(A=A, S=S, C=C, C_raw=C_raw, fs=float(fs))

def make_synth_keypoints(T: int, gap_mask: np.ndarray, seed=1) -> KeypointsBundle:
    if not HAVE_PANDAS:
        raise RuntimeError("pandas required for synthetic keypoints demo")
    rng = np.random.default_rng(seed)
    frames = np.where(~gap_mask)[0].astype(int)

    xy = np.cumsum(rng.normal(0, 0.01, size=(frames.size, 2)), axis=0)
    xy = (xy - xy.min(axis=0)) / (xy.ptp(axis=0) + 1e-9)
    body = np.clip(xy, 0, 1).astype(np.float32)

    hd = np.mod(np.cumsum(rng.normal(0, 0.03, size=frames.size)), 2*np.pi).astype(np.float32)
    nose = np.clip(body + np.stack([0.02*np.cos(hd), 0.02*np.sin(hd)], axis=1), 0, 1).astype(np.float32)

    bout_id = (frames // (25*90)).astype(int)  # fake bouts
    df = pd.DataFrame({
        "frame": frames,
        "x": nose[:,0], "y": nose[:,1],
        "mass_x": body[:,0], "mass_y": body[:,1],
        "head_dir": hd,
        "bout": bout_id
    })

    nose_xy = np.full((T,2), np.nan, np.float32)
    body_xy = np.full((T,2), np.nan, np.float32)
    nose_xy[frames] = nose
    body_xy[frames] = body

    speed = np.full((T,), np.nan, np.float32)
    # simple speed on body
    ok = np.isfinite(body_xy[:,0]) & np.isfinite(body_xy[:,1])
    dx = np.zeros(T, np.float32); dy = np.zeros(T, np.float32)
    ok2 = ok[1:] & ok[:-1]
    dx[1:][ok2] = body_xy[1:,0][ok2] - body_xy[:-1,0][ok2]
    dy[1:][ok2] = body_xy[1:,1][ok2] - body_xy[:-1,1][ok2]
    dist = np.sqrt(dx*dx + dy*dy)
    speed[ok] = dist[ok] * 25.0

    head_dir = np.full((T,), np.nan, np.float32); head_dir[frames] = hd
    bout = np.full((T,), np.nan, np.float32); bout[frames] = bout_id.astype(np.float32)

    return KeypointsBundle(df=df, nose_xy=nose_xy, body_xy=body_xy, speed=speed, head_dir=head_dir, bout=bout)


# ----------------------------
# Workers
# ----------------------------
class WorkerSignals(QtCore.QObject):
    fp_ready = QtCore.Signal(object)               # {maxval,argmax,p99}
    map_ready = QtCore.Signal(int, object)         # request_id, result dict
    error = QtCore.Signal(str)


class FPWorker(QtCore.QRunnable):
    def __init__(self, A: np.ndarray, signals: WorkerSignals):
        super().__init__()
        self.A = A
        self.signals = signals

    @QtCore.Slot()
    def run(self):
        try:
            A = self.A
            maxval = np.max(A, axis=2).astype(np.float32)
            argmax = np.argmax(A, axis=2).astype(np.int32)
            p99 = float(np.percentile(maxval[maxval > 0], 99)) if np.any(maxval > 0) else 1.0
            self.signals.fp_ready.emit({"maxval": maxval, "argmax": argmax, "p99": max(p99, 1e-6)})
        except Exception as e:
            self.signals.error.emit(f"FPWorker failed: {type(e).__name__}: {e}")


class MapWorker(QtCore.QRunnable):
    def __init__(self, request_id: int, fn, signals: WorkerSignals):
        super().__init__()
        self.request_id = request_id
        self.fn = fn
        self.signals = signals

    @QtCore.Slot()
    def run(self):
        try:
            res = self.fn()
        except Exception as e:
            self.signals.error.emit(f"MapWorker failed: {type(e).__name__}: {e}")
            return
        self.signals.map_ready.emit(self.request_id, res)


# ----------------------------
# Matplotlib widgets
# ----------------------------
class MplCanvasWidget(QtWidgets.QWidget):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self.setLayout(QtWidgets.QVBoxLayout())
        self.layout().setContentsMargins(0,0,0,0)

        if not HAVE_MPL:
            lab = QtWidgets.QLabel("matplotlib not installed; this panel is disabled.\nInstall: pip install matplotlib")
            lab.setWordWrap(True)
            self.layout().addWidget(lab)
            self.canvas = None
            self.fig = None
            self.ax = None
            return

        self.fig = Figure(figsize=(6,6), dpi=100)
        self.canvas = FigureCanvas(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title(title, fontsize=10)
        self.layout().addWidget(self.canvas)

    def clear(self):
        if self.canvas is None:
            return
        self.fig.clf()
        self.ax = self.fig.add_subplot(111)
        self.canvas.draw_idle()


class ArrowMapWidget(MplCanvasWidget):
    def __init__(self, parent=None):
        super().__init__(title="ArrowMap", parent=parent)

    def render(self, selected_df, C_raw: np.ndarray, S: np.ndarray, nid: int,
            thin_frames: int, std_mult: float,
            show_traj: bool, traj_source: str,
            traj_gap_frames: int, traj_alpha: float, traj_lw: float,
            arrow_color: str = "blue"):
        if self.canvas is None:
            return

        ax = self.ax
        ax.clear()
        ax.set_aspect("equal")
        ax.axis("off")

        # events
        sp = detect_events_S_vs_Craw(
            S[:, nid], C_raw[:, nid],
            std_mult=std_mult, thin_frames=thin_frames
        )

        temp_df = selected_df.loc[selected_df["frame"].isin(sp)].copy()
        temp_df = temp_df.sort_values("frame")
        d = temp_df["frame"].diff()
        temp_df = temp_df.drop(temp_df[(d < thin_frames) & (d > 0)].index)

        pos_sp = np.column_stack([temp_df["mass_x"].values, temp_df["mass_y"].values]).astype(np.float32)
        end_sp = np.column_stack([temp_df["x"].values, temp_df["y"].values]).astype(np.float32)

        if pos_sp.size > 0:
            pos_sp[:, 0] = pos_sp[:, 0] * 15 - 0.5
            pos_sp[:, 1] = pos_sp[:, 1] * 15 - 0.5
            end_sp[:, 0] = end_sp[:, 0] * 15 - 0.5
            end_sp[:, 1] = end_sp[:, 1] * 15 - 0.5
        diff_sp = end_sp - pos_sp

        # trajectory
        if show_traj:
            if traj_source.lower() == "mass":
                xcol, ycol = "mass_x", "mass_y"
            else:
                xcol, ycol = "x", "y"
            traj = selected_df[["frame", xcol, ycol]].dropna().sort_values("frame").copy()
            if len(traj) > 1:
                xs = traj[xcol].to_numpy(dtype=np.float32) * 15 - 0.5
                ys = traj[ycol].to_numpy(dtype=np.float32) * 15 - 0.5
                fr = traj["frame"].to_numpy(dtype=int)

                for s_idx, e_idx in segment_by_frame_gaps(fr, traj_gap_frames):
                    if e_idx <= s_idx:
                        continue
                    ax.plot(xs[s_idx:e_idx + 1], ys[s_idx:e_idx + 1],
                            "-", lw=traj_lw, alpha=traj_alpha, color="gray", zorder=1)

        # arrows
        for start, diff in zip(pos_sp, diff_sp):
            ax.arrow(start[0], start[1], diff[0] / 4, diff[1] / 4,
                    head_width=0.15, head_length=0.4,
                    fc=arrow_color, ec="white", alpha=0.4,
                    linestyle=":", linewidth=0.4, zorder=3)

        # maze walls (your real imports)
        drew_maze = False
        try:
            from .mm_maze_utils import NewMaze
            from .mm_plot_utils import plot
            ma = NewMaze(6)
            plot(ma.wa[:, 0], ma.wa[:, 1], fmts=["k-"], equal=True, linewidth=2, axes=ax)
            drew_maze = True
        except Exception:
            drew_maze = False

        if not drew_maze:
            ax.plot([-0.5, 14.5, 14.5, -0.5, -0.5],
                    [-0.5, -0.5, 14.5, 14.5, -0.5],
                    "k-", lw=2)

        ax.set_xlim(-1, 15)
        ax.set_ylim(-1, 15)
        ax.set_title(f"ArrowMap | neuron {nid} | spikes={len(sp)}", fontsize=10)

        self.canvas.draw_idle()



class TrajFig5Widget(MplCanvasWidget):
    def __init__(self, parent=None):
        super().__init__(title="Trajectory Fig5", parent=parent)

    def render_fig5(self, nickname: str, base_dir: str,
                    water_node: int = 94,
                    control_nodes: Tuple[int, int, int] = (116, 95, 73),
                    lmin: int = 7,
                    xlim: Tuple[float, float] = (0, 8000),
                    ylim: Tuple[float, float] = (0, 60)):
        if self.canvas is None:
            return

        ax = self.ax
        ax.clear()

        cwd = os.getcwd()
        try:
            if base_dir:
                os.chdir(base_dir)

            from .mm_traj import LoadTraj, FindPathsToNode, TimeInMaze
            from .mm_maze_utils import NewMaze
            from .mm_plot_utils import plot

            tf = LoadTraj(nickname + "-tf")

            # rewards in absolute frames
            re = np.array([y[0] + tf.fr[i, 0] for i, r in enumerate(tf.re) for y in r], dtype=int)

            ma = NewMaze(6)

            ptn_1 = FindPathsToNode(int(water_node), tf, ma)
            ptn_2 = FindPathsToNode(int(control_nodes[0]), tf, ma)
            ptn_3 = FindPathsToNode(int(control_nodes[1]), tf, ma)
            ptn_4 = FindPathsToNode(int(control_nodes[2]), tf, ma)

            ptn_m = ptn_1[np.where(ptn_1[:, 2] >= lmin)] if getattr(ptn_1, "size", 0) else np.zeros((0, 4))
            arrays = [ptn_2, ptn_3, ptn_4]
            arrays = [a for a in arrays if getattr(a, "size", 0) > 0]

            if len(arrays) > 0:
                ptn_co_m = np.concatenate(arrays)
                ptn_co_m = ptn_co_m[np.where(ptn_co_m[:, 2] >= lmin)]
                ptn_co_m = ptn_co_m[np.argsort(ptn_co_m[:, 3])]
            else:
                ptn_co_m = np.zeros((0, 4))

            # cumulative paths to water
            x = [TimeInMaze(p, tf) for p in (ptn_m[:, 3] if ptn_m.size else [])]
            y = np.arange(len(x)) + 1
            plot(x, y, fmts=["r"], figsize=(6, 4), axes=ax)

            # rewards
            x = [TimeInMaze(p, tf) for p in re] if re.size else []
            y = np.arange(len(x)) + 1
            plot(x, y, fmts=["g"], markersize=16, axes=ax,
                xlabel="Time in maze (s)",
                ylabel=f"Paths of length>={lmin}",
                xlim=list(xlim), ylim=list(ylim))

            ax.set_ylim(list(ylim))
            ax.set_title(f"{nickname} | water={water_node} | controls={control_nodes}", fontsize=10)

            self.canvas.draw_idle()

        except Exception as e:
            ax.clear()
            ax.text(0.02, 0.98, f"Trajectory Fig5 render failed:\n{type(e).__name__}: {e}",
                    transform=ax.transAxes, va="top", ha="left", fontsize=9)
            self.canvas.draw_idle()

        finally:
            os.chdir(cwd)



# ----------------------------
# Main GUI
# ----------------------------
class NeuralGUI(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neural GUI — Maps + Footprints + ArrowMap + Traj Fig5 + Video + Traces")
        self.resize(1900, 1030)

        pg.setConfigOptions(antialias=True, background=(18, 18, 18), foreground="w")

        self.threadpool = QtCore.QThreadPool.globalInstance()
        self.signals = WorkerSignals()
        self.signals.fp_ready.connect(self.on_fp_ready)
        self.signals.map_ready.connect(self.on_map_ready)
        self.signals.error.connect(self.on_worker_error)

        self.last_map_request_id = 0
        self.map_cache_max = 64
        self.map_cache: Dict[tuple, dict] = OrderedDict()
        self.video_cap = None
        self.video_fps = 0.0
        self.video_frame_count = 0
        self.video_frame_size = None
        self._video_last_idx = None

        self._build_ui()
        self._connect_signals()

        self.load_demo()

    # ---------- UI ----------
    def _build_ui(self):
        cw = QtWidgets.QWidget()
        self.setCentralWidget(cw)
        vlayout = QtWidgets.QVBoxLayout(cw)
        vlayout.setContentsMargins(0, 0, 0, 0)
        self._emptyLabel = QtWidgets.QLabel("Use View menu to show/hide panels.")
        self._emptyLabel.setAlignment(QtCore.Qt.AlignCenter)
        vlayout.addWidget(self._emptyLabel, 1)

        # --- Map tab ---
        self.mapPlot = pg.PlotWidget()
        self.mapPlot.setTitle("Map")
        self.mapPlot.setAspectLocked(True)
        self.mapPlot.hideAxis("bottom")
        self.mapPlot.hideAxis("left")

        self.mapImage = pg.ImageItem()
        self.occOverlay = pg.ImageItem()

        # Z-order: base map < occ overlay < traj < local traj < walls < current point
        self.mapImage.setZValue(0)
        self.occOverlay.setZValue(1)

        # ---- main map colormap (NOT grayscale) ----
        try:
            cmap = pg.colormap.get("magma")  # try "viridis" if you prefer
            self._map_lut = cmap.getLookupTable(0.0, 1.0, 256, alpha=False)
        except Exception:
            self._map_lut = None

        if self._map_lut is not None:
            self.mapImage.setLookupTable(self._map_lut)

        # ---- occupancy overlay: tinted alpha mask (NOT grayscale intensity) ----
        self._occ_lut = make_tint_alpha_lut(rgb=(80, 160, 255))  # blue tint
        self.occOverlay.setLookupTable(self._occ_lut)

        self.mapPlot.addItem(self.mapImage)
        self.mapPlot.addItem(self.occOverlay)

        # walls + full trajectory + local past/future + current point
        self.wallsCurve = self.mapPlot.plot([], [], pen=pg.mkPen((230, 230, 230, 200), width=2))
        self.wallsCurve.setZValue(4)

        self.trajCurve = self.mapPlot.plot([], [], pen=pg.mkPen((200, 200, 200, 70), width=1))
        self.trajCurve.setZValue(2)

        # local window: past (greenish) / future (pinkish)
        self.trajPastCurve = self.mapPlot.plot([], [], pen=pg.mkPen((80, 255, 180, 200), width=2))
        self.trajPastCurve.setZValue(3)

        self.trajFutureCurve = self.mapPlot.plot([], [], pen=pg.mkPen((255, 120, 200, 200), width=2))
        self.trajFutureCurve.setZValue(3)

        self.curPoint = pg.ScatterPlotItem(size=10, brush=pg.mkBrush(255, 0, 0, 200), pen=pg.mkPen(None))
        self.curPoint.setZValue(5)
        self.mapPlot.addItem(self.curPoint)


        # --- Footprints tab ---
        self.fpPlot = pg.PlotWidget()
        self.fpPlot.setTitle("Footprints — click to jump neuron")
        self.fpPlot.setAspectLocked(True)
        self.fpPlot.hideAxis("bottom")
        self.fpPlot.hideAxis("left")
        self.fpBgImage = pg.ImageItem()
        self.fpSelImage = pg.ImageItem()
        self.fpPlot.addItem(self.fpBgImage)
        self.fpPlot.addItem(self.fpSelImage)
        lut = np.zeros((256, 4), dtype=np.ubyte)
        lut[:, 1] = 255
        lut[:, 3] = np.arange(256)
        self.fpSelImage.setLookupTable(lut)

        # --- ArrowMap tab ---
        self.arrowMap = ArrowMapWidget()

        # --- Trajectory Fig5 tab ---
        self.trajFig5 = TrajFig5Widget()

        # --- Video panel ---
        self.videoContainer = QtWidgets.QWidget()
        videoLayout = QtWidgets.QVBoxLayout(self.videoContainer)
        videoLayout.setContentsMargins(0,0,0,0)

        self.videoPlot = pg.PlotWidget()
        self.videoPlot.setTitle("Behavior video")
        self.videoPlot.setAspectLocked(True)
        self.videoPlot.hideAxis("bottom")
        self.videoPlot.hideAxis("left")
        self.videoImage = pg.ImageItem()
        self.videoPlot.addItem(self.videoImage)
        videoLayout.addWidget(self.videoPlot, 1)

        hb = QtWidgets.QHBoxLayout()
        self.videoTimeSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.videoTimeLabel = QtWidgets.QLabel("t=0.00s")
        self.playBtn = QtWidgets.QPushButton("Play")
        self.playBtn.setCheckable(True)
        hb.addWidget(self.videoTimeSlider, 1)
        hb.addWidget(self.videoTimeLabel)
        hb.addWidget(self.playBtn)
        videoLayout.addLayout(hb)

        # Bottom traces
        self.tracesContainer = QtWidgets.QWidget()
        tracesLayout = QtWidgets.QVBoxLayout(self.tracesContainer)
        tracesLayout.setContentsMargins(0, 0, 0, 0)

        self.bottom = pg.GraphicsLayoutWidget()
        tracesLayout.addWidget(self.bottom, 1)

        self.overviewPlot = self.bottom.addPlot(row=0, col=0)
        self.overviewPlot.setMaximumHeight(120)
        self.overviewCurve = self.overviewPlot.plot([], [], pen=pg.mkPen((200, 200, 200), width=1))
        self.region = pg.LinearRegionItem([0, 60], brush=pg.mkBrush(50, 50, 200, 40))
        self.overviewPlot.addItem(self.region)

        self.tracePlot = self.bottom.addPlot(row=1, col=0)
        self.tracePlot.showGrid(x=True, y=True, alpha=0.2)
        self.traceCurve = self.tracePlot.plot([], [], pen=pg.mkPen((255, 255, 255), width=1))
        self.traceCurve.setDownsampling(auto=True, method="peak")
        self.traceCurve.setClipToView(True)

        self.eventScatter = pg.ScatterPlotItem(size=8, brush=pg.mkBrush(255, 180, 0, 220), pen=pg.mkPen(None))
        self.tracePlot.addItem(self.eventScatter)

        self.speedPlot = self.bottom.addPlot(row=2, col=0)
        self.speedPlot.showGrid(x=True, y=True, alpha=0.2)
        self.speedCurve = self.speedPlot.plot([], [], pen=pg.mkPen((0, 255, 200), width=1))
        self.speedCurve.setDownsampling(auto=True, method="peak")
        self.speedCurve.setClipToView(True)
        self.tracePlot.setXLink(self.speedPlot)

        self.headPlot = self.bottom.addPlot(row=3, col=0)
        self.headPlot.showGrid(x=True, y=True, alpha=0.2)
        self.headCurve = self.headPlot.plot([], [], pen=pg.mkPen((200, 120, 255), width=1))
        self.headCurve.setDownsampling(auto=True, method="peak")
        self.headCurve.setClipToView(True)
        self.speedPlot.setXLink(self.headPlot)

        self.timeLine1 = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen((255, 0, 0), width=1))
        self.timeLine2 = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen((255, 0, 0), width=1))
        self.timeLine3 = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen((255, 0, 0), width=1))
        self.tracePlot.addItem(self.timeLine1)
        self.speedPlot.addItem(self.timeLine2)
        self.headPlot.addItem(self.timeLine3)

        # zoom buttons
        zb = QtWidgets.QHBoxLayout()
        self.zoomInBtn = QtWidgets.QPushButton("Zoom In")
        self.zoomOutBtn = QtWidgets.QPushButton("Zoom Out")
        self.zoomResetBtn = QtWidgets.QPushButton("Reset 60s")
        zb.addWidget(self.zoomInBtn)
        zb.addWidget(self.zoomOutBtn)
        zb.addWidget(self.zoomResetBtn)
        tracesLayout.addLayout(zb)

        # ---------- Panel Docks ----------
        self.mapDock = QtWidgets.QDockWidget("Map", self)
        self.mapDock.setWidget(self.mapPlot)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.mapDock)

        self.fpDock = QtWidgets.QDockWidget("Footprints", self)
        self.fpDock.setWidget(self.fpPlot)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.fpDock)

        self.arrowDock = QtWidgets.QDockWidget("ArrowMap", self)
        self.arrowDock.setWidget(self.arrowMap)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.arrowDock)

        self.trajDock = QtWidgets.QDockWidget("Traj Fig5", self)
        self.trajDock.setWidget(self.trajFig5)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.trajDock)

        self.videoDock = QtWidgets.QDockWidget("Video", self)
        self.videoDock.setWidget(self.videoContainer)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.videoDock)

        self.tracesDock = QtWidgets.QDockWidget("Traces", self)
        self.tracesDock.setWidget(self.tracesContainer)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.tracesDock)

        for dock in [self.mapDock, self.fpDock, self.arrowDock, self.trajDock, self.videoDock, self.tracesDock]:
            dock.setFeatures(
                QtWidgets.QDockWidget.DockWidgetMovable
                | QtWidgets.QDockWidget.DockWidgetFloatable
                | QtWidgets.QDockWidget.DockWidgetClosable
            )
            dock.setAllowedAreas(QtCore.Qt.AllDockWidgetAreas)

        self.tabifyDockWidget(self.mapDock, self.fpDock)
        self.tabifyDockWidget(self.fpDock, self.arrowDock)
        self.tabifyDockWidget(self.arrowDock, self.trajDock)
        self.mapDock.raise_()

        # ---------- Controls Dock ----------
        self.ctrlDock = QtWidgets.QDockWidget("Controls", self)
        self.ctrlDock.setMinimumWidth(440)
        self.ctrlDock.setMaximumWidth(560)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.ctrlDock)

        ctrlW = QtWidgets.QWidget()
        self.ctrlDock.setWidget(ctrlW)
        form = QtWidgets.QFormLayout(ctrlW)

        # neuron control
        row = QtWidgets.QHBoxLayout()
        self.prevNeuronBtn = QtWidgets.QPushButton("◀")
        self.nextNeuronBtn = QtWidgets.QPushButton("▶")
        self.neuronSpin = QtWidgets.QSpinBox()
        self.neuronEdit = QtWidgets.QLineEdit()
        self.neuronEdit.setPlaceholderText("type id + Enter")
        row.addWidget(self.prevNeuronBtn)
        row.addWidget(self.neuronSpin, 1)
        row.addWidget(self.nextNeuronBtn)
        row.addWidget(self.neuronEdit, 1)
        form.addRow("Neuron", row)

        # trace source
        self.traceSourceCombo = QtWidgets.QComboBox()
        self.traceSourceCombo.addItems(["C", "C_raw", "S"])
        self.traceSourceCombo.setToolTip("Which signal to display AND to use for firing/rate map weighting.")
        form.addRow("Trace source", self.traceSourceCombo)

        # position source
        self.posSourceCombo = QtWidgets.QComboBox()
        self.posSourceCombo.addItems(["body (mass_x/y)", "nose (x/y)"])
        self.posSourceCombo.setToolTip("Which (x,y) stream to use for map binning and map trajectory overlay.")
        form.addRow("Position source", self.posSourceCombo)

        # map type
        self.mapTypeCombo = QtWidgets.QComboBox()
        self.mapTypeCombo.addItems(["Rate map (trace/occ)", "Firing map (sum trace)", "Occupancy map"])
        self.mapTypeCombo.setToolTip("Rate = sum(trace)/occupancy; Firing = sum(trace); Occupancy = counts.")
        form.addRow("Map type", self.mapTypeCombo)

        # bins
        self.binSpin = QtWidgets.QSpinBox()
        self.binSpin.setRange(10, 250)
        self.binSpin.setValue(60)
        self.binSpin.setToolTip("Spatial bin resolution (nx=ny). Higher is slower.")
        form.addRow("Bins", self.binSpin)

        # smoothing
        self.smoothSpin = QtWidgets.QDoubleSpinBox()
        self.smoothSpin.setRange(0.0, 10.0)
        self.smoothSpin.setSingleStep(0.5)
        self.smoothSpin.setValue(1.0)
        self.smoothSpin.setToolTip("Gaussian smoothing sigma (in bins). Applied to occ & act then recomputed rate.")
        form.addRow("Smooth sigma", self.smoothSpin)

        # min occupancy
        self.minOccSpin = QtWidgets.QSpinBox()
        self.minOccSpin.setRange(0, 999999)
        self.minOccSpin.setValue(2)
        self.minOccSpin.setToolTip("Bins with occ < minOcc will be masked (NaN in rate map).")
        form.addRow("Min occupancy", self.minOccSpin)

        # occupancy overlay alpha
        self.occAlphaSpin = QtWidgets.QDoubleSpinBox()
        self.occAlphaSpin.setRange(0.0, 1.0)
        self.occAlphaSpin.setSingleStep(0.05)
        self.occAlphaSpin.setValue(0.25)
        self.occAlphaSpin.setToolTip("Opacity of occupancy overlay drawn on top of the map image.")
        form.addRow("Occ overlay α", self.occAlphaSpin)

        # show maze walls
        self.showWallsCheck = QtWidgets.QCheckBox("Show maze walls (MM_Maze_Utils)")
        self.showWallsCheck.setChecked(True)
        self.showWallsCheck.setToolTip("If MM_Maze_Utils.NewMaze is importable, draw walls overlay in Map tab.")
        form.addRow("", self.showWallsCheck)

        # trajectory overlay + alpha + decim
        self.showTrajCheck = QtWidgets.QCheckBox("Overlay raw trajectory (Map)")
        self.showTrajCheck.setChecked(True)
        self.showTrajCheck.setToolTip("Overlay the raw position time series on the Map panel.")
        form.addRow("", self.showTrajCheck)

        self.trajAlphaSpin = QtWidgets.QDoubleSpinBox()
        self.trajAlphaSpin.setRange(0.0, 1.0)
        self.trajAlphaSpin.setSingleStep(0.02)
        self.trajAlphaSpin.setValue(0.08)
        self.trajAlphaSpin.setToolTip("Trajectory line alpha on the Map panel.")
        form.addRow("Traj α", self.trajAlphaSpin)

        self.trajDecimSpin = QtWidgets.QSpinBox()
        self.trajDecimSpin.setRange(1, 200)
        self.trajDecimSpin.setValue(4)
        self.trajDecimSpin.setToolTip("Plot every k-th sample for the trajectory overlay (speed).")
        form.addRow("Traj decim", self.trajDecimSpin)

        # local past/future trajectory window
        self.showLocalTrajCheck = QtWidgets.QCheckBox("Overlay local past/future trajectory")
        self.showLocalTrajCheck.setChecked(True)
        self.showLocalTrajCheck.setToolTip("Show only a window around current time, split into past and future.")
        form.addRow("", self.showLocalTrajCheck)

        self.localTrajWinSpin = QtWidgets.QDoubleSpinBox()
        self.localTrajWinSpin.setRange(0.0, 600.0)
        self.localTrajWinSpin.setSingleStep(0.5)
        self.localTrajWinSpin.setValue(5.0)
        self.localTrajWinSpin.setToolTip("Seconds shown into the past AND future. 0 disables local window.")
        form.addRow("Local traj window (s)", self.localTrajWinSpin)

        self.localTrajAlphaSpin = QtWidgets.QDoubleSpinBox()
        self.localTrajAlphaSpin.setRange(0.0, 1.0)
        self.localTrajAlphaSpin.setSingleStep(0.05)
        self.localTrajAlphaSpin.setValue(0.85)
        self.localTrajAlphaSpin.setToolTip("Opacity for local past/future trajectories.")
        form.addRow("Local traj α", self.localTrajAlphaSpin)

        # chunking controls
        self.chunkModeCombo = QtWidgets.QComboBox()
        self.chunkModeCombo.addItems(["All", "Fixed duration (s)", "N chunks", "By bout (CSV)"])
        self.chunkModeCombo.setToolTip("Split data into chunks and compute maps per chunk.")
        form.addRow("Chunk mode", self.chunkModeCombo)

        self.chunkParamSpin = QtWidgets.QDoubleSpinBox()
        self.chunkParamSpin.setRange(1.0, 1e6)
        self.chunkParamSpin.setValue(300.0)
        self.chunkParamSpin.setToolTip("If Fixed duration: seconds per chunk. If N chunks: number of chunks.")
        form.addRow("Chunk param", self.chunkParamSpin)

        self.chunkIndexSpin = QtWidgets.QSpinBox()
        self.chunkIndexSpin.setRange(0, 0)
        self.chunkIndexSpin.setValue(0)
        self.chunkIndexSpin.setToolTip("Which chunk index to display.")
        form.addRow("Chunk index", self.chunkIndexSpin)

        # event detection controls
        self.eventStdMult = QtWidgets.QDoubleSpinBox()
        self.eventStdMult.setRange(0.5, 20.0)
        self.eventStdMult.setValue(5.0)
        self.eventStdMult.setSingleStep(0.5)
        self.eventStdMult.setToolTip("Event rule: S[:,nid] > std_mult * sn(C_raw[:,nid])")
        form.addRow("Event std_mult", self.eventStdMult)

        self.thinFramesSpin = QtWidgets.QSpinBox()
        self.thinFramesSpin.setRange(0, 200)
        self.thinFramesSpin.setValue(4)
        self.thinFramesSpin.setToolTip("Thin events: keep only those separated by >= thinFrames.")
        form.addRow("Thin frames", self.thinFramesSpin)

        self.refreshEventsBtn = QtWidgets.QPushButton("Update event markers")
        form.addRow("", self.refreshEventsBtn)

        self.renderArrowBtn = QtWidgets.QPushButton("Render ArrowMap")
        self.autoArrowCheck = QtWidgets.QCheckBox("Auto render")
        self.autoArrowCheck.setChecked(True)
        arrowRow = QtWidgets.QHBoxLayout()
        arrowRow.addWidget(self.renderArrowBtn)
        arrowRow.addWidget(self.autoArrowCheck)
        form.addRow("", arrowRow)

        # footprint click threshold
        self.fpClickThr = QtWidgets.QDoubleSpinBox()
        self.fpClickThr.setRange(0.0, 10.0)
        self.fpClickThr.setValue(0.08)
        self.fpClickThr.setSingleStep(0.02)
        self.fpClickThr.setToolTip("Only allow clicking footprints where max(A) at pixel exceeds this.")
        form.addRow("FP click thr", self.fpClickThr)

        # Traj Fig5 controls
        form.addRow(QtWidgets.QLabel("— Traj Fig5 —"), QtWidgets.QLabel(""))

        self.trajNicknameEdit = QtWidgets.QLineEdit()
        self.trajNicknameEdit.setPlaceholderText("e.g. nickname (without -tf)")
        self.trajNicknameEdit.setToolTip("Used as LoadTraj(nickname+'-tf').")
        form.addRow("Nickname", self.trajNicknameEdit)

        self.waterNodeSpin = QtWidgets.QSpinBox(); self.waterNodeSpin.setRange(0, 9999); self.waterNodeSpin.setValue(94)
        self.ctrlNode1 = QtWidgets.QSpinBox(); self.ctrlNode1.setRange(0, 9999); self.ctrlNode1.setValue(116)
        self.ctrlNode2 = QtWidgets.QSpinBox(); self.ctrlNode2.setRange(0, 9999); self.ctrlNode2.setValue(95)
        self.ctrlNode3 = QtWidgets.QSpinBox(); self.ctrlNode3.setRange(0, 9999); self.ctrlNode3.setValue(73)

        cn = QtWidgets.QHBoxLayout()
        cn.addWidget(QtWidgets.QLabel("water")); cn.addWidget(self.waterNodeSpin)
        cn.addWidget(QtWidgets.QLabel("c1")); cn.addWidget(self.ctrlNode1)
        cn.addWidget(QtWidgets.QLabel("c2")); cn.addWidget(self.ctrlNode2)
        cn.addWidget(QtWidgets.QLabel("c3")); cn.addWidget(self.ctrlNode3)
        form.addRow("Nodes", cn)

        self.lminSpin = QtWidgets.QSpinBox(); self.lminSpin.setRange(1, 999); self.lminSpin.setValue(7)
        form.addRow("lmin", self.lminSpin)

        self.renderTrajBtn = QtWidgets.QPushButton("Render Traj Fig5 plot")
        self.autoTrajCheck = QtWidgets.QCheckBox("Auto render")
        self.autoTrajCheck.setChecked(True)
        trajRow = QtWidgets.QHBoxLayout()
        trajRow.addWidget(self.renderTrajBtn)
        trajRow.addWidget(self.autoTrajCheck)
        form.addRow("", trajRow)

        # ---------- Data Dock ----------
        self.dataDock = QtWidgets.QDockWidget("Data", self)
        self.dataDock.setMinimumWidth(440)
        self.dataDock.setMaximumWidth(560)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.dataDock)

        dataW = QtWidgets.QWidget()
        self.dataDock.setWidget(dataW)
        dform = QtWidgets.QFormLayout(dataW)

        self.dataNickEdit = QtWidgets.QLineEdit()
        self.dataNickEdit.setPlaceholderText("dataset nickname for auto-fill")
        dform.addRow("Dataset nickname", self.dataNickEdit)

        self.autoFillBtn = QtWidgets.QPushButton("Auto-fill paths")
        dform.addRow("", self.autoFillBtn)

        self.calciumDirEdit = QtWidgets.QLineEdit("D:/neuralData")
        self.calciumDirBrowseBtn = QtWidgets.QPushButton("Browse")
        hb_dir0 = QtWidgets.QHBoxLayout(); hb_dir0.addWidget(self.calciumDirEdit, 1); hb_dir0.addWidget(self.calciumDirBrowseBtn)
        dform.addRow("Calcium dir", hb_dir0)

        self.csvDirEdit = QtWidgets.QLineEdit("D:/combineddata/selected_data")
        self.csvDirBrowseBtn = QtWidgets.QPushButton("Browse")
        hb_dir1 = QtWidgets.QHBoxLayout(); hb_dir1.addWidget(self.csvDirEdit, 1); hb_dir1.addWidget(self.csvDirBrowseBtn)
        dform.addRow("CSV dir", hb_dir1)

        self.videoDirEdit = QtWidgets.QLineEdit("L:/behavior_121625/videos")
        self.videoDirBrowseBtn = QtWidgets.QPushButton("Browse")
        hb_dir2 = QtWidgets.QHBoxLayout(); hb_dir2.addWidget(self.videoDirEdit, 1); hb_dir2.addWidget(self.videoDirBrowseBtn)
        dform.addRow("Video dir", hb_dir2)

        self.trajBaseDirEdit = QtWidgets.QLineEdit("D:/combineddata/mm-trajectories")
        self.trajBaseDirEdit.setPlaceholderText("repo root or mm-trajectories folder")
        self.trajBaseDirEdit.setToolTip("We chdir so MM_Traj_Utils.LoadTraj can find mm-trajectories/.")
        self.trajDirBrowseBtn = QtWidgets.QPushButton("Browse")
        hb_dir3 = QtWidgets.QHBoxLayout(); hb_dir3.addWidget(self.trajBaseDirEdit, 1); hb_dir3.addWidget(self.trajDirBrowseBtn)
        dform.addRow("Traj base dir", hb_dir3)

        self.matPathEdit = QtWidgets.QLineEdit()
        self.matBrowseBtn = QtWidgets.QPushButton("Browse")
        hb0 = QtWidgets.QHBoxLayout(); hb0.addWidget(self.matPathEdit, 1); hb0.addWidget(self.matBrowseBtn)
        dform.addRow("Calcium MAT", hb0)

        self.csvPathEdit = QtWidgets.QLineEdit()
        self.csvBrowseBtn = QtWidgets.QPushButton("Browse")
        hb = QtWidgets.QHBoxLayout(); hb.addWidget(self.csvPathEdit, 1); hb.addWidget(self.csvBrowseBtn)
        dform.addRow("nose_interp_df CSV", hb)

        self.videoPathEdit = QtWidgets.QLineEdit()
        self.videoBrowseBtn = QtWidgets.QPushButton("Browse")
        hb3 = QtWidgets.QHBoxLayout(); hb3.addWidget(self.videoPathEdit, 1); hb3.addWidget(self.videoBrowseBtn)
        dform.addRow("Video (avi)", hb3)

        self.loadFilesBtn = QtWidgets.QPushButton("Load Selected Files")
        dform.addRow("", self.loadFilesBtn)

        self.loadDemoBtn = QtWidgets.QPushButton("Load Synthetic Demo")
        dform.addRow("", self.loadDemoBtn)

        # timers
        self._slider_debounce = QtCore.QTimer(self)
        self._slider_debounce.setSingleShot(True)
        self._slider_debounce.setInterval(30)

        self._play_timer = QtCore.QTimer(self)
        self._play_timer.setInterval(int(1000/25))

        self._arrow_render_timer = QtCore.QTimer(self)
        self._arrow_render_timer.setSingleShot(True)
        self._arrow_render_timer.setInterval(120)
        self._arrow_render_timer.timeout.connect(self._auto_render_arrow)

        self._traj_render_timer = QtCore.QTimer(self)
        self._traj_render_timer.setSingleShot(True)
        self._traj_render_timer.setInterval(200)
        self._traj_render_timer.timeout.connect(self._auto_render_traj)

        viewMenu = self.menuBar().addMenu("View")
        for dock in [self.mapDock, self.fpDock, self.arrowDock, self.trajDock,
                     self.videoDock, self.tracesDock, self.ctrlDock, self.dataDock]:
            viewMenu.addAction(dock.toggleViewAction())

    def _connect_signals(self):
        self.loadDemoBtn.clicked.connect(self.load_demo)

        self.autoFillBtn.clicked.connect(self.autofill_from_nickname)

        self.calciumDirBrowseBtn.clicked.connect(lambda: self.browse_dir(self.calciumDirEdit, "Calcium dir"))
        self.csvDirBrowseBtn.clicked.connect(lambda: self.browse_dir(self.csvDirEdit, "CSV dir"))
        self.videoDirBrowseBtn.clicked.connect(lambda: self.browse_dir(self.videoDirEdit, "Video dir"))
        self.trajDirBrowseBtn.clicked.connect(lambda: self.browse_dir(self.trajBaseDirEdit, "Traj base dir"))

        self.matBrowseBtn.clicked.connect(lambda: self.browse_file(self.matPathEdit, "MAT", "MAT (*.mat);;All files (*.*)"))
        self.csvBrowseBtn.clicked.connect(lambda: self.browse_file(self.csvPathEdit, "CSV", "CSV (*.csv);;All files (*.*)"))
        self.videoBrowseBtn.clicked.connect(lambda: self.browse_file(self.videoPathEdit, "Video", "Video (*.avi *.mp4 *.mov *.mkv);;All files (*.*)"))

        self.loadFilesBtn.clicked.connect(self.load_selected_files)

        self.prevNeuronBtn.clicked.connect(lambda: self.set_neuron(self.current_neuron - 1))
        self.nextNeuronBtn.clicked.connect(lambda: self.set_neuron(self.current_neuron + 1))
        self.neuronSpin.valueChanged.connect(self.set_neuron)
        self.neuronEdit.returnPressed.connect(self.on_neuron_edit_enter)

        for w in [self.traceSourceCombo, self.posSourceCombo, self.mapTypeCombo,
                  self.binSpin, self.smoothSpin, self.minOccSpin,
                  self.chunkModeCombo, self.chunkParamSpin, self.chunkIndexSpin,
                  self.showTrajCheck, self.trajAlphaSpin, self.trajDecimSpin,
                  self.occAlphaSpin, self.showWallsCheck]:
            if isinstance(w, QtWidgets.QComboBox):
                w.currentIndexChanged.connect(lambda _=None: self.on_map_params_changed())
            else:
                try:
                    w.valueChanged.connect(lambda _=None: self.on_map_params_changed())
                except Exception:
                    try:
                        w.stateChanged.connect(lambda _=None: self.on_map_params_changed())
                    except Exception:
                        pass

        self.renderArrowBtn.clicked.connect(self.render_arrow_map)
        self.renderTrajBtn.clicked.connect(self.render_traj_fig5)
        self.autoArrowCheck.stateChanged.connect(lambda _=None: self._maybe_auto_render_arrow())
        self.autoTrajCheck.stateChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.eventStdMult.valueChanged.connect(lambda _=None: self._maybe_auto_render_arrow())
        self.thinFramesSpin.valueChanged.connect(lambda _=None: self._maybe_auto_render_arrow())
        self.trajNicknameEdit.textChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.trajBaseDirEdit.textChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.waterNodeSpin.valueChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.ctrlNode1.valueChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.ctrlNode2.valueChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.ctrlNode3.valueChanged.connect(lambda _=None: self._maybe_auto_render_traj())
        self.lminSpin.valueChanged.connect(lambda _=None: self._maybe_auto_render_traj())

        self.refreshEventsBtn.clicked.connect(self.update_event_markers)

        self.fpPlot.scene().sigMouseClicked.connect(self.on_fp_clicked)

        self.region.sigRegionChanged.connect(self.on_region_changed)
        self.tracePlot.getViewBox().sigXRangeChanged.connect(self.on_detail_xrange_changed)
        self.tracePlot.scene().sigMouseClicked.connect(self.on_trace_clicked)

        self.videoTimeSlider.valueChanged.connect(self.on_video_slider_moved)
        self._slider_debounce.timeout.connect(self._apply_slider_time)

        self.playBtn.toggled.connect(self.on_play_toggled)
        self._play_timer.timeout.connect(self.on_play_tick)

        self.zoomInBtn.clicked.connect(lambda: self.zoom_region(0.5))
        self.zoomOutBtn.clicked.connect(lambda: self.zoom_region(2.0))
        self.zoomResetBtn.clicked.connect(self.zoom_reset)

        # local traj controls should NOT trigger map recompute; just refresh overlays
        self.showLocalTrajCheck.stateChanged.connect(lambda _=None: self.update_map_overlays_only())
        self.localTrajWinSpin.valueChanged.connect(lambda _=None: self.update_map_overlays_only())
        self.localTrajAlphaSpin.valueChanged.connect(lambda _=None: self.update_map_overlays_only())

    # ---------- Loading ----------
    def browse_file(self, line_edit, title, filt):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, title, str(Path.cwd()), filt)
        if path:
            line_edit.setText(path)

    def browse_dir(self, line_edit, title):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, title, str(Path.cwd()))
        if path:
            line_edit.setText(path)

    def _find_file_by_nickname(self, base_dir: str, nick: str, exts: Tuple[str, ...], recursive: bool = False) -> Optional[str]:
        if not base_dir:
            return None
        base = Path(base_dir)
        if not base.exists():
            return None
        nick_l = nick.lower()
        matches: List[Path] = []
        for ext in exts:
            it = base.rglob(f"*{ext}") if recursive else base.glob(f"*{ext}")
            for f in it:
                if nick_l in f.name.lower():
                    matches.append(f)
        if not matches:
            return None
        def _score(p: Path) -> int:
            stem = p.stem.lower()
            score = 0
            if stem == nick_l:
                score += 100
            if stem.startswith(nick_l):
                score += 50
            if stem.endswith(nick_l):
                score += 40
            score -= len(stem)
            return score
        best = max(matches, key=_score)
        return str(best)

    def _split_day_nickname(self, nick: str) -> Optional[Tuple[str, str]]:
        m = re.match(r"^(?P<base>.+?)day(?P<day>\d+)$", nick.strip(), flags=re.IGNORECASE)
        if not m:
            return None
        return m.group("base"), m.group("day")

    def _resolve_calcium_by_nickname(self, base_dir: str, nick: str) -> Optional[str]:
        if not base_dir:
            return None
        base = Path(base_dir)
        if not base.exists():
            return None
        day_info = self._split_day_nickname(nick)
        if not day_info:
            return None
        base_name, day = day_info

        folder = base / base_name
        if not folder.exists():
            # Try to find a folder containing the base name.
            for d in base.iterdir():
                if d.is_dir() and base_name.lower() in d.name.lower():
                    folder = d
                    break

        if not folder.exists():
            return None

        candidate = folder / f"final_day{day}.mat"
        if candidate.exists():
            return str(candidate)

        # Fallback: pick a .mat file in the folder containing "day{day}".
        matches = list(folder.glob(f"*day{day}*.mat"))
        if matches:
            return str(sorted(matches, key=lambda p: len(p.name))[0])
        return None

    def autofill_from_nickname(self):
        nick = self.dataNickEdit.text().strip()
        if not nick:
            QtWidgets.QMessageBox.information(self, "Missing nickname", "Enter a dataset nickname first.")
            return

        matp = self._resolve_calcium_by_nickname(self.calciumDirEdit.text().strip(), nick)
        if not matp:
            matp = self._find_file_by_nickname(self.calciumDirEdit.text().strip(), nick, (".mat",), recursive=True)
        if matp:
            self.matPathEdit.setText(matp)

        csvp = self._find_file_by_nickname(self.csvDirEdit.text().strip(), nick, (".csv",))
        if csvp:
            self.csvPathEdit.setText(csvp)

        videop = self._find_file_by_nickname(self.videoDirEdit.text().strip(), nick, (".avi", ".mp4", ".mov", ".mkv"))
        if videop:
            self.videoPathEdit.setText(videop)

        if not self.trajNicknameEdit.text().strip():
            self.trajNicknameEdit.setText(nick)

    def load_demo(self):
        cal = make_synth_calcium()
        T = cal.C.shape[0]
        gap_mask = ~np.isfinite(cal.C_raw[:, 0])
        kp = make_synth_keypoints(T, gap_mask)
        self.data = DataBundle(calcium=cal, keypoints=kp, video_path=None)
        self.set_bundle(self.data)
        self.statusBar().showMessage("Loaded synthetic demo (calcium + keypoints).")

    def load_selected_files(self):
        if not self.matPathEdit.text().strip() and self.dataNickEdit.text().strip():
            self.autofill_from_nickname()
        # calcium
        matp = self.matPathEdit.text().strip()
        if matp:
            try:
                cal = load_calcium_mat(matp)
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "MAT load failed", str(e))
                return
        else:
            cal = make_synth_calcium()

        data = DataBundle(calcium=cal)

        # keypoints
        csvp = self.csvPathEdit.text().strip()
        if csvp:
            try:
                data.keypoints = load_keypoints_csv(csvp, T=cal.C.shape[0])
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "CSV load failed", str(e))
                return

        # video path (optional)
        vp = self.videoPathEdit.text().strip()
        data.video_path = vp if vp else None

        # traj fig5 input fields
        data.traj_nickname = self.trajNicknameEdit.text().strip() or None
        data.traj_base_dir = self.trajBaseDirEdit.text().strip() or None

        self.data = data
        self.set_bundle(self.data)
        self.statusBar().showMessage("Loaded selected files.")

    # ---------- Bundle setup ----------
    def set_bundle(self, data: DataBundle):
        self.data = data
        cal = data.calcium

        self.A = cal.A.astype(np.float32, copy=False)
        self.S = cal.S.astype(np.float32, copy=False)
        self.C = cal.C.astype(np.float32, copy=False)
        self.C_raw = cal.C_raw.astype(np.float32, copy=False)
        self.fs = float(cal.fs)

        self.T, self.N = self.C.shape
        self.H, self.W, NA = self.A.shape
        assert NA == self.N

        self.t = (np.arange(self.T, dtype=np.float32) / self.fs)

        # init state
        self.current_neuron = 0
        self.current_time_idx = 0
        self.map_cache = OrderedDict()

        # neuron ranges
        self.neuronSpin.blockSignals(True)
        self.neuronSpin.setRange(0, self.N - 1)
        self.neuronSpin.setValue(0)
        self.neuronSpin.blockSignals(False)

        # footprint precompute
        self.fp_maxval = None
        self.fp_argmax = None
        self.fp_p99 = 1.0
        self.threadpool.start(FPWorker(self.A, self.signals))

        # video slider
        self.videoTimeSlider.blockSignals(True)
        self.videoTimeSlider.setRange(0, self.T - 1)
        self.videoTimeSlider.setValue(0)
        self.videoTimeSlider.blockSignals(False)
        if self.fs > 0:
            self._play_timer.setInterval(int(1000 / self.fs))
        self._open_video(data.video_path)

        # behavior traces
        if data.keypoints is not None:
            self.speedCurve.setData(self.t, data.keypoints.speed)
            self.headCurve.setData(self.t, data.keypoints.head_dir)
        else:
            self.speedCurve.setData([], [])
            self.headCurve.setData([], [])

        # show walls once (if enabled)
        self.update_walls_overlay()

        self.set_neuron(0)
        self.set_time_index(0)
        self.on_map_params_changed()
        self._maybe_auto_render_traj()

    # ---------- Accessors ----------
    def get_trace_matrix(self) -> np.ndarray:
        src = self.traceSourceCombo.currentText()
        return self.S if src == "S" else (self.C_raw if src == "C_raw" else self.C)

    def get_pos_xy01(self) -> Optional[np.ndarray]:
        if self.data.keypoints is None:
            return None
        src = self.posSourceCombo.currentText()
        return self.data.keypoints.body_xy if "body" in src else self.data.keypoints.nose_xy

    # ---------- Neuron ----------
    def on_neuron_edit_enter(self):
        try:
            nid = int(self.neuronEdit.text().strip())
            self.set_neuron(nid)
        except Exception:
            pass

    def set_neuron(self, nid: int):
        nid = int(np.clip(int(nid), 0, self.N - 1))
        self.current_neuron = nid

        # sync widgets without recursion
        self.neuronSpin.blockSignals(True)
        self.neuronSpin.setValue(nid)
        self.neuronSpin.blockSignals(False)

        # traces
        X = self.get_trace_matrix()
        y = X[:, nid]
        self.traceCurve.setData(self.t, y)
        t2, y2 = downsample_minmax(self.t, y, max_points=9000)
        self.overviewCurve.setData(t2, y2)

        self.zoom_reset()
        self.update_event_markers()

        # footprints update
        self.render_footprints()

        # map update
        self.on_map_params_changed()
        self._maybe_auto_render_arrow()

    # ---------- Events ----------
    def update_event_markers(self):
        nid = int(self.current_neuron)
        sp = detect_events_S_vs_Craw(self.S[:, nid], self.C_raw[:, nid],
                                     std_mult=float(self.eventStdMult.value()),
                                     thin_frames=int(self.thinFramesSpin.value()))
        X = self.get_trace_matrix()
        y = X[:, nid]
        # cap markers for speed
        sp = sp[:3000] if sp.size > 3000 else sp
        self.eventScatter.setData(self.t[sp], y[sp])

    def _maybe_auto_render_arrow(self):
        if not getattr(self, "autoArrowCheck", None):
            return
        if not self.autoArrowCheck.isChecked():
            return
        data = getattr(self, "data", None)
        if data is None or data.keypoints is None:
            return
        self._arrow_render_timer.start()

    def _auto_render_arrow(self):
        data = getattr(self, "data", None)
        if data is None or data.keypoints is None:
            return
        self.render_arrow_map()

    def _maybe_auto_render_traj(self):
        if not getattr(self, "autoTrajCheck", None):
            return
        if not self.autoTrajCheck.isChecked():
            return
        data = getattr(self, "data", None)
        if data is None:
            return
        nick = (self.trajNicknameEdit.text().strip() or data.traj_nickname or "").strip()
        if not nick:
            return
        self._traj_render_timer.start()

    def _auto_render_traj(self):
        data = getattr(self, "data", None)
        if data is None:
            return
        nick = (self.trajNicknameEdit.text().strip() or data.traj_nickname or "").strip()
        if not nick:
            return
        self.render_traj_fig5()

    # ---------- Time / click sync ----------
    def set_time_index(self, idx: int):
        self.current_time_idx = int(np.clip(idx, 0, self.T - 1))
        tcur = float(self.t[self.current_time_idx])
        self.timeLine1.setPos(tcur)
        self.timeLine2.setPos(tcur)
        self.timeLine3.setPos(tcur)
        self.videoTimeLabel.setText(f"t={tcur:.2f}s")
        self.update_map_overlays_only()
        self.update_video_frame(self.current_time_idx)

    def closeEvent(self, event):
        self._close_video()
        super().closeEvent(event)

    def on_trace_clicked(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        pos = event.scenePos()
        if not self.tracePlot.sceneBoundingRect().contains(pos):
            return
        vb = self.tracePlot.getViewBox()
        mp = vb.mapSceneToView(pos)
        t_clicked = float(mp.x())
        idx = int(np.clip(round(t_clicked * self.fs), 0, self.T - 1))
        self.set_time_index(idx)
        self.videoTimeSlider.blockSignals(True)
        self.videoTimeSlider.setValue(idx)
        self.videoTimeSlider.blockSignals(False)

    # region sync bugfix (avoid float->setRegion)
    def on_region_changed(self):
        rgn = self.region.getRegion()
        self.tracePlot.setXRange(rgn[0], rgn[1], padding=0)

    def on_detail_xrange_changed(self, _, xr):
        if xr is None:
            return
        if isinstance(xr, (list, tuple, np.ndarray)) and len(xr) == 2:
            rgn = [float(xr[0]), float(xr[1])]
        else:
            return
        self.region.blockSignals(True)
        self.region.setRegion(rgn)
        self.region.blockSignals(False)

    # ---------- Zoom controls ----------
    def zoom_region(self, factor: float):
        r0, r1 = self.region.getRegion()
        c = 0.5*(r0 + r1)
        w = (r1 - r0) * float(factor)
        w = max(0.2, min(w, float(self.t[-1] - self.t[0])))
        nr0 = max(float(self.t[0]), c - 0.5*w)
        nr1 = min(float(self.t[-1]), c + 0.5*w)
        self.region.setRegion([nr0, nr1])

    def zoom_reset(self):
        t0 = float(self.t[0])
        t1 = min(float(self.t[-1]), t0 + 60.0)
        self.region.setRegion([t0, t1])
        self.tracePlot.setXRange(t0, t1, padding=0)

    # ---------- Video ----------
    def _close_video(self):
        if self.video_cap is not None:
            try:
                self.video_cap.release()
            except Exception:
                pass
        self.video_cap = None
        self.video_fps = 0.0
        self.video_frame_count = 0
        self.video_frame_size = None
        self._video_last_idx = None

    def _open_video(self, path: Optional[str]):
        self._close_video()
        if not path:
            return
        if not HAVE_CV2:
            self.statusBar().showMessage("cv2 not installed; cannot load video.", 5000)
            return
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            self.statusBar().showMessage(f"Failed to open video: {path}", 5000)
            cap.release()
            return
        self.video_cap = cap
        self.video_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        self.video_frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        if w > 0 and h > 0:
            self.video_frame_size = (w, h)
        self._video_last_idx = None

    def on_video_slider_moved(self, value):
        self._pending_slider_idx = int(value)
        self._slider_debounce.start()

    def _apply_slider_time(self):
        self.set_time_index(self._pending_slider_idx)

    def on_play_toggled(self, checked: bool):
        if checked:
            self.playBtn.setText("Pause")
            self._play_timer.start()
        else:
            self.playBtn.setText("Play")
            self._play_timer.stop()

    def on_play_tick(self):
        idx = self.current_time_idx + 1
        if idx >= self.T:
            idx = 0
        self.videoTimeSlider.setValue(idx)  # triggers debounce -> set_time_index

    def update_video_frame(self, idx: int):
        if self.video_cap is not None:
            vid_idx = int(idx)
            if self.fs > 0 and self.video_fps > 0:
                t = float(idx) / float(self.fs)
                vid_idx = int(round(t * self.video_fps))
            if self.video_frame_count > 0:
                vid_idx = int(np.clip(vid_idx, 0, self.video_frame_count - 1))

            if self._video_last_idx is None or vid_idx != (self._video_last_idx + 1):
                self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, vid_idx)
            ok, frame = self.video_cap.read()
            if ok and frame is not None:
                self._video_last_idx = vid_idx
                if frame.ndim == 2:
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
                else:
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = frame_rgb.swapaxes(0, 1)
                self.videoImage.setImage(img, autoLevels=False)
                if self.video_frame_size is not None:
                    w, h = self.video_frame_size
                    self.videoImage.setRect(QtCore.QRectF(0, 0, w, h))
                return
            self._video_last_idx = None

        # Fallback synthetic video if no real video is available.
        H, W = 240, 320
        img = np.zeros((H, W), dtype=np.uint8)
        img[:] = 12
        for k in range(0, W, 32):
            img[:, k:k+1] = 22
        for k in range(0, H, 32):
            img[k:k+1, :] = 22

        # moving dot based on chosen position stream if available
        xy01 = self.get_pos_xy01()
        if xy01 is not None:
            x, y = xy01[idx]
            if np.isfinite(x) and np.isfinite(y):
                u = int(np.clip(x * (W - 1), 0, W - 1))
                v = int(np.clip((1 - y) * (H - 1), 0, H - 1))
                rr = 6
                img[max(0, v-rr):min(H, v+rr+1), max(0, u-rr):min(W, u+rr+1)] = 220

        self.videoImage.setImage(img.T, autoLevels=True)
        self.videoImage.setRect(QtCore.QRectF(0, 0, W, H))

    # ---------- Footprints ----------
    def on_fp_ready(self, res: dict):
        self.fp_maxval = res["maxval"]
        self.fp_argmax = res["argmax"]
        self.fp_p99 = res["p99"]
        self.render_footprints()

    def render_footprints(self):
        if self.fp_maxval is None:
            return
        bg = np.clip(self.fp_maxval / self.fp_p99, 0, 1)
        bg_u8 = (bg * 255).astype(np.uint8)
        self.fpBgImage.setImage(bg_u8.T, autoLevels=False, levels=(0, 255))
        self.fpBgImage.setRect(QtCore.QRectF(0, 0, self.W, self.H))

        sel = self.A[:, :, self.current_neuron]
        sel_u8 = (np.clip(sel / self.fp_p99, 0, 1) * 255).astype(np.uint8)
        self.fpSelImage.setImage(sel_u8.T, autoLevels=False, levels=(0, 255))
        self.fpSelImage.setRect(QtCore.QRectF(0, 0, self.W, self.H))

    def on_fp_clicked(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        if self.fp_argmax is None or self.fp_maxval is None:
            return

        pos = event.scenePos()
        if not self.fpPlot.sceneBoundingRect().contains(pos):
            return

        vb = self.fpPlot.getViewBox()
        mp = vb.mapSceneToView(pos)
        col = int(np.floor(float(mp.x())))
        row = int(np.floor(float(mp.y())))
        if row < 0 or row >= self.H or col < 0 or col >= self.W:
            return

        if float(self.fp_maxval[row, col]) < float(self.fpClickThr.value()):
            return

        nid = int(self.fp_argmax[row, col])
        self.set_neuron(nid)

    # ---------- Map: walls overlay ----------
    def update_walls_overlay(self):
        if not self.showWallsCheck.isChecked():
            self.wallsCurve.setData([], [])
            return
        try:
            from .mm_maze_utils import NewMaze
            ma = NewMaze(6)
            # ma.wa is typically an (M,2) polyline with NaNs separating segments (often)
            x = np.asarray(ma.wa[:, 0], dtype=np.float32)
            y = np.asarray(ma.wa[:, 1], dtype=np.float32)
            self.wallsCurve.setData(x, y)
        except Exception:
            # fallback: draw a simple bounding box
            x = np.array([-0.5, 14.5, 14.5, -0.5, -0.5], dtype=np.float32)
            y = np.array([-0.5, -0.5, 14.5, 14.5, -0.5], dtype=np.float32)
            self.wallsCurve.setData(x, y)

    # ---------- Map: chunking ----------
    def _compute_chunks(self) -> List[np.ndarray]:
        """
        Returns a list of boolean masks (length T) for each chunk.
        Chunk modes:
          - All
          - Fixed duration (s)
          - N chunks
          - By bout (CSV)
        """
        T = self.T
        mode = self.chunkModeCombo.currentText()

        if mode == "All":
            m = np.ones(T, dtype=bool)
            return [m]

        if mode == "Fixed duration (s)":
            sec = float(self.chunkParamSpin.value())
            nframes = max(1, int(round(sec * self.fs)))
            masks = []
            for start in range(0, T, nframes):
                end = min(T, start + nframes)
                m = np.zeros(T, dtype=bool)
                m[start:end] = True
                masks.append(m)
            return masks

        if mode == "N chunks":
            n = max(1, int(round(float(self.chunkParamSpin.value()))))
            step = int(math.ceil(T / n))
            masks = []
            for i in range(n):
                start = i * step
                end = min(T, (i + 1) * step)
                if start >= T:
                    break
                m = np.zeros(T, dtype=bool)
                m[start:end] = True
                masks.append(m)
            return masks if masks else [np.ones(T, dtype=bool)]

        if mode == "By bout (CSV)":
            if self.data.keypoints is None or self.data.keypoints.bout is None:
                return [np.ones(T, dtype=bool)]
            b = self.data.keypoints.bout
            ok = np.isfinite(b)
            if ok.sum() == 0:
                return [np.ones(T, dtype=bool)]
            uniq = np.unique(b[ok].astype(int))
            masks = []
            for u in uniq:
                m = ok & (b.astype(int) == int(u))
                masks.append(m)
            return masks if masks else [np.ones(T, dtype=bool)]

        return [np.ones(T, dtype=bool)]

    def _sync_chunk_index_spin(self):
        masks = self._compute_chunks()
        kmax = max(0, len(masks) - 1)
        cur = int(self.chunkIndexSpin.value())
        self.chunkIndexSpin.blockSignals(True)
        self.chunkIndexSpin.setRange(0, kmax)
        self.chunkIndexSpin.setValue(min(cur, kmax))
        self.chunkIndexSpin.blockSignals(False)

    def _get_current_chunk_mask(self) -> np.ndarray:
        masks = self._compute_chunks()
        k = int(self.chunkIndexSpin.value())
        k = int(np.clip(k, 0, len(masks) - 1))
        return masks[k]

    # ---------- Map: computation + render ----------
    def on_map_params_changed(self):
        # keep chunk index range consistent
        self._sync_chunk_index_spin()
        # walls might be toggled
        self.update_walls_overlay()
        # request map recompute
        self.request_map_update()

    def request_map_update(self):
        if self.data.keypoints is None:
            self.mapPlot.setTitle("Map (no keypoints loaded)")
            self.mapImage.setImage(np.zeros((10, 10), dtype=np.float32))
            self.occOverlay.setImage(np.zeros((10, 10), dtype=np.float32))
            return

        nid = int(self.current_neuron)
        nx = int(self.binSpin.value())
        sigma = float(self.smoothSpin.value())
        minocc = int(self.minOccSpin.value())
        map_type = self.mapTypeCombo.currentText()
        pos_src = self.posSourceCombo.currentText()
        trace_src = self.traceSourceCombo.currentText()
        chunk_mode = self.chunkModeCombo.currentText()
        chunk_param = float(self.chunkParamSpin.value())
        chunk_idx = int(self.chunkIndexSpin.value())

        # cache key includes compute-affecting params
        key = (nid, nx, sigma, minocc, map_type, pos_src, trace_src, chunk_mode, chunk_param, chunk_idx)
        if key in self.map_cache:
            res = self.map_cache[key]
            if isinstance(self.map_cache, OrderedDict):
                self.map_cache.move_to_end(key)
            self._render_map_from_result(res)
            return

        self.last_map_request_id += 1
        rid = self.last_map_request_id

        # snapshot inputs for worker
        xy01 = self.get_pos_xy01()
        X = self.get_trace_matrix()
        tr = X[:, nid].astype(np.float32, copy=False)
        chunk_mask = self._get_current_chunk_mask().copy()

        def fn():
            # coords in maze system for Map tab
            xs, ys = scale_to_maze_xy(xy01, scale=15.0, yflip=False, offset=-0.5)
            # apply chunk mask
            xs2 = xs.copy()
            ys2 = ys.copy()
            tr2 = tr.copy()
            # mask out-of-chunk samples
            xs2[~chunk_mask] = np.nan
            ys2[~chunk_mask] = np.nan
            tr2[~chunk_mask] = np.nan

            xmin, xmax = -0.5, 14.5
            ymin, ymax = -0.5, 14.5

            occ, act = compute_bincount_maps(xs2, ys2, tr2, nx, xmin, xmax, ymin, ymax)

            # smooth occ + act then recompute
            if sigma > 0:
                occ_s = gaussian_blur2d(occ, sigma)
                act_s = gaussian_blur2d(act, sigma)
            else:
                occ_s, act_s = occ, act

            # build display map
            if map_type.startswith("Occupancy"):
                disp = occ_s
            elif map_type.startswith("Firing"):
                disp = act_s
            else:
                disp = np.full_like(occ_s, np.nan, dtype=np.float32)
                valid = occ_s >= max(1, minocc)
                disp[valid] = act_s[valid] / (occ_s[valid] + 1e-9)

            # mask low occ in rate map explicitly
            if map_type.startswith("Rate") and minocc > 0:
                valid = occ_s >= minocc
                disp[~valid] = np.nan

            return {
                "nx": nx,
                "disp": disp.astype(np.float32, copy=False),
                "occ": occ_s.astype(np.float32, copy=False),
                "xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax,
                "chunk_mask": chunk_mask,  # for overlay
            }

        self.threadpool.start(MapWorker(rid, fn, self.signals))

    def on_map_ready(self, request_id: int, res: dict):
        if request_id != self.last_map_request_id:
            return

        nid = int(self.current_neuron)
        nx = int(self.binSpin.value())
        sigma = float(self.smoothSpin.value())
        minocc = int(self.minOccSpin.value())
        map_type = self.mapTypeCombo.currentText()
        pos_src = self.posSourceCombo.currentText()
        trace_src = self.traceSourceCombo.currentText()
        chunk_mode = self.chunkModeCombo.currentText()
        chunk_param = float(self.chunkParamSpin.value())
        chunk_idx = int(self.chunkIndexSpin.value())

        key = (nid, nx, sigma, minocc, map_type, pos_src, trace_src, chunk_mode, chunk_param, chunk_idx)
        self.map_cache[key] = res
        if isinstance(self.map_cache, OrderedDict):
            self.map_cache.move_to_end(key)
            while len(self.map_cache) > self.map_cache_max:
                self.map_cache.popitem(last=False)
        self._render_map_from_result(res)

    def on_worker_error(self, msg: str):
        self.statusBar().showMessage(msg, 5000)
        print(msg, file=sys.stderr)

    def _render_map_from_result(self, res: dict):
        disp = res["disp"]
        occ = res["occ"]
        nx = res["nx"]
        xmin, xmax = res["xmin"], res["xmax"]
        ymin, ymax = res["ymin"], res["ymax"]

        # pyqtgraph ImageItem expects (x,y) style; we use transpose for typical row-major arrays
        self.mapImage.setImage(disp.T, autoLevels=True)
        self.mapImage.setRect(QtCore.QRectF(xmin, ymin, (xmax - xmin), (ymax - ymin)))

        # occupancy overlay: tinted alpha mask + user opacity
        map_type = self.mapTypeCombo.currentText()
        alpha = float(self.occAlphaSpin.value())

        # If user is viewing Occupancy map, the overlay is redundant/confusing
        if map_type.startswith("Occupancy"):
            self.occOverlay.setOpacity(0.0)
        else:
            self.occOverlay.setOpacity(alpha)

        # occ -> [0..1] with mild log compression
        occn = occ.copy()
        if np.nanmax(occn) > 0:
            occn = np.log1p(occn)
            occn = occn / (np.nanpercentile(occn, 99) + 1e-9)
        occn = np.clip(occn, 0, 1).astype(np.float32)

        # Image values index LUT alpha; LUT RGB is constant tint
        self.occOverlay.setImage((occn * 255).T, autoLevels=False, levels=(0, 255))
        self.occOverlay.setRect(QtCore.QRectF(xmin, ymin, (xmax - xmin), (ymax - ymin)))


        # title
        self.mapPlot.setTitle(
            f"{self.mapTypeCombo.currentText()} | neuron {self.current_neuron} | "
            f"{self.posSourceCombo.currentText()} | {self.traceSourceCombo.currentText()} | "
            f"chunk={self.chunkModeCombo.currentText()}[{self.chunkIndexSpin.value()}]"
        )

        # update overlays (traj + current position)
        self.update_map_overlays_only(chunk_mask=res.get("chunk_mask", None))

    def update_map_overlays_only(self, chunk_mask: Optional[np.ndarray] = None):
        xy01 = self.get_pos_xy01()
        if xy01 is None:
            self.trajCurve.setData([], [])
            self.trajPastCurve.setData([], [])
            self.trajFutureCurve.setData([], [])
            self.curPoint.setData([], [])
            return

        if chunk_mask is None:
            chunk_mask = self._get_current_chunk_mask()

        # precompute maze coords
        xs_all, ys_all = scale_to_maze_xy(xy01, scale=15.0, yflip=False, offset=-0.5)
        ok_all = np.isfinite(xs_all) & np.isfinite(ys_all) & chunk_mask

        # ---- full trajectory overlay (gray) ----
        if self.showTrajCheck.isChecked():
            decim = max(1, int(self.trajDecimSpin.value()))
            fr = np.where(ok_all)[0].astype(np.int64)
            fr = fr[::decim]
            xs = xs_all[fr]
            ys = ys_all[fr]

            # break across gaps to avoid straight lines
            xs, ys = nan_break_polyline(xs, ys, fr, gap_frames=50)

            a = float(self.trajAlphaSpin.value())
            self.trajCurve.setPen(pg.mkPen((200, 200, 200, int(np.clip(a, 0, 1) * 255)), width=1))
            self.trajCurve.setData(xs, ys)
        else:
            self.trajCurve.setData([], [])

        # ---- local past/future overlay (colored) ----
        show_local = hasattr(self, "showLocalTrajCheck") and self.showLocalTrajCheck.isChecked()
        win_sec = float(self.localTrajWinSpin.value()) if hasattr(self, "localTrajWinSpin") else 0.0

        if show_local and win_sec > 0:
            win_frames = max(1, int(round(win_sec * self.fs)))
            i0 = max(0, self.current_time_idx - win_frames)
            i1 = min(self.T - 1, self.current_time_idx + win_frames)

            fr = np.arange(i0, i1 + 1, dtype=np.int64)
            ok = ok_all[fr]
            fr = fr[ok]
            xs = xs_all[fr]
            ys = ys_all[fr]

            # split into past / future around current index
            past_sel = fr <= self.current_time_idx
            fut_sel  = fr >= self.current_time_idx

            fr_p = fr[past_sel]; xs_p = xs[past_sel]; ys_p = ys[past_sel]
            fr_f = fr[fut_sel];  xs_f = xs[fut_sel];  ys_f = ys[fut_sel]

            xs_p, ys_p = nan_break_polyline(xs_p, ys_p, fr_p, gap_frames=50)
            xs_f, ys_f = nan_break_polyline(xs_f, ys_f, fr_f, gap_frames=50)

            a = float(self.localTrajAlphaSpin.value()) if hasattr(self, "localTrajAlphaSpin") else 0.85
            a255 = int(np.clip(a, 0, 1) * 255)

            # past (greenish) / future (pinkish)
            self.trajPastCurve.setPen(pg.mkPen((80, 255, 180, a255), width=2))
            self.trajFutureCurve.setPen(pg.mkPen((255, 120, 200, a255), width=2))

            self.trajPastCurve.setData(xs_p, ys_p)
            self.trajFutureCurve.setData(xs_f, ys_f)
        else:
            self.trajPastCurve.setData([], [])
            self.trajFutureCurve.setData([], [])

        # ---- current position marker ----
        x, y = xy01[self.current_time_idx]
        if np.isfinite(x) and np.isfinite(y):
            xs, ys = scale_to_maze_xy(np.array([[x, y]], dtype=np.float32), scale=15.0, yflip=False, offset=-0.5)
            self.curPoint.setData([float(xs[0])], [float(ys[0])])
        else:
            self.curPoint.setData([], [])


    # ---------- ArrowMap / Traj Fig5 ----------
    def render_arrow_map(self):
        if self.data.keypoints is None:
            QtWidgets.QMessageBox.information(self, "No keypoints", "Load keypoints CSV first.")
            return
        nid = int(self.current_neuron)
        df = self.data.keypoints.df

        self.arrowMap.render(
            selected_df=df,
            C_raw=self.C_raw,
            S=self.S,
            nid=nid,
            thin_frames=int(self.thinFramesSpin.value()),
            std_mult=float(self.eventStdMult.value()),
            show_traj=True,
            traj_source=("mass" if "body" in self.posSourceCombo.currentText() else "xy"),
            traj_gap_frames=50,
            traj_alpha=0.04,
            traj_lw=1.0,
            arrow_color="blue",
        )
        if hasattr(self, "arrowDock"):
            self.arrowDock.show()
            self.arrowDock.raise_()

    def render_traj_fig5(self):
        nick = (self.trajNicknameEdit.text().strip() or self.data.traj_nickname or "").strip()
        base_dir = (self.trajBaseDirEdit.text().strip() or self.data.traj_base_dir or "").strip()
        if not nick:
            QtWidgets.QMessageBox.information(self, "Missing nickname", "Enter nickname for LoadTraj(nickname+'-tf').")
            return
        nick_to_use = nick
        work_dir = base_dir
        if base_dir:
            base_path = Path(base_dir)
            if not base_path.exists():
                QtWidgets.QMessageBox.information(self, "Traj base dir missing", f"Folder not found: {base_dir}")
                return
            if (base_path / "mm-trajectories").exists():
                traj_root = base_path / "mm-trajectories"
                work_dir = str(base_path)
            elif base_path.name.lower() == "mm-trajectories":
                traj_root = base_path
                work_dir = str(base_path.parent)
            else:
                traj_root = base_path
                work_dir = str(base_path)

            matches = list(traj_root.glob(f"{nick}-tf*"))
            if not matches:
                day_info = self._split_day_nickname(nick)
                if day_info:
                    alt = day_info[0]
                    alt_matches = list(traj_root.glob(f"{alt}-tf*"))
                    if alt_matches:
                        nick_to_use = alt
                        self.statusBar().showMessage(
                            f"Traj nickname '{nick}' not found; using '{alt}' instead.", 5000
                        )
                if nick_to_use == nick:
                    QtWidgets.QMessageBox.information(
                        self,
                        "Traj not found",
                        f"No files matching '{nick}-tf*' in {traj_root}",
                    )
                    return

        water = int(self.waterNodeSpin.value())
        ctrls = (int(self.ctrlNode1.value()), int(self.ctrlNode2.value()), int(self.ctrlNode3.value()))
        lmin = int(self.lminSpin.value())

        self.trajFig5.render_fig5(
            nickname=nick_to_use,
            base_dir=work_dir,
            water_node=water,
            control_nodes=ctrls,
            lmin=lmin,
            xlim=(0, 16000),
            ylim=(0, 120),
        )
        if hasattr(self, "trajDock"):
            self.trajDock.show()
            self.trajDock.raise_()

# ----------------------------
# main
# ----------------------------
def main():
    app = QtWidgets.QApplication(sys.argv)
    w = NeuralGUI()
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()


# Public export surface (top-level callables/classes).
__all__ = [
    n for n, v in globals().items()
    if not n.startswith("_") and callable(v)
]
