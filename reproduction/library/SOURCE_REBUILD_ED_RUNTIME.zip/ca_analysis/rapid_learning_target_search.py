"""Opportunity-adjusted target-search metrics for rapid maze learning."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def score_anchor_progress_choices(
    choice_rows: pd.DataFrame,
    graph_distances: np.ndarray,
    anchor_node: int,
    *,
    decision_col: str = "decision_id",
    chosen_col: str = "chosen",
) -> pd.DataFrame:
    """Score chosen progress toward an anchor relative to available choices.

    For each decision, the score is the chosen neighbor's reduction in shortest
    path distance minus the mean reduction available across all alternatives.
    It is therefore zero when all alternatives are equivalent, positive when
    the chosen alternative is more target-directed than the opportunity set,
    and negative when it is less target-directed.  The calculation does not
    assume binary out-degree.
    """

    required = {
        decision_col,
        chosen_col,
        "current_node",
        "alternative_id",
    }
    missing = sorted(required.difference(choice_rows.columns))
    if missing:
        raise ValueError(f"missing target-search choice columns: {missing}")
    distances = np.asarray(graph_distances, dtype=float)
    anchor = int(anchor_node)
    if distances.ndim != 2 or distances.shape[0] != distances.shape[1]:
        raise ValueError("graph_distances must be a square matrix")
    if not 0 <= anchor < distances.shape[0]:
        raise ValueError("anchor_node is outside graph_distances")

    records: list[dict[str, Any]] = []
    for decision_id, group in choice_rows.groupby(decision_col, sort=False):
        chosen = group[chosen_col].astype(bool).to_numpy()
        if int(chosen.sum()) != 1 or len(group) < 2:
            continue
        current_values = group["current_node"].astype(int).unique()
        if len(current_values) != 1:
            raise ValueError(f"decision {decision_id!r} has multiple current nodes")
        current = int(current_values[0])
        alternatives = group["alternative_id"].astype(int).to_numpy()
        if (
            current < 0
            or current >= distances.shape[0]
            or np.any(alternatives < 0)
            or np.any(alternatives >= distances.shape[0])
        ):
            continue
        progress = distances[current, anchor] - distances[alternatives, anchor]
        if not np.all(np.isfinite(progress)):
            continue
        chosen_progress = float(progress[np.flatnonzero(chosen)[0]])
        mean_progress = float(np.mean(progress))
        record = {
            decision_col: str(decision_id),
            "anchor_node": anchor,
            "current_node": current,
            "n_alternatives": int(len(group)),
            "chosen_progress_steps": chosen_progress,
            "mean_available_progress_steps": mean_progress,
            "opportunity_adjusted_progress": chosen_progress - mean_progress,
            "chosen_is_best_progress": bool(
                np.isclose(chosen_progress, float(np.max(progress)))
            ),
            "best_progress_steps": float(np.max(progress)),
        }
        for column in ("animal_id", "cohort_group", "session_id", "pair_id"):
            if column in group.columns:
                record[column] = str(group.iloc[0][column])
        records.append(record)
    return pd.DataFrame(records)


def summarize_anchor_progress(decision_scores: pd.DataFrame) -> dict[str, Any]:
    """Return an animal-level summary of opportunity-adjusted target search."""

    if decision_scores.empty:
        return {
            "n_decisions": 0,
            "mean_opportunity_adjusted_progress": np.nan,
            "median_opportunity_adjusted_progress": np.nan,
            "best_progress_choice_rate": np.nan,
        }
    values = pd.to_numeric(
        decision_scores["opportunity_adjusted_progress"], errors="coerce"
    ).to_numpy(dtype=float)
    best = decision_scores["chosen_is_best_progress"].astype(float).to_numpy()
    finite = np.isfinite(values)
    return {
        "n_decisions": int(finite.sum()),
        "mean_opportunity_adjusted_progress": (
            float(np.mean(values[finite])) if finite.any() else np.nan
        ),
        "median_opportunity_adjusted_progress": (
            float(np.median(values[finite])) if finite.any() else np.nan
        ),
        "best_progress_choice_rate": (
            float(np.mean(best[finite])) if finite.any() else np.nan
        ),
    }


__all__ = ["score_anchor_progress_choices", "summarize_anchor_progress"]
