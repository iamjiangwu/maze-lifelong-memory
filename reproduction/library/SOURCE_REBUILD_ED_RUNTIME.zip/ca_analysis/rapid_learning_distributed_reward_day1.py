"""Support selection for same-Day-1 distributed reward-code analyses."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats


def select_exposure_matched_non_target_visits(
    visits: pd.DataFrame,
    *,
    first_reward_time_s: float,
    reward_node: int,
    mode_policy: str,
    min_frames_per_visit: int,
    max_visits_per_node: int = 2,
) -> tuple[dict[tuple[int, str], list[str]], dict[str, Any], pd.DataFrame]:
    """Freeze equal-exposure pre/post non-target terminal visit selections.

    The first ``n_pre`` eligible post-discovery visits are retained before
    identifying common nodes. This prevents a long post-reward epoch from
    manufacturing support unavailable before discovery.
    """

    required = {
        "visit_id",
        "node",
        "mode_label",
        "start_time_s",
        "end_time_s",
        "n_c_frames",
    }
    missing = sorted(required.difference(visits.columns))
    if missing:
        raise KeyError(f"visit table missing columns: {missing}")
    eligible = visits.loc[
        visits["node"].astype(int).ne(int(reward_node))
        & visits["n_c_frames"].astype(int).ge(int(min_frames_per_visit))
    ].copy()
    if mode_policy == "explore_only":
        eligible = eligible.loc[eligible["mode_label"].astype(str).eq("explore")]
    elif mode_policy == "nonconsumption":
        eligible = eligible.loc[~eligible["mode_label"].astype(str).eq("drink")]
    else:
        raise ValueError("mode_policy must be explore_only or nonconsumption")
    eligible = eligible.sort_values(["start_time_s", "visit_id"]).copy()
    pre = eligible.loc[
        eligible["end_time_s"].astype(float) < float(first_reward_time_s)
    ].copy()
    post_all = eligible.loc[
        eligible["start_time_s"].astype(float) > float(first_reward_time_s)
    ].copy()
    post = post_all.head(len(pre)).copy()
    selection: dict[tuple[int, str], list[str]] = {}
    rows = []
    common_nodes = sorted(set(pre["node"].astype(int)) & set(post["node"].astype(int)))
    for node in common_nodes:
        pre_node = pre.loc[pre["node"].astype(int).eq(node)].tail(
            int(max_visits_per_node)
        )
        post_node = post.loc[post["node"].astype(int).eq(node)].head(
            int(max_visits_per_node)
        )
        quota = min(len(pre_node), len(post_node), int(max_visits_per_node))
        if quota < 1:
            continue
        pre_ids = pre_node.tail(quota)["visit_id"].astype(str).tolist()
        post_ids = post_node.head(quota)["visit_id"].astype(str).tolist()
        selection[(int(node), "pre")] = pre_ids
        selection[(int(node), "post")] = post_ids
        for epoch, ids in (("pre", pre_ids), ("post", post_ids)):
            source = pre if epoch == "pre" else post
            chosen = source.loc[source["visit_id"].astype(str).isin(ids)]
            for item in chosen.itertuples(index=False):
                rows.append(
                    {
                        "visit_id": str(item.visit_id),
                        "node": int(item.node),
                        "epoch": epoch,
                        "mode_label": str(item.mode_label),
                        "start_time_s": float(item.start_time_s),
                        "end_time_s": float(item.end_time_s),
                        "n_c_frames": int(item.n_c_frames),
                        "node_visit_quota": int(quota),
                    }
                )
    audit = {
        "mode_policy": mode_policy,
        "min_frames_per_visit": int(min_frames_per_visit),
        "max_visits_per_node": int(max_visits_per_node),
        "n_eligible_pre_non_target_visits": int(len(pre)),
        "n_eligible_post_non_target_visits_total": int(len(post_all)),
        "n_post_visits_retained_exposure_match": int(len(post)),
        "n_common_non_target_nodes": int(
            len({node for node, epoch in selection if epoch == "pre"})
        ),
        "pre_post_exposure_match_exact": bool(len(post) == len(pre)),
    }
    return selection, audit, pd.DataFrame(rows)


def benjamini_hochberg(p_values: np.ndarray) -> np.ndarray:
    """Return BH-adjusted q-values while preserving input order."""

    p = np.asarray(p_values, dtype=float)
    result = np.full(p.shape, np.nan, dtype=float)
    finite = np.flatnonzero(np.isfinite(p))
    if finite.size == 0:
        return result
    order = finite[np.argsort(p[finite])]
    ranked = p[order] * finite.size / np.arange(1, finite.size + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    result[order] = np.minimum(ranked, 1.0)
    return result


def loono_ridge_coordinate_metrics(
    x: np.ndarray, y: np.ndarray, *, alpha: float
) -> tuple[float, float, np.ndarray]:
    """Return rank score and finite continuous-loss accessibility.

    The accessibility score is ``1 - MAE / supported_y_span``. Unlike
    Spearman correlation, it remains defined when held-out predictions tie.
    """

    features = np.asarray(x, dtype=float)
    target = np.asarray(y, dtype=float)
    if features.ndim != 2 or target.ndim != 1 or features.shape[0] != target.size:
        raise ValueError("x must be node-by-feature and y must have one value per node")
    if target.size < 4 or np.unique(target).size < 2:
        return np.nan, np.nan, np.full(target.shape, np.nan, dtype=float)
    prediction = np.empty(target.size, dtype=float)
    for index in range(target.size):
        train = np.ones(target.size, dtype=bool)
        train[index] = False
        x_train = features[train]
        x_test = features[[index]]
        center = np.mean(x_train, axis=0)
        scale = np.std(x_train, axis=0)
        scale[~np.isfinite(scale) | (scale < 1e-8)] = 1.0
        z_train = (x_train - center) / scale
        z_test = (x_test - center) / scale
        y_train = target[train]
        y_center = float(np.mean(y_train))
        kernel = z_train @ z_train.T
        regularized = kernel + float(alpha) * np.eye(kernel.shape[0])
        try:
            dual_weight = np.linalg.solve(regularized, y_train - y_center)
        except np.linalg.LinAlgError:
            dual_weight = np.linalg.lstsq(regularized, y_train - y_center, rcond=None)[
                0
            ]
        prediction[index] = float(
            np.asarray(z_test @ z_train.T @ dual_weight + y_center).item()
        )
    # Graph distance has a geometry-known finite range. Clipping prevents an
    # otherwise finite but meaningless p >> n ridge extrapolation from
    # dominating the continuous-loss rescue.
    prediction = np.clip(prediction, float(np.min(target)), float(np.max(target)))
    result = stats.spearmanr(target, prediction)
    spearman = float(result.statistic) if np.isfinite(result.statistic) else np.nan
    span = float(np.max(target) - np.min(target))
    accessibility = 1.0 - float(np.mean(np.abs(prediction - target))) / span
    return spearman, accessibility, prediction
