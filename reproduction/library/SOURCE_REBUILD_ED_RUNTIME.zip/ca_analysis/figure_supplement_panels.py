from __future__ import annotations

import json
import pickle
from copy import deepcopy
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, PathPatch, Polygon, Rectangle
from matplotlib.path import Path as MplPath

from .config import REWARD_NODE, get_behav_wd
from .figure_panels import (
    DEFAULT_EXPORT_FORMATS,
    DEFAULT_MAZE_ID,
    GRAY_BLOCKS,
    _bh_adjust_pvalues,
    _add_timeline_water_drop_icon,
    _significance_text,
    apply_panel_rcparams,
    draw_gray_blocks,
    draw_maze_outline,
    get_panel_maze,
    prepare_turning_bias_four_bias_points,
    render_turning_bias_four_bias_panel,
    save_panel,
)
from .behavior import build_behav_measure_design, default_behavior_groups_260113, extract_info
from .chemo_day2_compare import extract_long_path_events, extract_reward_events
from .maze import NewMaze
from .trajectory import LoadTraj, TimeInMaze

try:
    import statsmodels.api as sm
except Exception:  # pragma: no cover - optional dependency guard for lightweight plot reuse
    sm = None


DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR = Path("figs/supplement_figure_panels")

STABLE_PF_REWARD_CONTROLS_LAYOUT = {
    "panel_size": (10.0, 5.85),
    "reference_panel_size": (10.0, 5.85),
}

RAW_EXAMPLE_TRAJECTORY_SESSION_ROWS = [
    [
        {"nickname": "434RRday1", "display_title": "Day1"},
        {"nickname": "434-3day1", "display_title": "Day91"},
    ],
    [
        {"nickname": "434RRday2", "display_title": "Day2"},
        {"nickname": "434-6day1", "display_title": "Day181"},
    ],
]

RAW_TRAJECTORY_LAYOUT = {
    "panel_size": (6.2, 6.8),
    "maze_xlim": (-1.85, 15.95),
    "maze_ylim": (15.0, -1.0),
    "grid_wspace": 0.10,
    "grid_hspace": 0.10,
    "colorbar_height_ratio": 0.08,
    "colorbar_hspace": 0.28,
    "reference_panel_size": (6.2, 6.8),
}

RAW_TRAJECTORY_COLORS = {
    "background": "white",
    "wall": "black",
    "gray_block_face": "#d8d8d8",
    "gray_block_edge": "#d8d8d8",
    "cmap": "viridis",
    "colorbar_entry_text": "white",
    "colorbar_exit_text": "#202020",
}

RAW_TRAJECTORY_LANDMARKS = {
    "show": True,
    "home": {
        "xy": (-1.33, 6.86),
        "size": 0.88,
        "facecolor": "#111111",
        "edgecolor": "#111111",
        "door_color": "white",
        "linewidth": 0.0,
        "zorder": 8,
    },
    "reward": {
        "xy": (15.18, 6.12),
        "size": 0.82,
        "facecolor": "#36a3ff",
        "edgecolor": "#0866b2",
        "highlight_color": "#c9ecff",
        "linewidth": 0.9,
        "zorder": 8,
    },
}

RAW_TRAJECTORY_STYLE = {
    "maze_wall_linewidth": 1.15,
    "gray_block_linewidth": 0.5,
    "trajectory_linewidth": 0.7,
    "trajectory_alpha": 0.86,
    "trajectory_rasterized": True,
    "max_segment_step": 1.25,
    "title_fontsize": 16.5,
    "title_pad": 6,
    "title_fontweight": "normal",
    "colorbar_entry_label": "Entry",
    "colorbar_reward_label": "Reward",
    "colorbar_label_fontsize": 12.5,
    "colorbar_label_fontweight": "bold",
}

BEHAVIOR_ACCUMULATION_MONTH_COLORS = {
    0: "#8BBDEB",
    3: "#F5A18E",
    6: "#F37B6D",
    9: "#DB4B4B",
    12: "#9B0E13",
}

BEHAVIOR_ACCUMULATION_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_MONTH_COLORS[0],
    "return": "#DA2323",
    "experienced_day2": "green",
    "0mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[0],
    "3mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[3],
    "6mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[6],
    "9mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[9],
    "12mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[12],
    "axis": "#202020",
    "grid": "#d8d8d8",
}

BEHAVIOR_ACCUMULATION_LAYOUT = {
    "panel_size": (6.3, 2.75),
    "wspace": 0.36,
    "reference_panel_size": (6.3, 2.75),
}

BEHAVIOR_ACCUMULATION_STYLE = {
    "time_step_sec": 10.0,
    "coverage_fraction": 0.80,
    "band_multiplier": 1.0,
    "line_width": 2.0,
    "line_alpha": 0.96,
    "band_alpha": 0.18,
    "session_line_width": 0.45,
    "session_line_alpha": 0.12,
    "show_session_curves": False,
    "show_band": True,
    "use_coverage_window": True,
    "xlim_minutes": None,
    "title_fontsize": 11.5,
    "axis_label_fontsize": 10.5,
    "tick_labelsize": 9.5,
    "legend_fontsize": 9.5,
    "legend_loc": "upper left",
    "spine_top": False,
    "spine_right": False,
    "grid_alpha": 0.35,
}

BEHAVIOR_ACCUMULATION_LABELS = {
    "reward": {
        "title": "Rewards",
        "ylabel": "Cumulative rewards",
    },
    "long_path_reward": {
        "title": "Long bouts",
        "ylabel": "Cumulative long bouts",
    },
    "xlabel": "Time in maze (min)",
    "group_labels": {
        "naive": "Naive night",
        "return": "Return night",
        "experienced_day2": "Second night",
        "0mo": "Naive night",
        "3mo": "3 mo return",
        "6mo": "6 mo return",
        "9mo": "9 mo return",
        "12mo": "12 mo return",
    },
}

SPEED_MODE_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_COLORS["naive"],
    "return": BEHAVIOR_ACCUMULATION_COLORS["return"],
    "experienced_day2": "#2E7D32",
    "axis": "#202020",
    "grid": "#d8d8d8",
}

SPEED_MODE_LAYOUT = {
    "panel_size": (11.0, 2.75),
    "scope_grid_panel_size": (11.0, 8.6),
    "wspace": 0.08,
    "scope_grid_hspace": 0.20,
    "left": 0.075,
    "right": 0.995,
    "bottom": 0.12,
    "top": 0.78,
    "scope_grid_top": 0.91,
    "scope_grid_bottom": 0.07,
    "reference_panel_size": (11.0, 2.75),
}

SPEED_MODE_STYLE = {
    "line_width": 1.75,
    "marker_size": 4.5,
    "single_point_marker_size": None,
    "capsize": 3.2,
    "elinewidth": 1.35,
    "single_point_errorbar_color": None,
    "single_point_linestyle": "none",
    "shared_ylim": (0.0, 15.0),
    "xticks": (0, 3, 6, 9, 12),
    "title_fontsize": 10.5,
    "suptitle_fontsize": 11.0,
    "axis_label_fontsize": 9.5,
    "tick_labelsize": 8.5,
    "legend_fontsize": 8.8,
    "legend_loc": "upper left",
    "scope_label_x": -0.24,
    "scope_label_fontsize": 9.2,
    "grid_alpha": 0.30,
    "grid_linewidth": 0.45,
    "spine_top": True,
    "spine_right": True,
}

SPEED_MODE_LABELS = {
    "suptitle": "Bodymass speed by mode, first {scope_min:g} maze min; shared y-axis 0-15 cm/s",
    "scope_grid_suptitle": "Bodymass speed by mode and maze-time window; shared y-axis 0-15 cm/s",
    "ylabel": "Bodymass speed (cm/s)",
    "xlabel": "Month group",
    "scope_label": "{scope_min:g} min",
    "group_labels": {
        "naive": "Naive night",
        "return": "Return night",
        "experienced_day2": "Second night",
    },
    "mode_titles": {
        "all": "All modes",
        "explore": "Explore only",
        "reward": "Reward/drink only",
    },
}

EXPLORATION_CYCLE_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_COLORS["naive"],
    "return": BEHAVIOR_ACCUMULATION_COLORS["return"],
    "experienced_day2": "#2E7D32",
    "0mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[0],
    "3mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[3],
    "6mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[6],
    "9mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[9],
    "12mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[12],
    "axis": "#202020",
    "grid": "#d8d8d8",
}

EXPLORATION_CYCLE_LAYOUT = {
    "panel_size": (3.45, 2.55),
    "reference_panel_size": (3.45, 2.55),
}

EXPLORATION_CYCLE_STYLE = {
    "summary_kind": "mean_sem",
    "line_width": 1.9,
    "marker_size": 2.1,
    "markers": {
        "naive": "o",
        "return": "o",
        "experienced_day2": "o",
        "0mo": "o",
        "3mo": "o",
        "6mo": "o",
        "9mo": "o",
        "12mo": "o",
    },
    "linestyles": {
        "naive": "-",
        "return": "-",
        "experienced_day2": "-",
        "0mo": "-",
        "3mo": "-",
        "6mo": "-",
        "9mo": "-",
        "12mo": "-",
    },
    "band_alpha": 0.13,
    "show_band": True,
    "line_alpha": 0.98,
    "title_fontsize": 9.5,
    "axis_label_fontsize": 8.8,
    "tick_labelsize": 8.2,
    "legend_fontsize": 8.0,
    "legend_loc": "lower right",
    "legend_bbox_to_anchor": None,
    "show_legend_counts": True,
    "min_support": 1,
    "grid_alpha": 0.22,
    "spine_top": False,
    "spine_right": False,
    "xlim": None,
    "xticks": None,
    "ylim": (0.0, None),
}

EXPLORATION_CYCLE_LABELS = {
    "title": "Exploration efficiency",
    "xlabel": "32-unique block index",
    "ylabel": "Efficiency (32/N)",
    "group_labels": {
        "naive": "Naive night",
        "return": "Return night",
        "experienced_day2": "Second night",
        "0mo": "Naive night",
        "3mo": "3 mo",
        "6mo": "6 mo",
        "9mo": "9 mo",
        "12mo": "12 mo",
    },
}

REWARD_PERFORMANCE_METRICS = (
    "ti1",
    "wd",
    "nose_decisions_to_first_reward",
    "nose_tiles_to_first_reward",
)

REWARD_PERFORMANCE_LAYOUT = {
    "panel_size": (6.8, 4.8),
    "ncols": 2,
    "wspace": 0.36,
    "hspace": 0.44,
    "left": 0.10,
    "right": 0.98,
    "bottom": 0.14,
    "top": 0.94,
    "reference_panel_size": (6.8, 4.8),
}

REWARD_PERFORMANCE_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_COLORS["naive"],
    "return": BEHAVIOR_ACCUMULATION_COLORS["return"],
    "experienced_day2": EXPLORATION_CYCLE_COLORS["experienced_day2"],
    "0mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[0],
    "3mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[3],
    "6mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[6],
    "9mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[9],
    "12mo": BEHAVIOR_ACCUMULATION_MONTH_COLORS[12],
    "second": EXPLORATION_CYCLE_COLORS["experienced_day2"],
    "edge": "none",
    "error": "#202020",
    "axis": "#202020",
    "grid": "#d8d8d8",
}

REWARD_PERFORMANCE_STYLE = {
    "bar_width": 0.62,
    "bar_alpha": 0.72,
    "bar_linewidth": 0.0,
    "errorbar_capsize": 2.8,
    "errorbar_linewidth": 0.9,
    "point_size": 11.0,
    "point_alpha": 0.72,
    "point_jitter": 0.055,
    "point_seed": 0,
    "title_fontsize": 8.8,
    "axis_label_fontsize": 8.2,
    "tick_labelsize": 7.4,
    "xtick_rotation": 0.0,
    "month_xtick_rotation": 0.0,
    "annotation": True,
    "annotation_p_col": "cluster_p",
    "annotation_p_adjust": "displayed_bh",
    "annotation_show_ns": False,
    "annotation_linewidth": 1.0,
    "annotation_fontsize": 8.0,
    "annotation_fontweight": "bold",
    "annotation_y_start": None,
    "annotation_step": None,
    "annotation_offset_fraction": 0.06,
    "annotation_step_fraction": 0.08,
    "annotation_tick_fraction": 0.25,
    "annotation_text_offset_fraction": 0.10,
    "annotation_ylim_pad_fraction": 0.08,
    "spine_top": False,
    "spine_right": False,
    "grid_alpha": 0.22,
    "show_grid": True,
}

REWARD_PERFORMANCE_LABELS = {
    "metric_titles": {
        "ti1": "",
        "wd": "",
        "nose_decisions_to_first_reward": "",
        "nose_tiles_to_first_reward": "",
    },
    "metric_ylabels": {
        "ti1": "First reward latency (s)",
        "wd": "Max entry-to-reward latency (s)",
        "nose_decisions_to_first_reward": "Decisions before first reward",
        "nose_tiles_to_first_reward": "Maze-cell transitions before first reward",
    },
    "group_labels": {
        "naive": "Naive\nnight",
        "return": "Return\nnight",
        "experienced_day2": "Second\nnight",
    },
}

TURNING_BIAS_RETURN_SECOND_LAYOUT = {
    "reference_panel_size": (5.6, 2.7),
    "panel_size": (5.6, 2.7),
    "grid_wspace": 0.34,
}

TURNING_BIAS_RETURN_SECOND_COLORS = {
    "LTM": "#DA2323",
    "experienced": EXPLORATION_CYCLE_COLORS["experienced_day2"],
    "reference": "black",
}

TURNING_BIAS_RETURN_SECOND_STYLE = {
    "marker": "o",
    "marker_size": 4.4,
    "marker_alpha": 0.58,
    "reference_marker": "+",
    "reference_marker_size": 8.2,
    "reference_markeredgewidth": 1.5,
    "reference_halo": True,
    "reference_halo_marker_size": 10.0,
    "reference_halo_markeredgewidth": 3.0,
    "reference_halo_color": "white",
    "reference_linewidth": 0.55,
    "reference_alpha": 0.12,
    "show_reference_lines": True,
    "legend_fontsize": 6.8,
    "legend_markerscale": 0.80,
    "legend_handletextpad": 0.35,
    "legend_labelspacing": 0.25,
    "legend_loc": "lower left",
    "show_counts_in_legend": False,
    "equal_aspect": True,
    "xlim": (0.0, 1.0),
    "ylim": (0.0, 1.0),
}

TURNING_BIAS_RETURN_SECOND_LABELS = {
    "reference": "random",
    "group_labels": {
        "LTM": "Return night",
        "experienced": "Second night",
    },
}

TURNING_BIAS_SELECTED_CHUNKS = (1, 2, 8, 32)

TURNING_BIAS_SELECTED_CHUNK_LAYOUT = {
    "reference_panel_size": (7.8, 4.55),
    "panel_size": (7.8, 4.55),
    "left": 0.075,
    "right": 0.995,
    "bottom": 0.095,
    "top": 0.885,
    "wspace": 0.20,
    "hspace": 0.38,
}

TURNING_BIAS_SELECTED_CHUNK_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_COLORS["naive"],
    "LTM": BEHAVIOR_ACCUMULATION_COLORS["return"],
    "experienced": EXPLORATION_CYCLE_COLORS["experienced_day2"],
    "reference": "black",
}

TURNING_BIAS_SELECTED_CHUNK_STYLE = {
    "marker_size": 14.0,
    "marker_alpha": 0.48,
    "marker_linewidth": 0.0,
    "mean_marker": "D",
    "mean_marker_size": 28.0,
    "mean_marker_edgecolor": "black",
    "mean_marker_linewidth": 0.45,
    "reference_marker": "+",
    "reference_marker_size": 7.0,
    "reference_markeredgewidth": 1.2,
    "reference_linewidth": 0.55,
    "reference_alpha": 0.16,
    "grid_color": "#d8d8d8",
    "grid_linewidth": 0.35,
    "grid_alpha": 0.32,
    "title_fontsize": 8.7,
    "axis_label_fontsize": 8.4,
    "tick_labelsize": 7.2,
    "legend_fontsize": 7.8,
    "legend_marker_size": 5.2,
    "legend_mean_marker_size": 4.7,
    "legend_bbox_to_anchor": (0.52, 1.03),
    "legend_ncol": 3,
    "legend_handletextpad": 0.35,
    "legend_columnspacing": 1.1,
    "xlim": (0.0, 1.0),
    "ylim": (0.0, 1.0),
    "xticks": (0.0, 0.5, 1.0),
    "yticks": (0.0, 0.5, 1.0),
    "equal_aspect": True,
    "show_reference_lines": True,
}

TURNING_BIAS_SELECTED_CHUNK_LABELS = {
    "reference": "random",
    "mean": "Group mean",
    "chunk_labels": {
        1: "Full",
        2: "First 1/2",
        8: "First 1/8",
        32: "First 1/32",
    },
    "group_labels": {
        "naive": "Naive night",
        "LTM": "Return night",
        "experienced": "Second night",
    },
}

TURNING_BIAS_SIMULATOR_LAYOUT = {
    "reference_panel_size": (5.15, 2.85),
    "panel_size": (5.15, 2.85),
    "left": 0.15,
    "right": 0.985,
    "bottom": 0.19,
    "top": 0.78,
}

TURNING_BIAS_DEPTH_PBS_LAYOUT = {
    "reference_panel_size": (4.75, 2.95),
    "panel_size": (4.75, 2.95),
    "left": 0.16,
    "right": 0.99,
    "bottom": 0.20,
    "top": 0.78,
}

TURNING_BIAS_GRAPHITE_COLORS = {
    "four_bias": "#858B92",
    "depth_stratified": "#1F2A33",
    1: "#A9AFB5",
    2: "#7E878F",
    8: "#4D5963",
    32: "#1F2A33",
    "zero": "black",
    "reference": "black",
    "grid": "#d8d8d8",
}

TURNING_BIAS_SIMULATOR_STYLE = {
    "model_order": ("four_bias", "depth_stratified"),
    "model_markers": {
        "four_bias": "o",
        "depth_stratified": "s",
    },
    "line_width": 1.55,
    "marker_size": 4.3,
    "capsize": 2.2,
    "axis_label_fontsize": 8.8,
    "tick_labelsize": 7.9,
    "legend_fontsize": 8.0,
    "legend_bbox_to_anchor": (0.53, 1.23),
    "legend_ncol": 2,
    "legend_handlelength": 1.55,
    "legend_handletextpad": 0.45,
    "legend_columnspacing": 0.95,
    "xlim_pad_left": 0.16,
    "xlim_pad_right": 0.70,
    "ylim": (0.0, 112.0),
    "yticks": (0.0, 25.0, 50.0, 75.0, 100.0),
    "grid_alpha": 0.38,
    "grid_linewidth": 0.4,
    "zero_alpha": 0.25,
    "reference_alpha": 0.35,
    "reference_linewidth": 0.7,
}

TURNING_BIAS_DEPTH_PBS_STYLE = {
    "chunk_order": TURNING_BIAS_SELECTED_CHUNKS,
    "chunk_markers": {
        1: "o",
        2: "s",
        8: "^",
        32: "D",
    },
    "line_width": 1.6,
    "marker_size": 4.35,
    "capsize": 2.0,
    "axis_label_fontsize": 8.8,
    "tick_labelsize": 8.0,
    "legend_fontsize": 7.8,
    "legend_bbox_to_anchor": (0.5, 1.23),
    "legend_ncol": 4,
    "legend_handlelength": 1.35,
    "legend_handletextpad": 0.35,
    "legend_columnspacing": 0.75,
    "ylim": (-0.035, 0.255),
    "yticks": (0.0, 0.1, 0.2),
    "grid_alpha": 0.30,
    "grid_linewidth": 0.4,
    "zero_alpha": 0.24,
    "zero_linewidth": 0.65,
}

TURNING_BIAS_SIMULATOR_LABELS = {
    "ylabel": "Gap explained (%)",
    "model_labels": {
        "four_bias": "4-bias walker",
        "depth_stratified": r"Depth-stratified $P_{\mathrm{BS}}$",
    },
    "chunk_labels": TURNING_BIAS_SELECTED_CHUNK_LABELS["chunk_labels"],
}

TURNING_BIAS_DEPTH_PBS_LABELS = {
    "ylabel": r"Return - naive $P_{\mathrm{BS}}$",
    "chunk_labels": TURNING_BIAS_SELECTED_CHUNK_LABELS["chunk_labels"],
    "stratum_labels": {
        "Lo_shallow": "Shallow\nL1-2",
        "Lo_mid": "Mid\nL3-4",
        "Lo_deep": "Deep\nL5",
    },
}

FOV_DISPLACEMENT_LAYOUT = {
    "reference_panel_size": (6.1, 2.6),
    "panel_size": (6.1, 2.6),
    "left": 0.105,
    "right": 0.985,
    "bottom": 0.19,
    "top": 0.89,
    "wspace": 0.38,
    "xy_panel_width_ratio": 0.92,
    "magnitude_panel_width_ratio": 1.18,
}

FOV_DISPLACEMENT_COLORS = {
    "animal_line": "#9AA1A8",
    "animal_point": "#4D5963",
    "manual_edge": "#B26D21",
    "mean": "#111111",
    "sem": "#111111",
    "grid": "#d8d8d8",
    "axis": "#202020",
    "zero": "#202020",
}

FOV_DISPLACEMENT_STYLE = {
    "animal_linewidth": 0.75,
    "animal_line_alpha": 0.34,
    "animal_marker_size": 13.0,
    "animal_marker_alpha": 0.52,
    "manual_marker_size": 21.0,
    "manual_marker_linewidth": 0.9,
    "mean_linewidth": 1.55,
    "mean_marker_size": 4.4,
    "errorbar_capsize": 2.3,
    "errorbar_linewidth": 0.95,
    "min_summary_n": 2,
    "mark_manual_overrides": False,
    "jitter": 0.055,
    "jitter_seed": 13,
    "xy_margin_fraction": 0.11,
    "xy_scale_bar_um": 100.0,
    "xy_scale_bar_label": "100 um",
    "xy_scale_bar_linewidth": 1.2,
    "axis_label_fontsize": 8.4,
    "tick_labelsize": 7.4,
    "title_fontsize": 8.8,
    "annotation_fontsize": 7.2,
    "grid_alpha": 0.24,
    "spine_top": False,
    "spine_right": False,
}

FOV_DISPLACEMENT_LABELS = {
    "xy_title": "FOV drift path",
    "magnitude_title": "Displacement over experience",
    "xy_xlabel": "Cumulative x shift (um)",
    "xy_ylabel": "Cumulative y shift (um)",
    "magnitude_xlabel": None,
    "magnitude_ylabel": "FOV displacement from first footprint (um)",
    "n_label": "n = {n_animals} animals",
    "manual_label": "manual shift",
}

CELLREG_RELIABILITY_LAYOUT = {
    "reference_panel_size": (6.2, 2.65),
    "panel_size": (2.85, 2.35),
    "hist_only_panel_size": (2.75, 2.35),
    "left": 0.20,
    "right": 0.985,
    "bottom": 0.22,
    "top": 0.96,
    "wspace": 0.35,
    "hist_width_ratio": 1.12,
    "pair_width_ratio": 1.0,
}

CELLREG_RELIABILITY_COLORS = {
    "bar": "#4D5963",
    "bar_edge": "white",
    "point": "#858B92",
    "point_edge": "#1F2A33",
    "summary": "#111111",
    "threshold": "#B26D21",
    "grid": "#d8d8d8",
    "axis": "#202020",
}

CELLREG_RELIABILITY_STYLE = {
    "bar_alpha": 0.86,
    "bar_linewidth": 0.4,
    "bin_width": None,
    "threshold": 0.95,
    "threshold_values": (),
    "show_text": False,
    "show_titles": False,
    "threshold_linewidth": 1.0,
    "threshold_linestyle": "--",
    "point_size": 24.0,
    "point_alpha": 0.68,
    "point_linewidth": 0.25,
    "summary_linewidth": 1.15,
    "axis_label_fontsize": 8.4,
    "tick_labelsize": 7.4,
    "title_fontsize": 8.8,
    "annotation_fontsize": 7.2,
    "grid_alpha": 0.24,
    "xlim_hist": (0.0, 1.0),
    "ylim_fraction": (0.0, 1.03),
    "spine_top": False,
    "spine_right": False,
}

CELLREG_RELIABILITY_LABELS = {
    "hist_title": "CellReg pair reliability",
    "pair_title": "Session-pair summary",
    "hist_xlabel": "Registration score",
    "hist_ylabel": "Neuron number",
    "pair_xlabel": "Registered pairs / unique clusters (%)",
    "pair_ylabel": r"Registered pairs with $P_{\mathrm{same}} \geq 0.95$ (%)",
    "threshold_label": r"$P_{\mathrm{same}}=0.95$",
}

DECODING_ERROR_HEATMAP_EXCLUDED_UNREWARDED_0V3_SRCS = {
    "837day1",
    "838day1",
    "839day1",
    "842day1",
    "862day1",
}

DECODING_ERROR_HEATMAP_REWARD_BIN = 103
DECODING_ERROR_HEATMAP_CONTROL_BINS = (91, 121, 133)

DECODING_ERROR_HEATMAP_LAYOUT = {
    "panel_size": (8.1, 4.55),
    "left": 0.055,
    "right": 0.895,
    "bottom": 0.060,
    "top": 0.910,
    "wspace": 0.08,
    "hspace": 0.25,
    "colorbar_left": 0.948,
    "colorbar_bottom": 0.12,
    "colorbar_width": 0.016,
    "colorbar_height": 0.75,
    "row_label_x": 0.024,
    "column_label_y": 0.945,
    "packed_panel_size": (9.6, 5.30),
    "packed_n_cols": 11,
    "packed_left": 0.045,
    "packed_right": 0.925,
    "packed_bottom": 0.045,
    "packed_top": 0.940,
    "packed_wspace": 0.020,
    "packed_hspace": 0.22,
    "packed_section_hspace": 0.22,
    "average_panel_size": (7.0, 4.85),
    "average_n_cols": 3,
    "average_left": 0.035,
    "average_right": 0.910,
    "average_bottom": 0.045,
    "average_top": 0.930,
    "average_wspace": 0.045,
    "average_hspace": 0.18,
    "average_colorbar_left": 0.938,
    "average_colorbar_bottom": 0.135,
    "average_colorbar_width": 0.018,
    "average_colorbar_height": 0.73,
}

DECODING_ERROR_HEATMAP_COLORS = {
    "cmap": "viridis",
    "bad": "#f2f2f2",
    "reward_square": "#2F7EBB",
    "reward_icon_face": "#36a3ff",
    "reward_icon_edge": "#0866b2",
    "control_square": "#7f7f7f",
    "title": "#202020",
    "axis_label": "#202020",
}

DECODING_ERROR_HEATMAP_STYLE = {
    "n_bins_x": 15,
    "n_bins_y": 15,
    "vmin": 0.0,
    "vmax": None,
    "vmax_percentile": 98.0,
    "interpolation": "nearest",
    "invert_yaxis": True,
    "column_label_fontsize": 7.6,
    "row_label_fontsize": 8.4,
    "packed_title_fontsize": 7.0,
    "packed_title_pad": 1.2,
    "average_title_fontsize": 8.0,
    "average_title_pad": 2.0,
    "average_mode": "equal_pair",
    "average_min_support_pairs": None,
    "average_min_support_fraction": None,
    "average_show_maze_outline": True,
    "average_maze_wall_linewidth": 0.65,
    "reward_square_linewidth": 1.35,
    "reward_square_size": 1.08,
    "control_square_linewidth": 1.35,
    "control_square_size": 1.08,
    "control_screen_square_size": 24.0,
    "water_icon_size": 7.5,
    "water_icon_linewidth": 0.45,
    "water_icon_x_offset_points": 4.3,
    "tick_labelsize": 7.0,
    "colorbar_labelsize": 8.0,
}

DECODING_ERROR_HEATMAP_LABELS = {
    "colorbar": "Decoding error (bins)",
    "special_transition_label": "D1-D1b",
    "all_average_label": "All",
}

EQUAL_TIME_RATE_CONTROL_VARIANTS = ("d1v1", "d1v2", "d2v1", "d2v2")

EQUAL_TIME_RATE_CONTROL_LAYOUT = {
    "delta_panel_size": (3.25, 3.15),
    "absolute_panel_size": (2.25, 3.15),
    "left": 0.18,
    "right": 0.985,
    "bottom": 0.18,
    "top": 0.94,
    "reference_panel_size": (3.25, 3.15),
}

EQUAL_TIME_RATE_CONTROL_COLORS = {
    "bar": "#D9D9D9",
    "point": "#303030",
    "line": "#A8A8A8",
    "mean": "black",
    "error": "black",
    "axis": "#2F2F2F",
    "zero": "#6A6A6A",
    "annotation": "black",
}

EQUAL_TIME_RATE_CONTROL_STYLE = {
    "bar_width": 0.62,
    "bar_alpha": 0.72,
    "bar_linewidth": 0.0,
    "errorbar_capsize": 3.0,
    "errorbar_linewidth": 1.0,
    "point_size": 13.0,
    "point_alpha": 0.54,
    "point_jitter": 0.075,
    "point_seed": 20260514,
    "paired_line_alpha": 0.38,
    "paired_linewidth": 0.75,
    "paired_point_alpha": 0.66,
    "paired_jitter": 0.025,
    "paired_seed": 20260515,
    "mean_linewidth": 1.4,
    "mean_marker_size": 4.5,
    "annotation_fontsize": 8.0,
    "annotation_fontweight": "bold",
    "annotation_linewidth": 0.9,
    "annotation_offset_fraction": 0.08,
    "annotation_height_fraction": 0.035,
    "annotation_text_offset_fraction": 0.025,
    "ylim_pad_bottom_fraction": 0.12,
    "ylim_pad_top_fraction": 0.17,
    "axis_label_fontsize": 8.2,
    "tick_labelsize": 7.4,
    "spine_top": False,
    "spine_right": False,
}

EQUAL_TIME_RATE_CONTROL_LABELS = {
    "variant_labels": {
        "d1v1": "Day 1\nvs Day 1",
        "d1v2": "Day 1\nvs Day 2",
        "d2v1": "Day 2\nvs Day 1",
        "d2v2": "Day 2\nvs Day 2",
    },
    "delta_ylabel": "Maze - outside-maze\nensemble-rate correlation (r)",
    "absolute_ylabel": "Ensemble-rate\ncorrelation (r)",
    "outside_label": "Outside",
    "maze_label": "Maze",
}

DECODER_CONTROL_METHOD_ORDER = ("full", "frame_balanced", "visit_balanced")
DECODER_CONTROL_SOURCE_ORDER = ("D1 source", "D2 source")

DECODER_CONTROL_LAYOUT = {
    "panel_size": (6.0, 2.45),
    "left": 0.09,
    "right": 0.985,
    "bottom": 0.20,
    "top": 0.90,
    "wspace": 1.0,
    "reference_panel_size": (6.0, 2.45),
}

DECODER_CONTROL_COLORS = {
    "full": "#6E6E6E",
    "frame_balanced": "#4E8A8C",
    "visit_balanced": "#78A65A",
    "d1_source": "#565656",
    "d2_source": "#9A9A9A",
    "point_edge": "white",
    "error": "#333333",
    "axis": "#2F2F2F",
    "zero": "#BDBDBD",
    "annotation": "black",
}

DECODER_CONTROL_STYLE = {
    "primary_bar_width": 0.56,
    "comparison_bar_width": 0.31,
    "bar_alpha": 0.72,
    "comparison_bar_alpha": 0.70,
    "errorbar_linewidth": 0.9,
    "errorbar_capsize": 2.2,
    "point_size": 15.0,
    "comparison_point_size": 13.0,
    "point_alpha": 0.82,
    "comparison_point_alpha": 0.74,
    "point_linewidth": 0.28,
    "comparison_point_linewidth": 0.26,
    "point_jitter": 0.10,
    "comparison_point_jitter_scale": 0.50,
    "ylim": (-9.1, 1.25),
    "annotation_y": 0.72,
    "annotation_fontsize": 8.0,
    "title_fontsize": 9.0,
    "title_pad": 3.0,
    "axis_label_fontsize": 9.0,
    "tick_labelsize": 8.0,
    "legend_fontsize": 7.4,
    "legend_loc": "lower left",
    "legend_bbox_to_anchor": (-0.02, 0.00),
    "legend_handlelength": 1.4,
    "spine_top": False,
    "spine_right": False,
}

DECODER_CONTROL_LABELS = {
    "method_labels": {
        "full": "Uniform\nprior",
        "frame_balanced": "Frame\nbalanced",
        "visit_balanced": "Visit\nbalanced",
    },
    "source_labels": {
        "D1 source": "D1 source",
        "D2 source": "D2 source",
    },
    "primary_title": "D1 source",
    "comparison_title": "D1 vs D2 source",
    "ylabel": "Reward - control error (bins)",
}

REWARD_PROXY_LOCATION_PAIR_LAYOUT = {
    "panel_size": (7.35, 2.55),
    "width_ratios": (0.95, 1.0, 1.0, 1.0),
    "wspace": 0.46,
    "reference_panel_size": (7.35, 2.55),
}

REWARD_PROXY_LOCATION_PAIR_COLORS = {
    "water": "#36a3ff",
    "control": "#9A9A9A",
    "pair_line": "#8A8A8A",
    "point_edge": "white",
    "error": "#202020",
    "axis": "#2F2F2F",
    "zero": "#D5D5D5",
    "annotation": "black",
}

REWARD_PROXY_LOCATION_PAIR_STYLE = {
    "bar_width": 0.56,
    "bar_alpha": 0.55,
    "errorbar_linewidth": 0.95,
    "errorbar_capsize": 2.2,
    "point_size": 12.0,
    "point_alpha": 0.84,
    "point_linewidth": 0.35,
    "paired_line_alpha": 0.32,
    "paired_linewidth": 0.70,
    "paired_jitter": 0.035,
    "paired_seed": 20260518,
    "bracket_offset_fraction": 0.08,
    "bracket_height_fraction": 0.035,
    "annotation_fontsize": 8.5,
    "annotation_linewidth": 0.9,
    "title_fontsize": 8.2,
    "title_pad": 3.5,
    "axis_label_fontsize": 8.6,
    "tick_labelsize": 7.6,
    "pv_ylim": (0.0, 0.80),
    "decoder_ylim": (0.0, 14.0),
    "spine_top": False,
    "spine_right": False,
}

REWARD_PROXY_LOCATION_PAIR_LABELS = {
    "pv_title": "PV correlation",
    "decoder_titles": {
        "uniform_full": "Full uniform",
        "frame_balanced": "Frame balanced",
        "visit_balanced": "Visit balanced",
    },
    "pv_ylabel": "Location PV correlation (r)",
    "decoder_ylabel": "Decoding error (bins)",
    "water_label": "Water",
    "control_label": "Control\nmean",
}


def _merged_dict(base: dict, overrides: dict | None = None) -> dict:
    merged = deepcopy(base)
    if overrides:
        for key, value in overrides.items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = _merged_dict(merged[key], value)
            else:
                merged[key] = value
    return merged


def get_raw_trajectory_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(RAW_TRAJECTORY_LAYOUT, overrides)


def get_raw_trajectory_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(RAW_TRAJECTORY_COLORS, overrides)


def get_raw_trajectory_landmarks(overrides: dict | None = None) -> dict:
    return _merged_dict(RAW_TRAJECTORY_LANDMARKS, overrides)


def get_raw_trajectory_style(overrides: dict | None = None) -> dict:
    return _merged_dict(RAW_TRAJECTORY_STYLE, overrides)


def get_behavior_accumulation_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(BEHAVIOR_ACCUMULATION_LAYOUT, overrides)


def get_behavior_accumulation_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(BEHAVIOR_ACCUMULATION_COLORS, overrides)


def get_behavior_accumulation_style(overrides: dict | None = None) -> dict:
    return _merged_dict(BEHAVIOR_ACCUMULATION_STYLE, overrides)


def get_behavior_accumulation_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(BEHAVIOR_ACCUMULATION_LABELS, overrides)


def get_speed_mode_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(SPEED_MODE_LAYOUT, overrides)


def get_speed_mode_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(SPEED_MODE_COLORS, overrides)


def get_speed_mode_style(overrides: dict | None = None) -> dict:
    return _merged_dict(SPEED_MODE_STYLE, overrides)


def get_speed_mode_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(SPEED_MODE_LABELS, overrides)


def get_exploration_cycle_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(EXPLORATION_CYCLE_LAYOUT, overrides)


def get_exploration_cycle_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(EXPLORATION_CYCLE_COLORS, overrides)


def get_exploration_cycle_style(overrides: dict | None = None) -> dict:
    return _merged_dict(EXPLORATION_CYCLE_STYLE, overrides)


def get_exploration_cycle_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(EXPLORATION_CYCLE_LABELS, overrides)


def get_reward_performance_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PERFORMANCE_LAYOUT, overrides)


def get_reward_performance_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PERFORMANCE_COLORS, overrides)


def get_reward_performance_style(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PERFORMANCE_STYLE, overrides)


def get_reward_performance_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PERFORMANCE_LABELS, overrides)


def get_turning_bias_return_second_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_RETURN_SECOND_LAYOUT, overrides)


def get_turning_bias_return_second_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_RETURN_SECOND_COLORS, overrides)


def get_turning_bias_return_second_style(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_RETURN_SECOND_STYLE, overrides)


def get_turning_bias_return_second_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_RETURN_SECOND_LABELS, overrides)


def get_turning_bias_selected_chunk_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SELECTED_CHUNK_LAYOUT, overrides)


def get_turning_bias_selected_chunk_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SELECTED_CHUNK_COLORS, overrides)


def get_turning_bias_selected_chunk_style(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SELECTED_CHUNK_STYLE, overrides)


def get_turning_bias_selected_chunk_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SELECTED_CHUNK_LABELS, overrides)


def get_turning_bias_simulator_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SIMULATOR_LAYOUT, overrides)


def get_turning_bias_depth_pbs_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_DEPTH_PBS_LAYOUT, overrides)


def get_turning_bias_graphite_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_GRAPHITE_COLORS, overrides)


def get_turning_bias_simulator_style(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SIMULATOR_STYLE, overrides)


def get_turning_bias_depth_pbs_style(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_DEPTH_PBS_STYLE, overrides)


def get_turning_bias_simulator_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_SIMULATOR_LABELS, overrides)


def get_turning_bias_depth_pbs_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(TURNING_BIAS_DEPTH_PBS_LABELS, overrides)


def get_fov_displacement_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(FOV_DISPLACEMENT_LAYOUT, overrides)


def get_fov_displacement_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(FOV_DISPLACEMENT_COLORS, overrides)


def get_fov_displacement_style(overrides: dict | None = None) -> dict:
    return _merged_dict(FOV_DISPLACEMENT_STYLE, overrides)


def get_fov_displacement_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(FOV_DISPLACEMENT_LABELS, overrides)


def get_cellreg_reliability_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(CELLREG_RELIABILITY_LAYOUT, overrides)


def get_cellreg_reliability_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(CELLREG_RELIABILITY_COLORS, overrides)


def get_cellreg_reliability_style(overrides: dict | None = None) -> dict:
    return _merged_dict(CELLREG_RELIABILITY_STYLE, overrides)


def get_cellreg_reliability_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(CELLREG_RELIABILITY_LABELS, overrides)


def get_decoding_error_heatmap_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODING_ERROR_HEATMAP_LAYOUT, overrides)


def get_decoding_error_heatmap_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODING_ERROR_HEATMAP_COLORS, overrides)


def get_decoding_error_heatmap_style(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODING_ERROR_HEATMAP_STYLE, overrides)


def get_decoding_error_heatmap_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODING_ERROR_HEATMAP_LABELS, overrides)


def get_equal_time_rate_control_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(EQUAL_TIME_RATE_CONTROL_LAYOUT, overrides)


def get_equal_time_rate_control_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(EQUAL_TIME_RATE_CONTROL_COLORS, overrides)


def get_equal_time_rate_control_style(overrides: dict | None = None) -> dict:
    return _merged_dict(EQUAL_TIME_RATE_CONTROL_STYLE, overrides)


def get_equal_time_rate_control_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(EQUAL_TIME_RATE_CONTROL_LABELS, overrides)


def get_decoder_control_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODER_CONTROL_LAYOUT, overrides)


def get_decoder_control_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODER_CONTROL_COLORS, overrides)


def get_decoder_control_style(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODER_CONTROL_STYLE, overrides)


def get_decoder_control_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(DECODER_CONTROL_LABELS, overrides)


def get_reward_proxy_location_pair_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PROXY_LOCATION_PAIR_LAYOUT, overrides)


def get_reward_proxy_location_pair_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PROXY_LOCATION_PAIR_COLORS, overrides)


def get_reward_proxy_location_pair_style(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PROXY_LOCATION_PAIR_STYLE, overrides)


def get_reward_proxy_location_pair_labels(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_PROXY_LOCATION_PAIR_LABELS, overrides)


def _as_session_rows(session_rows=None) -> list[list[dict]]:
    if session_rows is None:
        return deepcopy(RAW_EXAMPLE_TRAJECTORY_SESSION_ROWS)
    return [[dict(spec) for spec in row] for row in session_rows]


def _resolve_bout_indices(n_bouts: int, bout_indices=None, max_bouts: int | None = None) -> list[int]:
    if bout_indices is None:
        indices = list(range(n_bouts))
    else:
        indices = [int(idx) for idx in bout_indices]
    if max_bouts is not None:
        indices = indices[: int(max_bouts)]
    return [idx for idx in indices if 0 <= idx < n_bouts]


def _points_and_frames_from_xy_frame(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    clean = df.loc[:, ["frame", "x", "y"]].dropna(subset=["x", "y"])
    if clean.empty:
        return np.zeros((0, 2), dtype=float), np.zeros(0, dtype=int)
    points = np.column_stack((-0.5 + 15.0 * clean["x"].to_numpy(float), -0.5 + 15.0 * clean["y"].to_numpy(float)))
    frames = clean["frame"].to_numpy(dtype=int)
    return points, frames


def _global_progress_values(trajectories: list[np.ndarray]) -> list[np.ndarray]:
    total_points = sum(int(points.shape[0]) for points in trajectories)
    if total_points <= 1:
        return [np.zeros(int(points.shape[0]), dtype=float) for points in trajectories]
    progress_values = []
    offset = 0
    denom = float(total_points - 1)
    for points in trajectories:
        n_points = int(points.shape[0])
        progress_values.append((offset + np.arange(n_points, dtype=float)) / denom)
        offset += n_points
    return progress_values


def _nose_interp_path(nickname: str, behav_wd=None) -> Path:
    return Path(behav_wd or get_behav_wd()) / "selected_data" / f"{nickname}_nose_interp_data.csv"


def _extract_nose_interp_segments(
    nickname: str,
    *,
    behav_wd=None,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
    clip_until_frame: int | None = None,
    clip_meta: dict | None = None,
) -> tuple[list[np.ndarray], pd.DataFrame]:
    path = _nose_interp_path(nickname, behav_wd=behav_wd)
    if not path.exists():
        raise FileNotFoundError(f"missing nose_interp_data CSV: {path}")
    df = pd.read_csv(path, usecols=["frame", "x", "y", "bout"])
    if clip_until_frame is not None:
        df = df.loc[df["frame"] <= int(clip_until_frame)].copy()
    bout_values = sorted(int(bout) for bout in pd.Series(df["bout"].dropna().unique()).astype(int))
    selected_indices = _resolve_bout_indices(len(bout_values), bout_indices=bout_indices, max_bouts=max_bouts)
    selected_bouts = [bout_values[idx] for idx in selected_indices]

    trajectories = []
    rows = []
    for bout in selected_bouts:
        bout_df = df.loc[df["bout"].astype("Int64") == int(bout)]
        points, frames = _points_and_frames_from_xy_frame(bout_df)
        included = points.shape[0] >= int(min_points)
        if included:
            trajectories.append(points)
        rows.append(
            {
                "nickname": nickname,
                "bout_idx": int(bout),
                "n_points": int(points.shape[0]),
                "included": bool(included),
                "trajectory_source": "nose_interp_data",
                "trajectory_path": str(path),
                "_frames": frames.tolist(),
                **(clip_meta or {}),
            }
        )
    return trajectories, pd.DataFrame(rows)


def _extract_traj_pickle_segments(
    nickname: str,
    *,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
    clip_until_frame: int | None = None,
    clip_meta: dict | None = None,
) -> tuple[list[np.ndarray], pd.DataFrame]:
    """Return raw nose trajectory point arrays for one behavior session.

    Coordinates use the same maze-frame convention as the legacy trajectory
    plots: ``x = -0.5 + 15 * nose_x`` and ``y = -0.5 + 15 * nose_y``.
    """
    tf = LoadTraj(f"{nickname}-tf")
    selected_indices = _resolve_bout_indices(len(tf.ke), bout_indices=bout_indices, max_bouts=max_bouts)

    trajectories = []
    rows = []
    for bout_idx in selected_indices:
        bout_start = int(tf.fr[bout_idx][0])
        if clip_until_frame is not None and bout_start > int(clip_until_frame):
            continue
        bout = np.asarray(tf.ke[bout_idx], dtype=float)
        frames = bout_start + np.arange(bout.shape[0], dtype=int) if bout.ndim else np.zeros(0, dtype=int)
        if bout.ndim != 2 or bout.shape[0] < int(min_points) or bout.shape[1] < 2:
            rows.append(
                {
                    "nickname": nickname,
                    "bout_idx": int(bout_idx),
                    "n_points": int(bout.shape[0]) if bout.ndim else 0,
                    "included": False,
                    "trajectory_source": "traj_ke",
                    "trajectory_path": f"{nickname}-tf",
                    "_frames": frames.tolist(),
                    **(clip_meta or {}),
                }
            )
            continue
        points = np.column_stack((-0.5 + 15.0 * bout[:, 0], -0.5 + 15.0 * bout[:, 1]))
        if clip_until_frame is not None:
            keep_frame = frames <= int(clip_until_frame)
            points = points[keep_frame]
            frames = frames[keep_frame]
            if points.shape[0] < int(min_points):
                rows.append(
                    {
                        "nickname": nickname,
                        "bout_idx": int(bout_idx),
                        "n_points": int(points.shape[0]),
                        "included": False,
                        "trajectory_source": "traj_ke",
                        "trajectory_path": f"{nickname}-tf",
                        "_frames": frames.tolist(),
                        **(clip_meta or {}),
                    }
                )
                continue
        trajectories.append(points)
        rows.append(
            {
                "nickname": nickname,
                "bout_idx": int(bout_idx),
                "n_points": int(points.shape[0]),
                "included": True,
                "trajectory_source": "traj_ke",
                "trajectory_path": f"{nickname}-tf",
                "_frames": frames.tolist(),
                **(clip_meta or {}),
            }
        )
    return trajectories, pd.DataFrame(rows)


def find_first_reward_reach(
    nickname: str,
    *,
    reward_node: int = REWARD_NODE,
) -> dict:
    """Find first reach of the canonical reward node in a trajectory pickle."""
    tf = LoadTraj(f"{nickname}-tf")
    hits = []
    for bout_idx, node_rows in enumerate(tf.no):
        arr = np.asarray(node_rows)
        if arr.ndim != 2 or arr.shape[1] < 2:
            continue
        reward_rows = arr[arr[:, 0].astype(int) == int(reward_node)]
        if len(reward_rows) == 0:
            continue
        rel_frame = int(np.nanmin(reward_rows[:, 1]))
        abs_frame = int(tf.fr[bout_idx][0]) + rel_frame
        hits.append((abs_frame, int(bout_idx), rel_frame))
    if not hits:
        raise ValueError(f"{nickname} never reaches reward node {reward_node}")
    abs_frame, bout_idx, rel_frame = min(hits, key=lambda row: row[0])
    return {
        "clip_mode": "until_reward",
        "reward_node": int(reward_node),
        "reward_abs_frame": int(abs_frame),
        "reward_bout_idx": int(bout_idx),
        "reward_relative_frame": int(rel_frame),
    }


def extract_raw_nose_trajectory_segments(
    nickname: str,
    *,
    data_source: str = "auto",
    behav_wd=None,
    clip_mode: str = "until_reward",
    reward_node: int = REWARD_NODE,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
) -> tuple[list[np.ndarray], pd.DataFrame]:
    """Return nose trajectory point arrays for one behavior session.

    ``data_source='auto'`` prefers corrected/interpolated
    ``selected_data/*_nose_interp_data.csv`` rows and falls back to legacy
    trajectory-pickle ``tf.ke`` only when the CSV is absent.
    """
    source = str(data_source).lower()
    if source not in {"auto", "nose_interp", "traj_ke"}:
        raise ValueError("data_source must be 'auto', 'nose_interp', or 'traj_ke'")
    clip_mode = str(clip_mode).lower()
    if clip_mode not in {"selected_bouts", "until_reward"}:
        raise ValueError("clip_mode must be 'selected_bouts' or 'until_reward'")
    clip_meta = {"clip_mode": clip_mode}
    clip_until_frame = None
    if clip_mode == "until_reward":
        reward_info = find_first_reward_reach(nickname, reward_node=reward_node)
        clip_meta.update(reward_info)
        clip_until_frame = int(reward_info["reward_abs_frame"])
        bout_indices = None
        max_bouts = None
    if source in {"auto", "nose_interp"}:
        try:
            return _extract_nose_interp_segments(
                nickname,
                behav_wd=behav_wd,
                bout_indices=bout_indices,
                max_bouts=max_bouts,
                min_points=min_points,
                clip_until_frame=clip_until_frame,
                clip_meta=clip_meta,
            )
        except FileNotFoundError:
            if source == "nose_interp":
                raise
    return _extract_traj_pickle_segments(
        nickname,
        bout_indices=bout_indices,
        max_bouts=max_bouts,
        min_points=min_points,
        clip_until_frame=clip_until_frame,
        clip_meta=clip_meta,
    )


def collect_raw_trajectory_plot_data(
    session_rows=None,
    *,
    style: dict | None = None,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
    data_source: str = "auto",
    behav_wd=None,
    clip_mode: str = "until_reward",
    reward_node: int = REWARD_NODE,
) -> pd.DataFrame:
    """Collect plot-ready trajectory coordinates for fast redraws."""
    session_rows = _as_session_rows(session_rows)
    panel_style = get_raw_trajectory_style(style)
    max_segment_step = panel_style.get("max_segment_step")
    rows = []
    for row_idx, session_row in enumerate(session_rows):
        for col_idx, spec in enumerate(session_row):
            nickname = spec["nickname"]
            display_title = spec.get("display_title", nickname)
            trajectories, summary = extract_raw_nose_trajectory_segments(
                nickname,
                data_source=spec.get("data_source", data_source),
                behav_wd=behav_wd,
                clip_mode=spec.get("clip_mode", clip_mode),
                reward_node=int(spec.get("reward_node", reward_node)),
                bout_indices=spec.get("bout_indices", bout_indices),
                max_bouts=spec.get("max_bouts", max_bouts),
                min_points=min_points,
            )
            included_summary = summary.loc[summary["included"]].reset_index(drop=True)
            progress_values = _global_progress_values(trajectories)
            for traj_idx, points in enumerate(trajectories):
                if points.shape[0] == 0:
                    continue
                meta = included_summary.iloc[traj_idx].to_dict()
                frames = meta.get("_frames")
                if not isinstance(frames, list) or len(frames) != points.shape[0]:
                    frames = [None] * points.shape[0]
                progress = progress_values[traj_idx]
                draw_to_next = np.zeros(points.shape[0], dtype=bool)
                if points.shape[0] > 1:
                    if max_segment_step is None:
                        draw_to_next[:-1] = True
                    else:
                        step = np.linalg.norm(points[1:] - points[:-1], axis=1)
                        draw_to_next[:-1] = np.isfinite(step) & (step <= float(max_segment_step))
                for point_idx, (xy, prog, keep_next) in enumerate(zip(points, progress, draw_to_next)):
                    rows.append(
                        {
                            "row_idx": int(row_idx),
                            "col_idx": int(col_idx),
                            "nickname": nickname,
                            "display_title": display_title,
                            "bout_idx": int(meta["bout_idx"]),
                            "point_idx": int(point_idx),
                            "frame": None if frames[point_idx] is None else int(frames[point_idx]),
                            "x": float(xy[0]),
                            "y": float(xy[1]),
                            "progress": float(prog),
                            "draw_to_next": bool(keep_next),
                            "max_segment_step": max_segment_step,
                            "trajectory_source": meta.get("trajectory_source"),
                            "trajectory_path": meta.get("trajectory_path"),
                            "clip_mode": meta.get("clip_mode"),
                            "reward_node": meta.get("reward_node"),
                            "reward_abs_frame": meta.get("reward_abs_frame"),
                            "reward_bout_idx": meta.get("reward_bout_idx"),
                            "reward_relative_frame": meta.get("reward_relative_frame"),
                        }
                    )
    return pd.DataFrame(rows)


def _draw_colored_trajectory(ax, points: np.ndarray, *, cmap, norm, style: dict, progress=None):
    if points.shape[0] < 2:
        return None
    segments = np.stack([points[:-1], points[1:]], axis=1)
    if progress is None:
        segment_progress = np.linspace(0.0, 1.0, len(segments), dtype=float)
    else:
        progress = np.asarray(progress, dtype=float)
        if progress.shape[0] != points.shape[0]:
            raise ValueError("progress length must match trajectory point count")
        segment_progress = 0.5 * (progress[:-1] + progress[1:])
    max_segment_step = style.get("max_segment_step")
    if max_segment_step is not None:
        step = np.linalg.norm(points[1:] - points[:-1], axis=1)
        keep = np.isfinite(step) & (step <= float(max_segment_step))
        segments = segments[keep]
        segment_progress = segment_progress[keep]
    if len(segments) == 0:
        return None
    collection = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidths=float(style["trajectory_linewidth"]),
        alpha=float(style["trajectory_alpha"]),
        rasterized=bool(style.get("trajectory_rasterized", True)),
        capstyle="round",
        joinstyle="round",
    )
    collection.set_array(segment_progress)
    ax.add_collection(collection)
    return collection


def _draw_house_icon(ax, spec: dict):
    x, y = map(float, spec["xy"])
    size = float(spec["size"])
    facecolor = spec.get("facecolor", "#111111")
    edgecolor = spec.get("edgecolor", facecolor)
    linewidth = float(spec.get("linewidth", 0.0))
    zorder = float(spec.get("zorder", 8))

    chimney = Rectangle(
        (x + 0.23 * size, y - 0.48 * size),
        0.14 * size,
        0.28 * size,
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=linewidth,
        zorder=zorder,
        clip_on=False,
    )
    silhouette = Polygon(
        [
            (x - 0.56 * size, y - 0.03 * size),
            (x, y - 0.62 * size),
            (x + 0.56 * size, y - 0.03 * size),
            (x + 0.40 * size, y - 0.03 * size),
            (x + 0.40 * size, y + 0.48 * size),
            (x - 0.40 * size, y + 0.48 * size),
            (x - 0.40 * size, y - 0.03 * size),
        ],
        closed=True,
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=linewidth,
        zorder=zorder,
        clip_on=False,
        joinstyle="miter",
    )
    door = Rectangle(
        (x - 0.10 * size, y + 0.19 * size),
        0.20 * size,
        0.29 * size,
        facecolor=spec.get("door_color", "white"),
        edgecolor=spec.get("door_color", "white"),
        linewidth=0.0,
        zorder=zorder + 0.1,
        clip_on=False,
    )
    for patch in (chimney, silhouette, door):
        ax.add_patch(patch)


def _draw_water_drop_icon(ax, spec: dict):
    x, y = map(float, spec["xy"])
    size = float(spec["size"])
    facecolor = spec.get("facecolor", "#36a3ff")
    edgecolor = spec.get("edgecolor", "#0866b2")
    linewidth = float(spec.get("linewidth", 0.9))
    zorder = float(spec.get("zorder", 8))

    verts = [
        (x, y - 0.66 * size),
        (x - 0.60 * size, y - 0.05 * size),
        (x - 0.48 * size, y + 0.52 * size),
        (x, y + 0.58 * size),
        (x + 0.48 * size, y + 0.52 * size),
        (x + 0.60 * size, y - 0.05 * size),
        (x, y - 0.66 * size),
        (x, y - 0.66 * size),
    ]
    codes = [
        MplPath.MOVETO,
        MplPath.CURVE4,
        MplPath.CURVE4,
        MplPath.CURVE4,
        MplPath.CURVE4,
        MplPath.CURVE4,
        MplPath.CURVE4,
        MplPath.CLOSEPOLY,
    ]
    drop = PathPatch(
        MplPath(verts, codes),
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=linewidth,
        zorder=zorder,
        clip_on=False,
        joinstyle="round",
    )
    highlight = Ellipse(
        (x - 0.13 * size, y - 0.02 * size),
        width=0.15 * size,
        height=0.30 * size,
        angle=-28,
        facecolor=spec.get("highlight_color", "#c9ecff"),
        edgecolor="none",
        alpha=0.9,
        zorder=zorder + 0.1,
        clip_on=False,
    )
    ax.add_patch(drop)
    ax.add_patch(highlight)


def draw_raw_trajectory_landmarks(ax, landmarks: dict | None = None):
    panel_landmarks = get_raw_trajectory_landmarks(landmarks)
    if not panel_landmarks.get("show", True):
        return
    home = panel_landmarks.get("home")
    reward = panel_landmarks.get("reward")
    if home:
        _draw_house_icon(ax, home)
    if reward:
        _draw_water_drop_icon(ax, reward)


def _read_plot_data(plot_data) -> pd.DataFrame:
    if isinstance(plot_data, (str, Path)):
        return pd.read_csv(plot_data, low_memory=False)
    return pd.DataFrame(plot_data).copy()


def _draw_cached_trajectory_group(ax, group: pd.DataFrame, *, cmap, norm, style: dict):
    group = group.sort_values("point_idx")
    points = group[["x", "y"]].to_numpy(float)
    if points.shape[0] < 2:
        return None
    progress = group["progress"].to_numpy(float)
    segments = np.stack([points[:-1], points[1:]], axis=1)
    segment_progress = 0.5 * (progress[:-1] + progress[1:])
    max_segment_step = style.get("max_segment_step")
    if max_segment_step is not None:
        step = np.linalg.norm(points[1:] - points[:-1], axis=1)
        keep = np.isfinite(step) & (step <= float(max_segment_step))
    elif "draw_to_next" in group:
        keep = group["draw_to_next"].iloc[:-1].astype(bool).to_numpy()
    else:
        keep = np.ones(len(segments), dtype=bool)
    segments = segments[keep]
    segment_progress = segment_progress[keep]
    if len(segments) == 0:
        return None
    collection = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidths=float(style["trajectory_linewidth"]),
        alpha=float(style["trajectory_alpha"]),
        rasterized=bool(style.get("trajectory_rasterized", True)),
        capstyle="round",
        joinstyle="round",
    )
    collection.set_array(segment_progress)
    ax.add_collection(collection)
    return collection


def draw_cached_raw_trajectory_axes(
    ax,
    plot_data,
    nickname: str,
    *,
    display_title: str | None = None,
    maze=None,
    maze_id: int = DEFAULT_MAZE_ID,
    layout: dict | None = None,
    colors: dict | None = None,
    landmarks: dict | None = None,
    style: dict | None = None,
    gray_blocks=GRAY_BLOCKS,
    cmap=None,
    norm=None,
):
    panel_layout = get_raw_trajectory_layout(layout)
    panel_colors = get_raw_trajectory_colors(colors)
    panel_landmarks = get_raw_trajectory_landmarks(landmarks)
    panel_style = get_raw_trajectory_style(style)
    panel_maze = get_panel_maze(maze_id) if maze is None else maze
    cmap = plt.get_cmap(panel_colors["cmap"] if cmap is None else cmap)
    norm = Normalize(0.0, 1.0) if norm is None else norm
    data = _read_plot_data(plot_data)
    session_data = data.loc[data["nickname"].astype(str) == str(nickname)].copy()

    draw_maze_outline(
        ax,
        panel_maze,
        layout={**panel_layout, **panel_style},
        colors={"wall": panel_colors["wall"]},
    )
    draw_gray_blocks(
        ax,
        blocks=gray_blocks,
        layout={**panel_layout, **panel_style},
        colors={
            "gray_block_face": panel_colors["gray_block_face"],
            "gray_block_edge": panel_colors["gray_block_edge"],
        },
    )

    last_collection = None
    if not session_data.empty:
        for _, group in session_data.groupby("bout_idx", sort=True):
            last_collection = _draw_cached_trajectory_group(
                ax,
                group,
                cmap=cmap,
                norm=norm,
                style=panel_style,
            )
    draw_raw_trajectory_landmarks(ax, panel_landmarks)

    ax.set_xlim(*panel_layout["maze_xlim"])
    ax.set_ylim(*panel_layout["maze_ylim"])
    ax.set_aspect("equal")
    ax.axis("off")
    if display_title:
        ax.set_title(
            str(display_title),
            fontsize=float(panel_style["title_fontsize"]),
            fontweight=panel_style["title_fontweight"],
            pad=float(panel_style["title_pad"]),
        )
    return last_collection


def draw_raw_trajectory_axes(
    ax,
    nickname: str,
    *,
    display_title: str | None = None,
    maze=None,
    maze_id: int = DEFAULT_MAZE_ID,
    layout: dict | None = None,
    colors: dict | None = None,
    landmarks: dict | None = None,
    style: dict | None = None,
    gray_blocks=GRAY_BLOCKS,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
    data_source: str = "auto",
    behav_wd=None,
    clip_mode: str = "until_reward",
    reward_node: int = REWARD_NODE,
    cmap=None,
    norm=None,
):
    panel_layout = get_raw_trajectory_layout(layout)
    panel_colors = get_raw_trajectory_colors(colors)
    panel_landmarks = get_raw_trajectory_landmarks(landmarks)
    panel_style = get_raw_trajectory_style(style)
    panel_maze = get_panel_maze(maze_id) if maze is None else maze
    cmap = plt.get_cmap(panel_colors["cmap"] if cmap is None else cmap)
    norm = Normalize(0.0, 1.0) if norm is None else norm

    draw_maze_outline(
        ax,
        panel_maze,
        layout={**panel_layout, **panel_style},
        colors={"wall": panel_colors["wall"]},
    )
    draw_gray_blocks(
        ax,
        blocks=gray_blocks,
        layout={**panel_layout, **panel_style},
        colors={
            "gray_block_face": panel_colors["gray_block_face"],
            "gray_block_edge": panel_colors["gray_block_edge"],
        },
    )

    trajectories, summary = extract_raw_nose_trajectory_segments(
        nickname,
        data_source=data_source,
        behav_wd=behav_wd,
        clip_mode=clip_mode,
        reward_node=reward_node,
        bout_indices=bout_indices,
        max_bouts=max_bouts,
        min_points=min_points,
    )
    last_collection = None
    for points, progress in zip(trajectories, _global_progress_values(trajectories)):
        last_collection = _draw_colored_trajectory(
            ax,
            points,
            cmap=cmap,
            norm=norm,
            style=panel_style,
            progress=progress,
        )
    draw_raw_trajectory_landmarks(ax, panel_landmarks)

    ax.set_xlim(*panel_layout["maze_xlim"])
    ax.set_ylim(*panel_layout["maze_ylim"])
    ax.set_aspect("equal")
    ax.axis("off")
    if display_title:
        ax.set_title(
            str(display_title),
            fontsize=float(panel_style["title_fontsize"]),
            fontweight=panel_style["title_fontweight"],
            pad=float(panel_style["title_pad"]),
        )
    return last_collection, summary


def render_raw_trajectory_grid_panel(
    session_rows=None,
    *,
    maze=None,
    maze_id: int = DEFAULT_MAZE_ID,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    landmarks: dict | None = None,
    style: dict | None = None,
    rcparams: dict | None = None,
    bout_indices=None,
    max_bouts: int | None = None,
    min_points: int = 2,
    data_source: str = "auto",
    behav_wd=None,
    clip_mode: str = "until_reward",
    reward_node: int = REWARD_NODE,
    save: bool = False,
    panel_name: str = "raw_example_session_trajectories",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    session_rows = _as_session_rows(session_rows)
    panel_layout = get_raw_trajectory_layout(layout)
    panel_colors = get_raw_trajectory_colors(colors)
    panel_landmarks = get_raw_trajectory_landmarks(landmarks)
    panel_style = get_raw_trajectory_style(style)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    panel_maze = get_panel_maze(maze_id) if maze is None else maze
    cmap = plt.get_cmap(panel_colors["cmap"])
    norm = Normalize(0.0, 1.0)

    n_rows = len(session_rows)
    n_cols = max(len(row) for row in session_rows)
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig = plt.figure(figsize=resolved_panel_size, facecolor=panel_colors["background"])
    grid = fig.add_gridspec(
        n_rows + 1,
        n_cols,
        height_ratios=[1.0] * n_rows + [float(panel_layout["colorbar_height_ratio"])],
        hspace=float(panel_layout["colorbar_hspace"]),
        wspace=float(panel_layout["grid_wspace"]),
    )

    axes = np.empty((n_rows, n_cols), dtype=object)
    summaries = []
    for row_idx, session_row in enumerate(session_rows):
        for col_idx in range(n_cols):
            ax = fig.add_subplot(grid[row_idx, col_idx])
            axes[row_idx, col_idx] = ax
            if col_idx >= len(session_row):
                ax.axis("off")
                continue
            spec = session_row[col_idx]
            _, summary = draw_raw_trajectory_axes(
                ax,
                spec["nickname"],
                display_title=spec.get("display_title", spec["nickname"]),
                maze=panel_maze,
                layout=panel_layout,
                colors=panel_colors,
                landmarks=panel_landmarks,
                style=panel_style,
                bout_indices=spec.get("bout_indices", bout_indices),
                max_bouts=spec.get("max_bouts", max_bouts),
                min_points=min_points,
                data_source=spec.get("data_source", data_source),
                behav_wd=behav_wd,
                clip_mode=spec.get("clip_mode", clip_mode),
                reward_node=int(spec.get("reward_node", reward_node)),
                cmap=cmap,
                norm=norm,
            )
            summary = summary.assign(display_title=spec.get("display_title", spec["nickname"]))
            summary = summary.drop(columns=["_frames"], errors="ignore")
            summaries.append(summary)

    cax = fig.add_subplot(grid[-1, :])
    sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    cbar = fig.colorbar(sm, cax=cax, orientation="horizontal")
    cbar.outline.set_visible(False)
    cbar.set_ticks([])
    cax.text(
        0.02,
        0.50,
        str(panel_style["colorbar_entry_label"]),
        color=panel_colors["colorbar_entry_text"],
        fontsize=float(panel_style["colorbar_label_fontsize"]),
        fontweight=panel_style["colorbar_label_fontweight"],
        ha="left",
        va="center",
        transform=cax.transAxes,
    )
    cax.text(
        0.98,
        0.50,
        str(panel_style["colorbar_reward_label"]),
        color=panel_colors["colorbar_exit_text"],
        fontsize=float(panel_style["colorbar_label_fontsize"]),
        fontweight=panel_style["colorbar_label_fontweight"],
        ha="right",
        va="center",
        transform=cax.transAxes,
    )

    panel_data = {
        "session_rows": deepcopy(session_rows),
        "summary": pd.concat(summaries, ignore_index=True) if summaries else pd.DataFrame(),
        "layout": panel_layout,
        "colors": panel_colors,
        "landmarks": panel_landmarks,
        "style": panel_style,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_cached_raw_trajectory_grid_panel(
    plot_data,
    session_rows=None,
    *,
    maze=None,
    maze_id: int = DEFAULT_MAZE_ID,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    landmarks: dict | None = None,
    style: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "raw_example_session_trajectories",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    data = _read_plot_data(plot_data)
    session_rows = _as_session_rows(session_rows)
    panel_layout = get_raw_trajectory_layout(layout)
    panel_colors = get_raw_trajectory_colors(colors)
    panel_landmarks = get_raw_trajectory_landmarks(landmarks)
    panel_style = get_raw_trajectory_style(style)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    panel_maze = get_panel_maze(maze_id) if maze is None else maze
    cmap = plt.get_cmap(panel_colors["cmap"])
    norm = Normalize(0.0, 1.0)

    n_rows = len(session_rows)
    n_cols = max(len(row) for row in session_rows)
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig = plt.figure(figsize=resolved_panel_size, facecolor=panel_colors["background"])
    grid = fig.add_gridspec(
        n_rows + 1,
        n_cols,
        height_ratios=[1.0] * n_rows + [float(panel_layout["colorbar_height_ratio"])],
        hspace=float(panel_layout["colorbar_hspace"]),
        wspace=float(panel_layout["grid_wspace"]),
    )

    axes = np.empty((n_rows, n_cols), dtype=object)
    for row_idx, session_row in enumerate(session_rows):
        for col_idx in range(n_cols):
            ax = fig.add_subplot(grid[row_idx, col_idx])
            axes[row_idx, col_idx] = ax
            if col_idx >= len(session_row):
                ax.axis("off")
                continue
            spec = session_row[col_idx]
            draw_cached_raw_trajectory_axes(
                ax,
                data,
                spec["nickname"],
                display_title=spec.get("display_title", spec["nickname"]),
                maze=panel_maze,
                layout=panel_layout,
                colors=panel_colors,
                landmarks=panel_landmarks,
                style=panel_style,
                cmap=cmap,
                norm=norm,
            )

    cax = fig.add_subplot(grid[-1, :])
    sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    cbar = fig.colorbar(sm, cax=cax, orientation="horizontal")
    cbar.outline.set_visible(False)
    cbar.set_ticks([])
    cax.text(
        0.02,
        0.50,
        str(panel_style["colorbar_entry_label"]),
        color=panel_colors["colorbar_entry_text"],
        fontsize=float(panel_style["colorbar_label_fontsize"]),
        fontweight=panel_style["colorbar_label_fontweight"],
        ha="left",
        va="center",
        transform=cax.transAxes,
    )
    cax.text(
        0.98,
        0.50,
        str(panel_style["colorbar_reward_label"]),
        color=panel_colors["colorbar_exit_text"],
        fontsize=float(panel_style["colorbar_label_fontsize"]),
        fontweight=panel_style["colorbar_label_fontweight"],
        ha="right",
        va="center",
        transform=cax.transAxes,
    )

    summary_cols = [
        "nickname",
        "display_title",
        "trajectory_source",
        "clip_mode",
        "reward_node",
        "reward_abs_frame",
        "reward_bout_idx",
        "reward_relative_frame",
    ]
    available_summary_cols = [col for col in summary_cols if col in data.columns]
    if available_summary_cols:
        summary = (
            data.groupby(available_summary_cols, dropna=False)
            .agg(
                n_bouts=("bout_idx", "nunique"),
                n_points=("point_idx", "count"),
                frame_min=("frame", "min") if "frame" in data.columns else ("point_idx", "min"),
                frame_max=("frame", "max") if "frame" in data.columns else ("point_idx", "max"),
            )
            .reset_index()
        )
    else:
        summary = pd.DataFrame()
    panel_data = {
        "session_rows": deepcopy(session_rows),
        "summary": summary,
        "layout": panel_layout,
        "colors": panel_colors,
        "landmarks": panel_landmarks,
        "style": panel_style,
        "plot_data_rows": int(len(data)),
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def _session_identity(nickname: str) -> dict:
    info = extract_info(nickname) or {}
    return {
        "animal_id": str(info.get("animal_id", nickname)),
        "experiment_type": int(info.get("experiment_type", 0)),
        "experiment_day": int(info.get("experiment_day", 1)),
    }


def build_whole_night_behavior_session_specs(
    *,
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool | None = None,
) -> pd.DataFrame:
    """Return current day-1 naive/return behavior sessions for accumulation panels.

    ``group_mode='pooled'`` produces naive month-0, pooled return-night, and
    experienced Day2 groups by default. ``group_mode='month'`` keeps the main
    figure month colors separate for 0, 3, 6, 9, and 12 months, and appends
    pooled experienced Day2 by default.
    """
    mode = str(group_mode).lower()
    if mode not in {"pooled", "month"}:
        raise ValueError("group_mode must be 'pooled' or 'month'")
    if include_experienced_day2 is None:
        include_experienced_day2 = True
    include_months = tuple(int(m) for m in include_months)
    cohort_by_month = {
        0: "RewardedDay1",
        3: "LTMThreeDay1",
        6: "LTMSixDay1",
        9: "LTMNineDay1",
        12: "LTMTwelveDay1",
    }
    cohort_by_month_day2 = {
        0: "RewardedDay2",
        3: "LTMThreeDay2",
        6: "LTMSixDay2",
        9: "LTMNineDay2",
        12: "LTMTwelveDay2",
    }
    groups = default_behavior_groups_260113()
    design = build_behav_measure_design(groups)
    if design.empty:
        return pd.DataFrame()
    design = design.loc[pd.to_numeric(design["month"], errors="coerce").isin(include_months)].copy()
    design["month"] = pd.to_numeric(design["month"], errors="coerce").astype(int)
    day = pd.to_numeric(design["day"], errors="coerce").astype(int)
    design["source_group"] = [
        cohort_by_month_day2[int(month)] if int(day_value) == 2 else cohort_by_month[int(month)]
        for month, day_value in zip(design["month"], day)
    ]
    design["memory_stage"] = np.where(day == 2, "experienced_day2", np.where(design["month"] == 0, "naive", "return"))

    if mode == "pooled":
        design = design.loc[(day == 1) | bool(include_experienced_day2)].copy()
        day = pd.to_numeric(design["day"], errors="coerce").astype(int)
        design["group_key"] = np.where(design["month"] == 0, "naive", "return")
        design.loc[day == 2, "group_key"] = "experienced_day2"
        design["group_label"] = np.where(design["month"] == 0, "Naive night", "Return night")
        design.loc[day == 2, "group_label"] = "Second night"
        design["group_order"] = np.where(design["month"] == 0, 0, 1)
        design.loc[day == 2, "group_order"] = 2
        design["color_key"] = design["group_key"]
    else:
        design = design.loc[(day == 1) | bool(include_experienced_day2)].copy()
        day = pd.to_numeric(design["day"], errors="coerce").astype(int)
        design["group_key"] = design["month"].map(lambda x: f"{int(x)}mo")
        design["group_label"] = design["month"].map(lambda x: "Naive night" if int(x) == 0 else f"{int(x)} mo return")
        month_to_order = {month: idx for idx, month in enumerate(include_months)}
        design["group_order"] = design["month"].map(month_to_order).astype(int)
        design.loc[day == 2, "group_key"] = "experienced_day2"
        design.loc[day == 2, "group_label"] = "Second night"
        design.loc[day == 2, "group_order"] = len(include_months)
        design["color_key"] = design["group_key"]

    identities = pd.DataFrame([_session_identity(nick) for nick in design["nickname"]])
    design = pd.concat([design.reset_index(drop=True), identities], axis=1)
    return design.sort_values(["group_order", "month", "nickname"]).reset_index(drop=True)


def _trajectory_duration_sec(tf) -> float:
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    if fr.ndim != 2 or fr.shape[0] == 0 or fr.shape[1] < 2:
        return float("nan")
    return float(TimeInMaze(float(fr[-1, 1]), tf))


def collect_whole_night_behavior_event_data(
    session_specs: pd.DataFrame | None = None,
    *,
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool | None = None,
    reward_node: int = REWARD_NODE,
    long_path_min: int = 7,
    maze_id: int = DEFAULT_MAZE_ID,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Collect current reward and long-bout events from trajectory files."""
    if int(reward_node) != int(REWARD_NODE):
        raise ValueError(f"Primary reward node must be {REWARD_NODE}.")
    specs = (
        build_whole_night_behavior_session_specs(
            group_mode=group_mode,
            include_months=include_months,
            include_experienced_day2=include_experienced_day2,
        )
        if session_specs is None
        else pd.DataFrame(session_specs).copy()
    )
    if specs.empty:
        empty_events = pd.DataFrame(
            columns=[
                "session",
                "abs_frame",
                "maze_seconds",
                "event_type",
                "group_key",
                "group_label",
                "group_order",
                "month",
                "memory_stage",
                "animal_id",
            ]
        )
        return specs, empty_events, pd.DataFrame()

    ma = NewMaze(int(maze_id))
    event_frames = []
    summary_rows = []
    for _, spec in specs.iterrows():
        nickname = str(spec["nickname"])
        common = {
            "group_key": str(spec["group_key"]),
            "group_label": str(spec["group_label"]),
            "group_order": int(spec["group_order"]),
            "color_key": str(spec.get("color_key", spec["group_key"])),
            "month": int(spec["month"]),
            "memory_stage": str(spec["memory_stage"]),
            "animal_id": str(spec["animal_id"]),
            "source_group": str(spec.get("source_group", "")),
        }
        try:
            tf = LoadTraj(f"{nickname}-tf")
            duration_sec = _trajectory_duration_sec(tf)
            reward_df = extract_reward_events(tf, session=nickname, time_in_maze_fn=TimeInMaze)
            long_df = extract_long_path_events(
                tf,
                ma,
                reward_node=int(reward_node),
                long_path_min=int(long_path_min),
                session=nickname,
                time_in_maze_fn=TimeInMaze,
            )
            for df in (reward_df, long_df):
                if not df.empty:
                    event_frames.append(df.assign(**common))
            summary_rows.append(
                {
                    "session": nickname,
                    **common,
                    "load_ok": True,
                    "error": "",
                    "maze_duration_sec": duration_sec,
                    "n_rewards": int(len(reward_df)),
                    "n_long_path_reward": int(len(long_df)),
                    "first_reward_sec": float(reward_df["maze_seconds"].iloc[0]) if len(reward_df) else np.nan,
                    "first_long_path_reward_sec": float(long_df["maze_seconds"].iloc[0]) if len(long_df) else np.nan,
                }
            )
        except Exception as exc:  # pragma: no cover - local data availability varies.
            summary_rows.append(
                {
                    "session": nickname,
                    **common,
                    "load_ok": False,
                    "error": str(exc),
                    "maze_duration_sec": np.nan,
                    "n_rewards": 0,
                    "n_long_path_reward": 0,
                    "first_reward_sec": np.nan,
                    "first_long_path_reward_sec": np.nan,
                }
            )

    event_table = pd.concat(event_frames, ignore_index=True) if event_frames else pd.DataFrame()
    session_summary = pd.DataFrame(summary_rows)
    return specs, event_table, session_summary


def _time_grid_from_durations(durations: np.ndarray, step_sec: float) -> np.ndarray:
    finite = np.asarray(durations, dtype=float)
    finite = finite[np.isfinite(finite) & (finite >= 0)]
    if finite.size == 0:
        return np.asarray([0.0], dtype=float)
    step = float(max(1.0, step_sec))
    max_dur = float(np.nanmax(finite))
    grid = np.arange(0.0, max_dur + step, step, dtype=float)
    if grid[-1] < max_dur:
        grid = np.append(grid, max_dur)
    return grid


def _sem_curve(mat: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(mat, dtype=float)
    n = np.sum(np.isfinite(arr), axis=0)
    mean = np.full(arr.shape[1], np.nan, dtype=float)
    sem = np.full(arr.shape[1], np.nan, dtype=float)
    valid = n > 0
    if np.any(valid):
        mean[valid] = np.nanmean(arr[:, valid], axis=0)
    valid_sem = n > 1
    if np.any(valid_sem):
        sem[valid_sem] = np.nanstd(arr[:, valid_sem], axis=0, ddof=1) / np.sqrt(n[valid_sem])
    sem[n == 1] = 0.0
    return mean, sem


def _coverage_windows(session_summary: pd.DataFrame, grid: np.ndarray, coverage_fraction: float) -> dict[str, dict]:
    windows = {}
    keep = session_summary.loc[session_summary["load_ok"] == True].copy()  # noqa: E712
    if keep.empty:
        return windows
    fraction = float(coverage_fraction)
    for group_key, sub in keep.groupby("group_key", sort=False):
        durations = pd.to_numeric(sub["maze_duration_sec"], errors="coerce").to_numpy(float)
        durations = durations[np.isfinite(durations)]
        initial_n = int(durations.size)
        min_n = int(np.ceil(max(0.0, min(1.0, fraction)) * initial_n))
        if min_n <= 0:
            min_n = 1 if initial_n else 0
        n_by_t = np.asarray([np.sum(durations >= t - 1e-9) for t in grid], dtype=int)
        ok = n_by_t >= min_n
        tmax = float(np.nanmax(grid[ok])) if np.any(ok) else 0.0
        windows[str(group_key)] = {
            "initial_n_sessions": initial_n,
            "min_coverage_n_sessions": min_n,
            "coverage_window_sec": tmax,
        }
    return windows


def build_whole_night_behavior_cumulative_curves(
    event_table: pd.DataFrame,
    session_summary: pd.DataFrame,
    *,
    event_types=("reward", "long_path_reward"),
    time_step_sec: float = 10.0,
    coverage_fraction: float = 0.80,
    band_multiplier: float = 1.0,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build plot-ready session-weighted cumulative-count curves."""
    keep = session_summary.loc[session_summary["load_ok"] == True].copy()  # noqa: E712
    if keep.empty:
        return pd.DataFrame(), pd.DataFrame()

    grid = _time_grid_from_durations(
        pd.to_numeric(keep["maze_duration_sec"], errors="coerce").to_numpy(float),
        float(time_step_sec),
    )
    windows = _coverage_windows(keep, grid, float(coverage_fraction))
    global_window = (
        min(item["coverage_window_sec"] for item in windows.values())
        if windows
        else float(grid[-1])
    )
    group_rows = []
    session_rows = []
    event_table = pd.DataFrame(event_table).copy()
    if event_table.empty:
        event_table = pd.DataFrame(columns=["session", "event_type", "maze_seconds"])

    sort_cols = ["group_order", "group_key", "session"]
    for event_type in event_types:
        for group_key, sub in keep.sort_values(sort_cols).groupby("group_key", sort=False):
            group_key = str(group_key)
            vals = []
            session_meta = []
            win = windows.get(group_key, {})
            initial_n = int(win.get("initial_n_sessions", len(sub)))
            min_n = int(win.get("min_coverage_n_sessions", 1))
            for _, row in sub.iterrows():
                session = str(row["session"])
                duration = float(row["maze_duration_sec"])
                times = event_table.loc[
                    (event_table["session"].astype(str) == session)
                    & (event_table["event_type"].astype(str) == str(event_type)),
                    "maze_seconds",
                ].to_numpy(dtype=float)
                times = np.sort(times[np.isfinite(times)])
                times = times[(times >= 0.0) & (times <= duration + 1e-9)]
                cum_for_mean = np.searchsorted(times, grid, side="right").astype(float)
                cum_active = np.full(grid.size, np.nan, dtype=float)
                mask = grid <= duration + 1e-9
                if np.any(mask):
                    cum_active[mask] = cum_for_mean[mask]
                vals.append(cum_for_mean)
                session_meta.append(row)
                for t, v, v_active, ok in zip(grid, cum_for_mean, cum_active, mask):
                    session_rows.append(
                        {
                            "group_key": group_key,
                            "group_label": str(row["group_label"]),
                            "group_order": int(row["group_order"]),
                            "color_key": str(row.get("color_key", group_key)),
                            "session": session,
                            "animal_id": str(row["animal_id"]),
                            "month": int(row["month"]),
                            "memory_stage": str(row["memory_stage"]),
                            "event_type": str(event_type),
                            "maze_seconds": float(t),
                            "time_minutes": float(t) / 60.0,
                            "cum_count": float(v) if np.isfinite(v) else np.nan,
                            "cum_count_active": float(v_active) if np.isfinite(v_active) else np.nan,
                            "session_in_window": bool(ok),
                            "coverage_ok": bool(float(t) <= global_window + 1e-9),
                        }
                    )
            mat = np.asarray(vals, dtype=float)
            mean, sem = _sem_curve(mat)
            n_averaged_by_t = np.sum(np.isfinite(mat), axis=0)
            durations = pd.to_numeric(sub["maze_duration_sec"], errors="coerce").to_numpy(float)
            n_active_by_t = np.asarray([np.sum(durations >= t - 1e-9) for t in grid], dtype=int)
            for t, m, s, n_avg, n_active in zip(grid, mean, sem, n_averaged_by_t, n_active_by_t):
                group_rows.append(
                    {
                        "group_key": group_key,
                        "group_label": str(sub["group_label"].iloc[0]),
                        "group_order": int(sub["group_order"].iloc[0]),
                        "color_key": str(sub.get("color_key", pd.Series([group_key])).iloc[0]),
                        "event_type": str(event_type),
                        "maze_seconds": float(t),
                        "time_minutes": float(t) / 60.0,
                        "cum_mean": float(m) if np.isfinite(m) else np.nan,
                        "cum_sem": float(s) if np.isfinite(s) else np.nan,
                        "cum_ci_low": float(m - float(band_multiplier) * s) if np.isfinite(m) and np.isfinite(s) else np.nan,
                        "cum_ci_high": float(m + float(band_multiplier) * s) if np.isfinite(m) and np.isfinite(s) else np.nan,
                        "n_sessions": int(n_active),
                        "n_averaged_sessions": int(n_avg),
                        "initial_n_sessions": initial_n,
                        "min_coverage_n_sessions": min_n,
                        "coverage_fraction": float(coverage_fraction),
                        "coverage_ok": bool(int(n_active) >= min_n and float(t) <= global_window + 1e-9),
                        "plot_window_sec": float(global_window),
                    }
                )
    return pd.DataFrame(group_rows), pd.DataFrame(session_rows)


def export_whole_night_behavior_accumulation_bundle(
    *,
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    panel_name: str = "whole_night_behavior_accumulation",
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool | None = None,
    reward_node: int = REWARD_NODE,
    long_path_min: int = 7,
    maze_id: int = DEFAULT_MAZE_ID,
    time_step_sec: float = 10.0,
    coverage_fraction: float = 0.80,
    band_multiplier: float = 1.0,
) -> dict:
    """Export cached data for whole-night behavior accumulation panels."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    session_specs, event_table, session_summary = collect_whole_night_behavior_event_data(
        group_mode=group_mode,
        include_months=include_months,
        include_experienced_day2=include_experienced_day2,
        reward_node=reward_node,
        long_path_min=long_path_min,
        maze_id=maze_id,
    )
    group_curves, session_curves = build_whole_night_behavior_cumulative_curves(
        event_table,
        session_summary,
        time_step_sec=time_step_sec,
        coverage_fraction=coverage_fraction,
        band_multiplier=band_multiplier,
    )

    paths = {
        "session_specs_csv": output_dir / f"{panel_name}_session_specs.csv",
        "events_csv": output_dir / f"{panel_name}_events.csv",
        "session_summary_csv": output_dir / f"{panel_name}_session_summary.csv",
        "session_curves_csv": output_dir / f"{panel_name}_session_curves.csv",
        "group_curves_csv": output_dir / f"{panel_name}_group_curves.csv",
        "manifest_json": output_dir / f"{panel_name}_manifest.json",
    }
    session_specs.to_csv(paths["session_specs_csv"], index=False)
    event_table.to_csv(paths["events_csv"], index=False)
    session_summary.to_csv(paths["session_summary_csv"], index=False)
    session_curves.to_csv(paths["session_curves_csv"], index=False)
    group_curves.to_csv(paths["group_curves_csv"], index=False)

    if session_summary.empty:
        counts_by_group = []
    else:
        counts_by_group = (
            session_summary.sort_values(["group_order", "group_key"])
            .groupby(["group_key", "group_label"], sort=False, dropna=False)
            .agg(
                n_sessions=("session", "count"),
                n_loaded=("load_ok", "sum"),
                n_animals=("animal_id", "nunique"),
                total_rewards=("n_rewards", "sum"),
                total_long_path_reward=("n_long_path_reward", "sum"),
                median_duration_min=("maze_duration_sec", lambda x: float(np.nanmedian(x) / 60.0)),
            )
            .reset_index()
            .to_dict(orient="records")
        )

    manifest = {
        "panel_name": panel_name,
        "group_mode": group_mode,
        "include_months": [int(m) for m in include_months],
        "include_experienced_day2": bool(True if include_experienced_day2 is None else include_experienced_day2),
        "reward_node": int(reward_node),
        "long_path_min": int(long_path_min),
        "maze_id": int(maze_id),
        "timebase": "TimeInMaze seconds",
        "time_step_sec": float(time_step_sec),
        "coverage_fraction": float(coverage_fraction),
        "averaging_unit": "session",
        "averaging_note": (
            "Each behavior session is one observation. Repeated sessions from the same animal "
            "are not animal-collapsed, matching the legacy behavior-measures notebook."
        ),
        "band": f"mean +/- {float(band_multiplier):g} SEM",
        "cohort_source": "default_behavior_groups_260113 + build_behav_measure_design",
        "event_source": "LoadTraj, extract_reward_events, extract_long_path_events",
        "counts_by_group": counts_by_group,
        "files": {key: str(path) for key, path in paths.items() if key != "manifest_json"},
    }
    paths["manifest_json"].write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {
        "paths": paths,
        "manifest": manifest,
        "session_specs": session_specs,
        "event_table": event_table,
        "session_summary": session_summary,
        "group_curves": group_curves,
        "session_curves": session_curves,
    }


def _read_optional_csv(path_or_df):
    if path_or_df is None:
        return pd.DataFrame()
    return _read_plot_data(path_or_df)


def render_cached_whole_night_behavior_accumulation_panel(
    group_curves,
    session_curves=None,
    *,
    event_types=("reward", "long_path_reward"),
    group_order=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "whole_night_behavior_accumulation",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render whole-night reward/long-bout accumulation from saved CSVs."""
    group_df = _read_plot_data(group_curves)
    session_df = _read_optional_csv(session_curves)
    panel_layout = get_behavior_accumulation_layout(layout)
    panel_colors = get_behavior_accumulation_colors(colors)
    panel_style = get_behavior_accumulation_style(style)
    panel_labels = get_behavior_accumulation_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    event_types = tuple(str(et) for et in event_types)

    if group_order is None:
        order_df = (
            group_df.loc[:, ["group_key", "group_order"]]
            .drop_duplicates()
            .sort_values(["group_order", "group_key"])
        )
        group_order = order_df["group_key"].astype(str).tolist()
    else:
        group_order = [str(g) for g in group_order]

    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig, axes = plt.subplots(
        1,
        len(event_types),
        figsize=resolved_panel_size,
        squeeze=False,
        facecolor="white",
    )
    axes = axes.ravel()

    if bool(panel_style.get("use_coverage_window", True)) and "plot_window_sec" in group_df.columns:
        finite_window = pd.to_numeric(group_df["plot_window_sec"], errors="coerce")
        finite_window = finite_window[np.isfinite(finite_window)]
        xmax_min = float(finite_window.min() / 60.0) if len(finite_window) else None
    else:
        xmax_min = None
    if panel_style.get("xlim_minutes") is not None:
        xmax_min = float(panel_style["xlim_minutes"])

    group_label_map = dict(panel_labels.get("group_labels", {}))
    for ax, event_type in zip(axes, event_types):
        event_group = group_df.loc[group_df["event_type"].astype(str) == event_type].copy()
        event_session = (
            session_df.loc[session_df["event_type"].astype(str) == event_type].copy()
            if not session_df.empty and "event_type" in session_df.columns
            else pd.DataFrame()
        )
        for group_key in group_order:
            color_key = group_key
            group_sub = event_group.loc[event_group["group_key"].astype(str) == group_key].sort_values("maze_seconds")
            if group_sub.empty:
                continue
            if "color_key" in group_sub.columns:
                color_key = str(group_sub["color_key"].iloc[0])
            color = panel_colors.get(color_key, panel_colors.get(group_key, "#444444"))
            label = group_label_map.get(group_key, str(group_sub["group_label"].iloc[0]))

            if bool(panel_style.get("show_session_curves", False)) and not event_session.empty:
                sess_sub = event_session.loc[event_session["group_key"].astype(str) == group_key]
                session_count_col = "cum_count_active" if "cum_count_active" in sess_sub.columns else "cum_count"
                for _, ssub in sess_sub.groupby("session", sort=False):
                    ax.plot(
                        pd.to_numeric(ssub["time_minutes"], errors="coerce"),
                        pd.to_numeric(ssub[session_count_col], errors="coerce"),
                        color=color,
                        linewidth=float(panel_style["session_line_width"]),
                        alpha=float(panel_style["session_line_alpha"]),
                        zorder=1,
                    )

            x = pd.to_numeric(group_sub["time_minutes"], errors="coerce").to_numpy(float)
            y = pd.to_numeric(group_sub["cum_mean"], errors="coerce").to_numpy(float)
            lo = pd.to_numeric(group_sub["cum_ci_low"], errors="coerce").to_numpy(float)
            hi = pd.to_numeric(group_sub["cum_ci_high"], errors="coerce").to_numpy(float)
            finite = np.isfinite(x) & np.isfinite(y)
            if not np.any(finite):
                continue
            if bool(panel_style.get("show_band", True)):
                band_ok = finite & np.isfinite(lo) & np.isfinite(hi)
                ax.fill_between(
                    x[band_ok],
                    lo[band_ok],
                    hi[band_ok],
                    color=color,
                    alpha=float(panel_style["band_alpha"]),
                    linewidth=0,
                    zorder=2,
                )
            ax.plot(
                x[finite],
                y[finite],
                color=color,
                linewidth=float(panel_style["line_width"]),
                alpha=float(panel_style["line_alpha"]),
                label=label,
                zorder=3,
            )

        event_labels = panel_labels.get(event_type, {})
        ax.set_title(str(event_labels.get("title", event_type)), fontsize=float(panel_style["title_fontsize"]))
        ax.set_xlabel(str(panel_labels.get("xlabel", "Time in maze (min)")), fontsize=float(panel_style["axis_label_fontsize"]))
        ax.set_ylabel(str(event_labels.get("ylabel", "Cumulative count")), fontsize=float(panel_style["axis_label_fontsize"]))
        ax.tick_params(labelsize=float(panel_style["tick_labelsize"]))
        if xmax_min is not None and np.isfinite(xmax_min) and xmax_min > 0:
            ax.set_xlim(0, xmax_min)
        ax.set_ylim(bottom=0)
        ax.grid(True, axis="y", color=panel_colors["grid"], alpha=float(panel_style["grid_alpha"]), linewidth=0.6)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(bool(panel_style.get(f"spine_{spine}", False)))
        ax.spines["left"].set_color(panel_colors["axis"])
        ax.spines["bottom"].set_color(panel_colors["axis"])

    if len(axes):
        axes[0].legend(frameon=False, loc=str(panel_style["legend_loc"]), fontsize=float(panel_style["legend_fontsize"]))
    fig.subplots_adjust(wspace=float(panel_layout["wspace"]))
    panel_data = {
        "group_order": group_order,
        "event_types": event_types,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "plot_window_min": xmax_min,
        "group_curve_rows": int(len(group_df)),
        "session_curve_rows": int(len(session_df)),
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def _cycle_group_specs(
    *,
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool = True,
) -> pd.DataFrame:
    mode = str(group_mode).lower()
    if mode not in {"pooled", "month"}:
        raise ValueError("group_mode must be 'pooled' or 'month'")
    include_months = tuple(int(m) for m in include_months)
    groups = default_behavior_groups_260113()
    rows = []

    def add_sessions(source_group: str, group_key: str, group_label: str, group_order: int, month: int, color_key: str):
        for nickname in groups.get(source_group, []):
            rows.append(
                {
                    "nickname": str(nickname),
                    "source_group": source_group,
                    "group_key": group_key,
                    "group_label": group_label,
                    "group_order": int(group_order),
                    "month": int(month),
                    "color_key": color_key,
                }
            )

    if mode == "pooled":
        add_sessions("RewardedDay1", "naive", "Naive night", 0, 0, "naive")
        for month, source_group in (
            (3, "LTMThreeDay1"),
            (6, "LTMSixDay1"),
            (9, "LTMNineDay1"),
            (12, "LTMTwelveDay1"),
        ):
            add_sessions(source_group, "return", "Return night", 1, month, "return")
        if include_experienced_day2:
            for month, source_group in (
                (0, "RewardedDay2"),
                (3, "LTMThreeDay2"),
                (6, "LTMSixDay2"),
                (9, "LTMNineDay2"),
                (12, "LTMTwelveDay2"),
            ):
                add_sessions(source_group, "experienced_day2", "Second night", 2, month, "experienced_day2")
    else:
        month_to_source = {
            0: "RewardedDay1",
            3: "LTMThreeDay1",
            6: "LTMSixDay1",
            9: "LTMNineDay1",
            12: "LTMTwelveDay1",
        }
        for order, month in enumerate(include_months):
            source_group = month_to_source.get(int(month))
            if source_group is None:
                continue
            group_key = f"{int(month)}mo"
            group_label = "Naive night" if int(month) == 0 else f"{int(month)} mo"
            add_sessions(source_group, group_key, group_label, order, int(month), group_key)
        if include_experienced_day2:
            for month, source_group in (
                (0, "RewardedDay2"),
                (3, "LTMThreeDay2"),
                (6, "LTMSixDay2"),
                (9, "LTMNineDay2"),
                (12, "LTMTwelveDay2"),
            ):
                if int(month) in include_months:
                    add_sessions(
                        source_group,
                        "experienced_day2",
                        "Second night",
                        len(include_months),
                        int(month),
                        "experienced_day2",
                    )

    if not rows:
        return pd.DataFrame(
            columns=["nickname", "source_group", "group_key", "group_label", "group_order", "month", "color_key"]
        )
    return pd.DataFrame(rows).drop_duplicates(["nickname", "group_key", "source_group"]).reset_index(drop=True)


def build_exploration_efficiency_cycle_summary(
    cycles,
    *,
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool = True,
    complete_only: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Summarize reset-after-32-unique-endpoint efficiency cycles for plotting."""
    cycles_df = _read_plot_data(cycles)
    specs = _cycle_group_specs(
        group_mode=group_mode,
        include_months=include_months,
        include_experienced_day2=include_experienced_day2,
    )
    if cycles_df.empty or specs.empty:
        return pd.DataFrame(), specs
    cycles_df = cycles_df.copy()
    if bool(complete_only) and "complete_cycle" in cycles_df.columns:
        cycles_df = cycles_df.loc[cycles_df["complete_cycle"].astype(bool)].copy()
    merged = cycles_df.merge(specs, on="nickname", how="inner", suffixes=("_cycle", ""))
    if merged.empty:
        return pd.DataFrame(), specs
    rows = []
    group_cols = ["group_order", "group_key", "group_label", "color_key", "cycle_index"]
    for keys, sub in merged.groupby(group_cols, sort=True, dropna=False):
        group_order, group_key, group_label, color_key, cycle_index = keys
        steps = pd.to_numeric(sub["steps_in_cycle"], errors="coerce").to_numpy(float)
        eff = pd.to_numeric(sub["efficiency_32_over_steps"], errors="coerce").to_numpy(float)
        steps = steps[np.isfinite(steps)]
        eff = eff[np.isfinite(eff)]
        if steps.size == 0 or eff.size == 0:
            continue
        rows.append(
            {
                "group_order": int(group_order),
                "group_key": str(group_key),
                "group_label": str(group_label),
                "color_key": str(color_key),
                "cycle_index": int(cycle_index),
                "n_sessions": int(sub["nickname"].astype(str).nunique()),
                "n_cycles": int(len(sub)),
                "steps_mean": float(np.nanmean(steps)),
                "steps_sem": float(np.nanstd(steps, ddof=1) / np.sqrt(steps.size)) if steps.size > 1 else 0.0,
                "steps_median": float(np.nanmedian(steps)),
                "steps_q25": float(np.nanpercentile(steps, 25)),
                "steps_q75": float(np.nanpercentile(steps, 75)),
                "eff_mean": float(np.nanmean(eff)),
                "eff_sem": float(np.nanstd(eff, ddof=1) / np.sqrt(eff.size)) if eff.size > 1 else 0.0,
                "eff_median": float(np.nanmedian(eff)),
                "eff_q25": float(np.nanpercentile(eff, 25)),
                "eff_q75": float(np.nanpercentile(eff, 75)),
            }
        )
    summary = pd.DataFrame(rows)
    if not summary.empty:
        summary = summary.sort_values(["group_order", "cycle_index", "group_key"]).reset_index(drop=True)
    return summary, specs


def export_exploration_efficiency_cycle_bundle(
    *,
    cycles_csv="docs/exploration_efficiency_animals_cycles.csv",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    panel_name: str = "exploration_efficiency_cycles",
    group_mode: str = "pooled",
    include_months=(0, 3, 6, 9, 12),
    include_experienced_day2: bool = True,
    complete_only: bool = True,
) -> dict:
    """Export plot-ready cycle-efficiency summary tables for supplement panels."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary, specs = build_exploration_efficiency_cycle_summary(
        cycles_csv,
        group_mode=group_mode,
        include_months=include_months,
        include_experienced_day2=include_experienced_day2,
        complete_only=complete_only,
    )
    paths = {
        "summary_csv": output_dir / f"{panel_name}_summary.csv",
        "session_specs_csv": output_dir / f"{panel_name}_session_specs.csv",
        "manifest_json": output_dir / f"{panel_name}_manifest.json",
    }
    summary.to_csv(paths["summary_csv"], index=False)
    specs.to_csv(paths["session_specs_csv"], index=False)
    if summary.empty:
        counts_by_group = []
    else:
        counts_by_group = (
            summary.sort_values(["group_order", "group_key"])
            .groupby(["group_key", "group_label"], sort=False, dropna=False)
            .agg(
                n_cycle_indices=("cycle_index", "max"),
                min_support=("n_sessions", "min"),
                max_support=("n_sessions", "max"),
            )
            .reset_index()
            .to_dict(orient="records")
        )
    manifest = {
        "panel_name": panel_name,
        "source_cycles_csv": str(cycles_csv),
        "group_mode": str(group_mode),
        "include_months": [int(m) for m in include_months],
        "include_experienced_day2": bool(include_experienced_day2),
        "complete_only": bool(complete_only),
        "metric_definition": (
            "Exploration-mode level-6 endpoint visits are segmented into cycles. "
            "Each cycle ends when 32 unique endpoints have been visited; efficiency is 32/N."
        ),
        "cohort_source": "default_behavior_groups_260113",
        "counts_by_group": counts_by_group,
        "files": {key: str(path) for key, path in paths.items() if key != "manifest_json"},
    }
    paths["manifest_json"].write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {"paths": paths, "manifest": manifest, "summary": summary, "session_specs": specs}


def render_cached_exploration_efficiency_cycle_panel(
    summary,
    *,
    group_order=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "exploration_efficiency_cycles",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the 32/N exploration-efficiency cycle panel from a saved summary CSV."""
    summary_df = _read_plot_data(summary)
    panel_layout = get_exploration_cycle_layout(layout)
    panel_colors = get_exploration_cycle_colors(colors)
    panel_style = get_exploration_cycle_style(style)
    panel_labels = get_exploration_cycle_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    summary_kind = str(panel_style.get("summary_kind", "mean_sem")).lower()
    if summary_kind not in {"median_iqr", "mean_sem"}:
        raise ValueError("summary_kind must be 'median_iqr' or 'mean_sem'")

    if group_order is None and not summary_df.empty:
        order_df = (
            summary_df.loc[:, ["group_key", "group_order"]]
            .drop_duplicates()
            .sort_values(["group_order", "group_key"])
        )
        group_order = order_df["group_key"].astype(str).tolist()
    else:
        group_order = [] if group_order is None else [str(g) for g in group_order]

    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig, ax = plt.subplots(1, 1, figsize=resolved_panel_size, facecolor="white")
    group_label_map = dict(panel_labels.get("group_labels", {}))
    min_support = int(panel_style.get("min_support", 1))

    for group_key in group_order:
        sub = summary_df.loc[summary_df["group_key"].astype(str) == group_key].sort_values("cycle_index")
        if sub.empty:
            continue
        sub = sub.loc[pd.to_numeric(sub["n_sessions"], errors="coerce") >= min_support].copy()
        if sub.empty:
            continue
        color_key = str(sub["color_key"].iloc[0]) if "color_key" in sub.columns else group_key
        color = panel_colors.get(color_key, panel_colors.get(group_key, "#444444"))
        x = pd.to_numeric(sub["cycle_index"], errors="coerce").to_numpy(float)
        if summary_kind == "mean_sem":
            y = pd.to_numeric(sub["eff_mean"], errors="coerce").to_numpy(float)
            sem = pd.to_numeric(sub["eff_sem"], errors="coerce").fillna(0.0).to_numpy(float)
            lo = y - sem
            hi = y + sem
        else:
            y = pd.to_numeric(sub["eff_median"], errors="coerce").to_numpy(float)
            lo = pd.to_numeric(sub["eff_q25"], errors="coerce").to_numpy(float)
            hi = pd.to_numeric(sub["eff_q75"], errors="coerce").to_numpy(float)
        finite = np.isfinite(x) & np.isfinite(y)
        if not np.any(finite):
            continue
        label = group_label_map.get(group_key, str(sub["group_label"].iloc[0]))
        if bool(panel_style.get("show_legend_counts", True)):
            total_n = int(pd.to_numeric(sub["n_sessions"], errors="coerce").max())
            label = f"{label} (n={total_n})"
        band_ok = finite & np.isfinite(lo) & np.isfinite(hi)
        if bool(panel_style.get("show_band", True)):
            ax.fill_between(
                x[band_ok],
                lo[band_ok],
                hi[band_ok],
                color=color,
                alpha=float(panel_style["band_alpha"]),
                linewidth=0,
                zorder=2,
            )
        ax.plot(
            x[finite],
            y[finite],
            color=color,
            linewidth=float(panel_style["line_width"]),
            alpha=float(panel_style["line_alpha"]),
            linestyle=str(panel_style.get("linestyles", {}).get(group_key, "-")),
            marker=str(panel_style.get("markers", {}).get(group_key, "o")),
            markersize=float(panel_style["marker_size"]),
            label=label,
            zorder=3,
        )

    suffix = "median + IQR" if summary_kind == "median_iqr" else "mean +/- SEM"
    title = str(panel_labels.get("title", "Exploration efficiency"))
    ax.set_title(f"{title}\n({suffix})", loc="left", fontsize=float(panel_style["title_fontsize"]))
    ax.set_xlabel(str(panel_labels.get("xlabel", "32-unique block index")), fontsize=float(panel_style["axis_label_fontsize"]))
    ax.set_ylabel(str(panel_labels.get("ylabel", "Efficiency (32/N)")), fontsize=float(panel_style["axis_label_fontsize"]))
    ax.tick_params(labelsize=float(panel_style["tick_labelsize"]))
    xlim = panel_style.get("xlim")
    if xlim is not None:
        ax.set_xlim(*tuple(xlim))
    if panel_style.get("xticks") is not None:
        ax.set_xticks([float(x) for x in panel_style["xticks"]])
    ylim = panel_style.get("ylim")
    if ylim is not None:
        ymin, ymax = tuple(ylim)
        ax.set_ylim(bottom=ymin, top=ymax)
    else:
        ax.set_ylim(bottom=0)
    ax.grid(True, color=panel_colors["grid"], alpha=float(panel_style["grid_alpha"]), linewidth=0.6)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(bool(panel_style.get(f"spine_{spine}", False)))
    ax.spines["left"].set_color(panel_colors["axis"])
    ax.spines["bottom"].set_color(panel_colors["axis"])
    if group_order:
        legend_kwargs = {
            "frameon": False,
            "loc": str(panel_style["legend_loc"]),
            "fontsize": float(panel_style["legend_fontsize"]),
        }
        if panel_style.get("legend_bbox_to_anchor") is not None:
            legend_kwargs["bbox_to_anchor"] = tuple(panel_style["legend_bbox_to_anchor"])
        ax.legend(**legend_kwargs)
    fig.tight_layout()
    panel_data = {
        "group_order": group_order,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "summary_rows": int(len(summary_df)),
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, ax, panel_data, saved_paths


def _sem(values: np.ndarray) -> float:
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals)]
    if vals.size <= 1:
        return 0.0 if vals.size == 1 else np.nan
    return float(np.nanstd(vals, ddof=1) / np.sqrt(vals.size))


def _read_optional_table(table) -> pd.DataFrame:
    if table is None:
        return pd.DataFrame()
    if isinstance(table, pd.DataFrame):
        return table.copy()
    path = Path(table)
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def _reward_performance_annotation_rows(
    stats_df: pd.DataFrame,
    *,
    metric: str,
    group_order: list[str],
    group_mode: str,
    style: dict,
) -> pd.DataFrame:
    if stats_df.empty or not bool(style.get("annotation", True)):
        return pd.DataFrame()
    p_col = str(style.get("annotation_p_col", "cluster_q_bh_within_metric"))
    if p_col not in stats_df.columns:
        return pd.DataFrame()
    required = {"metric", "group_a", "group_b", p_col}
    if not required.issubset(stats_df.columns):
        return pd.DataFrame()

    order_index = {str(group): idx for idx, group in enumerate(group_order)}
    rows = stats_df.loc[stats_df["metric"].astype(str) == str(metric)].copy()
    rows["group_a"] = rows["group_a"].astype(str)
    rows["group_b"] = rows["group_b"].astype(str)
    rows = rows.loc[rows["group_a"].isin(order_index) & rows["group_b"].isin(order_index)].copy()
    if rows.empty:
        return pd.DataFrame()

    if str(group_mode) == "month_stage":
        if "comparison_family" in rows.columns:
            rows = rows.loc[rows["comparison_family"].astype(str) == "vs_naive"].copy()
        if group_order:
            rows = rows.loc[rows["group_a"].astype(str) == str(group_order[0])].copy()

    rows["_x_a"] = rows["group_a"].map(order_index).astype(float)
    rows["_x_b"] = rows["group_b"].map(order_index).astype(float)
    swap = rows["_x_a"] > rows["_x_b"]
    if swap.any():
        rows.loc[swap, ["_x_a", "_x_b"]] = rows.loc[swap, ["_x_b", "_x_a"]].to_numpy()
    rows["_span"] = rows["_x_b"] - rows["_x_a"]
    rows["_annotation_p_raw"] = pd.to_numeric(rows[p_col], errors="coerce")
    rows = rows.loc[np.isfinite(rows["_annotation_p_raw"]) & (rows["_span"] > 0)].copy()
    if rows.empty:
        return pd.DataFrame()
    p_adjust = str(style.get("annotation_p_adjust", "")).lower()
    if p_adjust in {"displayed_bh", "bh"}:
        rows["_annotation_p"] = _bh_adjust_pvalues(rows["_annotation_p_raw"].to_numpy(dtype=float))
        rows["_annotation_p_source"] = f"{p_col}:displayed_bh"
    else:
        rows["_annotation_p"] = rows["_annotation_p_raw"]
        rows["_annotation_p_source"] = p_col
    rows["_annotation_text"] = rows["_annotation_p"].map(_significance_text)
    if not bool(style.get("annotation_show_ns", False)):
        rows = rows.loc[rows["_annotation_text"] != "n.s."].copy()
    return rows.reset_index(drop=True)


def _draw_reward_performance_annotations(
    ax,
    stats_df: pd.DataFrame,
    *,
    metric: str,
    group_order: list[str],
    group_mode: str,
    style: dict,
) -> pd.DataFrame:
    rows = _reward_performance_annotation_rows(
        stats_df,
        metric=metric,
        group_order=group_order,
        group_mode=group_mode,
        style=style,
    )
    if rows.empty:
        return rows

    ymin, ymax = ax.get_ylim()
    span = max(float(ymax - ymin), 1.0)
    annotation_y_start = style.get("annotation_y_start")
    annotation_step = style.get("annotation_step")
    y = (
        float(annotation_y_start)
        if annotation_y_start is not None
        else float(ymax) + span * float(style["annotation_offset_fraction"])
    )
    step = (
        max(float(annotation_step), 0.05)
        if annotation_step is not None
        else max(span * float(style["annotation_step_fraction"]), 0.05)
    )
    tick_height = step * float(style["annotation_tick_fraction"])
    text_offset = step * float(style["annotation_text_offset_fraction"])
    text_kwargs = {
        "ha": "center",
        "va": "bottom",
        "fontsize": float(style["annotation_fontsize"]),
        "fontweight": style["annotation_fontweight"],
    }
    y_top = ymax
    for idx, row in rows.iterrows():
        y_level = y + idx * step
        x1 = float(row["_x_a"])
        x2 = float(row["_x_b"])
        ax.plot(
            [x1, x1, x2, x2],
            [y_level, y_level + tick_height, y_level + tick_height, y_level],
            color="black",
            linewidth=float(style["annotation_linewidth"]),
            clip_on=False,
            zorder=5,
        )
        ax.text(
            (x1 + x2) / 2.0,
            y_level + text_offset,
            str(row["_annotation_text"]),
            clip_on=False,
            zorder=6,
            **text_kwargs,
        )
        y_top = max(y_top, y_level + tick_height + step * 0.20)
    ax.set_ylim(ymin, y_top + span * float(style["annotation_ylim_pad_fraction"]))
    return rows


def _reward_performance_group_columns(
    df: pd.DataFrame,
    group_mode: str,
    *,
    include_experienced_day2: bool = False,
) -> tuple[pd.DataFrame, list[str], dict]:
    out = df.copy()
    mode = str(group_mode).lower()
    if mode == "pooled":
        labels = dict(REWARD_PERFORMANCE_LABELS["group_labels"])
        if not bool(include_experienced_day2):
            out = out.loc[out["group_key"].astype(str) != "experienced_day2"].copy()
        out["plot_group"] = out["group_key"].astype(str)
        out["plot_label"] = out["plot_group"].map(labels).fillna(out["plot_group"])
        order = ["naive", "return"]
        if bool(include_experienced_day2):
            order.append("experienced_day2")
        return out, order, labels
    if mode != "month_stage":
        raise ValueError("group_mode must be 'pooled' or 'month_stage'")
    out["month"] = pd.to_numeric(out["month"], errors="coerce").astype("Int64")
    out["day"] = pd.to_numeric(out["day"], errors="coerce").astype("Int64")
    if not bool(include_experienced_day2):
        out = out.loc[out["day"].astype(int) == 1].copy()
    out["plot_group"] = out["month_stage_key"].astype(str)
    ordered = (
        out.loc[:, ["plot_group", "month_stage_order", "month", "day"]]
        .drop_duplicates()
        .sort_values(["month_stage_order", "plot_group"])
    )
    labels = {}
    for _, row in ordered.iterrows():
        month = int(row["month"])
        day = int(row["day"])
        key = str(row["plot_group"])
        if day == 1 and month == 0:
            labels[key] = "Naive"
        elif day == 1:
            labels[key] = f"{month} mo"
        elif day == 2 and month == 0:
            labels[key] = "S0"
        elif day == 2:
            labels[key] = f"S{month}"
        else:
            labels[key] = key
    out["plot_label"] = out["plot_group"].map(labels).fillna(out["plot_group"])
    return out, ordered["plot_group"].astype(str).tolist(), labels


def _reward_performance_color(group: str, row: pd.Series | None, colors: dict) -> str:
    if str(group) in colors:
        return colors[str(group)]
    if row is not None and "day" in row and "month" in row:
        month = int(row["month"])
        day = int(row["day"])
        if day == 2:
            return colors.get("second", "#2E7D32")
        return colors.get(f"{month}mo", "#8BBDEB")
    return "#8BBDEB"


def _draw_reward_performance_metric_axis(
    ax,
    data: pd.DataFrame,
    *,
    metric: str,
    group_order: list[str],
    group_labels: dict,
    stats_df: pd.DataFrame,
    colors: dict,
    style: dict,
    labels: dict,
    group_mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    rng = np.random.default_rng(int(style["point_seed"]))
    group_meta = (
        data.loc[:, ["plot_group", "month", "day"]].drop_duplicates("plot_group").set_index("plot_group")
        if {"plot_group", "month", "day"}.issubset(data.columns)
        else pd.DataFrame()
    )
    for x, group in enumerate(group_order):
        values = pd.to_numeric(data.loc[data["plot_group"].astype(str) == group, metric], errors="coerce").to_numpy(float)
        values = values[np.isfinite(values)]
        if values.size == 0:
            continue
        row_meta = group_meta.loc[group] if group in group_meta.index else None
        color = _reward_performance_color(group, row_meta, colors)
        mean = float(np.nanmean(values))
        sem = _sem(values)
        rows.append(
            {
                "metric": metric,
                "plot_group": group,
                "plot_label": group_labels.get(group, group),
                "n_sessions": int(values.size),
                "mean": mean,
                "sem": sem,
                "median": float(np.nanmedian(values)),
            }
        )
        ax.bar(
            x,
            mean,
            width=float(style["bar_width"]),
            color=color,
            alpha=float(style["bar_alpha"]),
            edgecolor=colors["edge"],
            linewidth=float(style["bar_linewidth"]),
            zorder=1,
        )
        ax.errorbar(
            x,
            mean,
            yerr=sem,
            color=colors["error"],
            capsize=float(style["errorbar_capsize"]),
            linewidth=float(style["errorbar_linewidth"]),
            zorder=2,
        )
        jitter = rng.normal(0.0, float(style["point_jitter"]), size=values.size)
        ax.scatter(
            np.full(values.size, float(x)) + jitter,
            values,
            s=float(style["point_size"]),
            alpha=float(style["point_alpha"]),
            color=color,
            edgecolors="none",
            zorder=3,
        )

    title = labels["metric_titles"].get(metric, metric)
    if title:
        ax.set_title(str(title), loc="left", fontsize=float(style["title_fontsize"]))
    ax.set_ylabel(labels["metric_ylabels"].get(metric, metric), fontsize=float(style["axis_label_fontsize"]))
    ax.set_xticks(np.arange(len(group_order), dtype=float))
    rotation = float(style["month_xtick_rotation"] if group_mode == "month_stage" else style["xtick_rotation"])
    ax.set_xticklabels(
        [group_labels.get(group, group) for group in group_order],
        rotation=rotation,
        ha="right" if rotation else "center",
        fontsize=float(style["tick_labelsize"]),
    )
    ax.tick_params(axis="y", labelsize=float(style["tick_labelsize"]))
    ax.tick_params(axis="x", length=0)
    if bool(style["show_grid"]):
        ax.grid(True, axis="y", color=colors["grid"], alpha=float(style["grid_alpha"]), linewidth=0.6)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(bool(style.get(f"spine_{spine}", False)))
    ax.spines["left"].set_color(colors["axis"])
    ax.spines["bottom"].set_color(colors["axis"])
    annotation_rows = _draw_reward_performance_annotations(
        ax,
        stats_df,
        metric=metric,
        group_order=group_order,
        group_mode=group_mode,
        style=style,
    )
    return pd.DataFrame(rows), annotation_rows


def render_reward_performance_metric_grid(
    per_session_csv,
    *,
    metrics=REWARD_PERFORMANCE_METRICS,
    group_mode: str = "pooled",
    include_experienced_day2: bool = False,
    stats_csv=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "supplement_reward_performance_metrics",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render selected reward-performance metrics from the cached per-session table."""
    panel_layout = get_reward_performance_layout(layout)
    panel_colors = get_reward_performance_colors(colors)
    panel_style = get_reward_performance_style(style)
    panel_labels = get_reward_performance_labels(labels)
    metrics = [str(metric) for metric in metrics]
    stats_df = _read_optional_table(stats_csv)

    df = pd.read_csv(Path(per_session_csv)).copy()
    missing = [metric for metric in metrics if metric not in df.columns]
    if missing:
        raise KeyError(f"Missing metric columns: {missing}")
    if "load_ok" in df.columns:
        df = df.loc[df["load_ok"].astype(bool)].copy()
    df, group_order, group_labels = _reward_performance_group_columns(
        df,
        group_mode,
        include_experienced_day2=bool(include_experienced_day2),
    )
    ncols = int(panel_layout["ncols"])
    nrows = int(np.ceil(len(metrics) / max(ncols, 1)))
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig, axes = plt.subplots(nrows, ncols, figsize=resolved_panel_size, squeeze=False, facecolor="white")
    summary_parts = []
    annotation_parts = []
    for ax, metric in zip(axes.ravel(), metrics):
        summary, annotations = _draw_reward_performance_metric_axis(
            ax,
            df,
            metric=metric,
            group_order=group_order,
            group_labels=group_labels,
            stats_df=stats_df,
            colors=panel_colors,
            style=panel_style,
            labels=panel_labels,
            group_mode=str(group_mode),
        )
        summary_parts.append(summary)
        if not annotations.empty:
            annotation_parts.append(annotations)
    for ax in axes.ravel()[len(metrics) :]:
        ax.axis("off")
    adjust_kwargs = {
        "wspace": float(panel_layout["wspace"]),
        "hspace": float(panel_layout["hspace"]),
    }
    for key in ("left", "right", "bottom", "top"):
        if key in panel_layout:
            adjust_kwargs[key] = float(panel_layout[key])
    fig.subplots_adjust(**adjust_kwargs)
    panel_data = {
        "points": df,
        "summary": pd.concat(summary_parts, ignore_index=True) if summary_parts else pd.DataFrame(),
        "stats": pd.concat(annotation_parts, ignore_index=True) if annotation_parts else pd.DataFrame(),
        "metrics": metrics,
        "group_order": group_order,
        "group_mode": str(group_mode),
        "include_experienced_day2": bool(include_experienced_day2),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_turning_bias_return_second_panel(
    csv_path,
    *,
    fraction: str = "1/32",
    groups: tuple[str, ...] = ("LTM", "experienced"),
    metric_pairs: list[dict] | None = None,
    min_axis_support: int | None = 10,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "turning_bias_return_vs_second_first_1_32_support10",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the supplement return-night vs second-night turning-bias panel.

    This intentionally reuses the same current CSV, four-bias mapping, first
    ``1/32`` fraction, and support filter as the main Figure 1 turning-bias
    panel, changing only the displayed groups.
    """
    panel_layout = get_turning_bias_return_second_layout(layout)
    panel_colors = get_turning_bias_return_second_colors(colors)
    panel_style = get_turning_bias_return_second_style(style)
    panel_labels = get_turning_bias_return_second_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    candidate_points, kept_points, excluded_points, rendered_metric_pairs, support_columns = (
        prepare_turning_bias_four_bias_points(
            csv_path=csv_path,
            fraction=fraction,
            groups=groups,
            metric_pairs=metric_pairs,
            min_axis_support=min_axis_support,
        )
    )
    fig, axes, rendered_points, saved_paths = render_turning_bias_four_bias_panel(
        csv_path=csv_path,
        fraction=fraction,
        groups=groups,
        metric_pairs=metric_pairs,
        min_axis_support=min_axis_support,
        panel_size=resolved_panel_size,
        layout=panel_layout,
        colors=panel_colors,
        style=panel_style,
        labels=panel_labels,
        save=save,
        panel_name=panel_name,
        output_dir=output_dir,
        formats=formats,
    )
    metric_pairs_df = pd.DataFrame(
        [
            {
                **{key: value for key, value in pair.items() if key != "reference_xy"},
                "reference_x": tuple(pair.get("reference_xy", (np.nan, np.nan)))[0],
                "reference_y": tuple(pair.get("reference_xy", (np.nan, np.nan)))[1],
            }
            for pair in rendered_metric_pairs
        ]
    )
    support_audit_columns = [
        "nickname",
        "group",
        "exclusion_reason",
        "support_threshold",
        "min_display_support",
        "n_events",
        *list(support_columns),
        "Bf",
        "Lf",
        "Ba",
        "Lo",
    ]
    support_audit = excluded_points.loc[
        :,
        [col for col in support_audit_columns if col in excluded_points.columns],
    ].copy()
    if not support_audit.empty:
        support_audit = support_audit.sort_values(["group", "nickname"]).reset_index(drop=True)
    panel_data = {
        "candidate_points": candidate_points,
        "points": rendered_points,
        "kept_points": kept_points,
        "excluded_points": excluded_points,
        "support_audit": support_audit,
        "metric_pairs": metric_pairs_df,
        "support_columns": list(support_columns),
        "groups": tuple(groups),
        "fraction": str(fraction),
        "min_axis_support": min_axis_support,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    return fig, axes, panel_data, saved_paths


def _default_turning_bias_selected_chunk_metric_pairs() -> list[dict]:
    return [
        {
            "x_col": "Bf",
            "y_col": "Lf",
            "xlabel": r"$P_{\mathrm{SF}}$",
            "ylabel": r"$P_{\mathrm{BF}}$",
            "reference_xy": (2.0 / 3.0, 2.0 / 3.0),
        },
        {
            "x_col": "Ba",
            "y_col": "Lo",
            "xlabel": r"$P_{\mathrm{SA}}$",
            "ylabel": r"$P_{\mathrm{BS}}$",
            "reference_xy": (0.5, 0.5),
        },
    ]


def render_turning_bias_selected_chunk_scatter_panel(
    csv_path,
    *,
    chunks: tuple[int, ...] = TURNING_BIAS_SELECTED_CHUNKS,
    groups: tuple[str, ...] = ("naive", "LTM"),
    metric_pairs: list[dict] | None = None,
    min_axis_support: int | None = 10,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "turning_bias_selected_chunks_scatter",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render selected chunk-size turning-bias scatter grids.

    The top row plots ``Bf``/``Lf`` as ``P_SF``/``P_BF`` and the bottom row
    plots ``Ba``/``Lo`` as ``P_SA``/``P_BS``. Support filtering is applied
    pair-wise so each row uses the relevant axis support columns.
    """
    panel_layout = get_turning_bias_selected_chunk_layout(layout)
    panel_colors = get_turning_bias_selected_chunk_colors(colors)
    panel_style = get_turning_bias_selected_chunk_style(style)
    panel_labels = get_turning_bias_selected_chunk_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    rendered_metric_pairs = deepcopy(metric_pairs) if metric_pairs is not None else (
        _default_turning_bias_selected_chunk_metric_pairs()
    )
    chunk_values = tuple(int(chunk) for chunk in chunks)
    group_values = tuple(str(group) for group in groups)

    points_df = pd.read_csv(Path(csv_path))
    required_base_columns = {"nickname", "group", "n_chunks"}
    missing_base_columns = required_base_columns.difference(points_df.columns)
    if missing_base_columns:
        raise ValueError(f"Turning-bias CSV is missing required columns: {sorted(missing_base_columns)}")
    missing_metric_columns = []
    for pair in rendered_metric_pairs:
        missing_metric_columns.extend(
            col for col in (str(pair["x_col"]), str(pair["y_col"])) if col not in points_df.columns
        )
    if missing_metric_columns:
        raise ValueError(
            "Turning-bias CSV is missing required metric columns: "
            f"{sorted(set(missing_metric_columns))}"
        )

    points_df = points_df.loc[
        points_df["group"].astype(str).isin(group_values)
        & pd.to_numeric(points_df["n_chunks"], errors="coerce").isin(chunk_values)
    ].copy()
    if points_df.empty:
        raise ValueError(
            f"No turning-bias rows found for groups={group_values!r} and chunks={chunk_values!r}."
        )
    missing_groups = set(group_values).difference(set(points_df["group"].astype(str)))
    if missing_groups:
        raise ValueError(f"Turning-bias CSV is missing required groups: {sorted(missing_groups)}")
    missing_chunks = set(chunk_values).difference(
        set(pd.to_numeric(points_df["n_chunks"], errors="coerce").dropna().astype(int))
    )
    if missing_chunks:
        raise ValueError(f"Turning-bias CSV is missing required chunks: {sorted(missing_chunks)}")

    n_rows = len(rendered_metric_pairs)
    n_cols = len(chunk_values)
    fig, axes = plt.subplots(
        n_rows,
        n_cols,
        figsize=resolved_panel_size,
        squeeze=False,
    )

    chunk_label_map = panel_labels.get("chunk_labels", {})
    group_label_map = panel_labels.get("group_labels", {})
    xlim = tuple(panel_style.get("xlim", (0.0, 1.0)))
    ylim = tuple(panel_style.get("ylim", (0.0, 1.0)))
    xticks = tuple(panel_style.get("xticks", (0.0, 0.5, 1.0)))
    yticks = tuple(panel_style.get("yticks", (0.0, 0.5, 1.0)))
    reference_color = panel_colors.get("reference", "black")
    plot_point_parts = []
    excluded_parts = []
    support_columns_by_pair = []

    for row_index, pair in enumerate(rendered_metric_pairs):
        x_col = str(pair["x_col"])
        y_col = str(pair["y_col"])
        support_columns = [
            str(pair.get("x_support_col", f"n_{x_col}")),
            str(pair.get("y_support_col", f"n_{y_col}")),
        ]
        support_columns_by_pair.extend(support_columns)
        missing_support_columns = [col for col in support_columns if col not in points_df.columns]
        if min_axis_support is not None and missing_support_columns:
            raise ValueError(
                "Turning-bias CSV is missing required support columns: "
                f"{missing_support_columns}"
            )
        pair_points = points_df.copy()
        pair_points["panel_pair"] = f"{x_col}_{y_col}"
        pair_points["x_metric"] = x_col
        pair_points["y_metric"] = y_col
        pair_points["x_value"] = pd.to_numeric(pair_points[x_col], errors="coerce")
        pair_points["y_value"] = pd.to_numeric(pair_points[y_col], errors="coerce")
        pair_points["support_threshold"] = min_axis_support
        pair_points["min_display_support"] = np.nan
        pair_points["exclusion_reason"] = ""
        if min_axis_support is not None:
            support_values = pair_points[support_columns].apply(pd.to_numeric, errors="coerce")
            pair_points["min_display_support"] = support_values.min(axis=1)
            keep = support_values.ge(float(min_axis_support)).all(axis=1)
            excluded = pair_points.loc[~keep].copy()
            if not excluded.empty:
                excluded["exclusion_reason"] = (
                    f"any of {', '.join(support_columns)} < {min_axis_support}"
                )
                excluded_parts.append(excluded)
            pair_points = pair_points.loc[keep].copy()
        plot_point_parts.append(pair_points)

        for col_index, chunk in enumerate(chunk_values):
            ax = axes[row_index, col_index]
            sub = pair_points.loc[pd.to_numeric(pair_points["n_chunks"], errors="coerce").eq(chunk)]
            ref_x, ref_y = tuple(pair.get("reference_xy", (0.5, 0.5)))
            if bool(panel_style.get("show_reference_lines", True)):
                ax.axvline(
                    float(ref_x),
                    color=reference_color,
                    linewidth=float(panel_style.get("reference_linewidth", 0.55)),
                    alpha=float(panel_style.get("reference_alpha", 0.16)),
                    linestyle="--",
                    zorder=0,
                )
                ax.axhline(
                    float(ref_y),
                    color=reference_color,
                    linewidth=float(panel_style.get("reference_linewidth", 0.55)),
                    alpha=float(panel_style.get("reference_alpha", 0.16)),
                    linestyle="--",
                    zorder=0,
                )
            ax.plot(
                [float(ref_x)],
                [float(ref_y)],
                linestyle="None",
                marker=str(panel_style.get("reference_marker", "+")),
                color=reference_color,
                markersize=float(panel_style.get("reference_marker_size", 7.0)),
                markeredgewidth=float(panel_style.get("reference_markeredgewidth", 1.2)),
                zorder=3,
            )
            for group_name in group_values:
                group_key = str(group_name)
                group_rows = sub.loc[sub["group"].astype(str).eq(group_key)]
                ax.scatter(
                    group_rows[x_col],
                    group_rows[y_col],
                    s=float(panel_style.get("marker_size", 14.0)),
                    alpha=float(panel_style.get("marker_alpha", 0.48)),
                    linewidths=float(panel_style.get("marker_linewidth", 0.0)),
                    color=panel_colors.get(group_key, "gray"),
                    zorder=2,
                )
                if not group_rows.empty:
                    ax.scatter(
                        [pd.to_numeric(group_rows[x_col], errors="coerce").mean()],
                        [pd.to_numeric(group_rows[y_col], errors="coerce").mean()],
                        marker=str(panel_style.get("mean_marker", "D")),
                        s=float(panel_style.get("mean_marker_size", 28.0)),
                        color=panel_colors.get(group_key, "gray"),
                        edgecolor=str(panel_style.get("mean_marker_edgecolor", "black")),
                        linewidth=float(panel_style.get("mean_marker_linewidth", 0.45)),
                        zorder=4,
                    )

            ax.set_xlim(*xlim)
            ax.set_ylim(*ylim)
            if bool(panel_style.get("equal_aspect", True)):
                ax.set_aspect("equal", adjustable="box")
            ax.set_xticks(xticks)
            ax.set_yticks(yticks)
            ax.tick_params(
                labelsize=float(panel_style.get("tick_labelsize", 7.2)),
                length=2.2,
                pad=1.5,
            )
            if row_index == 0:
                ax.set_title(
                    str(chunk_label_map.get(int(chunk), str(chunk))),
                    fontsize=float(panel_style.get("title_fontsize", 8.7)),
                    pad=4,
                )
                ax.set_xticklabels([])
            ax.set_xlabel(
                str(pair.get("xlabel", x_col)),
                fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
                labelpad=1.5,
            )
            if col_index == 0:
                ax.set_ylabel(
                    str(pair.get("ylabel", y_col)),
                    fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
                    labelpad=2,
                )
            else:
                ax.set_yticklabels([])
            ax.grid(
                True,
                color=str(panel_style.get("grid_color", "#d8d8d8")),
                linewidth=float(panel_style.get("grid_linewidth", 0.35)),
                alpha=float(panel_style.get("grid_alpha", 0.32)),
            )
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

    legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor=panel_colors.get(str(group), "gray"),
            markeredgecolor="none",
            markersize=float(panel_style.get("legend_marker_size", 5.2)),
            label=str(group_label_map.get(str(group), str(group))),
            alpha=0.75,
        )
        for group in group_values
    ]
    legend_handles.append(
        Line2D(
            [0],
            [0],
            marker=str(panel_style.get("mean_marker", "D")),
            color=str(panel_style.get("mean_marker_edgecolor", "black")),
            markerfacecolor="white",
            markersize=float(panel_style.get("legend_mean_marker_size", 4.7)),
            label=str(panel_labels.get("mean", "Group mean")),
            linewidth=0,
        )
    )
    fig.legend(
        handles=legend_handles,
        loc="upper center",
        ncol=int(panel_style.get("legend_ncol", 3)),
        frameon=False,
        fontsize=float(panel_style.get("legend_fontsize", 7.8)),
        bbox_to_anchor=tuple(panel_style.get("legend_bbox_to_anchor", (0.52, 1.03))),
        handletextpad=float(panel_style.get("legend_handletextpad", 0.35)),
        columnspacing=float(panel_style.get("legend_columnspacing", 1.1)),
    )
    adjust_kwargs = {
        "left": float(panel_layout.get("left", 0.075)),
        "right": float(panel_layout.get("right", 0.995)),
        "bottom": float(panel_layout.get("bottom", 0.095)),
        "top": float(panel_layout.get("top", 0.885)),
        "wspace": float(panel_layout.get("wspace", 0.20)),
        "hspace": float(panel_layout.get("hspace", 0.38)),
    }
    fig.subplots_adjust(**adjust_kwargs)

    plot_points = pd.concat(plot_point_parts, ignore_index=True) if plot_point_parts else pd.DataFrame()
    excluded_points = (
        pd.concat(excluded_parts, ignore_index=True) if excluded_parts else points_df.iloc[0:0].copy()
    )
    metric_pairs_df = pd.DataFrame(
        [
            {
                **{key: value for key, value in pair.items() if key != "reference_xy"},
                "reference_x": tuple(pair.get("reference_xy", (np.nan, np.nan)))[0],
                "reference_y": tuple(pair.get("reference_xy", (np.nan, np.nan)))[1],
            }
            for pair in rendered_metric_pairs
        ]
    )
    support_audit_columns = [
        "panel_pair",
        "nickname",
        "group",
        "n_chunks",
        "fraction",
        "exclusion_reason",
        "support_threshold",
        "min_display_support",
        "n_events",
        *list(dict.fromkeys(support_columns_by_pair)),
        "Bf",
        "Lf",
        "Ba",
        "Lo",
    ]
    support_audit = excluded_points.loc[
        :,
        [col for col in support_audit_columns if col in excluded_points.columns],
    ].copy()
    if not support_audit.empty:
        support_audit = support_audit.sort_values(
            ["panel_pair", "n_chunks", "group", "nickname"]
        ).reset_index(drop=True)

    panel_data = {
        "candidate_points": points_df,
        "points": plot_points,
        "excluded_points": excluded_points,
        "support_audit": support_audit,
        "metric_pairs": metric_pairs_df,
        "support_columns": list(dict.fromkeys(support_columns_by_pair)),
        "chunks": chunk_values,
        "groups": group_values,
        "min_axis_support": min_axis_support,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_cached_turning_bias_gap_explained_panel(
    plot_data_csv,
    *,
    chunks: tuple[int, ...] = TURNING_BIAS_SELECTED_CHUNKS,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "turning_bias_gap_explained_selected_chunks",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the cached selected-chunk simulator explained-gap panel."""
    panel_layout = get_turning_bias_simulator_layout(layout)
    panel_colors = get_turning_bias_graphite_colors(colors)
    panel_style = get_turning_bias_simulator_style(style)
    panel_labels = get_turning_bias_simulator_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    df = pd.read_csv(Path(plot_data_csv))
    required_columns = {
        "model",
        "n_chunks",
        "percent_explained_mean",
        "percent_explained_ci_lo",
        "percent_explained_ci_hi",
    }
    missing_columns = required_columns.difference(df.columns)
    if missing_columns:
        raise ValueError(f"Gap-explained plot data is missing columns: {sorted(missing_columns)}")
    chunk_values = tuple(int(chunk) for chunk in chunks)
    model_order = tuple(str(model) for model in panel_style["model_order"])
    plot_df = df.loc[
        pd.to_numeric(df["n_chunks"], errors="coerce").isin(chunk_values)
        & df["model"].astype(str).isin(model_order)
    ].copy()
    if plot_df.empty:
        raise ValueError("No gap-explained rows remained after selected chunk/model filtering.")

    fig, ax = plt.subplots(figsize=resolved_panel_size)
    x = np.arange(len(chunk_values), dtype=float)
    model_label_map = panel_labels.get("model_labels", {})
    model_marker_map = panel_style.get("model_markers", {})
    chunk_label_map = panel_labels.get("chunk_labels", {})
    for model in model_order:
        sub = (
            plot_df.loc[plot_df["model"].astype(str).eq(model)]
            .set_index("n_chunks")
            .reindex(chunk_values)
            .reset_index()
        )
        if sub["percent_explained_mean"].isna().any():
            raise ValueError(f"Missing gap-explained rows for model={model!r}.")
        y = sub["percent_explained_mean"].to_numpy(dtype=float)
        lo = sub["percent_explained_ci_lo"].to_numpy(dtype=float)
        hi = sub["percent_explained_ci_hi"].to_numpy(dtype=float)
        ax.errorbar(
            x,
            y,
            yerr=np.vstack([y - lo, hi - y]),
            marker=str(model_marker_map.get(model, "o")),
            markersize=float(panel_style.get("marker_size", 4.3)),
            linewidth=float(panel_style.get("line_width", 1.55)),
            capsize=float(panel_style.get("capsize", 2.2)),
            color=panel_colors.get(model, "gray"),
            label=str(model_label_map.get(model, model)),
            zorder=3,
        )
    ax.axhline(
        100.0,
        color=panel_colors.get("reference", "black"),
        linewidth=float(panel_style.get("reference_linewidth", 0.7)),
        linestyle="--",
        alpha=float(panel_style.get("reference_alpha", 0.35)),
        zorder=0,
    )
    ax.axhline(
        0.0,
        color=panel_colors.get("zero", "black"),
        linewidth=float(panel_style.get("reference_linewidth", 0.7)),
        alpha=float(panel_style.get("zero_alpha", 0.25)),
        zorder=0,
    )
    ax.set_xlim(
        -float(panel_style.get("xlim_pad_left", 0.16)),
        len(chunk_values) - float(panel_style.get("xlim_pad_right", 0.70)),
    )
    ax.set_xticks(x)
    ax.set_xticklabels(
        [str(chunk_label_map.get(int(chunk), str(chunk))) for chunk in chunk_values],
        fontsize=float(panel_style.get("tick_labelsize", 7.9)),
    )
    ax.set_ylabel(
        str(panel_labels.get("ylabel", "Gap explained (%)")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.8)),
    )
    ax.set_ylim(*tuple(panel_style.get("ylim", (0.0, 112.0))))
    ax.set_yticks(tuple(panel_style.get("yticks", (0.0, 25.0, 50.0, 75.0, 100.0))))
    ax.tick_params(axis="y", labelsize=float(panel_style.get("tick_labelsize", 7.9)), length=2.2)
    ax.grid(
        axis="y",
        color=panel_colors.get("grid", "#d8d8d8"),
        linewidth=float(panel_style.get("grid_linewidth", 0.4)),
        alpha=float(panel_style.get("grid_alpha", 0.38)),
    )
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(
        frameon=False,
        fontsize=float(panel_style.get("legend_fontsize", 8.0)),
        loc="upper center",
        bbox_to_anchor=tuple(panel_style.get("legend_bbox_to_anchor", (0.53, 1.23))),
        ncol=int(panel_style.get("legend_ncol", 2)),
        handlelength=float(panel_style.get("legend_handlelength", 1.55)),
        handletextpad=float(panel_style.get("legend_handletextpad", 0.45)),
        columnspacing=float(panel_style.get("legend_columnspacing", 0.95)),
    )
    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.15)),
        right=float(panel_layout.get("right", 0.985)),
        bottom=float(panel_layout.get("bottom", 0.19)),
        top=float(panel_layout.get("top", 0.78)),
    )
    panel_data = {
        "summary": plot_df.reset_index(drop=True),
        "chunks": chunk_values,
        "models": model_order,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, ax, panel_data, saved_paths


def render_cached_depth_stratified_pbs_shift_panel(
    plot_data_csv,
    *,
    chunks: tuple[int, ...] = TURNING_BIAS_SELECTED_CHUNKS,
    strata: tuple[str, ...] = ("Lo_shallow", "Lo_mid", "Lo_deep"),
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "depth_stratified_pbs_shift_selected_chunks",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render cached selected-chunk return-minus-naive depth-stratified P_BS shifts."""
    panel_layout = get_turning_bias_depth_pbs_layout(layout)
    panel_colors = get_turning_bias_graphite_colors(colors)
    panel_style = get_turning_bias_depth_pbs_style(style)
    panel_labels = get_turning_bias_depth_pbs_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    df = pd.read_csv(Path(plot_data_csv))
    required_columns = {
        "n_chunks",
        "stratum",
        "delta_mean",
        "delta_ci_lo",
        "delta_ci_hi",
    }
    missing_columns = required_columns.difference(df.columns)
    if missing_columns:
        raise ValueError(f"Depth-P_BS plot data is missing columns: {sorted(missing_columns)}")
    chunk_values = tuple(int(chunk) for chunk in chunks)
    stratum_values = tuple(str(stratum) for stratum in strata)
    plot_df = df.loc[
        pd.to_numeric(df["n_chunks"], errors="coerce").isin(chunk_values)
        & df["stratum"].astype(str).isin(stratum_values)
    ].copy()
    if plot_df.empty:
        raise ValueError("No depth-P_BS rows remained after selected chunk/stratum filtering.")

    fig, ax = plt.subplots(figsize=resolved_panel_size)
    x = np.arange(len(stratum_values), dtype=float)
    chunk_label_map = panel_labels.get("chunk_labels", {})
    stratum_label_map = panel_labels.get("stratum_labels", {})
    chunk_marker_map = panel_style.get("chunk_markers", {})
    for chunk in chunk_values:
        sub = (
            plot_df.loc[pd.to_numeric(plot_df["n_chunks"], errors="coerce").eq(chunk)]
            .set_index("stratum")
            .reindex(stratum_values)
            .reset_index()
        )
        if sub["delta_mean"].isna().any():
            raise ValueError(f"Missing depth-P_BS rows for chunk={chunk!r}.")
        y = sub["delta_mean"].to_numpy(dtype=float)
        lo = sub["delta_ci_lo"].to_numpy(dtype=float)
        hi = sub["delta_ci_hi"].to_numpy(dtype=float)
        ax.errorbar(
            x,
            y,
            yerr=np.vstack([y - lo, hi - y]),
            marker=str(chunk_marker_map.get(int(chunk), "o")),
            markersize=float(panel_style.get("marker_size", 4.35)),
            linewidth=float(panel_style.get("line_width", 1.6)),
            capsize=float(panel_style.get("capsize", 2.0)),
            color=panel_colors.get(int(chunk), panel_colors.get(str(chunk), "gray")),
            label=str(chunk_label_map.get(int(chunk), str(chunk))),
            zorder=3,
        )
    ax.axhline(
        0.0,
        color=panel_colors.get("zero", "black"),
        linewidth=float(panel_style.get("zero_linewidth", 0.65)),
        linestyle="--",
        alpha=float(panel_style.get("zero_alpha", 0.24)),
        zorder=0,
    )
    ax.set_xticks(x)
    ax.set_xticklabels(
        [str(stratum_label_map.get(stratum, stratum)) for stratum in stratum_values],
        fontsize=float(panel_style.get("tick_labelsize", 8.0)),
    )
    ax.set_ylabel(
        str(panel_labels.get("ylabel", r"Return - naive $P_{\mathrm{BS}}$")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.8)),
    )
    ax.set_ylim(*tuple(panel_style.get("ylim", (-0.035, 0.255))))
    ax.set_yticks(tuple(panel_style.get("yticks", (0.0, 0.1, 0.2))))
    ax.tick_params(axis="y", labelsize=float(panel_style.get("tick_labelsize", 8.0)), length=2.2)
    ax.grid(
        axis="y",
        color=panel_colors.get("grid", "#d8d8d8"),
        linewidth=float(panel_style.get("grid_linewidth", 0.4)),
        alpha=float(panel_style.get("grid_alpha", 0.30)),
    )
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(
        frameon=False,
        fontsize=float(panel_style.get("legend_fontsize", 7.8)),
        loc="upper center",
        bbox_to_anchor=tuple(panel_style.get("legend_bbox_to_anchor", (0.5, 1.23))),
        ncol=int(panel_style.get("legend_ncol", 4)),
        handlelength=float(panel_style.get("legend_handlelength", 1.35)),
        handletextpad=float(panel_style.get("legend_handletextpad", 0.35)),
        columnspacing=float(panel_style.get("legend_columnspacing", 0.75)),
    )
    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.16)),
        right=float(panel_layout.get("right", 0.99)),
        bottom=float(panel_layout.get("bottom", 0.20)),
        top=float(panel_layout.get("top", 0.78)),
    )
    panel_data = {
        "summary": plot_df.reset_index(drop=True),
        "chunks": chunk_values,
        "strata": stratum_values,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, ax, panel_data, saved_paths


def prepare_bodymass_speed_mode_plot_data(
    summary_csv,
    *,
    position_source: str = "bodymass",
    scope_min: float | tuple[float, ...] = 60.0,
    median_window: int = 5,
    max_segment_speed_cm_s: float = 80.0,
    bin_size_min: float = 5.0,
    mode_order: tuple[str, ...] = ("all", "explore", "reward"),
    month_order: tuple[int, ...] = (0, 3, 6, 9, 12),
) -> pd.DataFrame:
    """Prepare semantic-group plot data from cached continuous-speed summaries."""
    summary = pd.read_csv(Path(summary_csv))
    required_columns = {
        "day",
        "month_num",
        "position_source",
        "median_window",
        "max_segment_speed_cm_s",
        "bin_size_min",
        "scope_min",
        "mode_label",
        "mode_time_distance_rate_cm_s_mean",
        "mode_time_distance_rate_cm_s_sem",
        "n_sessions",
        "n_animals",
    }
    missing_columns = required_columns.difference(summary.columns)
    if missing_columns:
        raise ValueError(f"Speed-mode summary is missing columns: {sorted(missing_columns)}")
    work = summary.copy()
    work["month"] = pd.to_numeric(work["month_num"], errors="coerce").astype("Int64")
    if isinstance(scope_min, (list, tuple, set, np.ndarray, pd.Series)):
        scope_values = [float(value) for value in scope_min]
    else:
        scope_values = [float(scope_min)]
    filters = (
        work["position_source"].astype(str).eq(position_source)
        & pd.to_numeric(work["scope_min"], errors="coerce").isin(scope_values)
        & pd.to_numeric(work["median_window"], errors="coerce").eq(int(median_window))
        & pd.to_numeric(work["max_segment_speed_cm_s"], errors="coerce").eq(float(max_segment_speed_cm_s))
        & pd.to_numeric(work["bin_size_min"], errors="coerce").eq(float(bin_size_min))
        & work["mode_label"].astype(str).isin(mode_order)
        & work["month"].isin([int(month) for month in month_order])
    )
    work = work.loc[filters].copy()
    if work.empty:
        raise ValueError("No speed-mode rows remained after filtering.")

    day = work["day"].astype(str)
    month = work["month"].astype(int)
    group_key = np.full(len(work), "", dtype=object)
    group_key[(day == "day1") & (month == 0)] = "naive"
    group_key[(day == "day1") & (month > 0)] = "return"
    group_key[day == "day2"] = "experienced_day2"
    work["group_key"] = group_key
    work = work.loc[work["group_key"].astype(bool)].copy()
    group_order = {"naive": 0, "return": 1, "experienced_day2": 2}
    group_labels = SPEED_MODE_LABELS["group_labels"]
    work["group_order"] = work["group_key"].map(group_order).astype(int)
    work["group_label"] = work["group_key"].map(group_labels)
    work["mode_order"] = work["mode_label"].map({mode: idx for idx, mode in enumerate(mode_order)}).astype(int)
    work["speed_mean_cm_s"] = pd.to_numeric(work["mode_time_distance_rate_cm_s_mean"], errors="coerce")
    work["speed_sem_cm_s"] = pd.to_numeric(work["mode_time_distance_rate_cm_s_sem"], errors="coerce")
    columns = [
        "mode_label",
        "mode_order",
        "day",
        "month",
        "group_key",
        "group_label",
        "group_order",
        "speed_mean_cm_s",
        "speed_sem_cm_s",
        "n_sessions",
        "n_animals",
        "scope_min",
        "median_window",
        "max_segment_speed_cm_s",
        "bin_size_min",
        "position_source",
    ]
    for optional_column in [
        "eligible_time_sec_mean",
        "valid_pair_fraction_mean",
        "valid_pair_fraction_of_mode_time_mean",
        "kept_pair_fraction_mean",
    ]:
        if optional_column in work.columns:
            columns.append(optional_column)
    return work[columns].sort_values(["mode_order", "group_order", "month"]).reset_index(drop=True)


def render_cached_bodymass_speed_mode_panel(
    plot_data_csv,
    *,
    mode_order: tuple[str, ...] = ("all", "explore", "reward"),
    group_order: tuple[str, ...] = ("naive", "return", "experienced_day2"),
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "bodymass_speed_by_mode_first60_semantic",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the first-60-minute bodymass speed-by-mode panel from plot-ready data."""
    panel_layout = get_speed_mode_layout(layout)
    panel_colors = get_speed_mode_colors(colors)
    panel_style = get_speed_mode_style(style)
    panel_labels = get_speed_mode_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    plot_df = pd.read_csv(Path(plot_data_csv))
    required_columns = {
        "mode_label",
        "month",
        "group_key",
        "group_label",
        "speed_mean_cm_s",
        "speed_sem_cm_s",
        "scope_min",
    }
    missing_columns = required_columns.difference(plot_df.columns)
    if missing_columns:
        raise ValueError(f"Speed-mode plot data is missing columns: {sorted(missing_columns)}")
    plot_df["month"] = pd.to_numeric(plot_df["month"], errors="coerce")
    plot_df["speed_mean_cm_s"] = pd.to_numeric(plot_df["speed_mean_cm_s"], errors="coerce")
    plot_df["speed_sem_cm_s"] = pd.to_numeric(plot_df["speed_sem_cm_s"], errors="coerce")
    plot_df = plot_df.dropna(subset=["month", "speed_mean_cm_s"]).copy()
    if plot_df.empty:
        raise ValueError("No finite speed-mode plot rows are available.")

    fig, axes = plt.subplots(1, len(mode_order), figsize=resolved_panel_size, sharey=True)
    axes = np.atleast_1d(axes)
    mode_titles = panel_labels.get("mode_titles", {})
    group_labels = panel_labels.get("group_labels", {})
    for ax, mode in zip(axes, mode_order):
        sub_mode = plot_df.loc[plot_df["mode_label"].astype(str).eq(mode)].copy()
        for group in group_order:
            sub = sub_mode.loc[sub_mode["group_key"].astype(str).eq(group)].sort_values("month")
            if sub.empty:
                continue
            x = sub["month"].to_numpy(dtype=float)
            y = sub["speed_mean_cm_s"].to_numpy(dtype=float)
            sem = sub["speed_sem_cm_s"].to_numpy(dtype=float)
            yerr = None if np.all(~np.isfinite(sem)) else sem
            linestyle = "-" if len(sub) > 1 else str(panel_style.get("single_point_linestyle", "none"))
            marker_size = float(
                panel_style.get("single_point_marker_size") or panel_style.get("marker_size", 4.5)
                if len(sub) == 1
                else panel_style.get("marker_size", 4.5)
            )
            color = panel_colors.get(group, "gray")
            ax.plot(
                x,
                y,
                marker="o",
                markersize=marker_size,
                linewidth=float(panel_style.get("line_width", 1.75)),
                linestyle=linestyle,
                color=color,
                markerfacecolor=color,
                markeredgecolor=color,
                markeredgewidth=0.0,
                label=str(group_labels.get(group, group)),
                zorder=3,
            )
            if yerr is not None:
                errorbar_color = (
                    panel_style.get("single_point_errorbar_color", color) or color
                    if len(sub) == 1
                    else color
                )
                ax.errorbar(
                    x,
                    y,
                    yerr=yerr,
                    fmt="none",
                    capsize=float(panel_style.get("capsize", 2.2)),
                    elinewidth=float(panel_style.get("elinewidth", 1.15)),
                    capthick=float(panel_style.get("elinewidth", 1.15)),
                    color=errorbar_color,
                    zorder=4,
                )
        ax.set_title(
            str(mode_titles.get(mode, mode)),
            fontsize=float(panel_style.get("title_fontsize", 10.5)),
            pad=5,
        )
        ax.set_xticks(tuple(panel_style.get("xticks", (0, 3, 6, 9, 12))))
        ax.set_xlabel(
            str(panel_labels.get("xlabel", "Month group")),
            fontsize=float(panel_style.get("axis_label_fontsize", 9.5)),
        )
        ax.tick_params(labelsize=float(panel_style.get("tick_labelsize", 8.5)))
        ax.grid(
            color=panel_colors.get("grid", "#d8d8d8"),
            alpha=float(panel_style.get("grid_alpha", 0.30)),
            linewidth=float(panel_style.get("grid_linewidth", 0.45)),
        )
        ax.spines["top"].set_visible(bool(panel_style.get("spine_top", True)))
        ax.spines["right"].set_visible(bool(panel_style.get("spine_right", True)))
    axes[0].set_ylabel(
        str(panel_labels.get("ylabel", "Bodymass speed (cm/s)")),
        fontsize=float(panel_style.get("axis_label_fontsize", 9.5)),
    )
    if panel_style.get("shared_ylim") is not None:
        axes[0].set_ylim(*tuple(panel_style["shared_ylim"]))
    handles, legend_labels = axes[0].get_legend_handles_labels()
    if handles:
        axes[0].legend(
            handles,
            legend_labels,
            frameon=False,
            fontsize=float(panel_style.get("legend_fontsize", 8.8)),
            loc=str(panel_style.get("legend_loc", "upper left")),
        )
    scope_values = pd.to_numeric(plot_df["scope_min"], errors="coerce").dropna().unique()
    scope_min = float(scope_values[0]) if len(scope_values) else 60.0
    fig.suptitle(
        str(panel_labels.get("suptitle", "")).format(scope_min=scope_min),
        fontsize=float(panel_style.get("suptitle_fontsize", 11.0)),
    )
    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.075)),
        right=float(panel_layout.get("right", 0.995)),
        bottom=float(panel_layout.get("bottom", 0.20)),
        top=float(panel_layout.get("top", 0.78)),
        wspace=float(panel_layout.get("wspace", 0.08)),
    )
    panel_data = {
        "summary": plot_df.reset_index(drop=True),
        "mode_order": tuple(mode_order),
        "group_order": tuple(group_order),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def _plot_speed_mode_group_lines(
    ax,
    sub_mode: pd.DataFrame,
    *,
    group_order: tuple[str, ...],
    panel_colors: dict,
    panel_style: dict,
    group_labels: dict,
    show_labels: bool = True,
) -> None:
    for group in group_order:
        sub = sub_mode.loc[sub_mode["group_key"].astype(str).eq(group)].sort_values("month")
        if sub.empty:
            continue
        x = sub["month"].to_numpy(dtype=float)
        y = sub["speed_mean_cm_s"].to_numpy(dtype=float)
        sem = sub["speed_sem_cm_s"].to_numpy(dtype=float)
        yerr = None if np.all(~np.isfinite(sem)) else sem
        linestyle = "-" if len(sub) > 1 else str(panel_style.get("single_point_linestyle", "none"))
        marker_size = float(
            panel_style.get("single_point_marker_size") or panel_style.get("marker_size", 4.5)
            if len(sub) == 1
            else panel_style.get("marker_size", 4.5)
        )
        color = panel_colors.get(group, "gray")
        ax.plot(
            x,
            y,
            marker="o",
            markersize=marker_size,
            linewidth=float(panel_style.get("line_width", 1.75)),
            linestyle=linestyle,
            color=color,
            markerfacecolor=color,
            markeredgecolor=color,
            markeredgewidth=0.0,
            label=str(group_labels.get(group, group)) if show_labels else None,
            zorder=3,
        )
        if yerr is not None:
            errorbar_color = panel_style.get("single_point_errorbar_color", color) or color if len(sub) == 1 else color
            ax.errorbar(
                x,
                y,
                yerr=yerr,
                fmt="none",
                capsize=float(panel_style.get("capsize", 2.2)),
                elinewidth=float(panel_style.get("elinewidth", 1.15)),
                capthick=float(panel_style.get("elinewidth", 1.15)),
                color=errorbar_color,
                zorder=4,
            )


def render_cached_bodymass_speed_mode_scope_grid_panel(
    plot_data_csv,
    *,
    scopes_min: tuple[float, ...] = (60.0, 120.0, 180.0, 240.0, 300.0),
    mode_order: tuple[str, ...] = ("all", "explore", "reward"),
    group_order: tuple[str, ...] = ("naive", "return", "experienced_day2"),
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "bodymass_speed_by_mode_scopes_semantic",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render bodymass speed-by-mode for multiple maze-time windows."""
    panel_layout = get_speed_mode_layout(layout)
    panel_colors = get_speed_mode_colors(colors)
    panel_style = get_speed_mode_style(style)
    panel_labels = get_speed_mode_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["scope_grid_panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    plot_df = pd.read_csv(Path(plot_data_csv))
    required_columns = {
        "mode_label",
        "month",
        "group_key",
        "group_label",
        "speed_mean_cm_s",
        "speed_sem_cm_s",
        "scope_min",
    }
    missing_columns = required_columns.difference(plot_df.columns)
    if missing_columns:
        raise ValueError(f"Speed-mode plot data is missing columns: {sorted(missing_columns)}")
    for col in ["month", "speed_mean_cm_s", "speed_sem_cm_s", "scope_min"]:
        plot_df[col] = pd.to_numeric(plot_df[col], errors="coerce")
    plot_df = plot_df.dropna(subset=["month", "speed_mean_cm_s", "scope_min"]).copy()
    if plot_df.empty:
        raise ValueError("No finite speed-mode plot rows are available.")

    scope_values = tuple(float(scope) for scope in scopes_min)
    fig, axes = plt.subplots(len(scope_values), len(mode_order), figsize=resolved_panel_size, sharex=True, sharey=True)
    axes = np.asarray(axes)
    if axes.ndim == 1:
        axes = axes.reshape(len(scope_values), len(mode_order))
    mode_titles = panel_labels.get("mode_titles", {})
    group_labels = panel_labels.get("group_labels", {})
    for row_idx, scope in enumerate(scope_values):
        sub_scope = plot_df.loc[plot_df["scope_min"].eq(float(scope))].copy()
        for col_idx, mode in enumerate(mode_order):
            ax = axes[row_idx, col_idx]
            sub_mode = sub_scope.loc[sub_scope["mode_label"].astype(str).eq(mode)].copy()
            _plot_speed_mode_group_lines(
                ax,
                sub_mode,
                group_order=group_order,
                panel_colors=panel_colors,
                panel_style=panel_style,
                group_labels=group_labels,
                show_labels=(row_idx == 0 and col_idx == 0),
            )
            if row_idx == 0:
                ax.set_title(
                    str(mode_titles.get(mode, mode)),
                    fontsize=float(panel_style.get("title_fontsize", 10.5)),
                    pad=5,
                )
            if col_idx == 0:
                ax.set_ylabel(
                    str(panel_labels.get("ylabel", "Bodymass speed (cm/s)")),
                    fontsize=float(panel_style.get("axis_label_fontsize", 9.5)),
                )
                ax.text(
                    float(panel_style.get("scope_label_x", -0.24)),
                    0.5,
                    str(panel_labels.get("scope_label", "{scope_min:g} min")).format(scope_min=scope),
                    transform=ax.transAxes,
                    ha="right",
                    va="center",
                    rotation=90,
                    fontsize=float(panel_style.get("scope_label_fontsize", 9.2)),
                )
            if row_idx == len(scope_values) - 1:
                ax.set_xlabel(
                    str(panel_labels.get("xlabel", "Month group")),
                    fontsize=float(panel_style.get("axis_label_fontsize", 9.5)),
                )
            ax.set_xticks(tuple(panel_style.get("xticks", (0, 3, 6, 9, 12))))
            ax.tick_params(labelsize=float(panel_style.get("tick_labelsize", 8.5)))
            ax.grid(
                color=panel_colors.get("grid", "#d8d8d8"),
                alpha=float(panel_style.get("grid_alpha", 0.30)),
                linewidth=float(panel_style.get("grid_linewidth", 0.45)),
            )
            ax.spines["top"].set_visible(bool(panel_style.get("spine_top", True)))
            ax.spines["right"].set_visible(bool(panel_style.get("spine_right", True)))
    if panel_style.get("shared_ylim") is not None:
        axes[0, 0].set_ylim(*tuple(panel_style["shared_ylim"]))
    handles, legend_labels = axes[0, 0].get_legend_handles_labels()
    if handles:
        axes[0, 0].legend(
            handles,
            legend_labels,
            frameon=False,
            fontsize=float(panel_style.get("legend_fontsize", 8.8)),
            loc=str(panel_style.get("legend_loc", "upper left")),
        )
    fig.suptitle(
        str(panel_labels.get("scope_grid_suptitle", "")),
        fontsize=float(panel_style.get("suptitle_fontsize", 11.0)),
    )
    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.075)),
        right=float(panel_layout.get("right", 0.995)),
        bottom=float(panel_layout.get("scope_grid_bottom", panel_layout.get("bottom", 0.12))),
        top=float(panel_layout.get("scope_grid_top", 0.91)),
        wspace=float(panel_layout.get("wspace", 0.08)),
        hspace=float(panel_layout.get("scope_grid_hspace", 0.20)),
    )
    panel_data = {
        "summary": plot_df.reset_index(drop=True),
        "scopes_min": scope_values,
        "mode_order": tuple(mode_order),
        "group_order": tuple(group_order),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


LATENT_RETURN_JUNCTION_COLORS = {
    "latent": "#2E7D32",
    "return": "#DA2323",
    "specificity": "#4C78A8",
    "nonsig": "#6f7378",
    "grid": "#d8d8d8",
    "zero": "#303030",
}

LATENT_RETURN_JUNCTION_LABELS = {
    "condition_labels": {
        "latent": "Latent D2 sessions",
        "return": "Return sessions",
    },
    "row_labels": {
        "pre_explore_all_junctions": "Pre-reward\nexplore dwell",
        "pre_explore_direct_minus_other": "Pre-reward\nspecificity",
        "all_post_reward_approach_direct_chain": "Post-reward\napproach dwell",
    },
    "suptitle": "Latent vs return: junction timing claims",
    "raw_title": "Session and animal values",
    "effect_title": "Animal-balanced effects",
    "raw_xlabel": "Dwell or delta (s)",
    "effect_xlabel": "Return - latent (s)",
}

LATENT_RETURN_JUNCTION_LAYOUT = {
    "panel_size": (8.7, 3.7),
    "width_ratios": (1.35, 1.0),
    "wspace": 0.12,
    "left": 0.18,
    "right": 0.985,
    "bottom": 0.18,
    "top": 0.85,
    "raw_xlim": (-0.32, 1.24),
    "effect_xlim": (-0.55, 0.45),
}

LATENT_RETURN_JUNCTION_STYLE = {
    "session_marker_size": 13,
    "session_alpha": 0.22,
    "animal_marker_size": 34,
    "animal_alpha": 0.92,
    "animal_edgecolor": "white",
    "animal_edgewidth": 0.45,
    "animal_mean_linewidth": 2.3,
    "effect_linewidth": 1.9,
    "effect_capsize": 3.3,
    "effect_markersize": 5.8,
    "title_fontsize": 10.6,
    "suptitle_fontsize": 12.0,
    "axis_label_fontsize": 9.5,
    "tick_labelsize": 8.4,
    "legend_fontsize": 8.4,
    "q_label_fontsize": 8.2,
    "grid_alpha": 0.22,
    "grid_linewidth": 0.8,
}


REWARD_SEQUENCE_MEMORY_CONDITION_ORDER = ("naive", "experienced_day2", "return", "latent_day2")

REWARD_SEQUENCE_MEMORY_COLORS = {
    "naive": BEHAVIOR_ACCUMULATION_COLORS["naive"],
    "experienced_day2": EXPLORATION_CYCLE_COLORS["experienced_day2"],
    "return": BEHAVIOR_ACCUMULATION_COLORS["return"],
    "latent_day2": "#F2A15F",
    "maze_path": "#155D73",
    "maze_label_face": "#155D73",
    "maze_label_text": "white",
    "decision_node_face": "#155D73",
    "decision_node_edge": "white",
    "water": "#36A3FF",
    "water_edge": "#0866B2",
    "chance": "#777777",
    "axis": "#202020",
    "grid": "#D8D8D8",
    "point_edge": "white",
}

REWARD_SEQUENCE_MEMORY_LAYOUT = {
    "panel_size": (9.3, 4.65),
    "width_ratios": (1.55, 1.0, 1.0, 1.0, 1.0),
    "height_ratios": (1.22, 0.58),
    "wspace": 0.38,
    "hspace": 0.42,
    "left": 0.055,
    "right": 0.985,
    "bottom": 0.13,
    "top": 0.88,
    "maze_xlim": (-1.25, 15.9),
    "maze_ylim": (15.45, -0.75),
    "depth_ylim": (0.0, 1.05),
    "group_ylim": (0.0, 1.40),
}

REWARD_SEQUENCE_MEMORY_STYLE = {
    "maze_wall_linewidth": 0.75,
    "gray_block_linewidth": 0.25,
    "reward_path_linewidth": 1.9,
    "reward_path_alpha": 0.92,
    "reward_path_marker_size": 18,
    "decision_node_size": 0.74,
    "decision_node_linewidth": 0.55,
    "maze_depth_label_fontsize": 5.8,
    "maze_depth_label_boxsize": 0.55,
    "water_size": 0.70,
    "bar_width": 0.72,
    "bar_alpha": 0.38,
    "bar_edgecolor": "none",
    "errorbar_linewidth": 0.85,
    "errorbar_capsize": 2.0,
    "axis_label_fontsize": 9.5,
    "tick_labelsize": 8.0,
    "title_fontsize": 9.6,
    "suptitle_fontsize": 12.0,
    "group_bar_width": 0.11,
    "group_point_size": 8,
    "group_point_alpha": 0.38,
    "group_point_jitter": 0.020,
    "group_errorbar_linewidth": 0.90,
    "group_errorbar_capsize": 2.4,
    "legend_fontsize": 8.0,
    "stat_fontsize": 8.0,
    "bracket_linewidth": 0.9,
    "bracket_tick_height": 0.035,
    "bracket_text_pad": 0.010,
    "bracket_fontsize": 8.0,
    "bracket_comparisons": (
        ("experienced_day2_vs_return", "experienced_day2", "return"),
        ("experienced_day2_vs_naive", "experienced_day2", "naive"),
        ("experienced_day2_vs_latent_day2", "experienced_day2", "latent_day2"),
    ),
    "group_metric_order": ("route_fraction_correct",),
    "bracket_levels": {
        "experienced_day2_vs_return": 1.06,
        "experienced_day2_vs_naive": 1.16,
        "experienced_day2_vs_latent_day2": 1.27,
        "return_vs_latent_day2": 1.33,
    },
    "grid_alpha": 0.22,
    "grid_linewidth": 0.75,
    "spine_linewidth": 0.85,
    "jitter_seed": 20260512,
}

REWARD_SEQUENCE_MEMORY_LABELS = {
    "suptitle": "First turns toward the reward",
    "maze_title": "Scored decision nodes",
    "depth_ylabel": "Fraction toward reward",
    "depth_xlabel": "Parent node",
    "group_ylabel": "Session route score",
    "group_xlabel": "",
    "group_title": "",
    "group_note": "Session summaries\nanimal-clustered OLS",
    "condition_labels": {
        "naive": "Naive\nnight",
        "experienced_day2": "Second\nnight",
        "return": "Return\nnight",
        "latent_day2": "Latent\nsecond night",
    },
    "legend_labels": {
        "naive": "Naive night",
        "experienced_day2": "Second night",
        "return": "Return night",
        "latent_day2": "Latent second night",
    },
    "metric_labels": {
        "route_fraction_correct": "First-turn\nroute score",
        "exact_six_turn_sequence": "Exact six-turn\nsequence",
    },
    "stat_labels": {
        "route_fraction_correct": "Return vs latent n.s.; second > return",
        "exact_six_turn_sequence": "Return vs latent n.s.; second > return",
    },
}


def get_reward_sequence_memory_colors(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_SEQUENCE_MEMORY_COLORS, overrides)


def get_reward_sequence_memory_layout(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_SEQUENCE_MEMORY_LAYOUT, overrides)


def get_reward_sequence_memory_style(overrides: dict | None = None) -> dict:
    return _merged_dict(REWARD_SEQUENCE_MEMORY_STYLE, overrides)


def get_reward_sequence_memory_labels(overrides: dict | None = None) -> dict:
    labels = deepcopy(REWARD_SEQUENCE_MEMORY_LABELS)
    if overrides:
        for key, value in overrides.items():
            if isinstance(value, dict) and isinstance(labels.get(key), dict):
                labels[key] = {**labels[key], **value}
            else:
                labels[key] = value
    return labels


def _reward_sequence_condition_summary(
    animal_df: pd.DataFrame,
    value_col: str,
    *,
    group_cols: list[str],
    count_col: str = "n_units",
) -> pd.DataFrame:
    rows = []
    for keys, sub in animal_df.groupby(group_cols, sort=False, dropna=False, observed=True):
        key_tuple = keys if isinstance(keys, tuple) else (keys,)
        values = pd.to_numeric(sub[value_col], errors="coerce").dropna().to_numpy(float)
        if values.size == 0:
            mean = sem = np.nan
        else:
            mean = float(np.mean(values))
            sem = float(np.std(values, ddof=1) / np.sqrt(values.size)) if values.size > 1 else 0.0
        row = dict(zip(group_cols, key_tuple))
        row.update({"mean": mean, "sem": sem, "n_units": int(values.size), count_col: int(values.size)})
        rows.append(row)
    return pd.DataFrame(rows)


def _holm_adjust(pvals: np.ndarray) -> np.ndarray:
    p = np.asarray(pvals, dtype=float)
    out = np.full(p.shape, np.nan, dtype=float)
    finite = np.isfinite(p)
    if not finite.any():
        return out
    finite_idx = np.where(finite)[0]
    order = finite_idx[np.argsort(p[finite])]
    m = len(order)
    running = 0.0
    for rank, idx in enumerate(order):
        adjusted = min(1.0, float((m - rank) * p[idx]))
        running = max(running, adjusted)
        out[idx] = running
    return out


def _reward_sequence_session_cluster_ols(
    session_scores: pd.DataFrame,
    *,
    metric: str,
    value_col: str,
    comparisons: tuple[tuple[str, str, str], ...],
) -> pd.DataFrame:
    rows = []
    if session_scores.empty:
        return pd.DataFrame()
    for comparison, target_condition, baseline_condition in comparisons:
        sub = session_scores[
            session_scores["condition"].astype(str).isin([target_condition, baseline_condition])
        ].copy()
        sub[value_col] = pd.to_numeric(sub[value_col], errors="coerce")
        sub = sub.dropna(subset=[value_col, "animal", "condition"])
        base = {
            "plot_metric": metric,
            "source_metric": "session_clustered_ols_route_fraction_correct",
            "comparison": comparison,
            "target_condition": target_condition,
            "baseline_condition": baseline_condition,
            "n_sessions_target": int(sub["condition"].astype(str).eq(target_condition).sum()),
            "n_sessions_baseline": int(sub["condition"].astype(str).eq(baseline_condition).sum()),
            "n_animals_target": int(sub.loc[sub["condition"].astype(str).eq(target_condition), "animal"].nunique()),
            "n_animals_baseline": int(sub.loc[sub["condition"].astype(str).eq(baseline_condition), "animal"].nunique()),
            "note": "Session-level OLS; robust covariance clustered by animal.",
        }
        if sm is None or sub.empty or sub["condition"].nunique() < 2 or sub["animal"].nunique() < 3:
            rows.append(
                {
                    **base,
                    "mean_diff_target_minus_baseline": np.nan,
                    "ols_p": np.nan,
                    "ols_cluster_p": np.nan,
                    "ols_cluster_ci_low": np.nan,
                    "ols_cluster_ci_high": np.nan,
                    "ols_cluster_se": np.nan,
                }
            )
            continue
        y = sub[value_col].to_numpy(dtype=float)
        x = sub["condition"].astype(str).eq(target_condition).astype(float).to_numpy()
        xmat = sm.add_constant(x)
        groups = sub["animal"].astype(str).to_numpy()
        model = sm.OLS(y, xmat).fit(cov_type="cluster", cov_kwds={"groups": groups, "use_correction": True})
        ci = model.conf_int(alpha=0.05)
        rows.append(
            {
                **base,
                "mean_diff_target_minus_baseline": float(model.params[1]),
                "ols_p": float(model.pvalues[1]),
                "ols_cluster_p": float(model.pvalues[1]),
                "ols_cluster_ci_low": float(ci[1, 0]),
                "ols_cluster_ci_high": float(ci[1, 1]),
                "ols_cluster_se": float(model.bse[1]),
            }
        )
    out = pd.DataFrame(rows)
    if not out.empty:
        p = pd.to_numeric(out["ols_cluster_p"], errors="coerce")
        out["ols_cluster_holm_p_within_metric"] = _holm_adjust(p.to_numpy(dtype=float))
    return out


def prepare_reward_sequence_memory_plot_data(
    turn_sequence_dir,
    *,
    condition_order: tuple[str, ...] = REWARD_SEQUENCE_MEMORY_CONDITION_ORDER,
    group_metric_order: tuple[str, ...] | None = None,
) -> dict[str, pd.DataFrame]:
    """Load and summarize cached reward-path first-turn sequence outputs."""
    root = Path(turn_sequence_dir)
    paths = {
        "reward_path": root / "reward_path_definition.csv",
        "animal_depth": root / "animal_depth_summary.csv",
        "animal_route": root / "animal_route_summary.csv",
        "session_route": root / "session_route_summary.csv",
        "run_manifest": root / "run_manifest.json",
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing turn-sequence cache files: {missing}")

    reward_path = pd.read_csv(paths["reward_path"])
    animal_depth = pd.read_csv(paths["animal_depth"])
    animal_route = pd.read_csv(paths["animal_route"])
    session_route = pd.read_csv(paths["session_route"])
    condition_order = tuple(condition_order)
    animal_depth = animal_depth[animal_depth["condition"].isin(condition_order)].copy()
    animal_route = animal_route[animal_route["condition"].isin(condition_order)].copy()
    session_route = session_route[session_route["condition"].isin(condition_order)].copy()
    animal_depth["condition"] = pd.Categorical(animal_depth["condition"], condition_order, ordered=True)
    animal_route["condition"] = pd.Categorical(animal_route["condition"], condition_order, ordered=True)
    session_route["condition"] = pd.Categorical(session_route["condition"], condition_order, ordered=True)
    animal_depth["paper_depth"] = pd.to_numeric(animal_depth["paper_depth"], errors="coerce").astype("Int64")
    animal_depth["decision_index"] = animal_depth["paper_depth"].astype(int) - 1
    animal_depth["reward_correct_rate"] = pd.to_numeric(animal_depth["reward_correct_rate"], errors="coerce")
    parent_by_depth = (
        reward_path.assign(paper_depth=lambda df: pd.to_numeric(df["paper_depth"], errors="coerce").astype(int))
        .set_index("paper_depth")["parent_node"]
        .astype(int)
        .to_dict()
    )
    animal_depth["parent_node"] = animal_depth["paper_depth"].astype(int).map(parent_by_depth)

    depth_summary = _reward_sequence_condition_summary(
        animal_depth,
        "reward_correct_rate",
        group_cols=["condition", "condition_label", "paper_depth", "decision_index", "parent_node", "reward_side"],
        count_col="n_animals",
    )
    depth_summary = depth_summary.sort_values(["condition", "paper_depth"]).reset_index(drop=True)

    metric_value_cols = {"route_fraction_correct": "route_fraction_correct"}
    selected_group_metrics = tuple(group_metric_order or ("route_fraction_correct",))
    unknown_metrics = [metric for metric in selected_group_metrics if metric not in metric_value_cols]
    if unknown_metrics:
        raise ValueError(f"Unknown reward-sequence grouped metric(s): {unknown_metrics}")
    group_long_rows = []
    for metric in selected_group_metrics:
        value_col = metric_value_cols[metric]
        sub = session_route.loc[:, ["session_id", "animal", "condition", "condition_label", value_col]].copy()
        sub = sub.rename(columns={value_col: "value"})
        sub["metric"] = metric
        group_long_rows.append(sub)
    group_animals = pd.concat(group_long_rows, ignore_index=True)
    group_animals["value"] = pd.to_numeric(group_animals["value"], errors="coerce")
    group_summary = _reward_sequence_condition_summary(
        group_animals,
        "value",
        group_cols=["metric", "condition", "condition_label"],
        count_col="n_sessions",
    )
    metric_order = selected_group_metrics
    group_animals["metric"] = pd.Categorical(group_animals["metric"], metric_order, ordered=True)
    group_summary["metric"] = pd.Categorical(group_summary["metric"], metric_order, ordered=True)
    group_animals = group_animals.sort_values(["metric", "condition", "animal"]).reset_index(drop=True)
    group_summary = group_summary.sort_values(["metric", "condition"]).reset_index(drop=True)

    stats = _reward_sequence_session_cluster_ols(
        session_route,
        metric="route_fraction_correct",
        value_col="route_fraction_correct",
        comparisons=(
            ("experienced_day2_vs_naive", "experienced_day2", "naive"),
            ("return_vs_latent_day2", "return", "latent_day2"),
            ("experienced_day2_vs_return", "experienced_day2", "return"),
            ("experienced_day2_vs_latent_day2", "experienced_day2", "latent_day2"),
        ),
    )
    return {
        "reward_path": reward_path.reset_index(drop=True),
        "animal_depth": animal_depth.reset_index(drop=True),
        "depth_summary": depth_summary,
        "animal_route": animal_route.reset_index(drop=True),
        "group_animals": group_animals,
        "group_summary": group_summary,
        "stats": stats,
    }


def _maze_node_xy(maze, node: int) -> tuple[float, float]:
    anchor_cell = int(maze.ru[int(node)][-1])
    return float(maze.xc[anchor_cell]), float(maze.yc[anchor_cell])


def _draw_reward_sequence_run(ax, maze, node: int, *, color: str, linewidth: float, alpha: float, zorder: int):
    node = int(node)
    cells = list(maze.ru[node])
    parent = int(maze.pa[node])
    if parent >= 0:
        cells = [int(maze.ru[parent][-1])] + cells
    ax.plot(
        [float(maze.xc[int(cell)]) for cell in cells],
        [float(maze.yc[int(cell)]) for cell in cells],
        color=color,
        linewidth=linewidth,
        alpha=alpha,
        solid_capstyle="round",
        zorder=zorder,
    )


def _draw_reward_sequence_maze_key(ax, reward_path: pd.DataFrame, *, layout: dict, colors: dict, style: dict, labels: dict):
    maze = NewMaze(6)
    maze_layout = {
        "maze_wall_linewidth": float(style.get("maze_wall_linewidth", 0.75)),
        "gray_block_linewidth": float(style.get("gray_block_linewidth", 0.25)),
    }
    maze_colors = {
        "wall": colors.get("axis", "#202020"),
        "gray_block_face": "#D8D8D8",
        "gray_block_edge": "#D8D8D8",
    }
    draw_maze_outline(ax, maze, layout=maze_layout, colors=maze_colors)
    draw_gray_blocks(ax, layout=maze_layout, colors=maze_colors)
    reward_path = reward_path.sort_values("paper_depth").reset_index(drop=True)
    reward_chain = reward_path["parent_node"].astype(int).tolist() + [int(reward_path.iloc[-1]["reward_child"])]
    for node in reward_chain:
        _draw_reward_sequence_run(
            ax,
            maze,
            node,
            color=colors.get("maze_path", colors.get("decision_node_face", "#155D73")),
            linewidth=float(style.get("reward_path_linewidth", 2.4)),
            alpha=float(style.get("reward_path_alpha", 0.92)),
            zorder=5,
        )
    marker_size = float(style.get("decision_node_size", 0.62))
    for _, row in reward_path.iterrows():
        parent = int(row["parent_node"])
        x, y = _maze_node_xy(maze, parent)
        ax.add_patch(
            Ellipse(
                (x, y),
                width=marker_size,
                height=marker_size,
                facecolor=colors.get("decision_node_face", colors["maze_label_face"]),
                edgecolor=colors.get("decision_node_edge", "white"),
                linewidth=float(style.get("decision_node_linewidth", 0.55)),
                zorder=7,
            )
        )
        ax.text(
            x,
            y,
            str(parent),
            ha="center",
            va="center",
            color=colors["maze_label_text"],
            fontsize=float(style.get("maze_depth_label_fontsize", 7.2)),
            zorder=8,
        )
    reward_node = int(reward_path.iloc[-1]["reward_child"])
    parent_node = int(reward_path.iloc[-1]["parent_node"])
    reward_x, reward_y = _maze_node_xy(maze, reward_node)
    parent_x, parent_y = _maze_node_xy(maze, parent_node)
    direction = np.asarray([reward_x - parent_x, reward_y - parent_y], dtype=float)
    norm = float(np.linalg.norm(direction))
    if norm > 0:
        direction = direction / norm
    water_offset = float(style.get("water_offset", 0.70))
    _draw_water_drop_icon(
        ax,
        {
            "xy": (reward_x + water_offset * float(direction[0]), reward_y + water_offset * float(direction[1])),
            "size": float(style.get("water_size", 0.70)),
            "facecolor": colors.get("water", "#36A3FF"),
            "edgecolor": colors.get("water_edge", "#0866B2"),
            "linewidth": 0.75,
            "zorder": 8,
        },
    )
    ax.set_xlim(*tuple(layout.get("maze_xlim", (-1.25, 15.9))))
    ax.set_ylim(*tuple(layout.get("maze_ylim", (15.45, -0.75))))
    ax.set_title(str(labels.get("maze_title", "")), fontsize=float(style.get("title_fontsize", 9.6)), pad=3)


def _format_reward_sequence_p(value: float | None) -> str:
    if value is None or not np.isfinite(value):
        return "NA"
    if value < 0.001:
        return f"{value:.1e}"
    if value < 0.01:
        return f"{value:.3f}"
    return f"{value:.2f}"


def _draw_reward_sequence_depth_axis(
    ax,
    depth_summary: pd.DataFrame,
    condition: str,
    *,
    layout: dict,
    colors: dict,
    style: dict,
    labels: dict,
    show_ylabel: bool,
):
    sub = depth_summary[depth_summary["condition"].astype(str).eq(condition)].copy()
    sub = sub.sort_values("paper_depth")
    x = sub["decision_index"].to_numpy(dtype=float)
    y = sub["mean"].to_numpy(dtype=float)
    sem = sub["sem"].to_numpy(dtype=float)
    ax.bar(
        x,
        y,
        width=float(style.get("bar_width", 0.72)),
        color=colors[condition],
        alpha=float(style.get("bar_alpha", 0.72)),
        edgecolor=style.get("bar_edgecolor", "none"),
        linewidth=0.0,
        zorder=3,
    )
    ax.errorbar(
        x,
        y,
        yerr=sem,
        fmt="none",
        ecolor=colors["axis"],
        elinewidth=float(style.get("errorbar_linewidth", 0.85)),
        capsize=float(style.get("errorbar_capsize", 2.0)),
        capthick=float(style.get("errorbar_linewidth", 0.85)),
        zorder=4,
    )
    ax.axhline(0.5, color=colors["chance"], lw=0.85, ls="--", alpha=0.75, zorder=1)
    ax.set_ylim(*tuple(layout.get("depth_ylim", (0, 1.05))))
    ax.set_xlim(-0.65, 5.65)
    parent_labels = (
        sub.sort_values("decision_index")["parent_node"].astype(int).astype(str).tolist()
        if "parent_node" in sub.columns and not sub.empty
        else [str(i) for i in range(6)]
    )
    ax.set_xticks(np.arange(len(parent_labels)), parent_labels)
    ax.set_xlabel(str(labels.get("depth_xlabel", "")))
    if show_ylabel:
        ax.set_ylabel(str(labels.get("depth_ylabel", "")))
    else:
        ax.tick_params(labelleft=False)
    ax.set_title(
        labels["condition_labels"].get(condition, condition).replace("\n", " "),
        color=colors[condition],
        fontsize=float(style.get("title_fontsize", 9.6)),
        pad=3,
    )
    ax.grid(
        axis="y",
        color=colors["grid"],
        alpha=float(style.get("grid_alpha", 0.22)),
        linewidth=float(style.get("grid_linewidth", 0.75)),
        zorder=0,
    )


def _draw_reward_sequence_group_axis(
    ax,
    group_animals: pd.DataFrame,
    group_summary: pd.DataFrame,
    stats: pd.DataFrame,
    *,
    condition_order: tuple[str, ...],
    colors: dict,
    style: dict,
    labels: dict,
    layout: dict,
):
    metric_order = tuple(style.get("group_metric_order", ("route_fraction_correct",)))
    metric_x = {metric: idx for idx, metric in enumerate(metric_order)}
    offsets = np.linspace(-0.30, 0.30, len(condition_order))
    offset_by_condition = dict(zip(condition_order, offsets))
    rng = np.random.default_rng(int(style.get("jitter_seed", 20260512)))
    for condition in condition_order:
        for metric in metric_order:
            summary = group_summary[
                group_summary["metric"].astype(str).eq(metric) & group_summary["condition"].astype(str).eq(condition)
            ]
            animals = group_animals[
                group_animals["metric"].astype(str).eq(metric) & group_animals["condition"].astype(str).eq(condition)
            ]
            if summary.empty:
                continue
            x0 = metric_x[metric] + float(offset_by_condition[condition])
            mean = float(summary.iloc[0]["mean"])
            sem = float(summary.iloc[0]["sem"])
            ax.bar(
                x0,
                mean,
                width=float(style.get("group_bar_width", 0.17)),
                color=colors[condition],
                alpha=float(style.get("bar_alpha", 0.72)),
                edgecolor="none",
                zorder=3,
            )
            ax.errorbar(
                [x0],
                [mean],
                yerr=[[sem], [sem]],
                fmt="none",
                ecolor=colors["axis"],
                elinewidth=float(style.get("group_errorbar_linewidth", 0.9)),
                capsize=float(style.get("group_errorbar_capsize", 2.4)),
                capthick=float(style.get("group_errorbar_linewidth", 0.9)),
                zorder=5,
            )
            values = animals["value"].dropna().to_numpy(float)
            if values.size:
                jitter = rng.normal(0, float(style.get("group_point_jitter", 0.035)), size=values.size)
                ax.scatter(
                    np.full(values.size, x0) + jitter,
                    values,
                    s=float(style.get("group_point_size", 18)),
                    color=colors[condition],
                    alpha=float(style.get("group_point_alpha", 0.70)),
                    edgecolor=colors.get("point_edge", "white"),
                    linewidth=0.35,
                    zorder=6,
                )
    ax.axhline(0.5, color=colors["chance"], lw=0.85, ls="--", alpha=0.65, zorder=1)
    ax.set_ylim(*tuple(layout.get("group_ylim", (0, 1.05))))
    ax.set_yticks([0.0, 0.5, 1.0])
    if len(metric_order) == 1:
        ax.set_xlim(-0.47, 0.47)
        ax.set_xticks([])
    else:
        ax.set_xlim(-0.65, len(metric_order) - 0.35)
        ax.set_xticks([metric_x[metric] for metric in metric_order], [labels["metric_labels"][metric] for metric in metric_order])
    ax.set_ylabel(str(labels.get("group_ylabel", "Animal-level score")))
    ax.set_xlabel(str(labels.get("group_xlabel", "")))
    ax.set_title(str(labels.get("group_title", "")), fontsize=float(style.get("title_fontsize", 9.6)), pad=3)
    ax.grid(
        axis="y",
        color=colors["grid"],
        alpha=float(style.get("grid_alpha", 0.22)),
        linewidth=float(style.get("grid_linewidth", 0.75)),
        zorder=0,
    )
    handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor=colors[condition],
            markeredgecolor="white",
            markersize=5.2,
            label=labels["legend_labels"].get(condition, condition),
        )
        for condition in condition_order
    ]
    ax.legend(
        handles=handles,
        frameon=False,
        fontsize=float(style.get("legend_fontsize", 8.0)),
        ncol=int(style.get("group_legend_ncol", 2)),
        loc=str(style.get("group_legend_loc", "upper left")),
        bbox_to_anchor=tuple(style.get("group_legend_bbox_to_anchor", (1.01, 1.02))),
        borderaxespad=0.0,
    )
    stat_lookup = stats.set_index(["plot_metric", "comparison"]) if not stats.empty else pd.DataFrame()
    comparisons = tuple(style.get("bracket_comparisons", ()))
    bracket_levels = style.get("bracket_levels", {})
    for metric in metric_order:
        for comparison, left_condition, right_condition in comparisons:
            if stats.empty or (metric, comparison) not in stat_lookup.index:
                continue
            q_value = float(stat_lookup.loc[(metric, comparison), "ols_cluster_holm_p_within_metric"])
            y = float(bracket_levels.get(comparison, 1.08))
            x1 = metric_x[metric] + float(offset_by_condition[left_condition])
            x2 = metric_x[metric] + float(offset_by_condition[right_condition])
            _draw_reward_sequence_significance_bracket(
                ax,
                x1,
                x2,
                y,
                _significance_text(q_value),
                colors=colors,
                style=style,
            )


def _draw_reward_sequence_significance_bracket(ax, x1: float, x2: float, y: float, text: str, *, colors: dict, style: dict):
    tick = float(style.get("bracket_tick_height", 0.035))
    lw = float(style.get("bracket_linewidth", 0.9))
    color = colors.get("axis", "#202020")
    ax.plot([x1, x1, x2, x2], [y - tick, y, y, y - tick], color=color, lw=lw, clip_on=False, zorder=8)
    ax.text(
        (x1 + x2) / 2.0,
        y + float(style.get("bracket_text_pad", 0.010)),
        text,
        ha="center",
        va="bottom",
        fontsize=float(style.get("bracket_fontsize", 8.0)),
        fontweight="bold" if text != "n.s." else "normal",
        color=color,
        clip_on=False,
        zorder=9,
    )


def render_cached_reward_sequence_memory_panel(
    turn_sequence_dir,
    *,
    panel_kind: str = "combined",
    condition_order: tuple[str, ...] = REWARD_SEQUENCE_MEMORY_CONDITION_ORDER,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "reward_sequence_memory_panel",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render first-turn reward sequence memory panels from cached exporter outputs."""
    panel_layout = get_reward_sequence_memory_layout(layout)
    panel_colors = get_reward_sequence_memory_colors(colors)
    panel_style = get_reward_sequence_memory_style(style)
    panel_labels = get_reward_sequence_memory_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    panel_data = prepare_reward_sequence_memory_plot_data(
        turn_sequence_dir,
        condition_order=condition_order,
        group_metric_order=tuple(panel_style.get("group_metric_order", ("route_fraction_correct",))),
    )
    panel_kind = str(panel_kind).lower()
    condition_panel_kinds = {
        f"depth_{condition}": condition
        for condition in condition_order
    }
    valid_panel_kinds = {"combined", "depth", "maze", "grouped", *condition_panel_kinds.keys()}
    if panel_kind not in valid_panel_kinds:
        raise ValueError(
            "panel_kind must be one of "
            + ", ".join(sorted(valid_panel_kinds))
        )

    if panel_kind == "maze":
        fig, ax_maze = plt.subplots(figsize=resolved_panel_size)
        axes = {"maze": ax_maze}
    elif panel_kind in condition_panel_kinds:
        fig, ax_depth = plt.subplots(figsize=resolved_panel_size)
        axes = {"single_depth": ax_depth}
    elif panel_kind == "depth":
        fig = plt.figure(figsize=resolved_panel_size)
        gs = fig.add_gridspec(
            1,
            5,
            width_ratios=tuple(panel_layout.get("width_ratios", (1.55, 1, 1, 1, 1))),
            wspace=float(panel_layout.get("wspace", 0.38)),
        )
        ax_maze = fig.add_subplot(gs[0, 0])
        bar_axes = [fig.add_subplot(gs[0, idx + 1]) for idx in range(len(condition_order))]
        axes = {"maze": ax_maze, "depth": bar_axes}
    elif panel_kind == "grouped":
        fig, ax_group = plt.subplots(figsize=resolved_panel_size)
        axes = {"grouped": ax_group}
    else:
        fig = plt.figure(figsize=resolved_panel_size)
        gs = fig.add_gridspec(
            2,
            5,
            width_ratios=tuple(panel_layout.get("width_ratios", (1.55, 1, 1, 1, 1))),
            height_ratios=tuple(panel_layout.get("height_ratios", (1.08, 1.0))),
            wspace=float(panel_layout.get("wspace", 0.38)),
            hspace=float(panel_layout.get("hspace", 0.52)),
        )
        ax_maze = fig.add_subplot(gs[0, 0])
        bar_axes = [fig.add_subplot(gs[0, idx + 1]) for idx in range(len(condition_order))]
        ax_group = fig.add_subplot(gs[1, 1:4])
        ax_note = fig.add_subplot(gs[1, 0])
        ax_note.axis("off")
        ax_note.text(
            0.0,
            0.98,
            str(panel_labels.get("group_note", "")),
            ha="left",
            va="top",
            fontsize=float(panel_style.get("axis_label_fontsize", 9.5)),
            color="#333333",
        )
        axes = {"maze": ax_maze, "depth": bar_axes, "grouped": ax_group, "note": ax_note}

    if "maze" in axes:
        _draw_reward_sequence_maze_key(
            axes["maze"],
            panel_data["reward_path"],
            layout=panel_layout,
            colors=panel_colors,
            style=panel_style,
            labels=panel_labels,
        )
    if "single_depth" in axes:
        _draw_reward_sequence_depth_axis(
            axes["single_depth"],
            panel_data["depth_summary"],
            condition_panel_kinds[panel_kind],
            layout=panel_layout,
            colors=panel_colors,
            style=panel_style,
            labels=panel_labels,
            show_ylabel=True,
        )
    if "depth" in axes:
        for idx, condition in enumerate(condition_order):
            _draw_reward_sequence_depth_axis(
                axes["depth"][idx],
                panel_data["depth_summary"],
                condition,
                layout=panel_layout,
                colors=panel_colors,
                style=panel_style,
                labels=panel_labels,
                show_ylabel=idx == 0,
            )
    if "grouped" in axes:
        _draw_reward_sequence_group_axis(
            axes["grouped"],
            panel_data["group_animals"],
            panel_data["group_summary"],
            panel_data["stats"],
            condition_order=condition_order,
            colors=panel_colors,
            style=panel_style,
            labels=panel_labels,
            layout=panel_layout,
        )
    for ax in fig.axes:
        ax.tick_params(labelsize=float(panel_style.get("tick_labelsize", 8.0)))
        for spine in ax.spines.values():
            spine.set_linewidth(float(panel_style.get("spine_linewidth", 0.85)))
            spine.set_color(panel_colors["axis"])
        ax.xaxis.label.set_size(float(panel_style.get("axis_label_fontsize", 9.5)))
        ax.yaxis.label.set_size(float(panel_style.get("axis_label_fontsize", 9.5)))
    if panel_kind in {"combined", "depth"}:
        fig.suptitle(
            str(panel_labels.get("suptitle", "")),
            x=0.055,
            y=0.985,
            ha="left",
            fontsize=float(panel_style.get("suptitle_fontsize", 12.0)),
            fontweight="bold",
        )
    if panel_kind == "grouped":
        fig.subplots_adjust(
            left=float(panel_layout.get("left", 0.055)),
            right=float(panel_layout.get("right", 0.80)),
            bottom=float(panel_layout.get("bottom", 0.13)),
            top=float(panel_layout.get("top", 0.88)),
        )
    elif panel_kind == "maze":
        fig.subplots_adjust(left=0.02, right=0.98, bottom=0.02, top=0.86)
    elif panel_kind in condition_panel_kinds:
        fig.subplots_adjust(left=0.30, right=0.96, bottom=0.28, top=0.82)
    else:
        fig.subplots_adjust(
            left=float(panel_layout.get("left", 0.055)),
            right=float(panel_layout.get("right", 0.985)),
            bottom=float(panel_layout.get("bottom", 0.13)),
            top=float(panel_layout.get("top", 0.88)),
        )
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    panel_data = {**panel_data, "layout": panel_layout, "colors": panel_colors, "style": panel_style, "labels": panel_labels}
    return fig, axes, panel_data, saved_paths


def _latent_return_fmt_p(p_value: float | None) -> str:
    if p_value is None or not np.isfinite(p_value):
        return "NA"
    if p_value < 1e-4:
        return f"{p_value:.1e}"
    if p_value < 0.01:
        return f"{p_value:.3g}"
    return f"{p_value:.3f}"


def _latent_return_stars(p_value: float | None) -> str:
    if p_value is None or not np.isfinite(p_value):
        return ""
    if p_value < 0.001:
        return "***"
    if p_value < 0.01:
        return "**"
    if p_value < 0.05:
        return "*"
    return "n.s."


def render_cached_latent_return_junction_timing_panel(
    session_plot_data_csv,
    effect_plot_data_csv,
    *,
    row_order: tuple[str, ...] = (
        "pre_explore_all_junctions",
        "pre_explore_direct_minus_other",
        "all_post_reward_approach_direct_chain",
    ),
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "latent_return_junction_timing_claims",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the cached latent-vs-return three-claim junction timing panel."""
    panel_layout = {**LATENT_RETURN_JUNCTION_LAYOUT, **(layout or {})}
    panel_colors = {**LATENT_RETURN_JUNCTION_COLORS, **(colors or {})}
    panel_style = {**LATENT_RETURN_JUNCTION_STYLE, **(style or {})}
    panel_labels = deepcopy(LATENT_RETURN_JUNCTION_LABELS)
    if labels:
        for key, value in labels.items():
            if isinstance(value, dict) and isinstance(panel_labels.get(key), dict):
                panel_labels[key] = {**panel_labels[key], **value}
            else:
                panel_labels[key] = value
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    session = pd.read_csv(Path(session_plot_data_csv))
    effects = pd.read_csv(Path(effect_plot_data_csv))
    required_session = {"stratum", "condition", "animal", "session_id", "mean_decision_time_s"}
    required_effect = {
        "stratum",
        "animal_balanced_beta_return_minus_latent_s",
        "animal_balanced_ci95_low_s",
        "animal_balanced_ci95_high_s",
        "bh_q_primary_3_claims",
    }
    missing_session = required_session.difference(session.columns)
    missing_effect = required_effect.difference(effects.columns)
    if missing_session:
        raise ValueError(f"Latent-return session data is missing columns: {sorted(missing_session)}")
    if missing_effect:
        raise ValueError(f"Latent-return effect data is missing columns: {sorted(missing_effect)}")

    session = session[session["stratum"].isin(row_order)].copy()
    effects = effects[effects["stratum"].isin(row_order)].copy()
    session["stratum"] = pd.Categorical(session["stratum"], row_order, ordered=True)
    effects["stratum"] = pd.Categorical(effects["stratum"], row_order, ordered=True)
    session = session.sort_values(["stratum", "condition", "animal", "session_id"]).reset_index(drop=True)
    effects = effects.sort_values("stratum").reset_index(drop=True)
    session["mean_decision_time_s"] = pd.to_numeric(session["mean_decision_time_s"], errors="coerce")
    for col in [
        "animal_balanced_beta_return_minus_latent_s",
        "animal_balanced_ci95_low_s",
        "animal_balanced_ci95_high_s",
        "bh_q_primary_3_claims",
    ]:
        effects[col] = pd.to_numeric(effects[col], errors="coerce")

    animal_means = (
        session.groupby(["stratum", "condition", "animal"], observed=True, dropna=False)
        .agg(
            animal_mean_session_value_s=("mean_decision_time_s", "mean"),
            n_sessions=("session_id", "nunique"),
        )
        .reset_index()
    )

    fig, (ax_raw, ax_eff) = plt.subplots(
        1,
        2,
        figsize=resolved_panel_size,
        sharey=True,
        gridspec_kw={
            "width_ratios": tuple(panel_layout.get("width_ratios", (1.35, 1.0))),
            "wspace": float(panel_layout.get("wspace", 0.12)),
        },
    )
    rng = np.random.default_rng(int(panel_style.get("jitter_seed", 20260511)))
    y_base = np.arange(len(row_order))[::-1]
    offsets = {"latent": 0.13, "return": -0.13}
    condition_order = ("latent", "return")
    for idx, stratum in enumerate(row_order):
        y_row = y_base[idx]
        for condition in condition_order:
            sess = session[session["stratum"].astype(str).eq(stratum) & session["condition"].eq(condition)]
            if not sess.empty:
                jitter = rng.normal(0, 0.028, size=sess.shape[0])
                ax_raw.scatter(
                    sess["mean_decision_time_s"],
                    np.full(sess.shape[0], y_row + offsets[condition]) + jitter,
                    s=float(panel_style.get("session_marker_size", 13)),
                    color=panel_colors[condition],
                    alpha=float(panel_style.get("session_alpha", 0.22)),
                    edgecolor="none",
                    zorder=2,
                )
            animals = animal_means[
                animal_means["stratum"].astype(str).eq(stratum) & animal_means["condition"].eq(condition)
            ]
            if animals.empty:
                continue
            values = animals["animal_mean_session_value_s"].to_numpy(dtype=float)
            jitter = rng.normal(0, 0.022, size=values.size)
            ax_raw.scatter(
                values,
                np.full(values.size, y_row + offsets[condition]) + jitter,
                s=float(panel_style.get("animal_marker_size", 34)),
                color=panel_colors[condition],
                alpha=float(panel_style.get("animal_alpha", 0.92)),
                edgecolor=str(panel_style.get("animal_edgecolor", "white")),
                linewidth=float(panel_style.get("animal_edgewidth", 0.45)),
                zorder=4,
            )
            mean_x = float(np.mean(values))
            ax_raw.plot(
                [mean_x, mean_x],
                [y_row + offsets[condition] - 0.09, y_row + offsets[condition] + 0.09],
                color=panel_colors[condition],
                lw=float(panel_style.get("animal_mean_linewidth", 2.3)),
                solid_capstyle="round",
                zorder=5,
            )

    ax_raw.axvline(0, color=panel_colors["zero"], lw=0.8, alpha=0.45)
    ax_raw.set_xlim(*tuple(panel_layout.get("raw_xlim", (-0.32, 1.24))))
    row_labels = panel_labels["row_labels"]
    ax_raw.set_yticks(y_base, [str(row_labels.get(stratum, stratum)).replace("\n", " ") for stratum in row_order])
    ax_raw.tick_params(labelsize=float(panel_style.get("tick_labelsize", 8.4)))
    ax_raw.set_xlabel(str(panel_labels.get("raw_xlabel", "Dwell or delta (s)")))
    ax_raw.set_title(str(panel_labels.get("raw_title", "Session and animal values")))
    ax_raw.grid(
        axis="x",
        color=panel_colors["grid"],
        alpha=float(panel_style.get("grid_alpha", 0.22)),
        linewidth=float(panel_style.get("grid_linewidth", 0.8)),
    )
    handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor=panel_colors[condition],
            markeredgecolor="white",
            markersize=6.4,
            label=panel_labels["condition_labels"].get(condition, condition),
        )
        for condition in condition_order
    ]
    ax_raw.legend(handles=handles, loc="lower right", frameon=False, fontsize=float(panel_style["legend_fontsize"]))

    effect_lookup = effects.set_index("stratum")
    for y, stratum in zip(y_base, row_order):
        row = effect_lookup.loc[stratum]
        beta = float(row["animal_balanced_beta_return_minus_latent_s"])
        low = float(row["animal_balanced_ci95_low_s"])
        high = float(row["animal_balanced_ci95_high_s"])
        q_value = float(row["bh_q_primary_3_claims"])
        sig = np.isfinite(q_value) and q_value < 0.05
        if stratum == "pre_explore_direct_minus_other" and sig:
            color = panel_colors["specificity"]
        else:
            color = panel_colors["return"] if sig else panel_colors["nonsig"]
        ax_eff.errorbar(
            beta,
            y,
            xerr=[[beta - low], [high - beta]],
            fmt="o",
            color=color,
            ecolor=color,
            elinewidth=float(panel_style.get("effect_linewidth", 1.9)),
            capsize=float(panel_style.get("effect_capsize", 3.3)),
            markersize=float(panel_style.get("effect_markersize", 5.8)),
            zorder=3,
        )
        label = (
            f"{_latent_return_stars(q_value)}  q={_latent_return_fmt_p(q_value)}"
            if sig
            else f"q={_latent_return_fmt_p(q_value)}"
        )
        ax_eff.text(
            high + 0.014,
            y,
            label,
            va="center",
            ha="left",
            fontsize=float(panel_style.get("q_label_fontsize", 8.2)),
            fontweight="bold" if sig else "normal",
            color="#111111" if sig else "#555555",
        )
    ax_eff.axvline(0, color=panel_colors["zero"], lw=1.0, alpha=0.85)
    ax_eff.tick_params(axis="y", left=False, labelleft=False)
    ax_eff.tick_params(labelsize=float(panel_style.get("tick_labelsize", 8.4)))
    ax_eff.set_xlim(*tuple(panel_layout.get("effect_xlim", (-0.55, 0.45))))
    ax_eff.set_xlabel(str(panel_labels.get("effect_xlabel", "Return - latent (s)")))
    ax_eff.set_title(str(panel_labels.get("effect_title", "Animal-balanced effects")))
    ax_eff.grid(
        axis="x",
        color=panel_colors["grid"],
        alpha=float(panel_style.get("grid_alpha", 0.22)),
        linewidth=float(panel_style.get("grid_linewidth", 0.8)),
    )
    fig.suptitle(
        str(panel_labels.get("suptitle", "")),
        fontsize=float(panel_style.get("suptitle_fontsize", 12.0)),
        y=0.99,
    )
    for ax in (ax_raw, ax_eff):
        ax.xaxis.label.set_size(float(panel_style.get("axis_label_fontsize", 9.5)))
        ax.title.set_size(float(panel_style.get("title_fontsize", 10.6)))
    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.18)),
        right=float(panel_layout.get("right", 0.985)),
        bottom=float(panel_layout.get("bottom", 0.18)),
        top=float(panel_layout.get("top", 0.85)),
    )
    panel_data = {
        "session": session,
        "effects": effects,
        "animal_means": animal_means,
        "row_order": tuple(row_order),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.asarray([ax_raw, ax_eff]), panel_data, saved_paths


def _fov_sem(values: pd.Series) -> float:
    arr = pd.to_numeric(values, errors="coerce").dropna().to_numpy(dtype=float)
    if arr.size <= 1:
        return 0.0 if arr.size == 1 else np.nan
    return float(np.std(arr, ddof=1) / np.sqrt(arr.size))


def _summarize_fov_displacement(df: pd.DataFrame, *, x_col: str, value_col: str) -> pd.DataFrame:
    rows = []
    for x_value, sub in df.groupby(x_col, dropna=False):
        values = pd.to_numeric(sub[value_col], errors="coerce").dropna()
        rows.append(
            {
                x_col: x_value,
                "n_points": int(values.size),
                "n_animals": int(sub.loc[values.index, "animal_id"].astype(str).nunique()) if values.size else 0,
                "mean": float(values.mean()) if values.size else np.nan,
                "sem": _fov_sem(values),
                "median": float(values.median()) if values.size else np.nan,
                "min": float(values.min()) if values.size else np.nan,
                "max": float(values.max()) if values.size else np.nan,
            }
        )
    return pd.DataFrame(rows).sort_values(x_col).reset_index(drop=True)


def _clustered_ols_trend(
    df: pd.DataFrame,
    *,
    y_col: str,
    x_col: str,
    cluster_col: str,
    metric: str,
) -> pd.DataFrame:
    work = df[[y_col, x_col, cluster_col]].copy()
    work[y_col] = pd.to_numeric(work[y_col], errors="coerce")
    work[x_col] = pd.to_numeric(work[x_col], errors="coerce")
    work = work.dropna(subset=[y_col, x_col, cluster_col])
    base = {
        "metric": metric,
        "y_col": y_col,
        "x_col": x_col,
        "cluster_col": cluster_col,
        "n_rows": int(len(work)),
        "n_clusters": int(work[cluster_col].astype(str).nunique()) if len(work) else 0,
        "slope": np.nan,
        "slope_se": np.nan,
        "slope_ci_low": np.nan,
        "slope_ci_high": np.nan,
        "p_value": np.nan,
        "r_squared": np.nan,
    }
    if sm is None or len(work) < 3 or work[x_col].nunique() < 2 or base["n_clusters"] < 2:
        return pd.DataFrame([base])
    x = pd.to_numeric(work[x_col], errors="coerce").astype(float)
    y = pd.to_numeric(work[y_col], errors="coerce").astype(float)
    X = pd.DataFrame({"const": 1.0, x_col: x}, index=work.index)
    model = sm.OLS(y, X).fit(
        cov_type="cluster",
        cov_kwds={"groups": work[cluster_col].astype(str), "use_correction": True},
    )
    ci = model.conf_int().loc[x_col]
    base.update(
        {
            "slope": float(model.params[x_col]),
            "slope_se": float(model.bse[x_col]),
            "slope_ci_low": float(ci.iloc[0]),
            "slope_ci_high": float(ci.iloc[1]),
            "p_value": float(model.pvalues[x_col]),
            "r_squared": float(model.rsquared),
        }
    )
    return pd.DataFrame([base])


def prepare_fov_displacement_plot_data(
    curated_csv,
    *,
    include_removed: bool = False,
) -> dict:
    """Prepare adjacent and cumulative FOV displacement tables from curated CellReg shifts."""
    source_csv = Path(curated_csv)
    raw = pd.read_csv(source_csv)
    required_columns = {
        "animal_id",
        "pair_label",
        "fixed_session_label",
        "moving_session_label",
        "microns_per_pixel",
        "dx_um",
        "dy_um",
        "dx_pixels",
        "dy_pixels",
        "alignment_mode_used",
        "curated_status",
        "removed_from_current_dataset",
    }
    missing_columns = required_columns.difference(raw.columns)
    if missing_columns:
        raise ValueError(f"FOV displacement CSV is missing columns: {sorted(missing_columns)}")
    work = raw.copy()
    for col in [
        "fixed_session_label",
        "moving_session_label",
        "microns_per_pixel",
        "dx_um",
        "dy_um",
        "dx_pixels",
        "dy_pixels",
        "maximal_cross_correlation",
    ]:
        if col in work.columns:
            work[col] = pd.to_numeric(work[col], errors="coerce")
    work["animal_id"] = work["animal_id"].astype(str)
    work["pair_label"] = work["pair_label"].astype(str)
    work["removed_from_current_dataset"] = pd.to_numeric(
        work["removed_from_current_dataset"], errors="coerce"
    ).fillna(0).astype(int)
    if not include_removed:
        work = work.loc[work["removed_from_current_dataset"].eq(0)].copy()
    work = work.dropna(subset=["animal_id", "fixed_session_label", "moving_session_label", "dx_um", "dy_um"])
    if work.empty:
        raise ValueError("No finite curated FOV displacement rows are available.")
    work["distance_um"] = np.hypot(work["dx_um"].astype(float), work["dy_um"].astype(float))
    work["distance_pixels"] = np.hypot(
        work["dx_pixels"].astype(float), work["dy_pixels"].astype(float)
    )
    work["manual_override"] = (
        work["curated_status"].astype(str).str.lower().eq("manual_override")
        | work["alignment_mode_used"].astype(str).str.lower().eq("manual pixel shift")
    )
    work = work.sort_values(["animal_id", "fixed_session_label", "moving_session_label"]).reset_index(drop=True)
    work["moving_experience_index"] = work.groupby("animal_id").cumcount() + 1

    cumulative_rows = []
    for animal_id, animal_df in work.groupby("animal_id", sort=False):
        animal_df = animal_df.sort_values(["fixed_session_label", "moving_session_label"]).reset_index(drop=True)
        start_label = float(animal_df["fixed_session_label"].min())
        coords: dict[float, tuple[float, float]] = {start_label: (0.0, 0.0)}
        cumulative_rows.append(
            {
                "animal_id": animal_id,
                "session_label": start_label,
                "experience_index": 0,
                "cum_dx_um": 0.0,
                "cum_dy_um": 0.0,
                "baseline_distance_um": 0.0,
                "last_pair_label": "",
                "last_step_distance_um": 0.0,
                "last_step_manual_override": False,
                "last_step_curated_status": "",
            }
        )
        for experience_index, row in enumerate(animal_df.itertuples(index=False), start=1):
            fixed_label = float(row.fixed_session_label)
            moving_label = float(row.moving_session_label)
            if fixed_label not in coords:
                prior_labels = sorted(label for label in coords if label <= fixed_label)
                coords[fixed_label] = coords[prior_labels[-1]] if prior_labels else (0.0, 0.0)
            fixed_x, fixed_y = coords[fixed_label]
            moving_x = fixed_x + float(row.dx_um)
            moving_y = fixed_y + float(row.dy_um)
            coords[moving_label] = (moving_x, moving_y)
            cumulative_rows.append(
                {
                    "animal_id": animal_id,
                    "session_label": moving_label,
                    "experience_index": experience_index,
                    "cum_dx_um": moving_x,
                    "cum_dy_um": moving_y,
                    "baseline_distance_um": float(np.hypot(moving_x, moving_y)),
                    "last_pair_label": str(row.pair_label),
                    "last_step_distance_um": float(row.distance_um),
                    "last_step_manual_override": bool(row.manual_override),
                    "last_step_curated_status": str(row.curated_status),
                }
            )
    cumulative = pd.DataFrame(cumulative_rows).sort_values(
        ["animal_id", "experience_index", "session_label"]
    ).reset_index(drop=True)
    magnitude_summary_by_label = _summarize_fov_displacement(
        cumulative,
        x_col="session_label",
        value_col="baseline_distance_um",
    )
    magnitude_summary_by_index = _summarize_fov_displacement(
        cumulative,
        x_col="experience_index",
        value_col="baseline_distance_um",
    )
    adjacent_summary = _summarize_fov_displacement(
        work,
        x_col="moving_session_label",
        value_col="distance_um",
    )
    stats = pd.concat(
        [
            _clustered_ols_trend(
                cumulative.loc[cumulative["experience_index"].gt(0)],
                y_col="baseline_distance_um",
                x_col="session_label",
                cluster_col="animal_id",
                metric="cumulative_baseline_displacement_by_session_label",
            ),
            _clustered_ols_trend(
                cumulative.loc[cumulative["experience_index"].gt(0)],
                y_col="baseline_distance_um",
                x_col="experience_index",
                cluster_col="animal_id",
                metric="cumulative_baseline_displacement_by_experience_index",
            ),
            _clustered_ols_trend(
                work,
                y_col="distance_um",
                x_col="moving_session_label",
                cluster_col="animal_id",
                metric="adjacent_step_displacement_by_moving_session_label",
            ),
        ],
        ignore_index=True,
    )
    manifest = {
        "source_csv": str(source_csv),
        "n_rows": int(len(work)),
        "n_animals": int(work["animal_id"].nunique()),
        "n_manual_overrides": int(work["manual_override"].sum()),
        "include_removed": bool(include_removed),
        "removed_rows_excluded": int(raw.shape[0] - work.shape[0]),
    }
    return {
        "adjacent": work,
        "cumulative": cumulative,
        "magnitude_summary_by_label": magnitude_summary_by_label,
        "magnitude_summary_by_index": magnitude_summary_by_index,
        "adjacent_summary": adjacent_summary,
        "stats": stats,
        "manifest": manifest,
    }


def render_cached_fov_displacement_panel(
    curated_csv,
    *,
    x_col: str = "session_label",
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "fov_displacement_over_experience",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render cumulative FOV XY drift and magnitude from curated adjacent CellReg shifts."""
    if x_col not in {"session_label", "experience_index"}:
        raise ValueError("x_col must be 'session_label' or 'experience_index'")
    plot_data = prepare_fov_displacement_plot_data(curated_csv)
    cumulative = plot_data["cumulative"].copy()
    summary_key = "magnitude_summary_by_label" if x_col == "session_label" else "magnitude_summary_by_index"
    magnitude_summary = plot_data[summary_key].copy()
    panel_layout = get_fov_displacement_layout(layout)
    panel_colors = get_fov_displacement_colors(colors)
    panel_style = get_fov_displacement_style(style)
    panel_labels = get_fov_displacement_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    fig = plt.figure(figsize=resolved_panel_size, facecolor="white")
    gs = fig.add_gridspec(
        1,
        2,
        width_ratios=[
            float(panel_layout.get("xy_panel_width_ratio", 0.92)),
            float(panel_layout.get("magnitude_panel_width_ratio", 1.18)),
        ],
        wspace=float(panel_layout.get("wspace", 0.38)),
    )
    ax_xy = fig.add_subplot(gs[0, 0])
    ax_mag = fig.add_subplot(gs[0, 1])

    animals = sorted(cumulative["animal_id"].astype(str).unique())
    rng = np.random.default_rng(int(panel_style.get("jitter_seed", 13)))
    jitter_width = float(panel_style.get("jitter", 0.055))
    jitter_by_animal = {
        animal: offset for animal, offset in zip(animals, rng.uniform(-jitter_width, jitter_width, len(animals)))
    }
    mark_manual_overrides = bool(panel_style.get("mark_manual_overrides", False))

    for animal_id, sub in cumulative.groupby("animal_id", sort=False):
        sub = sub.sort_values("experience_index")
        ax_xy.plot(
            sub["cum_dx_um"],
            sub["cum_dy_um"],
            color=panel_colors["animal_line"],
            linewidth=float(panel_style.get("animal_linewidth", 0.75)),
            alpha=float(panel_style.get("animal_line_alpha", 0.34)),
            zorder=1,
        )
        ax_xy.scatter(
            sub["cum_dx_um"],
            sub["cum_dy_um"],
            s=float(panel_style.get("animal_marker_size", 13.0)),
            color=panel_colors["animal_point"],
            alpha=float(panel_style.get("animal_marker_alpha", 0.52)),
            linewidths=0.0,
            zorder=2,
        )
        manual = sub.loc[sub["last_step_manual_override"].astype(bool)]
        if mark_manual_overrides and not manual.empty:
            ax_xy.scatter(
                manual["cum_dx_um"],
                manual["cum_dy_um"],
                s=float(panel_style.get("manual_marker_size", 21.0)),
                facecolors="none",
                edgecolors=panel_colors["manual_edge"],
                linewidths=float(panel_style.get("manual_marker_linewidth", 0.9)),
                marker="s",
                zorder=4,
            )

        x = pd.to_numeric(sub[x_col], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(sub["baseline_distance_um"], errors="coerce").to_numpy(dtype=float)
        ax_mag.plot(
            x,
            y,
            color=panel_colors["animal_line"],
            linewidth=float(panel_style.get("animal_linewidth", 0.75)),
            alpha=float(panel_style.get("animal_line_alpha", 0.34)),
            zorder=1,
        )
        scatter_x = x + float(jitter_by_animal[str(animal_id)])
        ax_mag.scatter(
            scatter_x,
            y,
            s=float(panel_style.get("animal_marker_size", 13.0)),
            color=panel_colors["animal_point"],
            alpha=float(panel_style.get("animal_marker_alpha", 0.52)),
            linewidths=0.0,
            zorder=2,
        )
        manual = sub.loc[sub["last_step_manual_override"].astype(bool)]
        if mark_manual_overrides and not manual.empty:
            manual_x = pd.to_numeric(manual[x_col], errors="coerce").to_numpy(dtype=float)
            manual_y = pd.to_numeric(manual["baseline_distance_um"], errors="coerce").to_numpy(dtype=float)
            ax_mag.scatter(
                manual_x + float(jitter_by_animal[str(animal_id)]),
                manual_y,
                s=float(panel_style.get("manual_marker_size", 21.0)),
                facecolors="none",
                edgecolors=panel_colors["manual_edge"],
                linewidths=float(panel_style.get("manual_marker_linewidth", 0.9)),
                marker="s",
                zorder=4,
            )

    ax_xy.axhline(0.0, color=panel_colors["zero"], linewidth=0.5, alpha=0.30, zorder=0)
    ax_xy.axvline(0.0, color=panel_colors["zero"], linewidth=0.5, alpha=0.30, zorder=0)
    xy_values = pd.concat([cumulative["cum_dx_um"], cumulative["cum_dy_um"]], ignore_index=True)
    finite_xy = xy_values[np.isfinite(xy_values)]
    if not finite_xy.empty:
        xy_min = float(finite_xy.min())
        xy_max = float(finite_xy.max())
        xy_span = max(xy_max - xy_min, 1.0)
        margin = xy_span * float(panel_style.get("xy_margin_fraction", 0.11))
        ax_xy.set_xlim(xy_min - margin, xy_max + margin)
        ax_xy.set_ylim(xy_min - margin, xy_max + margin)
    ax_xy.set_aspect("equal", adjustable="box")
    scale_len = float(panel_style.get("xy_scale_bar_um", 100.0))
    xmin, xmax = ax_xy.get_xlim()
    ymin, ymax = ax_xy.get_ylim()
    if (xmax - xmin) >= scale_len * 1.35:
        x0 = xmax - scale_len - 0.07 * (xmax - xmin)
        y0 = ymin + 0.08 * (ymax - ymin)
        ax_xy.plot(
            [x0, x0 + scale_len],
            [y0, y0],
            color=panel_colors["mean"],
            linewidth=float(panel_style.get("xy_scale_bar_linewidth", 1.2)),
            solid_capstyle="butt",
            zorder=6,
        )
        ax_xy.text(
            x0 + scale_len / 2,
            y0 + 0.035 * (ymax - ymin),
            str(panel_style.get("xy_scale_bar_label", "100 um")),
            ha="center",
            va="bottom",
            fontsize=float(panel_style.get("annotation_fontsize", 7.2)),
            color=panel_colors["axis"],
        )

    min_summary_n = int(panel_style.get("min_summary_n", 2))
    mean_summary_plot = magnitude_summary.loc[
        pd.to_numeric(magnitude_summary["n_animals"], errors="coerce").fillna(0).ge(min_summary_n)
    ].copy()
    mean_x = pd.to_numeric(mean_summary_plot[x_col], errors="coerce").to_numpy(dtype=float)
    mean_y = pd.to_numeric(mean_summary_plot["mean"], errors="coerce").to_numpy(dtype=float)
    sem_y = pd.to_numeric(mean_summary_plot["sem"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    ax_mag.errorbar(
        mean_x,
        mean_y,
        yerr=sem_y,
        marker="o",
        markersize=float(panel_style.get("mean_marker_size", 4.4)),
        linewidth=float(panel_style.get("mean_linewidth", 1.55)),
        elinewidth=float(panel_style.get("errorbar_linewidth", 0.95)),
        capsize=float(panel_style.get("errorbar_capsize", 2.3)),
        color=panel_colors["mean"],
        markerfacecolor=panel_colors["mean"],
        markeredgecolor=panel_colors["mean"],
        zorder=6,
    )
    for ax in (ax_xy, ax_mag):
        ax.grid(axis="y", color=panel_colors["grid"], alpha=float(panel_style.get("grid_alpha", 0.24)), linewidth=0.55)
        ax.tick_params(labelsize=float(panel_style.get("tick_labelsize", 7.4)), colors=panel_colors["axis"])
        ax.spines["top"].set_visible(bool(panel_style.get("spine_top", False)))
        ax.spines["right"].set_visible(bool(panel_style.get("spine_right", False)))
        ax.spines["left"].set_color(panel_colors["axis"])
        ax.spines["bottom"].set_color(panel_colors["axis"])

    ax_xy.set_title(
        str(panel_labels.get("xy_title", "")),
        fontsize=float(panel_style.get("title_fontsize", 8.8)),
        pad=5,
    )
    ax_xy.set_xlabel(
        str(panel_labels.get("xy_xlabel", "")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    ax_xy.set_ylabel(
        str(panel_labels.get("xy_ylabel", "")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    ax_mag.set_title(
        str(panel_labels.get("magnitude_title", "")),
        fontsize=float(panel_style.get("title_fontsize", 8.8)),
        pad=5,
    )
    magnitude_xlabel = panel_labels.get("magnitude_xlabel")
    if not magnitude_xlabel:
        magnitude_xlabel = "Imaging experience index" if x_col == "experience_index" else "Imaging session label"
    ax_mag.set_xlabel(
        str(magnitude_xlabel),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    ax_mag.set_ylabel(
        str(panel_labels.get("magnitude_ylabel", "")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    x_values = np.sort(pd.to_numeric(cumulative[x_col], errors="coerce").dropna().unique())
    ax_mag.set_xticks(x_values)
    if np.all(np.equal(np.mod(x_values, 1), 0)):
        ax_mag.set_xticklabels([str(int(value)) for value in x_values])
    ax_mag.set_ylim(bottom=0.0)
    ax_mag.text(
        0.02,
        0.96,
        str(panel_labels.get("n_label", "n = {n_animals} animals")).format(
            n_animals=plot_data["manifest"]["n_animals"],
            n_rows=plot_data["manifest"]["n_rows"],
        ),
        transform=ax_mag.transAxes,
        ha="left",
        va="top",
        fontsize=float(panel_style.get("annotation_fontsize", 7.2)),
        color=panel_colors["axis"],
    )
    if mark_manual_overrides and plot_data["manifest"]["n_manual_overrides"]:
        manual_handle = Line2D(
            [0],
            [0],
            marker="s",
            linestyle="none",
            markerfacecolor="none",
            markeredgecolor=panel_colors["manual_edge"],
            markeredgewidth=float(panel_style.get("manual_marker_linewidth", 0.9)),
            markersize=4.8,
            label=str(panel_labels.get("manual_label", "manual shift")),
        )
        ax_mag.legend(
            handles=[manual_handle],
            loc="upper right",
            frameon=False,
            fontsize=float(panel_style.get("annotation_fontsize", 7.2)),
            handletextpad=0.35,
            borderaxespad=0.0,
        )

    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.105)),
        right=float(panel_layout.get("right", 0.985)),
        bottom=float(panel_layout.get("bottom", 0.19)),
        top=float(panel_layout.get("top", 0.89)),
    )
    panel_data = {
        **plot_data,
        "magnitude_summary": magnitude_summary,
        "x_col": x_col,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.asarray([ax_xy, ax_mag]), panel_data, saved_paths


def prepare_cellreg_reliability_plot_data(
    summary_csv,
    long_csv,
    histogram_csv,
) -> dict:
    """Prepare CellReg registered-pair reliability tables and headline metrics."""
    summary_path = Path(summary_csv)
    long_path = Path(long_csv)
    histogram_path = Path(histogram_csv)
    summary = pd.read_csv(summary_path)
    long = pd.read_csv(long_path)
    histogram = pd.read_csv(histogram_path)
    required_summary_columns = {
        "animal_id",
        "pair_label",
        "curated_status",
        "total_unique_registered_clusters",
        "total_neuron_detections_across_sessions",
        "registered_pair_count",
        "registered_pair_fraction_of_unique_clusters",
        "p_same_median",
        "p_same_mean",
        "frac_p_same_ge_0p95",
        "frac_p_same_ge_0p99",
    }
    required_long_columns = {"animal_id", "pair_label", "cluster_index", "p_same"}
    required_histogram_columns = {"bin_center", "probability", "count"}
    missing_summary = required_summary_columns.difference(summary.columns)
    missing_long = required_long_columns.difference(long.columns)
    missing_histogram = required_histogram_columns.difference(histogram.columns)
    if missing_summary:
        raise ValueError(f"CellReg summary CSV is missing columns: {sorted(missing_summary)}")
    if missing_long:
        raise ValueError(f"CellReg long CSV is missing columns: {sorted(missing_long)}")
    if missing_histogram:
        raise ValueError(f"CellReg histogram CSV is missing columns: {sorted(missing_histogram)}")
    for frame, numeric_cols in [
        (
            summary,
            [
                "total_unique_registered_clusters",
                "total_neuron_detections_across_sessions",
                "registered_pair_count",
                "registered_pair_fraction_of_unique_clusters",
                "p_same_median",
                "p_same_mean",
                "frac_p_same_ge_0p90",
                "frac_p_same_ge_0p95",
                "frac_p_same_ge_0p99",
            ],
        ),
        (long, ["p_same"]),
        (histogram, ["bin_center", "probability", "count"]),
    ]:
        for col in numeric_cols:
            if col in frame.columns:
                frame[col] = pd.to_numeric(frame[col], errors="coerce")
    summary["animal_id"] = summary["animal_id"].astype(str)
    summary["pair_label"] = summary["pair_label"].astype(str)
    long["animal_id"] = long["animal_id"].astype(str)
    long["pair_label"] = long["pair_label"].astype(str)
    histogram = histogram.sort_values("bin_center").reset_index(drop=True)
    finite_p_same = pd.to_numeric(long["p_same"], errors="coerce").dropna()
    if finite_p_same.empty:
        raise ValueError("CellReg long CSV has no finite P_same values.")
    total_registered_pairs = int(finite_p_same.size)
    total_unique_clusters = int(pd.to_numeric(summary["total_unique_registered_clusters"], errors="coerce").sum())
    total_detections = int(pd.to_numeric(summary["total_neuron_detections_across_sessions"], errors="coerce").sum())
    registered_pairs_from_summary = int(pd.to_numeric(summary["registered_pair_count"], errors="coerce").sum())
    histogram_count = int(pd.to_numeric(histogram["count"], errors="coerce").sum())
    headline = {
        "n_session_pairs": int(summary.shape[0]),
        "n_animals": int(summary["animal_id"].nunique()),
        "registered_pair_p_same_count": total_registered_pairs,
        "registered_pair_count_from_summary": registered_pairs_from_summary,
        "histogram_count": histogram_count,
        "total_unique_registered_clusters": total_unique_clusters,
        "total_neuron_detections_across_sessions": total_detections,
        "mean_p_same": float(finite_p_same.mean()),
        "median_p_same": float(finite_p_same.median()),
        "frac_p_same_ge_0p90": float((finite_p_same >= 0.90).mean()),
        "frac_p_same_ge_0p95": float((finite_p_same >= 0.95).mean()),
        "frac_p_same_ge_0p99": float((finite_p_same >= 0.99).mean()),
        "registered_pairs_per_unique_cluster": (
            float(total_registered_pairs / total_unique_clusters) if total_unique_clusters else np.nan
        ),
        "mean_pair_frac_p_same_ge_0p95": float(summary["frac_p_same_ge_0p95"].mean()),
        "mean_pair_registered_fraction_unique_clusters": float(
            summary["registered_pair_fraction_of_unique_clusters"].mean()
        ),
        "median_pair_registered_fraction_unique_clusters": float(
            summary["registered_pair_fraction_of_unique_clusters"].median()
        ),
    }
    for status, count in summary["curated_status"].astype(str).value_counts(dropna=False).items():
        headline[f"curated_status_{status}_count"] = int(count)
    pair_plot_data = summary.copy()
    pair_plot_data["registered_pair_fraction_percent"] = (
        pair_plot_data["registered_pair_fraction_of_unique_clusters"] * 100.0
    )
    pair_plot_data["frac_p_same_ge_0p95_percent"] = pair_plot_data["frac_p_same_ge_0p95"] * 100.0
    pair_plot_data["registered_pair_count_sqrt"] = np.sqrt(pair_plot_data["registered_pair_count"].clip(lower=0))
    headline_df = pd.DataFrame([headline])
    manifest = {
        "summary_csv": str(summary_path),
        "long_csv": str(long_path),
        "histogram_csv": str(histogram_path),
        "histogram_denominator": "registered_pair_p_same_count",
    }
    return {
        "summary": summary,
        "long": long,
        "histogram": histogram,
        "pair_plot_data": pair_plot_data,
        "headline": headline_df,
        "manifest": manifest,
    }


def prepare_equal_time_rate_control_plot_data(pair_summary_csv, clustered_stats_csv) -> dict:
    pair_summary = pd.read_csv(pair_summary_csv)
    clustered_stats = pd.read_csv(clustered_stats_csv)
    for frame in (pair_summary, clustered_stats):
        if "variant" in frame:
            frame["variant"] = frame["variant"].astype(str)
    return {
        "pair_summary": pair_summary,
        "clustered_stats": clustered_stats,
    }


def _equal_time_stats_lookup(clustered_stats: pd.DataFrame) -> pd.DataFrame:
    stats_df = clustered_stats.copy()
    if stats_df.empty or "variant" not in stats_df.columns:
        return pd.DataFrame()
    return stats_df.set_index("variant", drop=False)


def _decoder_control_uniform_stats(
    figure2_stats_csv=None,
    resampling_stats_csv=None,
    *,
    source_label: str,
) -> pd.DataFrame:
    rows = []
    figure2_stats = _read_optional_table(figure2_stats_csv)
    if not figure2_stats.empty:
        required = {"analysis_family", "cohort", "prior_mode"}
        if required.issubset(figure2_stats.columns):
            full = figure2_stats.loc[
                (figure2_stats["analysis_family"].astype(str) == "decoder")
                & (figure2_stats["cohort"].astype(str) == "primary_rewarded_template")
                & (figure2_stats["prior_mode"].astype(str) == "uniform")
            ].copy()
            full["method_key"] = "full"
            full["method"] = "Full"
            full["source_label"] = source_label
            rows.append(full)
    resampling_stats = _read_optional_table(resampling_stats_csv)
    if not resampling_stats.empty:
        required = {"analysis_family", "cohort", "prior_mode", "resample_method"}
        if required.issubset(resampling_stats.columns):
            resampled = resampling_stats.loc[
                (resampling_stats["analysis_family"].astype(str) == "decoder_resampling")
                & (resampling_stats["cohort"].astype(str) == "primary_rewarded_template")
                & (resampling_stats["prior_mode"].astype(str) == "uniform")
            ].copy()
            resampled["method_key"] = resampled["resample_method"].astype(str)
            resampled["method"] = resampled["method_key"].map(
                {"frame_balanced": "Frame-balanced", "visit_balanced": "Visit-balanced"}
            )
            resampled["source_label"] = source_label
            rows.append(resampled)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True, sort=False)


def prepare_decoder_control_plot_data(
    plot_data_csv,
    *,
    d1_figure2_stats_csv=None,
    d1_resampling_stats_csv=None,
    d2_figure2_stats_csv=None,
    d2_resampling_stats_csv=None,
) -> dict:
    plot_data = pd.read_csv(plot_data_csv)
    if "delta" not in plot_data.columns:
        raise ValueError("Decoder-control plot data must include a 'delta' column.")
    plot_data = plot_data.copy()
    plot_data["source_label"] = plot_data["source_label"].astype(str)
    plot_data["method_key"] = plot_data["method_key"].astype(str)
    plot_data["delta"] = pd.to_numeric(plot_data["delta"], errors="coerce")
    if "animal" in plot_data.columns:
        plot_data["animal"] = plot_data["animal"].astype(str)
    summary = (
        plot_data.groupby(["source_label", "method_key", "method"], dropna=False, sort=False)
        .agg(
            n=("delta", "count"),
            n_animals=("animal", "nunique") if "animal" in plot_data.columns else ("delta", "count"),
            mean=("delta", "mean"),
            sem=("delta", _sem),
            median=("delta", "median"),
            n_negative=("delta", lambda x: int((pd.to_numeric(x, errors="coerce") < 0).sum())),
        )
        .reset_index()
    )
    stats = pd.concat(
        [
            _decoder_control_uniform_stats(
                d1_figure2_stats_csv,
                d1_resampling_stats_csv,
                source_label="D1 source",
            ),
            _decoder_control_uniform_stats(
                d2_figure2_stats_csv,
                d2_resampling_stats_csv,
                source_label="D2 source",
            ),
        ],
        ignore_index=True,
        sort=False,
    )
    return {"plot_data": plot_data, "summary": summary, "stats": stats}


def _decoder_control_jitter(n_points: int, half_width: float) -> np.ndarray:
    if n_points <= 1:
        return np.zeros(n_points, dtype=float)
    return np.linspace(-float(half_width), float(half_width), int(n_points), dtype=float)


def _style_decoder_control_axis(ax, *, ylabel: str, colors: dict, style: dict) -> None:
    ax.axhline(0, color=colors["zero"], linewidth=1.0, zorder=0)
    ax.spines["top"].set_visible(bool(style.get("spine_top", False)))
    ax.spines["right"].set_visible(bool(style.get("spine_right", False)))
    ax.spines["left"].set_color(colors["axis"])
    ax.spines["bottom"].set_color(colors["axis"])
    ax.tick_params(axis="both", labelsize=float(style["tick_labelsize"]))
    ax.tick_params(axis="x", pad=2)
    ax.set_ylabel(ylabel, fontsize=float(style["axis_label_fontsize"]))


def _decoder_control_stat_row(stats: pd.DataFrame, source_label: str, method_key: str) -> pd.DataFrame:
    if stats.empty or not {"source_label", "method_key"}.issubset(stats.columns):
        return pd.DataFrame()
    return stats.loc[
        (stats["source_label"].astype(str) == str(source_label))
        & (stats["method_key"].astype(str) == str(method_key))
    ].copy()


def prepare_reward_proxy_location_pair_panel_data(
    *,
    pv_plot_data_csv,
    pv_summary_csv,
    pv_stats_csv,
    decoder_plot_data_csv,
    decoder_summary_csv,
    decoder_stats_csv,
) -> dict:
    """Load cached water/control PV and decoder paired-panel data."""
    pv_plot = pd.read_csv(Path(pv_plot_data_csv)).copy()
    pv_summary = pd.read_csv(Path(pv_summary_csv)).copy()
    pv_stats = pd.read_csv(Path(pv_stats_csv)).copy()
    decoder_plot = pd.read_csv(Path(decoder_plot_data_csv)).copy()
    decoder_summary = pd.read_csv(Path(decoder_summary_csv)).copy()
    decoder_stats = pd.read_csv(Path(decoder_stats_csv)).copy()
    for frame, value_col in [(pv_plot, "pv_correlation"), (decoder_plot, "decoding_error")]:
        frame["location_key"] = frame["location_key"].astype(str)
        frame[value_col] = pd.to_numeric(frame[value_col], errors="coerce")
        if "animal" in frame.columns:
            frame["animal"] = frame["animal"].astype(str)
    if "method_key" in decoder_plot.columns:
        decoder_plot["method_key"] = decoder_plot["method_key"].astype(str)
    if "method_key" in decoder_summary.columns:
        decoder_summary["method_key"] = decoder_summary["method_key"].astype(str)
    if "method_key" in decoder_stats.columns:
        decoder_stats["method_key"] = decoder_stats["method_key"].astype(str)
    for frame in (pv_summary, decoder_summary):
        frame["location_key"] = frame["location_key"].astype(str)
        frame["mean"] = pd.to_numeric(frame["mean"], errors="coerce")
        frame["sem"] = pd.to_numeric(frame["sem"], errors="coerce")
    for frame in (pv_stats, decoder_stats):
        if "cluster_ols_p" in frame.columns:
            frame["cluster_ols_p"] = pd.to_numeric(frame["cluster_ols_p"], errors="coerce")
    return {
        "pv_plot_data": pv_plot,
        "pv_summary": pv_summary,
        "pv_stats": pv_stats,
        "decoder_plot_data": decoder_plot,
        "decoder_summary": decoder_summary,
        "decoder_stats": decoder_stats,
    }


def _location_pair_stat_p(stats_df: pd.DataFrame, method_key: str | None = None) -> float:
    if stats_df.empty or "cluster_ols_p" not in stats_df.columns:
        return np.nan
    rows = stats_df
    if method_key is not None and "method_key" in rows.columns:
        rows = rows.loc[rows["method_key"].astype(str) == str(method_key)]
    if rows.empty:
        return np.nan
    return float(pd.to_numeric(rows["cluster_ols_p"], errors="coerce").iloc[0])


def _location_pair_summary_row(summary_df: pd.DataFrame, location_key: str, method_key: str | None = None) -> pd.Series:
    rows = summary_df.loc[summary_df["location_key"].astype(str) == str(location_key)].copy()
    if method_key is not None and "method_key" in rows.columns:
        rows = rows.loc[rows["method_key"].astype(str) == str(method_key)]
    if rows.empty:
        raise ValueError(f"No summary row for location={location_key!r}, method={method_key!r}")
    return rows.iloc[0]


def _render_location_pair_axis(
    ax,
    plot_df: pd.DataFrame,
    summary_df: pd.DataFrame,
    stats_df: pd.DataFrame,
    *,
    value_col: str,
    method_key: str | None,
    title: str,
    ylabel: str,
    ylim: tuple[float, float] | None,
    rng: np.random.Generator,
    colors: dict,
    style: dict,
    labels: dict,
) -> list[dict]:
    rows = plot_df.copy()
    if method_key is not None and "method_key" in rows.columns:
        rows = rows.loc[rows["method_key"].astype(str) == str(method_key)].copy()
    rows = rows.loc[np.isfinite(pd.to_numeric(rows[value_col], errors="coerce"))].copy()
    if rows.empty:
        raise ValueError(f"No finite rows for {title!r}")
    sort_cols = [col for col in ["month_transition", "animal", "pair_id"] if col in rows.columns]
    water_rows = rows.loc[rows["location_key"].astype(str) == "water"].copy()
    if sort_cols:
        water_rows = water_rows.sort_values(sort_cols)
    pair_order = water_rows["pair_id"].astype(str).tolist()
    if not pair_order:
        raise ValueError(f"No water rows for {title!r}")
    rows["pair_id"] = rows["pair_id"].astype(str)
    wide = rows.pivot_table(index="pair_id", columns="location_key", values=value_col, aggfunc="mean")
    wide = wide.reindex(pair_order).dropna(subset=["water", "control"])
    jitter = {pair_id: float(rng.uniform(-float(style["paired_jitter"]), float(style["paired_jitter"]))) for pair_id in wide.index}
    point_rows = []
    for pair_id, row in wide.iterrows():
        xs = [0.0 + jitter[pair_id], 1.0 + jitter[pair_id]]
        ys = [float(row["water"]), float(row["control"])]
        ax.plot(
            xs,
            ys,
            color=colors["pair_line"],
            alpha=float(style["paired_line_alpha"]),
            linewidth=float(style["paired_linewidth"]),
            zorder=1,
        )
    for location_key, x in [("water", 0.0), ("control", 1.0)]:
        summary_row = _location_pair_summary_row(summary_df, location_key, method_key)
        mean = float(summary_row["mean"])
        sem = float(summary_row["sem"])
        ax.bar(
            x,
            mean,
            width=float(style["bar_width"]),
            color=colors[location_key],
            alpha=float(style["bar_alpha"]),
            edgecolor="none",
            zorder=2,
        )
        if np.isfinite(sem):
            ax.errorbar(
                x,
                mean,
                yerr=sem,
                color=colors["error"],
                linewidth=float(style["errorbar_linewidth"]),
                capsize=float(style["errorbar_capsize"]),
                capthick=float(style["errorbar_linewidth"]),
                zorder=4,
            )
        vals = (
            rows.loc[rows["location_key"].astype(str) == location_key]
            .set_index("pair_id")
            .reindex(wide.index)
            .reset_index()
        )
        xs = np.array([x + jitter[str(pair_id)] for pair_id in vals["pair_id"]], dtype=float)
        values = pd.to_numeric(vals[value_col], errors="coerce").to_numpy(dtype=float)
        ax.scatter(
            xs,
            values,
            s=float(style["point_size"]),
            color=colors[location_key],
            edgecolors=colors["point_edge"],
            linewidth=float(style["point_linewidth"]),
            alpha=float(style["point_alpha"]),
            zorder=3,
        )
        for point_pair_id, x_value, y_value in zip(vals["pair_id"], xs, values):
            point_rows.append(
                {
                    "title": title,
                    "method_key": method_key or "",
                    "pair_id": str(point_pair_id),
                    "location_key": location_key,
                    "x": float(x_value),
                    "value": float(y_value),
                }
            )
    p_value = _location_pair_stat_p(stats_df, method_key)
    stars = _significance_text(p_value) if np.isfinite(p_value) else ""
    if stars:
        data_top = float(np.nanmax(rows[value_col].to_numpy(dtype=float)))
        data_bottom = min(0.0, float(np.nanmin(rows[value_col].to_numpy(dtype=float))))
        span = max(data_top - data_bottom, 0.2)
        y = data_top + span * float(style["bracket_offset_fraction"])
        h = span * float(style["bracket_height_fraction"])
        ax.plot([0, 0, 1, 1], [y, y + h, y + h, y], color=colors["annotation"], linewidth=float(style["annotation_linewidth"]), clip_on=False)
        ax.text(0.5, y + h, stars, ha="center", va="bottom", fontsize=float(style["annotation_fontsize"]), color=colors["annotation"])
    ax.set_xticks([0, 1])
    ax.set_xticklabels([labels["water_label"], labels["control_label"]], fontsize=float(style["tick_labelsize"]))
    ax.set_title(title, fontsize=float(style["title_fontsize"]), pad=float(style["title_pad"]))
    ax.set_ylabel(ylabel, fontsize=float(style["axis_label_fontsize"]))
    ax.axhline(0, color=colors["zero"], linewidth=0.9, zorder=0)
    ax.tick_params(axis="both", labelsize=float(style["tick_labelsize"]), width=0.9, length=3)
    ax.spines["top"].set_visible(bool(style.get("spine_top", False)))
    ax.spines["right"].set_visible(bool(style.get("spine_right", False)))
    ax.spines["left"].set_color(colors["axis"])
    ax.spines["bottom"].set_color(colors["axis"])
    if ylim is not None:
        ax.set_ylim(*tuple(ylim))
    return point_rows


def render_cached_reward_proxy_location_pair_panel(
    pv_plot_data_csv,
    pv_summary_csv,
    pv_stats_csv,
    decoder_plot_data_csv,
    decoder_summary_csv,
    decoder_stats_csv,
    *,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "reward_proxy_location_pv_decoder_pairs",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render cached PV and decoder water/control paired panels together."""
    panel_layout = get_reward_proxy_location_pair_layout(layout)
    panel_colors = get_reward_proxy_location_pair_colors(colors)
    panel_style = get_reward_proxy_location_pair_style(style)
    panel_labels = get_reward_proxy_location_pair_labels(labels)
    plot_bundle = prepare_reward_proxy_location_pair_panel_data(
        pv_plot_data_csv=pv_plot_data_csv,
        pv_summary_csv=pv_summary_csv,
        pv_stats_csv=pv_stats_csv,
        decoder_plot_data_csv=decoder_plot_data_csv,
        decoder_summary_csv=decoder_summary_csv,
        decoder_stats_csv=decoder_stats_csv,
    )
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    fig, axes = plt.subplots(
        1,
        4,
        figsize=resolved_panel_size,
        facecolor="white",
        gridspec_kw={"width_ratios": tuple(panel_layout["width_ratios"])},
    )
    rng = np.random.default_rng(int(panel_style["paired_seed"]))
    point_rows = []
    point_rows.extend(
        _render_location_pair_axis(
            axes[0],
            plot_bundle["pv_plot_data"],
            plot_bundle["pv_summary"],
            plot_bundle["pv_stats"],
            value_col="pv_correlation",
            method_key=None,
            title=str(panel_labels["pv_title"]),
            ylabel=str(panel_labels["pv_ylabel"]),
            ylim=tuple(panel_style["pv_ylim"]),
            rng=rng,
            colors=panel_colors,
            style=panel_style,
            labels=panel_labels,
        )
    )
    decoder_titles = panel_labels["decoder_titles"]
    for ax_idx, method_key in enumerate(["uniform_full", "frame_balanced", "visit_balanced"], start=1):
        point_rows.extend(
            _render_location_pair_axis(
                axes[ax_idx],
                plot_bundle["decoder_plot_data"],
                plot_bundle["decoder_summary"],
                plot_bundle["decoder_stats"],
                value_col="decoding_error",
                method_key=method_key,
                title=str(decoder_titles.get(method_key, method_key)),
                ylabel=str(panel_labels["decoder_ylabel"]) if ax_idx == 1 else "",
                ylim=tuple(panel_style["decoder_ylim"]),
                rng=rng,
                colors=panel_colors,
                style=panel_style,
                labels=panel_labels,
            )
        )
    fig.tight_layout(w_pad=float(panel_layout["wspace"]), pad=0.35)
    panel_data = {
        **plot_bundle,
        "points": pd.DataFrame(point_rows),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_cached_decoder_control_support_panel(
    plot_data_csv,
    *,
    d1_figure2_stats_csv=None,
    d1_resampling_stats_csv=None,
    d2_figure2_stats_csv=None,
    d2_resampling_stats_csv=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "decoder_control_uniform_support_reproduction",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render uniform-prior and support-balanced reward-decoder controls."""
    panel_layout = get_decoder_control_layout(layout)
    panel_colors = get_decoder_control_colors(colors)
    panel_style = get_decoder_control_style(style)
    panel_labels = get_decoder_control_labels(labels)
    plot_bundle = prepare_decoder_control_plot_data(
        plot_data_csv,
        d1_figure2_stats_csv=d1_figure2_stats_csv,
        d1_resampling_stats_csv=d1_resampling_stats_csv,
        d2_figure2_stats_csv=d2_figure2_stats_csv,
        d2_resampling_stats_csv=d2_resampling_stats_csv,
    )
    plot_df = plot_bundle["plot_data"]
    summary = plot_bundle["summary"]
    stats = plot_bundle["stats"]
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    fig, axes = plt.subplots(1, 2, figsize=resolved_panel_size, sharey=True, facecolor="white")
    method_order = list(DECODER_CONTROL_METHOD_ORDER)
    method_labels = [panel_labels["method_labels"].get(key, key) for key in method_order]
    point_rows = []

    ax = axes[0]
    primary_source = "D1 source"
    for x, method_key in enumerate(method_order):
        sub = plot_df.loc[
            (plot_df["source_label"] == primary_source) & (plot_df["method_key"] == method_key)
        ].copy()
        if sub.empty:
            continue
        sort_cols = [col for col in ["month_transition", "animal", "pair_id"] if col in sub.columns]
        if sort_cols:
            sub = sub.sort_values(sort_cols).reset_index(drop=True)
        srow = summary.loc[
            (summary["source_label"] == primary_source) & (summary["method_key"] == method_key)
        ].iloc[0]
        color = panel_colors.get(method_key, panel_colors["full"])
        ax.bar(
            x,
            float(srow["mean"]),
            yerr=float(srow["sem"]) if np.isfinite(float(srow["sem"])) else None,
            width=float(panel_style["primary_bar_width"]),
            color=color,
            alpha=float(panel_style["bar_alpha"]),
            edgecolor="none",
            error_kw={
                "elinewidth": float(panel_style["errorbar_linewidth"]),
                "capsize": float(panel_style["errorbar_capsize"]),
                "capthick": float(panel_style["errorbar_linewidth"]),
                "ecolor": panel_colors["error"],
            },
            zorder=1,
        )
        jitter = _decoder_control_jitter(len(sub), float(panel_style["point_jitter"]))
        values = sub["delta"].to_numpy(dtype=float)
        ax.scatter(
            np.full(len(sub), float(x)) + jitter,
            values,
            s=float(panel_style["point_size"]),
            color=color,
            edgecolor=panel_colors["point_edge"],
            linewidth=float(panel_style["point_linewidth"]),
            alpha=float(panel_style["point_alpha"]),
            zorder=3,
        )
        for row, value, x_jitter in zip(sub.itertuples(index=False), values, jitter):
            point_rows.append(
                {
                    "source_label": primary_source,
                    "method_key": method_key,
                    "x": float(x + x_jitter),
                    "delta": float(value),
                    "pair_id": getattr(row, "pair_id", ""),
                    "animal": getattr(row, "animal", ""),
                }
            )
        stat_row = _decoder_control_stat_row(stats, primary_source, method_key)
        if not stat_row.empty and "cluster_ols_p" in stat_row.columns:
            stars = _significance_text(float(stat_row["cluster_ols_p"].iloc[0]))
            if stars != "n.s.":
                ax.text(
                    x,
                    float(panel_style["annotation_y"]),
                    stars,
                    ha="center",
                    va="center",
                    fontsize=float(panel_style["annotation_fontsize"]),
                    color=panel_colors["annotation"],
                    clip_on=False,
                    zorder=5,
                )
    _style_decoder_control_axis(ax, ylabel=str(panel_labels["ylabel"]), colors=panel_colors, style=panel_style)
    ax.set_xticks(np.arange(len(method_order), dtype=float))
    ax.set_xticklabels(method_labels, fontsize=float(panel_style["tick_labelsize"]))
    ax.set_title(str(panel_labels["primary_title"]), fontsize=float(panel_style["title_fontsize"]), pad=float(panel_style["title_pad"]))

    ax = axes[1]
    width = float(panel_style["comparison_bar_width"])
    offsets = {"D1 source": -width / 2.0, "D2 source": width / 2.0}
    source_color_keys = {"D1 source": "d1_source", "D2 source": "d2_source"}
    for source_label in DECODER_CONTROL_SOURCE_ORDER:
        source_color = panel_colors[source_color_keys[source_label]]
        for x, method_key in enumerate(method_order):
            sub = plot_df.loc[
                (plot_df["source_label"] == source_label) & (plot_df["method_key"] == method_key)
            ].copy()
            if sub.empty:
                continue
            sort_cols = [col for col in ["month_transition", "animal", "pair_id"] if col in sub.columns]
            if sort_cols:
                sub = sub.sort_values(sort_cols).reset_index(drop=True)
            srow = summary.loc[
                (summary["source_label"] == source_label) & (summary["method_key"] == method_key)
            ].iloc[0]
            xpos = x + offsets[source_label]
            ax.bar(
                xpos,
                float(srow["mean"]),
                yerr=float(srow["sem"]) if np.isfinite(float(srow["sem"])) else None,
                width=width,
                color=source_color,
                alpha=float(panel_style["comparison_bar_alpha"]),
                edgecolor="none",
                error_kw={
                    "elinewidth": float(panel_style["errorbar_linewidth"]),
                    "capsize": float(panel_style["errorbar_capsize"]),
                    "capthick": float(panel_style["errorbar_linewidth"]),
                    "ecolor": panel_colors["error"],
                },
                label=panel_labels["source_labels"].get(source_label, source_label) if x == 0 else None,
                zorder=1,
            )
            jitter = _decoder_control_jitter(
                len(sub),
                float(panel_style["point_jitter"]) * float(panel_style["comparison_point_jitter_scale"]),
            )
            values = sub["delta"].to_numpy(dtype=float)
            ax.scatter(
                np.full(len(sub), float(xpos)) + jitter,
                values,
                s=float(panel_style["comparison_point_size"]),
                color=source_color,
                edgecolor=panel_colors["point_edge"],
                linewidth=float(panel_style["comparison_point_linewidth"]),
                alpha=float(panel_style["comparison_point_alpha"]),
                zorder=3,
            )
            for row, value, x_jitter in zip(sub.itertuples(index=False), values, jitter):
                point_rows.append(
                    {
                        "source_label": source_label,
                        "method_key": method_key,
                        "x": float(xpos + x_jitter),
                        "delta": float(value),
                        "pair_id": getattr(row, "pair_id", ""),
                        "animal": getattr(row, "animal", ""),
                    }
                )
    _style_decoder_control_axis(ax, ylabel="", colors=panel_colors, style=panel_style)
    ax.set_xticks(np.arange(len(method_order), dtype=float))
    ax.set_xticklabels(method_labels, fontsize=float(panel_style["tick_labelsize"]))
    ax.set_title(str(panel_labels["comparison_title"]), fontsize=float(panel_style["title_fontsize"]), pad=float(panel_style["title_pad"]))
    ax.legend(
        frameon=False,
        fontsize=float(panel_style["legend_fontsize"]),
        loc=str(panel_style["legend_loc"]),
        bbox_to_anchor=tuple(panel_style["legend_bbox_to_anchor"]),
        handlelength=float(panel_style["legend_handlelength"]),
    )
    for axis in axes:
        axis.set_ylim(tuple(panel_style["ylim"]))
    fig.tight_layout(w_pad=float(panel_layout["wspace"]), pad=0.35)
    panel_data = {
        **plot_bundle,
        "points": pd.DataFrame(point_rows),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_cached_stable_pf_reward_controls_panel(
    preview_png,
    *,
    caption_stats_md=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "stable_pf_reward_controls_supplement_only",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render the approved stable-PF reward-control composite from its cached preview image."""
    panel_layout = {**STABLE_PF_REWARD_CONTROLS_LAYOUT, **(layout or {})}
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    preview_png = Path(preview_png)
    image = plt.imread(preview_png)

    fig, ax = plt.subplots(figsize=resolved_panel_size, facecolor="white")
    ax.imshow(image)
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)

    caption_text = ""
    if caption_stats_md is not None:
        caption_path = Path(caption_stats_md)
        if caption_path.exists():
            caption_text = caption_path.read_text(encoding="utf-8")

    panel_data = {
        "preview_png": preview_png,
        "image_shape": tuple(image.shape),
        "caption_stats_path": Path(caption_stats_md) if caption_stats_md is not None else None,
        "caption_stats": caption_text,
        "layout": panel_layout,
        "colors": colors or {},
        "style": style or {},
        "labels": labels or {},
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, ax, panel_data, saved_paths


def render_cached_equal_time_rate_control_delta_panel(
    pair_summary_csv,
    clustered_stats_csv,
    *,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "equal_time_ensemble_rate_maze_outside_delta",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render equal-time maze-minus-outside ensemble-rate control across variants."""
    plot_data = prepare_equal_time_rate_control_plot_data(pair_summary_csv, clustered_stats_csv)
    pair_df = plot_data["pair_summary"].copy()
    stats_lookup = _equal_time_stats_lookup(plot_data["clustered_stats"])
    panel_layout = get_equal_time_rate_control_layout(layout)
    panel_colors = get_equal_time_rate_control_colors(colors)
    panel_style = get_equal_time_rate_control_style(style)
    panel_labels = get_equal_time_rate_control_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout.get("delta_panel_size", panel_layout["reference_panel_size"]))
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    fig, ax = plt.subplots(figsize=resolved_panel_size, facecolor="white")
    rng = np.random.default_rng(int(panel_style["point_seed"]))
    summary_rows = []
    point_rows = []
    y_top = -np.inf
    y_bottom = np.inf
    for x, variant in enumerate(EQUAL_TIME_RATE_CONTROL_VARIANTS):
        sub = pair_df.loc[pair_df["variant"].astype(str) == variant].copy()
        if sub.empty or variant not in stats_lookup.index:
            continue
        values_raw = pd.to_numeric(sub["equal_time_maze_minus_outside_mean"], errors="coerce").to_numpy(dtype=float)
        finite = np.isfinite(values_raw)
        values = values_raw[finite]
        sub = sub.loc[finite].copy()
        if values.size == 0:
            continue
        stat = stats_lookup.loc[variant]
        mean = float(stat["mean_diff"])
        err = float(stat["cluster_se"])
        qvalue = float(stat["qvalue_bh"])
        stars = _significance_text(qvalue)
        if stars == "n.s.":
            stars = ""
        y_top = max(y_top, float(np.nanmax(values)), mean + err)
        y_bottom = min(y_bottom, float(np.nanmin(values)), mean - err)
        summary_rows.append(
            {
                "variant": variant,
                "label": panel_labels["variant_labels"].get(variant, variant).replace("\n", " "),
                "n_pair_rows": int(stat["n_pair_rows"]),
                "n_animals": int(stat["n_animals"]),
                "mean_diff": mean,
                "cluster_se": err,
                "pvalue": float(stat["pvalue"]),
                "qvalue_bh": qvalue,
                "stars": stars,
            }
        )
        ax.bar(
            x,
            mean,
            width=float(panel_style["bar_width"]),
            color=panel_colors["bar"],
            alpha=float(panel_style["bar_alpha"]),
            edgecolor="none",
            linewidth=float(panel_style["bar_linewidth"]),
            zorder=1,
        )
        ax.errorbar(
            x,
            mean,
            yerr=err,
            color=panel_colors["error"],
            linewidth=float(panel_style["errorbar_linewidth"]),
            capsize=float(panel_style["errorbar_capsize"]),
            zorder=3,
        )
        jitter = rng.normal(0.0, float(panel_style["point_jitter"]), size=values.size)
        ax.scatter(
            np.full(values.size, float(x)) + jitter,
            values,
            s=float(panel_style["point_size"]),
            color=panel_colors["point"],
            alpha=float(panel_style["point_alpha"]),
            edgecolors="none",
            zorder=4,
        )
        for row, value, x_jitter in zip(sub.itertuples(index=False), values, jitter):
            point_rows.append(
                {
                    "variant": variant,
                    "x": float(x + x_jitter),
                    "value": float(value),
                    "animal_id": str(row.animal_id),
                    "group": str(row.group),
                    "src_session": str(row.src_session),
                    "dst_session": str(row.dst_session),
                }
            )

    if not np.isfinite(y_top):
        y_top = 1.0
        y_bottom = 0.0
    span = max(float(y_top - y_bottom), 0.1)
    star_y = y_top + span * float(panel_style["annotation_offset_fraction"])
    for x, row in enumerate(summary_rows):
        if row["stars"]:
            ax.text(
                x,
                star_y,
                row["stars"],
                ha="center",
                va="bottom",
                fontsize=float(panel_style["annotation_fontsize"]),
                fontweight=panel_style["annotation_fontweight"],
                color=panel_colors["annotation"],
                clip_on=False,
                zorder=5,
            )

    ax.axhline(0, color=panel_colors["zero"], linewidth=0.8, zorder=0)
    ax.set_xticks(np.arange(len(EQUAL_TIME_RATE_CONTROL_VARIANTS), dtype=float))
    ax.set_xticklabels(
        [panel_labels["variant_labels"].get(v, v) for v in EQUAL_TIME_RATE_CONTROL_VARIANTS],
        fontsize=float(panel_style["tick_labelsize"]),
    )
    ax.set_ylabel(str(panel_labels["delta_ylabel"]), fontsize=float(panel_style["axis_label_fontsize"]))
    ax.tick_params(axis="y", labelsize=float(panel_style["tick_labelsize"]))
    ax.tick_params(axis="x", length=0)
    ax.spines["top"].set_visible(bool(panel_style.get("spine_top", False)))
    ax.spines["right"].set_visible(bool(panel_style.get("spine_right", False)))
    ax.spines["left"].set_color(panel_colors["axis"])
    ax.spines["bottom"].set_color(panel_colors["axis"])
    ax.set_ylim(
        y_bottom - span * float(panel_style["ylim_pad_bottom_fraction"]),
        star_y + span * float(panel_style["ylim_pad_top_fraction"]),
    )
    fig.tight_layout(pad=0.8)
    panel_data = {
        **plot_data,
        "summary": pd.DataFrame(summary_rows),
        "points": pd.DataFrame(point_rows),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.asarray([ax]), panel_data, saved_paths


def render_cached_equal_time_rate_control_d1v1_absolute_panel(
    pair_summary_csv,
    clustered_stats_csv,
    *,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "equal_time_ensemble_rate_d1v1_absolute",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render Day1-vs-Day1 absolute outside-maze and maze ensemble-rate correlations."""
    plot_data = prepare_equal_time_rate_control_plot_data(pair_summary_csv, clustered_stats_csv)
    pair_df = plot_data["pair_summary"].copy()
    stats_lookup = _equal_time_stats_lookup(plot_data["clustered_stats"])
    panel_layout = get_equal_time_rate_control_layout(layout)
    panel_colors = get_equal_time_rate_control_colors(colors)
    panel_style = get_equal_time_rate_control_style(style)
    panel_labels = get_equal_time_rate_control_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout.get("absolute_panel_size", panel_layout["reference_panel_size"]))
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    variant = "d1v1"
    sub = pair_df.loc[pair_df["variant"].astype(str) == variant].copy()
    sub["outside"] = pd.to_numeric(sub["equal_time_outside_r_mean"], errors="coerce")
    sub["maze"] = pd.to_numeric(sub["equal_time_maze_r_mean"], errors="coerce")
    sub = sub.loc[np.isfinite(sub["outside"]) & np.isfinite(sub["maze"])].copy()
    fig, ax = plt.subplots(figsize=resolved_panel_size, facecolor="white")
    rng = np.random.default_rng(int(panel_style["paired_seed"]))
    point_rows = []
    for row in sub.itertuples(index=False):
        jitter = float(rng.normal(0.0, float(panel_style["paired_jitter"])))
        xs = np.array([0.0 + jitter, 1.0 + jitter])
        ys = np.array([float(row.outside), float(row.maze)])
        ax.plot(
            xs,
            ys,
            color=panel_colors["line"],
            alpha=float(panel_style["paired_line_alpha"]),
            linewidth=float(panel_style["paired_linewidth"]),
            zorder=1,
        )
        ax.scatter(
            xs,
            ys,
            s=float(panel_style["point_size"]),
            color=panel_colors["point"],
            alpha=float(panel_style["paired_point_alpha"]),
            edgecolors="none",
            zorder=2,
        )
        point_rows.extend(
            [
                {
                    "variant": variant,
                    "animal_id": str(row.animal_id),
                    "group": str(row.group),
                    "src_session": str(row.src_session),
                    "dst_session": str(row.dst_session),
                    "domain": "outside",
                    "x": float(xs[0]),
                    "value": float(ys[0]),
                },
                {
                    "variant": variant,
                    "animal_id": str(row.animal_id),
                    "group": str(row.group),
                    "src_session": str(row.src_session),
                    "dst_session": str(row.dst_session),
                    "domain": "maze",
                    "x": float(xs[1]),
                    "value": float(ys[1]),
                },
            ]
        )

    outside = sub["outside"].to_numpy(dtype=float)
    maze = sub["maze"].to_numpy(dtype=float)
    means = np.array([np.nanmean(outside), np.nanmean(maze)])
    sems = np.array([_sem(outside), _sem(maze)])
    ax.plot([0, 1], means, color=panel_colors["mean"], linewidth=float(panel_style["mean_linewidth"]), zorder=4)
    ax.errorbar(
        [0, 1],
        means,
        yerr=sems,
        color=panel_colors["mean"],
        marker="o",
        markersize=float(panel_style["mean_marker_size"]),
        linewidth=float(panel_style["errorbar_linewidth"]),
        capsize=float(panel_style["errorbar_capsize"]),
        zorder=5,
    )

    stat = stats_lookup.loc[variant] if variant in stats_lookup.index else pd.Series(dtype=float)
    qvalue = float(stat.get("qvalue_bh", np.nan))
    stars = _significance_text(qvalue)
    if stars == "n.s.":
        stars = ""
    y_values = np.concatenate([outside, maze, means + np.nan_to_num(sems, nan=0.0)])
    y_min = float(np.nanmin(y_values))
    y_max = float(np.nanmax(y_values))
    span = max(float(y_max - y_min), 0.1)
    bracket_y = y_max + span * float(panel_style["annotation_offset_fraction"])
    tick_h = span * float(panel_style["annotation_height_fraction"])
    ax.plot(
        [0, 0, 1, 1],
        [bracket_y - tick_h, bracket_y, bracket_y, bracket_y - tick_h],
        color=panel_colors["annotation"],
        linewidth=float(panel_style["annotation_linewidth"]),
        clip_on=False,
        zorder=6,
    )
    if stars:
        ax.text(
            0.5,
            bracket_y + span * float(panel_style["annotation_text_offset_fraction"]),
            stars,
            ha="center",
            va="bottom",
            fontsize=float(panel_style["annotation_fontsize"]),
            fontweight=panel_style["annotation_fontweight"],
            color=panel_colors["annotation"],
            clip_on=False,
            zorder=7,
        )

    ax.set_xlim(-0.22, 1.22)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(
        [panel_labels["outside_label"], panel_labels["maze_label"]],
        fontsize=float(panel_style["tick_labelsize"]),
    )
    ax.set_ylabel(str(panel_labels["absolute_ylabel"]), fontsize=float(panel_style["axis_label_fontsize"]))
    ax.tick_params(axis="y", labelsize=float(panel_style["tick_labelsize"]))
    ax.tick_params(axis="x", length=0)
    ax.spines["top"].set_visible(bool(panel_style.get("spine_top", False)))
    ax.spines["right"].set_visible(bool(panel_style.get("spine_right", False)))
    ax.spines["left"].set_color(panel_colors["axis"])
    ax.spines["bottom"].set_color(panel_colors["axis"])
    ax.set_ylim(
        y_min - span * float(panel_style["ylim_pad_bottom_fraction"]),
        bracket_y + span * 0.22,
    )
    fig.tight_layout(pad=0.8)
    summary = pd.DataFrame(
        [
            {
                "variant": variant,
                "n_pair_rows": int(sub.shape[0]),
                "n_animals": int(sub["animal_id"].nunique()),
                "outside_mean": float(means[0]),
                "outside_sem": float(sems[0]),
                "maze_mean": float(means[1]),
                "maze_sem": float(sems[1]),
                "mean_diff": float(stat.get("mean_diff", np.nan)),
                "cluster_se_diff": float(stat.get("cluster_se", np.nan)),
                "pvalue": float(stat.get("pvalue", np.nan)),
                "qvalue_bh": qvalue,
                "stars": stars,
            }
        ]
    )
    panel_data = {
        **plot_data,
        "summary": summary,
        "points": pd.DataFrame(point_rows),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.asarray([ax]), panel_data, saved_paths


def render_cached_cellreg_reliability_panel(
    summary_csv,
    long_csv,
    histogram_csv,
    *,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "cellreg_registered_pair_reliability",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render a CellReg registered-pair registration-score histogram."""
    plot_data = prepare_cellreg_reliability_plot_data(summary_csv, long_csv, histogram_csv)
    histogram = plot_data["histogram"].copy()
    long = plot_data["long"].copy()
    panel_layout = get_cellreg_reliability_layout(layout)
    panel_colors = get_cellreg_reliability_colors(colors)
    panel_style = get_cellreg_reliability_style(style)
    panel_labels = get_cellreg_reliability_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    fig, ax_hist = plt.subplots(figsize=resolved_panel_size, facecolor="white")

    requested_bin_width = panel_style.get("bin_width")
    if requested_bin_width is None:
        hist_plot = histogram.copy()
        bin_centers = pd.to_numeric(hist_plot["bin_center"], errors="coerce").to_numpy(dtype=float)
        counts = pd.to_numeric(hist_plot["count"], errors="coerce").to_numpy(dtype=float)
        if len(bin_centers) > 1:
            bin_width = float(np.nanmedian(np.diff(np.sort(bin_centers))))
        else:
            bin_width = 0.05
    else:
        bin_width = float(requested_bin_width)
        if not (0 < bin_width <= 1):
            raise ValueError("CellReg reliability bin_width must be in the interval (0, 1].")
        p_same = pd.to_numeric(long["p_same"], errors="coerce").dropna().to_numpy(dtype=float)
        edges = np.arange(0.0, 1.0 + bin_width, bin_width)
        if edges[-1] < 1.0:
            edges = np.append(edges, 1.0)
        edges[-1] = 1.0000000001
        counts, edges = np.histogram(p_same, bins=edges)
        bin_centers = (edges[:-1] + edges[1:]) / 2.0
        hist_plot = pd.DataFrame(
            {
                "bin_center": bin_centers,
                "count": counts.astype(int),
                "probability": counts / counts.sum() if counts.sum() else np.nan,
            }
        )
    ax_hist.bar(
        bin_centers,
        counts,
        width=bin_width * 0.92,
        color=panel_colors["bar"],
        edgecolor=panel_colors["bar_edge"],
        linewidth=float(panel_style.get("bar_linewidth", 0.4)),
        alpha=float(panel_style.get("bar_alpha", 0.86)),
        align="center",
        zorder=2,
    )
    threshold_values = tuple(panel_style.get("threshold_values", ()))
    for threshold in threshold_values:
        ax_hist.axvline(
            float(threshold),
            color=panel_colors["threshold"],
            linestyle=str(panel_style.get("threshold_linestyle", "--")),
            linewidth=float(panel_style.get("threshold_linewidth", 1.0)),
            alpha=0.72 if float(threshold) == 0.95 else 0.42,
            zorder=3,
        )
    if bool(panel_style.get("show_titles", False)):
        ax_hist.set_title(
            str(panel_labels.get("hist_title", "")),
            fontsize=float(panel_style.get("title_fontsize", 8.8)),
            pad=5,
        )
    ax_hist.set_xlabel(
        str(panel_labels.get("hist_xlabel", "")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    ax_hist.set_ylabel(
        str(panel_labels.get("hist_ylabel", "")),
        fontsize=float(panel_style.get("axis_label_fontsize", 8.4)),
    )
    ax_hist.set_xlim(tuple(panel_style.get("xlim_hist", (0.0, 1.0))))
    ax_hist.set_ylim(bottom=0.0)

    ax_hist.grid(axis="y", color=panel_colors["grid"], alpha=float(panel_style.get("grid_alpha", 0.24)), linewidth=0.55)
    ax_hist.tick_params(labelsize=float(panel_style.get("tick_labelsize", 7.4)), colors=panel_colors["axis"])
    ax_hist.spines["top"].set_visible(bool(panel_style.get("spine_top", False)))
    ax_hist.spines["right"].set_visible(bool(panel_style.get("spine_right", False)))
    ax_hist.spines["left"].set_color(panel_colors["axis"])
    ax_hist.spines["bottom"].set_color(panel_colors["axis"])

    fig.subplots_adjust(
        left=float(panel_layout.get("left", 0.20)),
        right=float(panel_layout.get("right", 0.985)),
        bottom=float(panel_layout.get("bottom", 0.22)),
        top=float(panel_layout.get("top", 0.96)),
    )
    panel_data = {
        **plot_data,
        "histogram_plot": hist_plot,
        "bin_width": bin_width,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.asarray([ax_hist]), panel_data, saved_paths


def _session_month_for_decoder_label(session_id: str) -> int:
    text = str(session_id)
    for month in (12, 9, 6, 3):
        if f"-{month}day" in text:
            return month
    return 0


def _decoder_transition_sort_value(transition: str) -> float:
    if str(transition) == "D1-D1b":
        return -0.5
    try:
        return float(str(transition).split("-", maxsplit=1)[0])
    except Exception:
        return 999.0


def _decoder_transition_label(src: str, dst: str) -> str:
    if str(src) == "1616day1" and str(dst) == "1616bday1":
        return "D1-D1b"
    return f"{_session_month_for_decoder_label(src)}-{_session_month_for_decoder_label(dst)}"


def _decoder_transition_display_label(transition: str, panel_labels: dict) -> str:
    transition = str(transition)
    if transition == "D1-D1b":
        return str(panel_labels["special_transition_label"])
    if transition == "All":
        return str(panel_labels["all_average_label"])
    if "-" in transition:
        start, end = transition.split("-", maxsplit=1)
        return f"{start}->{end} mo"
    return transition


def _decoder_pair_title(row: pd.Series) -> str:
    animal = str(row.get("animal", ""))
    return f"{animal} {_decoder_transition_label(row['src'], row['dst'])}"


def _load_cross_session_decoding_pickle(src: str, dst: str, cohort: str, old_decoding_dir, new_decoding_dir) -> tuple[dict, Path]:
    filename = f"cross_session_{src}_to_{dst}.pkl"
    search_dirs = [Path(new_decoding_dir)] if str(cohort) == "new" else [Path(old_decoding_dir)]
    search_dirs.append(Path(old_decoding_dir) if str(cohort) == "new" else Path(new_decoding_dir))
    for base_dir in search_dirs:
        path = base_dir / filename
        if path.exists():
            with path.open("rb") as handle:
                return pickle.load(handle), path
    raise FileNotFoundError(f"Could not find {filename} in {old_decoding_dir} or {new_decoding_dir}.")


def _per_bin_decoding_error(decoded_pos, labels_pos, *, n_bins_x: int, n_bins_y: int) -> tuple[np.ndarray, np.ndarray, float]:
    decoded_pos = np.asarray(decoded_pos)
    labels_pos = np.asarray(labels_pos)
    keep = np.isfinite(decoded_pos) & np.isfinite(labels_pos)
    decoded_pos = decoded_pos[keep].astype(int)
    labels_pos = labels_pos[keep].astype(int)
    n_bins = int(n_bins_x) * int(n_bins_y)
    in_range = (decoded_pos >= 0) & (decoded_pos < n_bins) & (labels_pos >= 0) & (labels_pos < n_bins)
    decoded_pos = decoded_pos[in_range]
    labels_pos = labels_pos[in_range]
    px = decoded_pos % int(n_bins_x)
    py = decoded_pos // int(n_bins_x)
    tx = labels_pos % int(n_bins_x)
    ty = labels_pos // int(n_bins_x)
    euclidean_error = np.sqrt((px - tx).astype(float) ** 2 + (py - ty).astype(float) ** 2)
    counts = np.bincount(labels_pos, minlength=n_bins)
    sums = np.bincount(labels_pos, weights=euclidean_error, minlength=n_bins)
    means = np.full(n_bins, np.nan, dtype=float)
    valid = counts > 0
    means[valid] = sums[valid] / counts[valid]
    return means, counts, float(np.nanmean(euclidean_error))


def prepare_decoding_error_heatmap_plot_data(
    summary_csv,
    *,
    old_decoding_dir,
    new_decoding_dir,
    exclude_unrewarded_0v3: bool = True,
    excluded_srcs=None,
    style: dict | None = None,
) -> dict:
    """Load current cross-session decoder pickles and compute per-bin spatial errors."""
    panel_style = get_decoding_error_heatmap_style(style)
    n_bins_x = int(panel_style["n_bins_x"])
    n_bins_y = int(panel_style["n_bins_y"])
    excluded = set(excluded_srcs or DECODING_ERROR_HEATMAP_EXCLUDED_UNREWARDED_0V3_SRCS)

    summary = pd.read_csv(Path(summary_csv)).copy()
    required = {"src", "dst", "animal", "cohort", "mean_eu_error"}
    missing = required.difference(summary.columns)
    if missing:
        raise KeyError(f"Missing required columns in {summary_csv!r}: {sorted(missing)}")
    summary["src"] = summary["src"].astype(str)
    summary["dst"] = summary["dst"].astype(str)
    summary["cohort"] = summary["cohort"].astype(str)
    summary["animal"] = summary["animal"].astype(str)
    summary["is_excluded_unrewarded_0v3"] = summary["src"].isin(excluded)

    pair_rows = []
    long_rows = []
    for _, row in summary.iterrows():
        payload, source_pickle = _load_cross_session_decoding_pickle(
            row["src"],
            row["dst"],
            row["cohort"],
            old_decoding_dir,
            new_decoding_dir,
        )
        means, counts, frame_mean = _per_bin_decoding_error(
            payload["decoded_pos"],
            payload["labels_pos"],
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
        )
        keep_pair = (not bool(exclude_unrewarded_0v3)) or (not bool(row["is_excluded_unrewarded_0v3"]))
        transition = _decoder_transition_label(row["src"], row["dst"])
        pair_id = f"{row['src']}_to_{row['dst']}"
        pair_rows.append(
            {
                "pair_id": pair_id,
                "src": row["src"],
                "dst": row["dst"],
                "animal": row["animal"],
                "cohort": row["cohort"],
                "transition": transition,
                "source_pickle": str(source_pickle),
                "n_frames": int(np.asarray(payload["decoded_pos"]).size),
                "frame_mean_eu_error": frame_mean,
                "summary_mean_eu_error": float(row["mean_eu_error"]),
                "abs_delta_vs_summary": abs(frame_mean - float(row["mean_eu_error"])),
                "is_excluded_unrewarded_0v3": bool(row["is_excluded_unrewarded_0v3"]),
                "included_in_plot": bool(keep_pair),
                "level_definition": payload.get("level_definition", ""),
            }
        )
        if not keep_pair:
            continue
        for bin_index, value in enumerate(means):
            long_rows.append(
                {
                    "pair_id": pair_id,
                    "src": row["src"],
                    "dst": row["dst"],
                    "animal": row["animal"],
                    "cohort": row["cohort"],
                    "transition": transition,
                    "bin_index": int(bin_index),
                    "bx": int(bin_index % n_bins_x),
                    "by": int(bin_index // n_bins_x),
                    "decoding_error": float(value) if np.isfinite(value) else np.nan,
                    "frame_count": int(counts[bin_index]),
                    "panel_title": _decoder_pair_title(row),
                }
            )

    pair_summary = pd.DataFrame(pair_rows)
    plot_long = pd.DataFrame(long_rows)
    if pair_summary.empty or plot_long.empty:
        raise ValueError("No decoding-error heatmap data were prepared.")
    included_pairs = pair_summary.loc[pair_summary["included_in_plot"].astype(bool)].copy()
    included_pairs["_transition_rank"] = included_pairs["transition"].map(_decoder_transition_sort_value)
    included_pairs = included_pairs.sort_values(
        ["animal", "_transition_rank", "src", "dst"],
        kind="stable",
    ).drop(columns=["_transition_rank"])
    plot_long["pair_id"] = pd.Categorical(plot_long["pair_id"], categories=included_pairs["pair_id"].tolist(), ordered=True)
    plot_long = plot_long.sort_values(["pair_id", "bin_index"], kind="stable").reset_index(drop=True)

    return {
        "summary": summary,
        "pair_summary": pair_summary,
        "included_pairs": included_pairs.reset_index(drop=True),
        "plot_long": plot_long,
        "excluded_srcs": sorted(excluded),
        "n_bins_x": n_bins_x,
        "n_bins_y": n_bins_y,
    }


def render_cached_decoding_error_heatmap_grid_panel(
    summary_csv,
    *,
    old_decoding_dir,
    new_decoding_dir,
    exclude_unrewarded_0v3: bool = True,
    excluded_srcs=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "decoding_error_heatmap_grid",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render compact per-pair 15x15 spatial decoding-error heatmaps."""
    plot_data = prepare_decoding_error_heatmap_plot_data(
        summary_csv,
        old_decoding_dir=old_decoding_dir,
        new_decoding_dir=new_decoding_dir,
        exclude_unrewarded_0v3=exclude_unrewarded_0v3,
        excluded_srcs=excluded_srcs,
        style=style,
    )
    panel_layout = get_decoding_error_heatmap_layout(layout)
    panel_colors = get_decoding_error_heatmap_colors(colors)
    panel_style = get_decoding_error_heatmap_style(style)
    panel_labels = get_decoding_error_heatmap_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    included_pairs = plot_data["included_pairs"]
    plot_long = plot_data["plot_long"]
    n_pairs = int(included_pairs.shape[0])
    animals = included_pairs["animal"].astype(str).drop_duplicates().tolist()
    transitions = sorted(
        included_pairs["transition"].astype(str).drop_duplicates().tolist(),
        key=_decoder_transition_sort_value,
    )
    n_cols = len(animals)
    n_rows = len(transitions)
    n_bins_x = int(plot_data["n_bins_x"])
    n_bins_y = int(plot_data["n_bins_y"])
    reward_bin = DECODING_ERROR_HEATMAP_REWARD_BIN
    reward_x = reward_bin % n_bins_x
    reward_y = reward_bin // n_bins_x

    finite = pd.to_numeric(plot_long["decoding_error"], errors="coerce").dropna().to_numpy(dtype=float)
    vmax = panel_style.get("vmax")
    if vmax is None:
        vmax = float(np.nanpercentile(finite, float(panel_style["vmax_percentile"]))) if finite.size else 1.0
    vmin = float(panel_style["vmin"]) if panel_style.get("vmin") is not None else 0.0

    cmap = plt.get_cmap(panel_colors["cmap"]).copy()
    cmap.set_bad(panel_colors["bad"])
    fig, axes = plt.subplots(n_rows, n_cols, figsize=resolved_panel_size, squeeze=False, facecolor="white")

    image = None
    pair_lookup = {
        pair_id: group.sort_values("bin_index", kind="stable")
        for pair_id, group in plot_long.groupby("pair_id", observed=True)
    }
    animal_to_col = {animal: idx for idx, animal in enumerate(animals)}
    transition_to_row = {transition: idx for idx, transition in enumerate(transitions)}
    for _, row in included_pairs.reset_index(drop=True).iterrows():
        ax = axes[transition_to_row[str(row["transition"])], animal_to_col[str(row["animal"])]]
        pair_values = pair_lookup[row["pair_id"]]
        heat = pair_values["decoding_error"].to_numpy(dtype=float).reshape(n_bins_y, n_bins_x)
        image = ax.imshow(
            np.ma.masked_invalid(heat),
            origin="lower",
            interpolation=str(panel_style["interpolation"]),
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            aspect="equal",
        )
        if bool(panel_style["invert_yaxis"]):
            ax.set_ylim(n_bins_y - 0.5, -0.5)
        _add_decoding_error_control_markers(
            ax,
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            panel_colors=panel_colors,
            panel_style=panel_style,
        )
        square_size = float(panel_style["reward_square_size"])
        ax.add_patch(
            Rectangle(
                (reward_x - square_size / 2.0, reward_y - square_size / 2.0),
                square_size,
                square_size,
                fill=False,
                edgecolor=panel_colors["reward_square"],
                linewidth=float(panel_style["reward_square_linewidth"]),
                zorder=7,
            )
        )
        reward_y_axes = ax.transAxes.inverted().transform(ax.transData.transform((reward_x, reward_y)))[1]
        _add_timeline_water_drop_icon(
            ax,
            (1.0, float(reward_y_axes)),
            {
                "kind": "water",
                "size": float(panel_style["water_icon_size"]),
                "linewidth": float(panel_style["water_icon_linewidth"]),
                "x_offset_points": float(panel_style["water_icon_x_offset_points"]),
                "facecolor": panel_colors["reward_icon_face"],
                "edgecolor": panel_colors["reward_icon_edge"],
                "zorder": 8,
            },
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    expected_pairs = {(str(row["transition"]), str(row["animal"])) for _, row in included_pairs.iterrows()}
    for transition in transitions:
        for animal in animals:
            if (transition, animal) not in expected_pairs:
                axes[transition_to_row[transition], animal_to_col[animal]].axis("off")

    fig.subplots_adjust(
        left=float(panel_layout["left"]),
        right=float(panel_layout["right"]),
        bottom=float(panel_layout["bottom"]),
        top=float(panel_layout["top"]),
        wspace=float(panel_layout["wspace"]),
        hspace=float(panel_layout["hspace"]),
    )
    for animal in animals:
        col = animal_to_col[animal]
        bbox = axes[0, col].get_position()
        fig.text(
            (bbox.x0 + bbox.x1) / 2.0,
            float(panel_layout["column_label_y"]),
            animal,
            ha="center",
            va="bottom",
            fontsize=float(panel_style["column_label_fontsize"]),
            color=panel_colors["axis_label"],
        )
    for transition in transitions:
        row_idx = transition_to_row[transition]
        bbox = axes[row_idx, 0].get_position()
        label = _decoder_transition_display_label(transition, panel_labels)
        fig.text(
            float(panel_layout["row_label_x"]),
            (bbox.y0 + bbox.y1) / 2.0,
            label,
            ha="right",
            va="center",
            fontsize=float(panel_style["row_label_fontsize"]),
            color=panel_colors["axis_label"],
            rotation=0,
        )
    cbar_ax = fig.add_axes(
        [
            float(panel_layout["colorbar_left"]),
            float(panel_layout["colorbar_bottom"]),
            float(panel_layout["colorbar_width"]),
            float(panel_layout["colorbar_height"]),
        ]
    )
    colorbar = fig.colorbar(image, cax=cbar_ax)
    colorbar.set_label(str(panel_labels["colorbar"]), fontsize=float(panel_style["colorbar_labelsize"]))
    colorbar.ax.tick_params(labelsize=float(panel_style["tick_labelsize"]), length=2.0)

    panel_data = {
        **plot_data,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "vmin": vmin,
        "vmax": vmax,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def _add_decoding_error_reward_marker(
    ax,
    *,
    reward_x: int,
    reward_y: int,
    n_bins_x: int,
    n_bins_y: int,
    panel_colors: dict,
    panel_style: dict,
    include_icon: bool = True,
) -> None:
    square_size = float(panel_style["reward_square_size"])
    ax.add_patch(
        Rectangle(
            (reward_x - square_size / 2.0, reward_y - square_size / 2.0),
            square_size,
            square_size,
            fill=False,
            edgecolor=panel_colors["reward_square"],
            linewidth=float(panel_style["reward_square_linewidth"]),
            zorder=7,
        )
    )
    if not include_icon:
        return
    reward_y_axes = ax.transAxes.inverted().transform(ax.transData.transform((reward_x, reward_y)))[1]
    _add_timeline_water_drop_icon(
        ax,
        (1.0, float(reward_y_axes)),
        {
            "kind": "water",
            "size": float(panel_style["water_icon_size"]),
            "linewidth": float(panel_style["water_icon_linewidth"]),
            "x_offset_points": float(panel_style["water_icon_x_offset_points"]),
            "facecolor": panel_colors["reward_icon_face"],
            "edgecolor": panel_colors["reward_icon_edge"],
            "zorder": 8,
        },
    )


def _add_decoding_error_control_markers(
    ax,
    *,
    control_bins=DECODING_ERROR_HEATMAP_CONTROL_BINS,
    n_bins_x: int,
    n_bins_y: int,
    panel_colors: dict,
    panel_style: dict,
    mode: str = "data_square",
) -> None:
    control_xy = [
        (int(bin_index) % int(n_bins_x), int(bin_index) // int(n_bins_x))
        for bin_index in control_bins
    ]
    if str(mode) == "screen_square":
        ax.scatter(
            [xy[0] for xy in control_xy],
            [xy[1] for xy in control_xy],
            marker="s",
            s=float(panel_style["control_screen_square_size"]),
            facecolors="none",
            edgecolors=panel_colors["control_square"],
            linewidths=float(panel_style["control_square_linewidth"]),
            zorder=6,
        )
        return
    square_size = float(panel_style["control_square_size"])
    for control_x, control_y in control_xy:
        ax.add_patch(
            Rectangle(
                (control_x - square_size / 2.0, control_y - square_size / 2.0),
                square_size,
                square_size,
                fill=False,
                edgecolor=panel_colors["control_square"],
                linewidth=float(panel_style["control_square_linewidth"]),
                zorder=6,
            )
        )


def _decoding_error_color_limits(plot_long: pd.DataFrame, panel_style: dict) -> tuple[float, float]:
    finite = pd.to_numeric(plot_long["decoding_error"], errors="coerce").dropna().to_numpy(dtype=float)
    vmax = panel_style.get("vmax")
    if vmax is None:
        vmax = float(np.nanpercentile(finite, float(panel_style["vmax_percentile"]))) if finite.size else 1.0
    vmin = float(panel_style["vmin"]) if panel_style.get("vmin") is not None else 0.0
    return vmin, float(vmax)


def _decoding_error_transition_order(included_pairs: pd.DataFrame) -> list[str]:
    return sorted(
        included_pairs["transition"].astype(str).drop_duplicates().tolist(),
        key=_decoder_transition_sort_value,
    )


def render_cached_decoding_error_heatmap_packed_panel(
    summary_csv,
    *,
    old_decoding_dir,
    new_decoding_dir,
    exclude_unrewarded_0v3: bool = True,
    excluded_srcs=None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "decoding_error_heatmap_packed",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render per-pair decoding-error maps packed by experience transition."""
    plot_data = prepare_decoding_error_heatmap_plot_data(
        summary_csv,
        old_decoding_dir=old_decoding_dir,
        new_decoding_dir=new_decoding_dir,
        exclude_unrewarded_0v3=exclude_unrewarded_0v3,
        excluded_srcs=excluded_srcs,
        style=style,
    )
    panel_layout = get_decoding_error_heatmap_layout(layout)
    panel_colors = get_decoding_error_heatmap_colors(colors)
    panel_style = get_decoding_error_heatmap_style(style)
    panel_labels = get_decoding_error_heatmap_labels(labels)
    resolved_panel_size = tuple(panel_size or panel_layout["packed_panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    included_pairs = plot_data["included_pairs"].copy()
    plot_long = plot_data["plot_long"].copy()
    transitions = _decoding_error_transition_order(included_pairs)
    counts_by_transition = included_pairs.groupby("transition", sort=False)["pair_id"].size()
    n_cols = int(panel_layout.get("packed_n_cols", 5))
    n_cols = max(1, n_cols)
    n_rows_by_transition = {
        transition: int(np.ceil(float(counts_by_transition.loc[transition]) / float(n_cols)))
        for transition in transitions
    }
    n_bins_x = int(plot_data["n_bins_x"])
    n_bins_y = int(plot_data["n_bins_y"])
    reward_bin = DECODING_ERROR_HEATMAP_REWARD_BIN
    reward_x = reward_bin % n_bins_x
    reward_y = reward_bin // n_bins_x
    vmin, vmax = _decoding_error_color_limits(plot_long, panel_style)

    cmap = plt.get_cmap(panel_colors["cmap"]).copy()
    cmap.set_bad(panel_colors["bad"])
    fig = plt.figure(figsize=resolved_panel_size, facecolor="white")
    outer_grid = fig.add_gridspec(
        len(transitions),
        1,
        left=float(panel_layout["packed_left"]),
        right=float(panel_layout["packed_right"]),
        bottom=float(panel_layout["packed_bottom"]),
        top=float(panel_layout["packed_top"]),
        hspace=float(panel_layout.get("packed_section_hspace", panel_layout["packed_hspace"])),
        height_ratios=[n_rows_by_transition[transition] for transition in transitions],
    )
    pair_lookup = {
        str(pair_id): group.sort_values("bin_index", kind="stable")
        for pair_id, group in plot_long.groupby("pair_id", observed=True)
    }
    image = None
    axes_for_return = []
    transition_axes = {}
    for row_idx, transition in enumerate(transitions):
        sub = included_pairs.loc[included_pairs["transition"].astype(str) == transition].reset_index(drop=True)
        n_group_rows = n_rows_by_transition[transition]
        inner_grid = outer_grid[row_idx, 0].subgridspec(
            n_group_rows,
            n_cols,
            wspace=float(panel_layout["packed_wspace"]),
            hspace=float(panel_layout["packed_hspace"]),
        )
        transition_axes[transition] = []
        for pair_idx, pair in sub.iterrows():
            ax = fig.add_subplot(inner_grid[pair_idx // n_cols, pair_idx % n_cols])
            pair_values = pair_lookup[str(pair["pair_id"])]
            heat = pair_values["decoding_error"].to_numpy(dtype=float).reshape(n_bins_y, n_bins_x)
            image = ax.imshow(
                np.ma.masked_invalid(heat),
                origin="lower",
                interpolation=str(panel_style["interpolation"]),
                cmap=cmap,
                vmin=vmin,
                vmax=vmax,
                aspect="equal",
            )
            if bool(panel_style["invert_yaxis"]):
                ax.set_ylim(n_bins_y - 0.5, -0.5)
            _add_decoding_error_control_markers(
                ax,
                n_bins_x=n_bins_x,
                n_bins_y=n_bins_y,
                panel_colors=panel_colors,
                panel_style=panel_style,
                mode="screen_square",
            )
            _add_decoding_error_reward_marker(
                ax,
                reward_x=reward_x,
                reward_y=reward_y,
                n_bins_x=n_bins_x,
                n_bins_y=n_bins_y,
                panel_colors=panel_colors,
                panel_style=panel_style,
                include_icon=False,
            )
            ax.set_title(
                str(pair["animal"]),
                fontsize=float(panel_style["packed_title_fontsize"]),
                color=panel_colors["title"],
                pad=float(panel_style["packed_title_pad"]),
            )
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            axes_for_return.append(ax)
            transition_axes[transition].append(ax)
        for blank_idx in range(len(sub), n_group_rows * n_cols):
            ax = fig.add_subplot(inner_grid[blank_idx // n_cols, blank_idx % n_cols])
            ax.axis("off")
            axes_for_return.append(ax)

    for transition in transitions:
        visible_axes = transition_axes[transition]
        y0 = min(ax.get_position().y0 for ax in visible_axes)
        y1 = max(ax.get_position().y1 for ax in visible_axes)
        label = _decoder_transition_display_label(transition, panel_labels)
        fig.text(
            float(panel_layout["row_label_x"]),
            (y0 + y1) / 2.0,
            label,
            ha="right",
            va="center",
            fontsize=float(panel_style["row_label_fontsize"]),
            color=panel_colors["axis_label"],
        )
    cbar_ax = fig.add_axes(
        [
            float(panel_layout["colorbar_left"]),
            float(panel_layout["colorbar_bottom"]),
            float(panel_layout["colorbar_width"]),
            float(panel_layout["colorbar_height"]),
        ]
    )
    colorbar = fig.colorbar(image, cax=cbar_ax)
    colorbar.set_label(str(panel_labels["colorbar"]), fontsize=float(panel_style["colorbar_labelsize"]))
    colorbar.ax.tick_params(labelsize=float(panel_style["tick_labelsize"]), length=2.0)

    panel_data = {
        **plot_data,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "vmin": vmin,
        "vmax": vmax,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, np.array(axes_for_return, dtype=object), panel_data, saved_paths


def _average_decoding_error_maps(
    plot_long: pd.DataFrame,
    included_pairs: pd.DataFrame,
    *,
    average_mode: str,
    min_support_pairs: int | None = None,
    min_support_fraction: float | None = None,
) -> pd.DataFrame:
    average_mode = str(average_mode)
    if average_mode not in {"equal_pair", "frame_weighted"}:
        raise ValueError("average_mode must be 'equal_pair' or 'frame_weighted'.")
    if min_support_pairs is not None and min_support_fraction is not None:
        raise ValueError("Use either min_support_pairs or min_support_fraction, not both.")
    if min_support_pairs is not None and int(min_support_pairs) < 1:
        raise ValueError("min_support_pairs must be >= 1.")
    if min_support_fraction is not None and not (0.0 < float(min_support_fraction) <= 1.0):
        raise ValueError("min_support_fraction must be in (0, 1].")
    rows = []
    groups = [(transition, included_pairs.loc[included_pairs["transition"].astype(str) == transition])
              for transition in _decoding_error_transition_order(included_pairs)]
    groups.append(("All", included_pairs))
    for transition, pair_rows in groups:
        pair_ids = pair_rows["pair_id"].astype(str).tolist()
        n_total_pairs = len(pair_ids)
        if min_support_pairs is not None:
            support_threshold = int(min_support_pairs)
        elif min_support_fraction is not None:
            support_threshold = int(np.ceil(float(min_support_fraction) * float(n_total_pairs)))
        else:
            support_threshold = 1
        sub = plot_long.loc[plot_long["pair_id"].astype(str).isin(pair_ids)].copy()
        for bin_index, bin_rows in sub.groupby("bin_index", sort=True):
            values = pd.to_numeric(bin_rows["decoding_error"], errors="coerce")
            counts = pd.to_numeric(bin_rows["frame_count"], errors="coerce").fillna(0.0)
            valid = values.notna() & (counts > 0)
            n_valid_pairs = int(valid.sum())
            if n_valid_pairs < support_threshold:
                value = np.nan
            elif average_mode == "frame_weighted":
                denominator = float(counts.loc[valid].sum())
                value = float((values.loc[valid] * counts.loc[valid]).sum() / denominator) if denominator > 0 else np.nan
            else:
                value = float(values.loc[valid].mean()) if valid.any() else np.nan
            rows.append(
                {
                    "transition": transition,
                    "bin_index": int(bin_index),
                    "bx": int(bin_rows["bx"].iloc[0]),
                    "by": int(bin_rows["by"].iloc[0]),
                    "decoding_error": value,
                    "n_pairs": n_valid_pairs,
                    "n_total_pairs": int(n_total_pairs),
                    "support_threshold": int(support_threshold),
                    "frame_count": int(counts.sum()),
                    "average_mode": average_mode,
                }
            )
    return pd.DataFrame(rows)


def render_cached_decoding_error_average_map_panel(
    summary_csv,
    *,
    old_decoding_dir,
    new_decoding_dir,
    exclude_unrewarded_0v3: bool = True,
    excluded_srcs=None,
    average_mode: str | None = None,
    min_support_pairs: int | None = None,
    min_support_fraction: float | None = None,
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "decoding_error_average_maps",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render transition-wise and overall average decoding-error maps."""
    plot_data = prepare_decoding_error_heatmap_plot_data(
        summary_csv,
        old_decoding_dir=old_decoding_dir,
        new_decoding_dir=new_decoding_dir,
        exclude_unrewarded_0v3=exclude_unrewarded_0v3,
        excluded_srcs=excluded_srcs,
        style=style,
    )
    panel_layout = get_decoding_error_heatmap_layout(layout)
    panel_colors = get_decoding_error_heatmap_colors(colors)
    panel_style = get_decoding_error_heatmap_style(style)
    panel_labels = get_decoding_error_heatmap_labels(labels)
    average_mode = str(average_mode or panel_style["average_mode"])
    min_support_pairs = (
        int(min_support_pairs)
        if min_support_pairs is not None
        else (
            int(panel_style["average_min_support_pairs"])
            if panel_style.get("average_min_support_pairs") is not None
            else None
        )
    )
    min_support_fraction = (
        float(min_support_fraction)
        if min_support_fraction is not None
        else (
            float(panel_style["average_min_support_fraction"])
            if panel_style.get("average_min_support_fraction") is not None
            else None
        )
    )
    average_long = _average_decoding_error_maps(
        plot_data["plot_long"].copy(),
        plot_data["included_pairs"].copy(),
        average_mode=average_mode,
        min_support_pairs=min_support_pairs,
        min_support_fraction=min_support_fraction,
    )
    resolved_panel_size = tuple(panel_size or panel_layout["average_panel_size"])
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)

    transitions = _decoding_error_transition_order(plot_data["included_pairs"]) + ["All"]
    n_cols = int(panel_layout["average_n_cols"])
    n_rows = int(np.ceil(len(transitions) / n_cols))
    n_bins_x = int(plot_data["n_bins_x"])
    n_bins_y = int(plot_data["n_bins_y"])
    reward_bin = DECODING_ERROR_HEATMAP_REWARD_BIN
    reward_x = reward_bin % n_bins_x
    reward_y = reward_bin // n_bins_x
    vmin, vmax = _decoding_error_color_limits(plot_data["plot_long"], panel_style)

    cmap = plt.get_cmap(panel_colors["cmap"]).copy()
    cmap.set_bad(panel_colors["bad"])
    fig, axes = plt.subplots(n_rows, n_cols, figsize=resolved_panel_size, squeeze=False, facecolor="white")
    maze = get_panel_maze(DEFAULT_MAZE_ID)
    image = None
    for idx, transition in enumerate(transitions):
        ax = axes[idx // n_cols, idx % n_cols]
        sub = average_long.loc[average_long["transition"].astype(str) == transition].sort_values("bin_index", kind="stable")
        heat = sub["decoding_error"].to_numpy(dtype=float).reshape(n_bins_y, n_bins_x)
        image = ax.imshow(
            np.ma.masked_invalid(heat),
            origin="lower",
            interpolation=str(panel_style["interpolation"]),
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            aspect="equal",
            zorder=1,
        )
        if bool(panel_style["invert_yaxis"]):
            ax.set_ylim(n_bins_y - 0.5, -0.5)
        if bool(panel_style["average_show_maze_outline"]):
            draw_maze_outline(
                ax,
                maze,
                panel_size=resolved_panel_size,
                layout={"maze_wall_linewidth": float(panel_style["average_maze_wall_linewidth"])},
                colors={"wall": "black"},
            )
        _add_decoding_error_control_markers(
            ax,
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            panel_colors=panel_colors,
            panel_style=panel_style,
        )
        _add_decoding_error_reward_marker(
            ax,
            reward_x=reward_x,
            reward_y=reward_y,
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            panel_colors=panel_colors,
            panel_style=panel_style,
        )
        n_pairs = int(plot_data["included_pairs"].shape[0]) if transition == "All" else int(
            (plot_data["included_pairs"]["transition"].astype(str) == transition).sum()
        )
        title = _decoder_transition_display_label(transition, panel_labels)
        support_threshold = int(sub["support_threshold"].iloc[0]) if len(sub) else 1
        ax.set_title(
            f"{title} (n={n_pairs})\n>={support_threshold}/{n_pairs} pairs",
            fontsize=float(panel_style["average_title_fontsize"]),
            color=panel_colors["title"],
            pad=float(panel_style["average_title_pad"]),
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
    for idx in range(len(transitions), n_rows * n_cols):
        axes[idx // n_cols, idx % n_cols].axis("off")

    fig.subplots_adjust(
        left=float(panel_layout["average_left"]),
        right=float(panel_layout["average_right"]),
        bottom=float(panel_layout["average_bottom"]),
        top=float(panel_layout["average_top"]),
        wspace=float(panel_layout["average_wspace"]),
        hspace=float(panel_layout["average_hspace"]),
    )
    cbar_ax = fig.add_axes(
        [
            float(panel_layout["average_colorbar_left"]),
            float(panel_layout["average_colorbar_bottom"]),
            float(panel_layout["average_colorbar_width"]),
            float(panel_layout["average_colorbar_height"]),
        ]
    )
    colorbar = fig.colorbar(image, cax=cbar_ax)
    colorbar.set_label(str(panel_labels["colorbar"]), fontsize=float(panel_style["colorbar_labelsize"]))
    colorbar.ax.tick_params(labelsize=float(panel_style["tick_labelsize"]), length=2.0)

    panel_data = {
        **plot_data,
        "average_long": average_long,
        "average_mode": average_mode,
        "average_min_support_pairs": min_support_pairs,
        "average_min_support_fraction": min_support_fraction,
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "vmin": vmin,
        "vmax": vmax,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


def render_cached_decoding_error_all_average_support_options_panel(
    summary_csv,
    *,
    old_decoding_dir,
    new_decoding_dir,
    exclude_unrewarded_0v3: bool = True,
    excluded_srcs=None,
    support_options=None,
    average_mode: str = "equal_pair",
    panel_size=None,
    layout: dict | None = None,
    colors: dict | None = None,
    style: dict | None = None,
    labels: dict | None = None,
    rcparams: dict | None = None,
    save: bool = False,
    panel_name: str = "decoding_error_all_average_support_options",
    output_dir=DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR,
    formats=DEFAULT_EXPORT_FORMATS,
):
    """Render all-pair average maps under several bin-support thresholds."""
    plot_data = prepare_decoding_error_heatmap_plot_data(
        summary_csv,
        old_decoding_dir=old_decoding_dir,
        new_decoding_dir=new_decoding_dir,
        exclude_unrewarded_0v3=exclude_unrewarded_0v3,
        excluded_srcs=excluded_srcs,
        style=style,
    )
    panel_layout = get_decoding_error_heatmap_layout(layout)
    panel_colors = get_decoding_error_heatmap_colors(colors)
    panel_style = get_decoding_error_heatmap_style(style)
    panel_labels = get_decoding_error_heatmap_labels(labels)
    if support_options is None:
        support_options = [
            {"label": "Any pair", "min_support_pairs": None, "min_support_fraction": None},
            {"label": ">10 pairs", "min_support_pairs": 11, "min_support_fraction": None},
            {"label": "Half pairs", "min_support_pairs": None, "min_support_fraction": 0.50},
            {"label": "75% pairs", "min_support_pairs": None, "min_support_fraction": 0.75},
        ]

    resolved_panel_size = tuple(panel_size or (8.0, 3.15))
    apply_panel_rcparams(rcparams, panel_size=resolved_panel_size, layout=panel_layout)
    n_options = len(support_options)
    fig, axes = plt.subplots(1, n_options, figsize=resolved_panel_size, squeeze=False, facecolor="white")
    axes = axes[0]
    n_bins_x = int(plot_data["n_bins_x"])
    n_bins_y = int(plot_data["n_bins_y"])
    reward_bin = DECODING_ERROR_HEATMAP_REWARD_BIN
    reward_x = reward_bin % n_bins_x
    reward_y = reward_bin // n_bins_x
    vmin, vmax = _decoding_error_color_limits(plot_data["plot_long"], panel_style)
    cmap = plt.get_cmap(panel_colors["cmap"]).copy()
    cmap.set_bad(panel_colors["bad"])
    maze = get_panel_maze(DEFAULT_MAZE_ID)
    option_rows = []
    image = None

    for ax, option in zip(axes, support_options):
        min_pairs = option.get("min_support_pairs")
        min_fraction = option.get("min_support_fraction")
        average_long = _average_decoding_error_maps(
            plot_data["plot_long"].copy(),
            plot_data["included_pairs"].copy(),
            average_mode=average_mode,
            min_support_pairs=int(min_pairs) if min_pairs is not None else None,
            min_support_fraction=float(min_fraction) if min_fraction is not None else None,
        )
        sub = average_long.loc[average_long["transition"].astype(str) == "All"].sort_values("bin_index", kind="stable")
        heat = sub["decoding_error"].to_numpy(dtype=float).reshape(n_bins_y, n_bins_x)
        image = ax.imshow(
            np.ma.masked_invalid(heat),
            origin="lower",
            interpolation=str(panel_style["interpolation"]),
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            aspect="equal",
            zorder=1,
        )
        if bool(panel_style["invert_yaxis"]):
            ax.set_ylim(n_bins_y - 0.5, -0.5)
        if bool(panel_style["average_show_maze_outline"]):
            draw_maze_outline(
                ax,
                maze,
                panel_size=resolved_panel_size,
                layout={"maze_wall_linewidth": float(panel_style["average_maze_wall_linewidth"])},
                colors={"wall": "black"},
            )
        _add_decoding_error_control_markers(
            ax,
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            panel_colors=panel_colors,
            panel_style=panel_style,
        )
        _add_decoding_error_reward_marker(
            ax,
            reward_x=reward_x,
            reward_y=reward_y,
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            panel_colors=panel_colors,
            panel_style=panel_style,
            include_icon=True,
        )
        kept_bins = int(sub["decoding_error"].notna().sum())
        threshold = int(sub["support_threshold"].iloc[0]) if len(sub) else 1
        title = str(option.get("label", ""))
        ax.set_title(
            f"{title}\n>={threshold}/29 pairs\n{kept_bins}/225 bins",
            fontsize=float(panel_style["average_title_fontsize"]),
            color=panel_colors["title"],
            pad=float(panel_style["average_title_pad"]),
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        option_rows.append(
            {
                "label": title,
                "average_mode": average_mode,
                "min_support_pairs": min_pairs,
                "min_support_fraction": min_fraction,
                "resolved_support_threshold": threshold,
                "n_total_pairs": int(plot_data["included_pairs"].shape[0]),
                "kept_bins": kept_bins,
            }
        )

    fig.subplots_adjust(left=0.025, right=0.910, bottom=0.080, top=0.790, wspace=0.060)
    cbar_ax = fig.add_axes([0.935, 0.175, 0.016, 0.56])
    colorbar = fig.colorbar(image, cax=cbar_ax)
    colorbar.set_label(str(panel_labels["colorbar"]), fontsize=float(panel_style["colorbar_labelsize"]))
    colorbar.ax.tick_params(labelsize=float(panel_style["tick_labelsize"]), length=2.0)
    panel_data = {
        **plot_data,
        "support_options": pd.DataFrame(option_rows),
        "layout": panel_layout,
        "colors": panel_colors,
        "style": panel_style,
        "labels": panel_labels,
        "vmin": vmin,
        "vmax": vmax,
    }
    saved_paths = save_panel(fig, panel_name, formats=formats, output_dir=output_dir) if save else []
    return fig, axes, panel_data, saved_paths


__all__ = [
    "BEHAVIOR_ACCUMULATION_COLORS",
    "BEHAVIOR_ACCUMULATION_LABELS",
    "BEHAVIOR_ACCUMULATION_LAYOUT",
    "BEHAVIOR_ACCUMULATION_MONTH_COLORS",
    "BEHAVIOR_ACCUMULATION_STYLE",
    "CELLREG_RELIABILITY_COLORS",
    "CELLREG_RELIABILITY_LABELS",
    "CELLREG_RELIABILITY_LAYOUT",
    "CELLREG_RELIABILITY_STYLE",
    "DECODING_ERROR_HEATMAP_COLORS",
    "DECODING_ERROR_HEATMAP_CONTROL_BINS",
    "DECODING_ERROR_HEATMAP_EXCLUDED_UNREWARDED_0V3_SRCS",
    "DECODING_ERROR_HEATMAP_LABELS",
    "DECODING_ERROR_HEATMAP_LAYOUT",
    "DECODING_ERROR_HEATMAP_REWARD_BIN",
    "DECODING_ERROR_HEATMAP_STYLE",
    "DECODER_CONTROL_COLORS",
    "DECODER_CONTROL_LABELS",
    "DECODER_CONTROL_LAYOUT",
    "DECODER_CONTROL_METHOD_ORDER",
    "DECODER_CONTROL_SOURCE_ORDER",
    "DECODER_CONTROL_STYLE",
    "DEFAULT_SUPPLEMENT_PANEL_OUTPUT_DIR",
    "EQUAL_TIME_RATE_CONTROL_COLORS",
    "EQUAL_TIME_RATE_CONTROL_LABELS",
    "EQUAL_TIME_RATE_CONTROL_LAYOUT",
    "EQUAL_TIME_RATE_CONTROL_STYLE",
    "EQUAL_TIME_RATE_CONTROL_VARIANTS",
    "EXPLORATION_CYCLE_COLORS",
    "EXPLORATION_CYCLE_LABELS",
    "EXPLORATION_CYCLE_LAYOUT",
    "EXPLORATION_CYCLE_STYLE",
    "FOV_DISPLACEMENT_COLORS",
    "FOV_DISPLACEMENT_LABELS",
    "FOV_DISPLACEMENT_LAYOUT",
    "FOV_DISPLACEMENT_STYLE",
    "LATENT_RETURN_JUNCTION_COLORS",
    "LATENT_RETURN_JUNCTION_LABELS",
    "LATENT_RETURN_JUNCTION_LAYOUT",
    "LATENT_RETURN_JUNCTION_STYLE",
    "RAW_EXAMPLE_TRAJECTORY_SESSION_ROWS",
    "RAW_TRAJECTORY_COLORS",
    "RAW_TRAJECTORY_LANDMARKS",
    "RAW_TRAJECTORY_LAYOUT",
    "RAW_TRAJECTORY_STYLE",
    "REWARD_SEQUENCE_MEMORY_COLORS",
    "REWARD_SEQUENCE_MEMORY_CONDITION_ORDER",
    "REWARD_SEQUENCE_MEMORY_LABELS",
    "REWARD_SEQUENCE_MEMORY_LAYOUT",
    "REWARD_SEQUENCE_MEMORY_STYLE",
    "REWARD_PROXY_LOCATION_PAIR_COLORS",
    "REWARD_PROXY_LOCATION_PAIR_LABELS",
    "REWARD_PROXY_LOCATION_PAIR_LAYOUT",
    "REWARD_PROXY_LOCATION_PAIR_STYLE",
    "REWARD_PERFORMANCE_COLORS",
    "REWARD_PERFORMANCE_LABELS",
    "REWARD_PERFORMANCE_LAYOUT",
    "REWARD_PERFORMANCE_METRICS",
    "REWARD_PERFORMANCE_STYLE",
    "SPEED_MODE_COLORS",
    "SPEED_MODE_LABELS",
    "SPEED_MODE_LAYOUT",
    "SPEED_MODE_STYLE",
    "TURNING_BIAS_RETURN_SECOND_COLORS",
    "TURNING_BIAS_RETURN_SECOND_LABELS",
    "TURNING_BIAS_RETURN_SECOND_LAYOUT",
    "TURNING_BIAS_RETURN_SECOND_STYLE",
    "TURNING_BIAS_DEPTH_PBS_LABELS",
    "TURNING_BIAS_DEPTH_PBS_LAYOUT",
    "TURNING_BIAS_DEPTH_PBS_STYLE",
    "TURNING_BIAS_GRAPHITE_COLORS",
    "TURNING_BIAS_SELECTED_CHUNK_COLORS",
    "TURNING_BIAS_SELECTED_CHUNK_LABELS",
    "TURNING_BIAS_SELECTED_CHUNK_LAYOUT",
    "TURNING_BIAS_SELECTED_CHUNK_STYLE",
    "TURNING_BIAS_SELECTED_CHUNKS",
    "TURNING_BIAS_SIMULATOR_LABELS",
    "TURNING_BIAS_SIMULATOR_LAYOUT",
    "TURNING_BIAS_SIMULATOR_STYLE",
    "build_exploration_efficiency_cycle_summary",
    "draw_raw_trajectory_landmarks",
    "draw_cached_raw_trajectory_axes",
    "draw_raw_trajectory_axes",
    "collect_raw_trajectory_plot_data",
    "collect_whole_night_behavior_event_data",
    "export_exploration_efficiency_cycle_bundle",
    "extract_raw_nose_trajectory_segments",
    "export_whole_night_behavior_accumulation_bundle",
    "find_first_reward_reach",
    "build_whole_night_behavior_cumulative_curves",
    "build_whole_night_behavior_session_specs",
    "get_behavior_accumulation_colors",
    "get_behavior_accumulation_labels",
    "get_behavior_accumulation_layout",
    "get_behavior_accumulation_style",
    "get_cellreg_reliability_colors",
    "get_cellreg_reliability_labels",
    "get_cellreg_reliability_layout",
    "get_cellreg_reliability_style",
    "get_decoding_error_heatmap_colors",
    "get_decoding_error_heatmap_labels",
    "get_decoding_error_heatmap_layout",
    "get_decoding_error_heatmap_style",
    "get_decoder_control_colors",
    "get_decoder_control_labels",
    "get_decoder_control_layout",
    "get_decoder_control_style",
    "get_equal_time_rate_control_colors",
    "get_equal_time_rate_control_labels",
    "get_equal_time_rate_control_layout",
    "get_equal_time_rate_control_style",
    "get_exploration_cycle_colors",
    "get_exploration_cycle_labels",
    "get_exploration_cycle_layout",
    "get_exploration_cycle_style",
    "get_fov_displacement_colors",
    "get_fov_displacement_labels",
    "get_fov_displacement_layout",
    "get_fov_displacement_style",
    "get_raw_trajectory_colors",
    "get_raw_trajectory_landmarks",
    "get_raw_trajectory_layout",
    "get_raw_trajectory_style",
    "get_reward_sequence_memory_colors",
    "get_reward_sequence_memory_labels",
    "get_reward_sequence_memory_layout",
    "get_reward_sequence_memory_style",
    "get_reward_proxy_location_pair_colors",
    "get_reward_proxy_location_pair_labels",
    "get_reward_proxy_location_pair_layout",
    "get_reward_proxy_location_pair_style",
    "get_reward_performance_colors",
    "get_reward_performance_labels",
    "get_reward_performance_layout",
    "get_reward_performance_style",
    "get_speed_mode_colors",
    "get_speed_mode_labels",
    "get_speed_mode_layout",
    "get_speed_mode_style",
    "get_turning_bias_return_second_colors",
    "get_turning_bias_return_second_labels",
    "get_turning_bias_return_second_layout",
    "get_turning_bias_return_second_style",
    "get_turning_bias_depth_pbs_labels",
    "get_turning_bias_depth_pbs_layout",
    "get_turning_bias_depth_pbs_style",
    "get_turning_bias_graphite_colors",
    "get_turning_bias_selected_chunk_colors",
    "get_turning_bias_selected_chunk_labels",
    "get_turning_bias_selected_chunk_layout",
    "get_turning_bias_selected_chunk_style",
    "get_turning_bias_simulator_labels",
    "get_turning_bias_simulator_layout",
    "get_turning_bias_simulator_style",
    "prepare_bodymass_speed_mode_plot_data",
    "prepare_cellreg_reliability_plot_data",
    "prepare_decoder_control_plot_data",
    "prepare_decoding_error_heatmap_plot_data",
    "prepare_equal_time_rate_control_plot_data",
    "prepare_fov_displacement_plot_data",
    "prepare_reward_proxy_location_pair_panel_data",
    "prepare_reward_sequence_memory_plot_data",
    "render_cached_bodymass_speed_mode_panel",
    "render_cached_bodymass_speed_mode_scope_grid_panel",
    "render_cached_cellreg_reliability_panel",
    "render_cached_decoder_control_support_panel",
    "render_cached_decoding_error_average_map_panel",
    "render_cached_decoding_error_all_average_support_options_panel",
    "render_cached_decoding_error_heatmap_grid_panel",
    "render_cached_decoding_error_heatmap_packed_panel",
    "render_cached_depth_stratified_pbs_shift_panel",
    "render_cached_equal_time_rate_control_d1v1_absolute_panel",
    "render_cached_equal_time_rate_control_delta_panel",
    "render_cached_exploration_efficiency_cycle_panel",
    "render_cached_fov_displacement_panel",
    "render_cached_latent_return_junction_timing_panel",
    "render_cached_reward_sequence_memory_panel",
    "render_cached_reward_proxy_location_pair_panel",
    "render_cached_turning_bias_gap_explained_panel",
    "render_turning_bias_return_second_panel",
    "render_turning_bias_selected_chunk_scatter_panel",
    "render_reward_performance_metric_grid",
    "render_cached_whole_night_behavior_accumulation_panel",
    "render_cached_raw_trajectory_grid_panel",
    "render_raw_trajectory_grid_panel",
]
