from __future__ import annotations

import copy
import itertools
import math

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats as scipy_stats

from .maze import NewMaze

NUM_TILES = 176

def _safe_corr(a, b):
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    ok = np.isfinite(a) & np.isfinite(b)
    if np.sum(ok) < 4:
        return np.nan
    return float(np.corrcoef(a[ok], b[ok])[0, 1])


def _pair_bins_within_level(bin_idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    b = np.asarray(bin_idx, dtype=int).ravel()
    if b.size < 2:
        return np.zeros(0, dtype=int), np.zeros(0, dtype=int)
    n = b.size // 2
    if n == 0:
        return np.zeros(0, dtype=int), np.zeros(0, dtype=int)
    left = b[:n]
    right = b[-n:][::-1]
    return left, right


def compute_levelwise_symmetry_scores(
    place_maps,
    bin_levels,
    *,
    deepest_perm_level: int | None = None,
) -> np.ndarray:
    """
    Compute neuron x level symmetry scores by correlating mirrored bins within each level.
    """
    M = np.asarray(place_maps, dtype=float)
    if M.ndim == 1:
        M = M[None, :]
    lv = np.asarray(bin_levels, dtype=int).ravel()
    if M.shape[1] != lv.size:
        raise ValueError("place_maps width must match len(bin_levels)")
    max_level = int(np.nanmax(lv)) if lv.size else 0
    L = int(deepest_perm_level) if deepest_perm_level is not None else max_level
    L = max(1, min(L, max_level))
    out = np.full((M.shape[0], L), np.nan, dtype=float)
    for l in range(1, L + 1):
        idx = np.where(lv == l)[0]
        if idx.size < 2:
            continue
        a_idx, b_idx = _pair_bins_within_level(idx)
        if a_idx.size == 0:
            continue
        for n in range(M.shape[0]):
            out[n, l - 1] = _safe_corr(M[n, a_idx], M[n, b_idx])
    return out


def compute_control_null(
    place_maps,
    bin_levels,
    *,
    deepest_perm_level: int | None = None,
    n_perm: int = 500,
    seed: int = 0,
) -> np.ndarray:
    M = np.asarray(place_maps, dtype=float)
    if M.ndim == 1:
        M = M[None, :]
    lv = np.asarray(bin_levels, dtype=int).ravel()
    base = compute_levelwise_symmetry_scores(M, lv, deepest_perm_level=deepest_perm_level)
    L = base.shape[1]
    rng = np.random.default_rng(int(seed))
    null = np.full((int(n_perm), L), np.nan, dtype=float)
    for i in range(int(n_perm)):
        idx = np.arange(M.shape[1], dtype=int)
        for l in range(1, L + 1):
            lidx = np.where(lv == l)[0]
            if lidx.size > 1:
                idx[lidx] = rng.permutation(lidx)
        Mp = M[:, idx]
        s = compute_levelwise_symmetry_scores(Mp, lv, deepest_perm_level=L)
        null[i, :] = np.nanmean(s, axis=0)
    return null


def compare_early_late_symmetry(scores_early, scores_late) -> dict[str, float]:
    A = np.asarray(scores_early, dtype=float)
    B = np.asarray(scores_late, dtype=float)
    if A.ndim == 1:
        A = A[None, :]
    if B.ndim == 1:
        B = B[None, :]
    ma = np.nanmean(A, axis=0)
    mb = np.nanmean(B, axis=0)
    return {
        "mean_corr": _safe_corr(ma, mb),
        "mean_delta": float(np.nanmean(mb - ma)),
        "median_delta": float(np.nanmedian(mb - ma)),
    }


def plot_symmetry_panels(scores, *, null_scores=None, title: str = "Permutation symmetry"):
    S = np.asarray(scores, dtype=float)
    if S.ndim == 1:
        S = S[None, :]
    L = S.shape[1]
    x = np.arange(1, L + 1)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].plot(x, np.nanmean(S, axis=0), marker="o")
    axes[0].set_xlabel("Level")
    axes[0].set_ylabel("Symmetry score")
    axes[0].set_title("Data mean by level")
    if null_scores is not None:
        N = np.asarray(null_scores, dtype=float)
        axes[1].hist(np.nanmean(N, axis=1), bins=30, alpha=0.6, label="null")
        axes[1].axvline(float(np.nanmean(S)), color="r", linestyle="--", label="observed")
        axes[1].set_xlabel("Mean symmetry")
        axes[1].set_ylabel("Count")
        axes[1].legend()
        axes[1].set_title("Control null")
    else:
        axes[1].axis("off")
    fig.suptitle(title)
    fig.tight_layout()
    return fig, axes


def _tree_level(node):
    return int(np.floor(np.log2(node + 1)) + 1)


def _subtree_nodes(maze, root_node, deepest_level):
    ret = [int(root_node)]
    if _tree_level(int(maze.ch[root_node][0])) <= deepest_level:
        ret += _subtree_nodes(maze, int(maze.ch[root_node][0]), deepest_level)
        ret += _subtree_nodes(maze, int(maze.ch[root_node][1]), deepest_level)
    return ret


def _subtree_tiles(maze, root_node):
    ret = copy.deepcopy(maze.ru[int(root_node)])
    if int(maze.ch[root_node][0]) != -1 and int(maze.ch[root_node][1]) != -1:
        ret += _subtree_tiles(maze, int(maze.ch[root_node][0]))
        ret += _subtree_tiles(maze, int(maze.ch[root_node][1]))
    return ret


def _permutation_for_code(maze, binary_code):
    perm = np.arange(len(maze.ce))
    for node in range(len(binary_code) - 1, -1, -1):
        if binary_code[node]:
            left_tiles = _subtree_tiles(maze, int(maze.ch[node][0]))
            right_tiles = _subtree_tiles(maze, int(maze.ch[node][1]))
            perm[left_tiles], perm[right_tiles] = perm[right_tiles], perm[left_tiles]
    return perm


def _two_subtree_masks(maze, node):
    left_tree_mask = np.zeros((len(maze.ce),), dtype=bool)
    right_tree_mask = np.zeros((len(maze.ce),), dtype=bool)
    left_child, right_child = int(maze.ch[node][0]), int(maze.ch[node][1])
    left_tree_tiles = _subtree_tiles(maze, left_child)
    right_tree_tiles = _subtree_tiles(maze, right_child)
    left_tree_mask[np.asarray(left_tree_tiles)] = True
    right_tree_mask[np.asarray(right_tree_tiles)] = True
    return left_tree_mask, right_tree_mask


class _LeftSubtreeBinaryCode:
    def __init__(self, maze, root_node, deepest_level):
        self.code_length = 2**deepest_level - 1
        self.root_node_level = _tree_level(root_node)
        self.num_bits = 2 ** (deepest_level - self.root_node_level) - 1
        if self.num_bits == 0:
            self.left_subtree_nodes = []
        else:
            self.left_subtree_nodes = np.asarray(_subtree_nodes(maze, int(maze.ch[root_node][0]), deepest_level))

    def __iter__(self):
        if self.num_bits == 0:
            code = np.zeros(self.code_length, dtype=bool)
            yield code
            return
        for bits in itertools.product([0, 1], repeat=self.num_bits):
            code = np.zeros(self.code_length, dtype=bool)
            code[self.left_subtree_nodes] = bits
            yield code


def compute_symmetry_scores_permutation(rf, deepest_perm_level: int, *, atol: float = 1e-3, maze=None):
    rf = np.asarray(rf, dtype=float)
    if rf.ndim != 2:
        raise ValueError("rf must be 2D (tiles x neurons)")
    if rf.shape[0] != NUM_TILES:
        raise ValueError("rf axis 0 must be 176 tiles")
    if not np.all(rf >= 0):
        raise ValueError("rf must be non-negative")
    if maze is None:
        maze = NewMaze()
    x = rf.copy()
    den = x.sum(axis=0, keepdims=True)
    den[den == 0] = 1.0
    x = x / den
    num_neurons = x.shape[1]
    symmetry_scores = np.zeros((num_neurons, 2**deepest_perm_level - 1, 2), dtype=float)
    for node in range(2**deepest_perm_level - 1):
        all_codes = _LeftSubtreeBinaryCode(maze, node, deepest_perm_level)
        left_mask, right_mask = _two_subtree_masks(maze, node)
        symmetry_scores[:, node, 1] = x[left_mask, :].sum(axis=0) + x[right_mask, :].sum(axis=0)
        for code in all_codes:
            perm = _permutation_for_code(maze, code)
            lvecs, rvecs = x[perm, :][left_mask, :], x[right_mask, :]
            lnrm, rnrm = np.linalg.norm(lvecs, axis=0), np.linalg.norm(rvecs, axis=0)
            with np.errstate(divide="ignore", invalid="ignore"):
                cos_sim = (lvecs * rvecs).sum(axis=0) / (lnrm * rnrm)
            cos_sim[(lnrm == 0) | (rnrm == 0)] = 0
            with np.errstate(divide="ignore", invalid="ignore"):
                nrm_sim = 1 - np.abs(lnrm - rnrm) / np.maximum(lnrm, rnrm)
            nrm_sim[np.maximum(lnrm, rnrm) == 0] = 0
            symmetry_scores[:, node, 0] = np.maximum(cos_sim * nrm_sim, symmetry_scores[:, node, 0])
    symmetry_scores = np.clip(symmetry_scores, 0, 1 + atol)
    return np.clip(symmetry_scores, 0, 1)


def compute_levelwise_symmetry_scores_permutation(symmetry_scores, num_neurons: int, deepest_perm_level: int, *, atol: float = 1e-3):
    S = np.asarray(symmetry_scores, dtype=float)
    if S.shape != (int(num_neurons), 2**deepest_perm_level - 1, 2):
        raise ValueError("unexpected symmetry_scores shape")
    out = np.zeros((int(num_neurons), int(deepest_perm_level)), dtype=float)
    total_weights = S[:, 0, 1]
    for i in range(int(deepest_perm_level)):
        vals = S[:, 2**i - 1 : 2 ** (i + 1) - 1, 0]
        weights = S[:, 2**i - 1 : 2 ** (i + 1) - 1, 1]
        with np.errstate(divide="ignore", invalid="ignore"):
            out[:, i] = (vals * weights).sum(axis=1) / total_weights
        out[total_weights < atol, i] = 0.0
    return np.clip(out, 0, 1)


# ---------------------------------------------------------------------------
# Tile-mapping and windowed symmetry helpers
# ---------------------------------------------------------------------------


def assign_tile_ids(positions_bx, positions_by, maze):
    """Map grid-binned positions (mass_bx, mass_by) to tile IDs via maze.ce.

    Uses the same (by, bx) key convention as ``assign_levels`` in spatial.py.
    Returns (T,) int array; -1 for positions that don't map to a valid tile.
    """
    bx = np.asarray(positions_bx, dtype=int).ravel()
    by = np.asarray(positions_by, dtype=int).ravel()
    tile_ids = np.array(
        [maze.ce.get((int(byy), int(bxx)), -1) for byy, bxx in zip(by, bx)],
        dtype=int,
    )
    return tile_ids


def compute_tile_rate_maps(tile_ids, spike_counts, n_tiles=NUM_TILES, min_occ_frames=1):
    """Compute (n_tiles, N) rate maps from tile assignments and spike counts.

    Parameters
    ----------
    tile_ids : (T,) int array — tile id per time bin (-1 = invalid)
    spike_counts : (T, N) float array — spike counts per neuron
    n_tiles : int — number of tiles (default 176)
    min_occ_frames : int — minimum occupancy to keep a tile (default 1)

    Returns
    -------
    rate_map : (n_tiles, N) float array
    """
    tile_ids = np.asarray(tile_ids, dtype=int).ravel()
    S = np.asarray(spike_counts, dtype=float)
    if S.ndim == 1:
        S = S[:, None]
    T, N = S.shape
    if tile_ids.shape[0] != T:
        raise ValueError("tile_ids length must match spike_counts rows")

    occ = np.zeros(n_tiles, dtype=float)
    acc = np.zeros((n_tiles, N), dtype=float)
    valid = (tile_ids >= 0) & (tile_ids < n_tiles)
    np.add.at(occ, tile_ids[valid], 1.0)
    np.add.at(acc, (tile_ids[valid],), S[valid])

    with np.errstate(divide="ignore", invalid="ignore"):
        rate_map = acc / occ[:, None]
    rate_map[occ < min_occ_frames] = 0.0
    rate_map = np.nan_to_num(rate_map, nan=0.0)
    return rate_map


def pivot_window_symmetry(
    spike_counts,
    tile_ids,
    maze_time,
    maze,
    *,
    win_len_sec=600,
    pivot_step_sec=120,
    deepest_perm_level=4,
    min_occ_frames=5,
    tile_mask=None,
):
    """Sliding-window symmetry time-course within a session.

    Uses the same center-based window generation as
    ``pivot_window_spatial_information_fast`` in similarity.py.

    Parameters
    ----------
    spike_counts : (T, N) float array
    tile_ids : (T,) int array from ``assign_tile_ids``
    maze_time : (T,) float array — time in seconds for each row
    maze : Maze dataclass from ``NewMaze()``
    win_len_sec : float — window length in seconds (default 600 = 10 min)
    pivot_step_sec : float — stride between window centers (default 120 = 2 min)
    deepest_perm_level : int — deepest tree level for permutation (default 4)
    min_occ_frames : int — minimum occupancy per tile within window (default 5)
    tile_mask : (n_tiles,) bool array or None — when provided, zero out excluded
        tiles in each window's rate map before computing symmetry scores

    Returns
    -------
    dict with keys:
        pivot_times : (W,) float — window center times in seconds
        pivot_bounds : list of (start, end) index pairs
        level_scores : (W, N, L) float — per-window, per-neuron, per-level symmetry
        mean_level_scores : (W, L) float — neuron-averaged symmetry
        meta : dict with parameters
    """
    S = np.asarray(spike_counts, dtype=float)
    if S.ndim == 1:
        S = S[:, None]
    N = S.shape[1]
    tile_ids = np.asarray(tile_ids, dtype=int).ravel()
    t = np.asarray(maze_time, dtype=float).ravel()
    L = int(deepest_perm_level)

    if tile_mask is not None:
        tile_mask = np.asarray(tile_mask, dtype=bool).ravel()

    # Generate window centers (same pattern as similarity.py:2977)
    half = float(win_len_sec) / 2.0
    centers = []
    cur = float(t[0]) + half
    while cur + half <= float(t[-1]):
        centers.append(cur)
        cur += float(pivot_step_sec)

    if len(centers) == 0:
        return dict(
            pivot_times=np.array([], dtype=float),
            pivot_bounds=[],
            level_scores=np.zeros((0, N, L), dtype=float),
            mean_level_scores=np.zeros((0, L), dtype=float),
            meta=dict(
                win_len_sec=win_len_sec,
                pivot_step_sec=pivot_step_sec,
                deepest_perm_level=deepest_perm_level,
                min_occ_frames=min_occ_frames,
                n_windows=0,
            ),
        )

    bounds = []
    for c in centers:
        m = (t >= (c - half)) & (t < (c + half))
        idx = np.where(m)[0]
        if idx.size == 0:
            bounds.append((0, 0))
        else:
            bounds.append((int(idx[0]), int(idx[-1]) + 1))

    level_scores = np.full((len(centers), N, L), np.nan, dtype=float)
    for wi, (s, e) in enumerate(bounds):
        if e <= s:
            continue
        rm = compute_tile_rate_maps(
            tile_ids[s:e], S[s:e], n_tiles=NUM_TILES, min_occ_frames=min_occ_frames
        )
        if tile_mask is not None:
            rm[~tile_mask] = 0.0
        sym = compute_symmetry_scores_permutation(rm, deepest_perm_level, maze=maze)
        lev = compute_levelwise_symmetry_scores_permutation(sym, N, deepest_perm_level)
        level_scores[wi] = lev

    mean_level_scores = np.nanmean(level_scores, axis=1)

    return dict(
        pivot_times=np.asarray(centers, dtype=float),
        pivot_bounds=bounds,
        level_scores=level_scores,
        mean_level_scores=mean_level_scores,
        meta=dict(
            win_len_sec=win_len_sec,
            pivot_step_sec=pivot_step_sec,
            deepest_perm_level=deepest_perm_level,
            min_occ_frames=min_occ_frames,
            n_windows=len(centers),
        ),
    )


# ---------------------------------------------------------------------------
# Multi-session trend / inference helpers
# ---------------------------------------------------------------------------


def compute_symmetry_trend(mean_level_scores, pivot_times):
    """Fit linear trend per level and return summary DataFrame.

    Parameters
    ----------
    mean_level_scores : (W, L) float — neuron-averaged symmetry per window
    pivot_times : (W,) float — window center times (any unit)

    Returns
    -------
    pd.DataFrame with columns: level, slope, intercept, r_pearson, p_pearson,
        rho_spearman, p_spearman
    """
    ms = np.asarray(mean_level_scores, dtype=float)
    t = np.asarray(pivot_times, dtype=float).ravel()
    if ms.ndim == 1:
        ms = ms[:, None]
    L = ms.shape[1]
    rows = []
    for lev in range(L):
        y = ms[:, lev]
        finite = np.isfinite(y) & np.isfinite(t)
        if np.sum(finite) < 3:
            rows.append(dict(
                level=lev + 1, slope=np.nan, intercept=np.nan,
                r_pearson=np.nan, p_pearson=np.nan,
                rho_spearman=np.nan, p_spearman=np.nan,
            ))
            continue
        slope, intercept, r, p, _ = scipy_stats.linregress(t[finite], y[finite])
        rho, p_sp = scipy_stats.spearmanr(t[finite], y[finite])
        rows.append(dict(
            level=lev + 1, slope=float(slope), intercept=float(intercept),
            r_pearson=float(r), p_pearson=float(p),
            rho_spearman=float(rho), p_spearman=float(p_sp),
        ))
    return pd.DataFrame(rows)


def compute_early_late_delta_per_level(level_scores):
    """Early-late delta per level from non-overlapping window scores.

    Averaging order: mean over neurons first (per window per level), then
    split into early/late halves by window, then delta = mean(late) - mean(early).

    Parameters
    ----------
    level_scores : (W, N, L) float — per-window, per-neuron, per-level symmetry.
        L is inferred from shape.

    Returns
    -------
    (L,) float array — early-late delta per level. Negative = symmetry declined.
    """
    ls = np.asarray(level_scores, dtype=float)
    if ls.ndim == 2:
        ls = ls[:, None, :]
    W = ls.shape[0]
    if W < 2:
        return np.full(ls.shape[2], np.nan, dtype=float)
    mean_per_window = np.nanmean(ls, axis=1)  # (W, L)
    mid = W // 2
    early = np.nanmean(mean_per_window[:mid], axis=0)
    late = np.nanmean(mean_per_window[mid:], axis=0)
    return late - early


def window_permutation_trend_null(mean_level_scores, pivot_times, *, n_perm=2000, seed=42):
    """Window-permutation null for temporal trend on non-overlapping windows.

    Under H₀ (no temporal trend), the order of window scores is exchangeable.
    When W ≤ 8 (W! ≤ 40320), all permutations are enumerated exactly.
    Otherwise, ``n_perm`` random permutations are sampled.

    Parameters
    ----------
    mean_level_scores : (W, L) float — neuron-averaged symmetry per window
    pivot_times : (W,) float — window center times
    n_perm : int — number of random permutations when W > 8 (default 2000)
    seed : int — random seed for Monte Carlo sampling

    Returns
    -------
    dict with keys:
        observed_slopes : (L,) float
        null_slopes : (n_actual, L) float
        p_values : (L,) float — one-tailed: fraction of null slopes ≤ observed
        exact : bool — True if exact enumeration was used
    """
    ms = np.asarray(mean_level_scores, dtype=float)
    t = np.asarray(pivot_times, dtype=float).ravel()
    if ms.ndim == 1:
        ms = ms[:, None]
    W, L = ms.shape

    # Observed slopes
    obs_slopes = np.full(L, np.nan, dtype=float)
    for lev in range(L):
        y = ms[:, lev]
        finite = np.isfinite(y) & np.isfinite(t)
        if np.sum(finite) >= 3:
            obs_slopes[lev] = scipy_stats.linregress(t[finite], y[finite]).slope

    use_exact = W <= 8
    if use_exact:
        perms = list(itertools.permutations(range(W)))
        n_actual = len(perms)
    else:
        n_actual = int(n_perm)
        rng = np.random.default_rng(int(seed))

    null_slopes = np.full((n_actual, L), np.nan, dtype=float)
    for pi in range(n_actual):
        if use_exact:
            order = list(perms[pi])
        else:
            order = rng.permutation(W)
        ms_perm = ms[order]
        for lev in range(L):
            y = ms_perm[:, lev]
            finite = np.isfinite(y) & np.isfinite(t)
            if np.sum(finite) >= 3:
                null_slopes[pi, lev] = scipy_stats.linregress(t[finite], y[finite]).slope

    # One-tailed p-values: fraction of null slopes ≤ observed (plus-one for MC)
    p_values = np.full(L, np.nan, dtype=float)
    for lev in range(L):
        ns = null_slopes[:, lev]
        ns_finite = ns[np.isfinite(ns)]
        if ns_finite.size == 0 or not np.isfinite(obs_slopes[lev]):
            continue
        count = np.sum(ns_finite <= obs_slopes[lev])
        if use_exact:
            p_values[lev] = float(count) / float(ns_finite.size)
        else:
            p_values[lev] = float(count + 1) / float(ns_finite.size + 1)

    return dict(
        observed_slopes=obs_slopes,
        null_slopes=null_slopes,
        p_values=p_values,
        exact=use_exact,
    )


def compute_window_coverage_diagnostics(tile_ids, pivot_bounds, *, n_tiles=NUM_TILES, min_occ_frames=5):
    """Per-window tile coverage diagnostics for occupancy confound screening.

    Parameters
    ----------
    tile_ids : (T,) int array — full-session tile IDs
    pivot_bounds : list of (start, end) index pairs from ``pivot_window_symmetry``
    n_tiles : int — total number of tiles (default 176)
    min_occ_frames : int — occupancy threshold matching ``compute_tile_rate_maps``

    Returns
    -------
    dict with keys:
        tiles_above_threshold_per_window : (W,) int — tiles with occ ≥ min_occ_frames
        tile_stability_mask : (n_tiles,) bool — True for tiles meeting threshold
            in ≥ 80% of windows
        n_stable_tiles : int
        occupancy_per_window : (W, n_tiles) float — raw occupancy matrix
    """
    tile_ids = np.asarray(tile_ids, dtype=int).ravel()
    W = len(pivot_bounds)
    occ_matrix = np.zeros((W, n_tiles), dtype=float)

    for wi, (s, e) in enumerate(pivot_bounds):
        if e <= s:
            continue
        ids_win = tile_ids[s:e]
        valid = (ids_win >= 0) & (ids_win < n_tiles)
        np.add.at(occ_matrix[wi], ids_win[valid], 1.0)

    above_thresh = (occ_matrix >= min_occ_frames).astype(int)
    tiles_above = above_thresh.sum(axis=1)

    # Stability: tile meets threshold in ≥ 80% of windows
    if W > 0:
        frac_above = above_thresh.sum(axis=0) / W
        stability_mask = frac_above >= 0.8
    else:
        stability_mask = np.zeros(n_tiles, dtype=bool)

    return dict(
        tiles_above_threshold_per_window=tiles_above,
        tile_stability_mask=stability_mask,
        n_stable_tiles=int(stability_mask.sum()),
        occupancy_per_window=occ_matrix,
    )


def compute_session_wide_tile_mask(tile_ids, n_windows, *, n_tiles=NUM_TILES, min_occ_frames=5):
    """Session-wide occupancy mask: tile kept if total occupancy >= min_occ_frames * n_windows.

    Unlike the 80%-of-windows stability mask, this does not penalize tiles whose
    visits are concentrated in part of the session (e.g., tiles discovered during
    learning).  A tile qualifies as long as its *total* session occupancy is high
    enough to support one rate-map estimate per window on average.

    Parameters
    ----------
    tile_ids : (T,) int array — tile id per frame (-1 = invalid)
    n_windows : int — number of non-overlapping windows in the analysis
    n_tiles : int — total tile count (default 176)
    min_occ_frames : int — per-window occupancy threshold (default 5)

    Returns
    -------
    mask : (n_tiles,) bool — True for tiles meeting session-wide threshold
    """
    tile_ids = np.asarray(tile_ids, dtype=int).ravel()
    occ = np.zeros(n_tiles, dtype=float)
    valid = (tile_ids >= 0) & (tile_ids < n_tiles)
    np.add.at(occ, tile_ids[valid], 1.0)
    threshold = float(min_occ_frames) * float(n_windows)
    return occ >= threshold


def clustered_sign_permutation_test(differences, cluster_ids, *, seed=42):
    """Clustered sign-flip permutation test for paired differences.

    Each observation is a paired difference (e.g., naive_delta - recall_delta).
    Observations are clustered by ``cluster_ids`` (e.g., animal). Under H₀,
    the sign of all differences within a cluster can be flipped together.

    With K clusters, there are 2^K sign-flip configurations. When K ≤ 15
    (2^K ≤ 32768), all configurations are enumerated exactly. Otherwise,
    Monte Carlo sampling is used.

    Parameters
    ----------
    differences : (N,) float — paired differences (one per observation)
    cluster_ids : (N,) — cluster label per observation (e.g., animal ID)
    seed : int — random seed for Monte Carlo sampling

    Returns
    -------
    dict with keys:
        observed_mean : float — mean of differences
        p_value : float — two-tailed p-value
        null_means : (n_perm,) float — null distribution of mean differences
        n_perm : int — number of permutations used
        exact : bool — True if exact enumeration was used
    """
    diffs = np.asarray(differences, dtype=float).ravel()
    cids = np.asarray(cluster_ids).ravel()
    if diffs.size != cids.size:
        raise ValueError("differences and cluster_ids must have same length")

    # Group indices by cluster
    unique_clusters = np.unique(cids)
    K = len(unique_clusters)
    cluster_indices = [np.where(cids == c)[0] for c in unique_clusters]

    obs_mean = float(np.nanmean(diffs))

    use_exact = K <= 15
    if use_exact:
        n_perm = 2 ** K
        null_means = np.empty(n_perm, dtype=float)
        for config in range(n_perm):
            flipped = diffs.copy()
            for ki in range(K):
                if (config >> ki) & 1:
                    flipped[cluster_indices[ki]] *= -1
            null_means[config] = np.nanmean(flipped)
        p_value = float(np.mean(np.abs(null_means) >= abs(obs_mean)))
    else:
        n_perm = 2000
        rng = np.random.default_rng(int(seed))
        null_means = np.empty(n_perm, dtype=float)
        for pi in range(n_perm):
            flipped = diffs.copy()
            signs = rng.choice([-1, 1], size=K)
            for ki in range(K):
                flipped[cluster_indices[ki]] *= signs[ki]
            null_means[pi] = np.nanmean(flipped)
        count = np.sum(np.abs(null_means) >= abs(obs_mean))
        p_value = float(count + 1) / float(n_perm + 1)

    return dict(
        observed_mean=obs_mean,
        p_value=p_value,
        null_means=null_means,
        n_perm=n_perm,
        exact=use_exact,
    )


# Backward-compat aliases retained for notebooks/scripts that still call legacy names.
compute_symmetry_scores_legacy = compute_symmetry_scores_permutation
compute_levelwise_symmetry_scores_legacy = compute_levelwise_symmetry_scores_permutation
