"""Data-backed pipeline for the longitudinal neural robustness controls.

This module deliberately writes an append-only review bundle and never edits
the maintained figure or manuscript authorities.  The CLI wrapper in
``scripts/run_longitudinal_neural_controls.py`` exposes independent stages so
that raw-data caching can be resumed without repeating completed sessions.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import re
import time
from typing import Any, Iterable, Mapping, Sequence

import h5py
import numpy as np
import pandas as pd
import scipy.io
from scipy import stats

from .longitudinal_controls import (
    DEFAULT_BLOCK_SAMPLES,
    DT,
    N_SPATIAL_BINS,
    REPRESENTATION_MIN_LABELS,
    SessionSufficientStats,
    aggregate_location_sums,
    animal_bootstrap_contrasts,
    benjamini_hochberg,
    columnwise_correlations,
    common_permitted_locations,
    cr1_ols,
    fit_representation_map,
    fit_representation_from_location_sums,
    linear_contrast,
    load_session_stats,
    location_labels_from_selected_df,
    rate_vector,
    representation_location_maps,
    rowwise_correlations,
    safe_pearson,
    save_session_stats,
    sha256_file,
    spearman_brown,
    split_location_episodes,
    split_retained_blocks,
    stable_seed,
    stacked_recurrence_contrasts,
    stacked_recurrence_design,
)


REPO = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT = REPO / "docs" / "longitudinal_neural_controls_2026-08-17"
PAIR_MANIFEST = (
    REPO
    / "docs"
    / "extended_data_figure_panel_refresh_2026-07-12"
    / "source_tables"
    / "corrected_long_gap_metrics"
    / "sorted_unified_pair_manifest_corrected_842.csv"
)
CHAIN_SCOPE = (
    REPO
    / "docs"
    / "sorted_data_full_figure_rerun_2026-06-11"
    / "figure2_consecutive_gap_clean_long_gap_corrected_2026-08-03"
    / "consecutive_gap_clean_long_gap_22_chain_scope.csv"
)
CURRENT_PAIR_ROOT = (
    REPO
    / "docs"
    / "sorted_data_full_figure_rerun_2026-06-11"
    / "figure2_distribution_shuffle_corrected_842_no_presort_exclusions_2026-08-03"
)
CURRENT_CHAIN_ROOT = CHAIN_SCOPE.parent
CURRENT_MAIN3_ROOT = (
    REPO
    / "docs"
    / "sorted_data_full_figure_rerun_2026-06-11"
    / "main3_long_gap_bh4_correlations_2026-08-14"
)
REGISTRATION_ROOT = (
    REPO
    / "docs"
    / "main_figs_v3_source_render_2026-06-24"
    / "registration_quality_exact_36_2026-07-09"
)
REGISTRATION_EXTRA_ROOT = (
    REPO
    / "docs"
    / "main_figs_v3_source_render_2026-06-24"
    / "registration_quality_additional_evidence_2026-07-10"
)
SHORT_PAIR_ID = "1616day1__1616bday1"
REPRESENTATIONS = (
    "place15x15",
    "tree_depth7",
    "geometric8",
    "horizontal8",
    "vertical8",
)
CONTROL3_COMPARISONS = {
    "level_minus_place": ("tree_depth7", "place15x15"),
    "level_minus_geometric8": ("tree_depth7", "geometric8"),
    "level_minus_horizontal8": ("tree_depth7", "horizontal8"),
    "level_minus_vertical8": ("tree_depth7", "vertical8"),
}


def _write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")


def _write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _parse_session(session_id: str) -> tuple[str, int, int]:
    match = re.match(r"^([0-9]+[a-z]?)(?:-?(\d*))?(?:[RL]+)?(?:day)?(\d+)?$", str(session_id))
    if not match:
        raise ValueError(f"Could not parse session ID: {session_id}")
    animal = match.group(1)
    exposure = int(match.group(2)) if match.group(2) else 0
    day = int(match.group(3)) if match.group(3) else 1
    return animal, exposure, day


def _mat_path(session_id: str, neural_root: Path) -> Path:
    animal, exposure, day = _parse_session(session_id)
    folder = animal if exposure == 0 else f"{animal}-{exposure}"
    return Path(neural_root) / folder / f"final_day{day}.mat"


def _read_h5_rows(dataset: h5py.Dataset, frames: np.ndarray) -> np.ndarray:
    frames = np.asarray(frames, dtype=int)
    if frames.size == 0:
        return np.zeros((0, int(dataset.shape[1])), dtype=np.float32)
    if np.any(np.diff(frames) <= 0):
        raise ValueError("Selected acquisition frames must be strictly increasing")
    return np.asarray(dataset[frames, :], dtype=np.float32)


def _append_episode_groups(
    *,
    frames: np.ndarray,
    locations: np.ndarray,
    counts: np.ndarray,
    episode_locations: list[int],
    episode_starts: list[int],
    episode_ends: list[int],
    episode_n: list[int],
    episode_sums: list[np.ndarray],
) -> None:
    spatial = np.flatnonzero(locations >= 0)
    if spatial.size == 0:
        return
    break_before = np.ones(spatial.size, dtype=bool)
    if spatial.size > 1:
        prev = spatial[:-1]
        curr = spatial[1:]
        break_before[1:] = (
            (curr != prev + 1)
            | (frames[curr] != frames[prev] + 1)
            | (locations[curr] != locations[prev])
        )
    group_starts = np.flatnonzero(break_before)
    group_ends = np.r_[group_starts[1:], spatial.size]
    for group_start, group_end in zip(group_starts, group_ends, strict=True):
        row_ids = spatial[group_start:group_end]
        start_frame = int(frames[row_ids[0]])
        end_frame = int(frames[row_ids[-1]])
        location = int(locations[row_ids[0]])
        group_sum = counts[row_ids].sum(axis=0, dtype=np.float64)
        n_rows = int(row_ids.size)
        if (
            episode_locations
            and episode_locations[-1] == location
            and start_frame == episode_ends[-1] + 1
        ):
            episode_ends[-1] = end_frame
            episode_n[-1] += n_rows
            episode_sums[-1] += group_sum
        else:
            episode_locations.append(location)
            episode_starts.append(start_frame)
            episode_ends.append(end_frame)
            episode_n.append(n_rows)
            episode_sums.append(group_sum)


def stream_session_sufficient_stats(
    session_id: str,
    *,
    selected_root: Path,
    neural_root: Path,
    chunk_rows: int = 10_000,
) -> tuple[SessionSufficientStats, dict[str, Any]]:
    """Stream selected C/S rows once and accumulate episode/block statistics."""

    selected_path = Path(selected_root) / f"{session_id}_selected_data.csv"
    mat_path = _mat_path(session_id, Path(neural_root))
    if not selected_path.exists() or not mat_path.exists():
        raise FileNotFoundError(f"Missing input for {session_id}: {selected_path} / {mat_path}")
    selected = pd.read_csv(selected_path)
    frames_all = pd.to_numeric(selected["frame"], errors="raise").to_numpy(dtype=int)
    if np.any(np.diff(frames_all) <= 0):
        raise ValueError(f"Non-increasing or duplicate selected frames in {session_id}")
    locations_all = location_labels_from_selected_df(selected)
    episode_locations: list[int] = []
    episode_starts: list[int] = []
    episode_ends: list[int] = []
    episode_n: list[int] = []
    episode_sums: list[np.ndarray] = []
    block_n: list[int] = []
    block_sums: list[np.ndarray] = []
    full_count: np.ndarray | None = None
    full_event: np.ndarray | None = None
    retained_count = 0
    dropped_nan = 0
    prior_frame: int | None = None
    prior_location = -1
    started = time.time()
    with h5py.File(mat_path, "r") as handle:
        if "C" not in handle or "S" not in handle:
            raise KeyError(f"Expected C and S arrays in {mat_path}")
        if handle["C"].shape != handle["S"].shape:
            raise ValueError(f"C/S shape mismatch in {mat_path}")
        n_neurons = int(handle["C"].shape[1])
        full_count = np.zeros(n_neurons, dtype=np.float64)
        full_event = np.zeros(n_neurons, dtype=np.float64)
        for start in range(0, frames_all.size, int(chunk_rows)):
            stop = min(frames_all.size, start + int(chunk_rows))
            frames = frames_all[start:stop]
            locations = locations_all[start:stop]
            counts = _read_h5_rows(handle["C"], frames)
            events = _read_h5_rows(handle["S"], frames)
            finite = np.isfinite(counts).all(axis=1) & np.isfinite(events).all(axis=1)
            dropped_nan += int((~finite).sum())
            frames = frames[finite]
            locations = locations[finite]
            counts = counts[finite]
            events = events[finite]
            if frames.size == 0:
                prior_frame = None
                prior_location = -1
                continue
            full_count += counts.sum(axis=0, dtype=np.float64)
            full_event += events.sum(axis=0, dtype=np.float64)

            global_block = (retained_count + np.arange(frames.size, dtype=int)) // DEFAULT_BLOCK_SAMPLES
            needed_blocks = int(global_block.max()) + 1
            while len(block_n) < needed_blocks:
                block_n.append(0)
                block_sums.append(np.zeros(n_neurons, dtype=np.float64))
            for block_id in np.unique(global_block):
                use = global_block == block_id
                block_n[int(block_id)] += int(use.sum())
                block_sums[int(block_id)] += counts[use].sum(axis=0, dtype=np.float64)

            if prior_frame is not None:
                can_continue = (
                    int(frames[0]) == prior_frame + 1
                    and int(locations[0]) >= 0
                    and int(locations[0]) == prior_location
                )
                if not can_continue and episode_ends:
                    # The group builder merges only when endpoints are consecutive;
                    # this assignment makes the cross-chunk intent explicit.
                    pass
            _append_episode_groups(
                frames=frames,
                locations=locations,
                counts=counts,
                episode_locations=episode_locations,
                episode_starts=episode_starts,
                episode_ends=episode_ends,
                episode_n=episode_n,
                episode_sums=episode_sums,
            )
            retained_count += int(frames.size)
            prior_frame = int(frames[-1])
            prior_location = int(locations[-1])
    assert full_count is not None and full_event is not None
    duration = retained_count * DT
    event_rate = full_event / (duration / 60.0) if duration > 0 else np.full(full_event.size, np.nan)
    stats_obj = SessionSufficientStats(
        session_id=str(session_id),
        episode_location=np.asarray(episode_locations, dtype=int),
        episode_start_frame=np.asarray(episode_starts, dtype=int),
        episode_end_frame=np.asarray(episode_ends, dtype=int),
        episode_n_frames=np.asarray(episode_n, dtype=int),
        episode_duration_sec=np.asarray(episode_n, dtype=float) * DT,
        episode_count_sum=(
            np.vstack(episode_sums)
            if episode_sums
            else np.zeros((0, full_count.size), dtype=np.float64)
        ),
        block_n_samples=np.asarray(block_n, dtype=int),
        block_count_sum=(
            np.vstack(block_sums)
            if block_sums
            else np.zeros((0, full_count.size), dtype=np.float64)
        ),
        full_count_sum=full_count,
        full_event_rate_per_min=event_rate,
        total_retained_samples=retained_count,
        total_retained_duration_sec=duration,
        n_dropped_nan_rows=dropped_nan,
    )
    audit = {
        "session_id": session_id,
        "animal": _parse_session(session_id)[0].rstrip("b"),
        "selected_path": str(selected_path),
        "neural_path": str(mat_path),
        "selected_rows_before_nan_drop": int(frames_all.size),
        "retained_rows": retained_count,
        "dropped_nan_rows": dropped_nan,
        "n_neurons": stats_obj.n_neurons,
        "n_location_episodes": stats_obj.n_episodes,
        "n_retained_blocks": int(stats_obj.block_n_samples.size),
        "retained_duration_sec": duration,
        "frame_gap_count": int(np.sum(np.diff(frames_all) != 1)),
        "invalid_location_rows_before_nan_drop": int(np.sum(locations_all < 0)),
        "runtime_sec": time.time() - started,
        "timebase": "absolute acquisition frame index at 25 Hz",
        "continuity_rule": "acquisition gaps and invalid locations break location episodes",
    }
    return stats_obj, audit


def load_pair_and_chain_scopes() -> tuple[pd.DataFrame, pd.DataFrame]:
    pairs = pd.read_csv(PAIR_MANIFEST, dtype=str)
    pairs = pairs.loc[pairs["family"].eq("d1v1")].copy()
    pairs["pair_label"] = pairs["session1"] + "->" + pairs["session2"]
    pairs["primary_36"] = ~pairs["pair_id"].eq(SHORT_PAIR_ID)
    chains = pd.read_csv(CHAIN_SCOPE, dtype=str)
    chains = chains.loc[chains["selected_for_run"].astype(str).str.lower().eq("true")].copy()
    if len(pairs) != 37 or int(pairs["primary_36"].sum()) != 36:
        raise AssertionError("Expected 37 ordinal and 36 canonical d1v1 pairs")
    if len(chains) != 22:
        raise AssertionError("Expected 22 clean long-gap chains")
    return pairs.reset_index(drop=True), chains.reset_index(drop=True)


def load_cimap(path: str | Path) -> np.ndarray:
    payload = scipy.io.loadmat(str(path))
    if "cell_to_index_map" in payload:
        raw = payload["cell_to_index_map"]
    else:
        keys = [key for key in payload if not key.startswith("__")]
        if not keys:
            raise KeyError(f"No CIMap array found in {path}")
        raw = payload[keys[0]]
    pairs = np.asarray(raw, dtype=int)
    if pairs.ndim == 1:
        pairs = pairs.reshape(-1, 1)
    pairs = pairs[:, :2]
    pairs = pairs[(pairs[:, 0] > 0) & (pairs[:, 1] > 0)] - 1
    if len(np.unique(pairs[:, 0])) != len(pairs) or len(np.unique(pairs[:, 1])) != len(pairs):
        raise ValueError(f"CIMap is not one-to-one: {path}")
    return pairs.astype(int)


def compose_chain(cimap_ab: str | Path, cimap_bc: str | Path) -> np.ndarray:
    ab = load_cimap(cimap_ab)
    bc = load_cimap(cimap_bc)
    b_to_c = {int(b): int(c) for b, c in bc}
    rows = [(int(a), int(b), b_to_c[int(b)]) for a, b in ab if int(b) in b_to_c]
    chain = np.asarray(rows, dtype=int)
    if chain.size == 0:
        return np.zeros((0, 3), dtype=int)
    if any(len(np.unique(chain[:, col])) != len(chain) for col in range(3)):
        raise ValueError("Composed chain is not one-to-one")
    return chain


def _pair_fit(frame: pd.DataFrame, x: str, y: str, animal: str) -> dict[str, Any]:
    data = frame[[x, y, animal]].copy()
    X = np.column_stack([np.ones(len(data)), pd.to_numeric(data[x], errors="coerce")])
    fit = cr1_ols(pd.to_numeric(data[y], errors="coerce"), X, data[animal].astype(str))
    result = linear_contrast(fit, [0, 1])
    return {**result, "n_rows": int(fit["n"]), "n_animals": int(fit["g"]), "intercept": float(np.asarray(fit["beta"])[0])}


def _intercept_test(values: Sequence[float], animals: Sequence[object]) -> dict[str, Any]:
    y = np.asarray(values, dtype=float)
    fit = cr1_ols(y, np.ones((y.size, 1)), animals)
    result = linear_contrast(fit, [1.0])
    return {**result, "n_rows": int(fit["n"]), "n_animals": int(fit["g"])}


def _animal_bootstrap_mean(
    frame: pd.DataFrame,
    *,
    value_col: str,
    animal_col: str,
    repeats: int,
    seed: int,
) -> dict[str, Any]:
    work = frame[[value_col, animal_col]].dropna().copy()
    groups = [group[value_col].to_numpy(float) for _, group in work.groupby(animal_col, sort=False)]
    rng = np.random.default_rng(seed)
    estimates = np.full(repeats, np.nan)
    for repeat in range(repeats):
        selected = rng.integers(0, len(groups), size=len(groups))
        estimates[repeat] = np.concatenate([groups[index] for index in selected]).mean()
    return {
        "estimate": float(work[value_col].mean()),
        "bootstrap_ci_low": float(np.percentile(estimates, 2.5)),
        "bootstrap_ci_high": float(np.percentile(estimates, 97.5)),
        "bootstrap_sd": float(np.std(estimates, ddof=1)),
        "n_rows": int(len(work)),
        "n_animals": int(work[animal_col].nunique()),
    }


def run_baseline_audit(output: Path) -> None:
    audit_dir = output / "00_baseline_audit"
    audit_dir.mkdir(parents=True, exist_ok=True)
    pairs, chains = load_pair_and_chain_scopes()
    _write_csv(pairs, audit_dir / "canonical_37_pair_scope_with_primary36_flag.csv")
    _write_csv(chains, audit_dir / "canonical_22_chain_scope.csv")

    current_stats = pd.read_csv(CURRENT_CHAIN_ROOT / "consecutive_gap_clean_long_gap_corrected_stats.csv")
    current_points = pd.read_csv(CURRENT_CHAIN_ROOT / "consecutive_gap_clean_long_gap_corrected_points.csv")
    reproduced = []
    for metric, group in current_points.groupby("metric", sort=False):
        fit = _pair_fit(group, "prev_gap_correlation", "next_gap_correlation", "animal_id")
        authority = current_stats.loc[current_stats["metric"].eq(metric)].iloc[0]
        reproduced.append(
            {
                "metric": metric,
                **fit,
                "authority_slope": float(authority["slope"]),
                "authority_se": float(authority["slope_se"]),
                "authority_p": float(authority["p_two_sided"]),
                "slope_abs_delta": abs(float(fit["estimate"]) - float(authority["slope"])),
                "se_abs_delta": abs(float(fit["se"]) - float(authority["slope_se"])),
                "p_abs_delta": abs(float(fit["p_two_sided"]) - float(authority["p_two_sided"])),
            }
        )
    reproduction = pd.DataFrame(reproduced)
    _write_csv(reproduction, audit_dir / "baseline_22_chain_coefficient_reproduction.csv")
    if not (reproduction[["slope_abs_delta", "se_abs_delta", "p_abs_delta"]].to_numpy() < 1e-10).all():
        raise AssertionError("Current recurrence coefficients did not reproduce exactly")

    pair_metrics = pd.read_csv(CURRENT_PAIR_ROOT / "pair_metric_summary.csv")
    pair_support = pd.read_csv(CURRENT_PAIR_ROOT / "pair_support_audit.csv")
    pair_audit = pd.DataFrame(
        [
            {
                "scope": "current canonical long-gap pairs",
                "n_pairs": int(pair_metrics["pair_key"].nunique()),
                "n_animals": int(pair_metrics["animal"].astype(str).nunique()),
                "n_metrics": int(pair_metrics["metric"].nunique()),
                "n_activity_qualified_cells": int(
                    pair_support.drop_duplicates("pair_key")["n_pairs_final"].sum()
                ),
            },
            {
                "scope": "current clean recurrence chains",
                "n_pairs": 44,
                "n_animals": int(chains["animal_id"].nunique()),
                "n_metrics": int(current_stats["metric"].nunique()),
                "n_activity_qualified_cells": int(
                    pd.read_csv(CURRENT_CHAIN_ROOT / "sorted_place_map_correlation_per_neuron.csv").shape[0]
                ),
            },
        ]
    )
    _write_csv(pair_audit, audit_dir / "baseline_scope_reproduction.csv")

    main3_points = pd.read_csv(CURRENT_MAIN3_ROOT / "main3_experience_trend_points_no_manual_mask.csv", dtype={"animal": str})
    influence_rows = []
    for metric, group in main3_points.groupby("metric", sort=False):
        for label, use in (
            ("all_37_including_14_day", group),
            (
                "exclude_14_day_influence_sensitivity",
                group.loc[
                    ~(
                        group["src"].astype(str).eq("1616day1")
                        & group["dst"].astype(str).eq("1616bday1")
                    )
                ],
            ),
        ):
            fit = _pair_fit(use, "experience", "value", "animal")
            influence_rows.append({"metric": metric, "scope": label, **fit})
    influence = pd.DataFrame(influence_rows)
    _write_csv(influence, audit_dir / "ordinal_trend_37_vs_36_influence_sensitivity.csv")

    features = pd.read_csv(REGISTRATION_ROOT / "registered_pair_features_long.csv", dtype=str)
    features["src_zero"] = pd.to_numeric(features["session1_cell_id_corrected"]) - 1
    features["dst_zero"] = pd.to_numeric(features["session2_cell_id_corrected"]) - 1
    join_audit = []
    for row in pairs.loc[pairs["primary_36"]].itertuples(index=False):
        cimap = load_cimap(row.cimap_path)
        observed = features.loc[features["pair_label"].eq(row.pair_label), ["src_zero", "dst_zero"]].to_numpy(int)
        join_audit.append(
            {
                "pair_label": row.pair_label,
                "n_cimap": int(len(cimap)),
                "n_registered_features": int(len(observed)),
                "exact_coordinate_set_match": bool(set(map(tuple, cimap)) == set(map(tuple, observed))),
                "one_to_one_cimap": bool(len(np.unique(cimap[:, 0])) == len(cimap) and len(np.unique(cimap[:, 1])) == len(cimap)),
            }
        )
    joins = pd.DataFrame(join_audit)
    _write_csv(joins, audit_dir / "one_to_one_registration_join_audit.csv")
    if not joins[["exact_coordinate_set_match", "one_to_one_cimap"]].all().all():
        raise AssertionError("Registration feature/CIMap join audit failed")

    estimator_audit = pd.DataFrame(
        [
            {
                "item": "pairwise activity gate",
                "executed_current": "S event rate >=0.1/min in both sessions",
                "written_methods": "S event rate >=0.1/min in both sessions",
                "status": "aligned",
                "control_action": "retain full-session gate before splitting",
            },
            {
                "item": "pairwise place and level occupancy",
                "executed_current": "positive occupancy; no 5-s minimum in maintained pair builder",
                "written_methods": ">=5 s in both sessions",
                "status": "divergent; current Methods describes intended estimator",
                "control_action": "regenerate candidate corrected 5-s result without promoting current panel",
            },
            {
                "item": "recurrence activity gate",
                "executed_current": "no 0.1/min gate in maintained recurrence builder",
                "written_methods": ">=0.1/min in every compared session",
                "status": "divergent; current Methods describes intended estimator",
                "control_action": "regenerate candidate corrected gated baseline before split control",
            },
            {
                "item": "recurrence ensemble rate",
                "executed_current": "unweighted mean of occupancy-normalized spatial map",
                "written_methods": "total denoised activity / analyzed duration outside gap-length analysis",
                "status": "divergent; current Methods describes intended estimator",
                "control_action": "use total C / retained duration for candidate corrected baseline and split blocks",
            },
            {
                "item": "corrected 842 registration",
                "executed_current": "zero-footprint coordinates reinserted in corrected 0->3 CIMap",
                "written_methods": "pairwise CellReg registration with ambiguity audit",
                "status": "aligned with corrected current record",
                "control_action": "use corrected manifest path",
            },
        ]
    )
    _write_csv(estimator_audit, audit_dir / "executed_code_vs_written_methods.csv")

    claim_text = "# Prose-claims audit\n\n"
    claim_text += "- **P_BF:** the supported neural-policy result is depth-weighted P_BS; P_BF is the companion sensitivity policy and must not be described as supported.\n"
    claim_text += "- **Within-level null:** the current structured null is a cyclic shift/reversal within connected same-depth components followed by the fixed 0.65/0.35 smoothing transform. The observed-versus-null difference is small in absolute correlation units, so `dropped sharply` is not supported wording.\n"
    claim_text += "- **Corridor wording:** spatial maps use retained body-centre 15x15 grid locations; `corridor locations` is narrower than the implemented binning and should be corrected in the next Methods revision.\n"
    claim_text += "- **Recurrence wording:** the current result is a next-gap association, not uninterrupted persistence of individual representations. The disjoint-middle-session control tests only reuse of the same middle-session activity and occupancy samples.\n"
    claim_text += "\nNo maintained manuscript or caption source was edited in this control run.\n"
    (audit_dir / "prose_claims_audit.md").write_text(claim_text, encoding="utf-8")

    _write_json(
        {
            "pair_scope": {"ordinal": 37, "canonical_long_gap": 36, "animals": int(pairs["animal"].nunique())},
            "chain_scope": {"chains": 22, "animals": int(chains["animal_id"].nunique())},
            "baseline_reproduced": True,
            "controls_authorized_after_audit": True,
            "decision": "Methods 5-s occupancy, recurrence activity gate and total-rate estimator treated as intended; candidate corrected results are generated append-only and current panels remain untouched.",
        },
        audit_dir / "audit_decision.json",
    )


def build_session_cache(
    output: Path,
    *,
    selected_root: Path,
    neural_root: Path,
    overwrite: bool,
    max_sessions: int = 0,
) -> None:
    pairs, chains = load_pair_and_chain_scopes()
    sessions = sorted(
        set(pairs["session1"])
        | set(pairs["session2"])
        | set(chains["session_a"])
        | set(chains["session_b"])
        | set(chains["session_c"])
    )
    if max_sessions:
        sessions = sessions[: int(max_sessions)]
    cache_dir = output / "cache" / "session_sufficient_stats"
    audit_path = output / "01_cache" / "session_cache_audit.csv"
    prior = pd.read_csv(audit_path) if audit_path.exists() else pd.DataFrame()
    prior_by_session = {str(row.session_id): row._asdict() for row in prior.itertuples(index=False)} if not prior.empty else {}
    rows: list[dict[str, Any]] = []
    for number, session_id in enumerate(sessions, start=1):
        target = cache_dir / f"{session_id}.npz"
        if target.exists() and not overwrite:
            stats_obj = load_session_stats(target)
            existing = dict(prior_by_session.get(session_id, {}))
            existing.update(
                {
                    "session_id": session_id,
                    "cache_path": str(target),
                    "cache_sha256": sha256_file(target),
                    "cache_reused": True,
                    "n_neurons": stats_obj.n_neurons,
                    "n_location_episodes": stats_obj.n_episodes,
                    "retained_rows": stats_obj.total_retained_samples,
                    "retained_duration_sec": stats_obj.total_retained_duration_sec,
                }
            )
            rows.append(existing)
            print(f"[{number}/{len(sessions)}] reuse {session_id}", flush=True)
            continue
        print(f"[{number}/{len(sessions)}] cache {session_id}", flush=True)
        stats_obj, audit = stream_session_sufficient_stats(
            session_id,
            selected_root=selected_root,
            neural_root=neural_root,
        )
        save_session_stats(target, stats_obj)
        audit.update({"cache_path": str(target), "cache_sha256": sha256_file(target), "cache_reused": False})
        rows.append(audit)
        _write_csv(pd.DataFrame(rows), audit_path)
    _write_csv(pd.DataFrame(rows), audit_path)


def _stats(output: Path, session_id: str) -> SessionSufficientStats:
    path = output / "cache" / "session_sufficient_stats" / f"{session_id}.npz"
    if not path.exists():
        raise FileNotFoundError(f"Run cache stage first; missing {path}")
    return load_session_stats(path)


def _activity_gate(ids_a: np.ndarray, ids_b: np.ndarray, a: SessionSufficientStats, b: SessionSufficientStats) -> np.ndarray:
    return (
        (a.full_event_rate_per_min[ids_a] >= 0.1)
        & (b.full_event_rate_per_min[ids_b] >= 0.1)
        & np.isfinite(a.full_event_rate_per_min[ids_a])
        & np.isfinite(b.full_event_rate_per_min[ids_b])
    )


def full_pair_metrics(
    a: SessionSufficientStats,
    b: SessionSufficientStats,
    cimap: np.ndarray,
    *,
    min_occupancy_sec: float = 5.0,
) -> dict[str, Any]:
    ids_a = cimap[:, 0].astype(int)
    ids_b = cimap[:, 1].astype(int)
    keep = _activity_gate(ids_a, ids_b, a, b)
    ids_a = ids_a[keep]
    ids_b = ids_b[keep]
    output: dict[str, Any] = {"ids_a": ids_a, "ids_b": ids_b, "n_registered": len(cimap), "n_activity": len(ids_a)}
    for name, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        map_a = fit_representation_map(a, representation, ids_a, min_occupancy_sec=min_occupancy_sec)
        map_b = fit_representation_map(b, representation, ids_b, min_occupancy_sec=min_occupancy_sec)
        shared = map_a["valid_mask"] & map_b["valid_mask"]
        correlations = columnwise_correlations(
            map_a["rate_map"], map_b["rate_map"], shared, min_labels=REPRESENTATION_MIN_LABELS[representation]
        )
        output[f"{name}_map_a"] = map_a["rate_map"]
        output[f"{name}_map_b"] = map_b["rate_map"]
        output[f"{name}_shared"] = shared
        output[f"{name}_correlation"] = correlations
        output[f"{name}_n_shared_labels"] = int(shared.sum())
    place_shared = output["place_shared"]
    output["pv_correlation"] = rowwise_correlations(
        output["place_map_a"], output["place_map_b"], place_shared, min_neurons=3
    )
    output["rate_a"] = rate_vector(a, ids_a)
    output["rate_b"] = rate_vector(b, ids_b)
    output["rate_correlation"] = safe_pearson(output["rate_a"], output["rate_b"])
    return output


def build_corrected_pair_baseline(output: Path) -> None:
    pairs, _ = load_pair_and_chain_scopes()
    rows = []
    cell_rows = []
    pv_rows = []
    support_rows = []
    for number, row in enumerate(pairs.itertuples(index=False), start=1):
        print(f"[{number}/{len(pairs)}] corrected pair {row.pair_label}", flush=True)
        a = _stats(output, row.session1)
        b = _stats(output, row.session2)
        metrics = full_pair_metrics(a, b, load_cimap(row.cimap_path))
        for metric in ("place", "level"):
            values = np.asarray(metrics[f"{metric}_correlation"], dtype=float)
            for index, value in enumerate(values):
                cell_rows.append(
                    {
                        "pair_id": row.pair_id,
                        "pair_label": row.pair_label,
                        "animal": row.animal,
                        "primary_36": row.primary_36,
                        "metric": metric,
                        "src_cell_id_zero": int(metrics["ids_a"][index]),
                        "dst_cell_id_zero": int(metrics["ids_b"][index]),
                        "correlation": value,
                        "src_event_rate_per_min": float(a.full_event_rate_per_min[metrics["ids_a"][index]]),
                        "dst_event_rate_per_min": float(b.full_event_rate_per_min[metrics["ids_b"][index]]),
                    }
                )
        for location, value in enumerate(metrics["pv_correlation"]):
            if np.isfinite(value):
                pv_rows.append(
                    {
                        "pair_id": row.pair_id,
                        "pair_label": row.pair_label,
                        "animal": row.animal,
                        "primary_36": row.primary_36,
                        "location": location,
                        "correlation": value,
                    }
                )
        summaries = {
            "place": np.nanmean(metrics["place_correlation"]),
            "level": np.nanmean(metrics["level_correlation"]),
            "pv": np.nanmean(metrics["pv_correlation"]),
            "rate": metrics["rate_correlation"],
        }
        for metric, value in summaries.items():
            rows.append(
                {
                    "pair_id": row.pair_id,
                    "pair_label": row.pair_label,
                    "animal": row.animal,
                    "primary_36": row.primary_36,
                    "metric": metric,
                    "pair_value": value,
                }
            )
        support_rows.append(
            {
                "pair_id": row.pair_id,
                "pair_label": row.pair_label,
                "animal": row.animal,
                "primary_36": row.primary_36,
                "n_registered": metrics["n_registered"],
                "n_activity_qualified": metrics["n_activity"],
                "n_place_correlations": int(np.isfinite(metrics["place_correlation"]).sum()),
                "n_level_correlations": int(np.isfinite(metrics["level_correlation"]).sum()),
                "n_pv_locations": int(np.isfinite(metrics["pv_correlation"]).sum()),
                "n_shared_place_locations": metrics["place_n_shared_labels"],
                "n_shared_levels": metrics["level_n_shared_labels"],
            }
        )
    target = output / "02_corrected_baseline"
    _write_csv(pd.DataFrame(rows), target / "corrected_pair_metric_summary_37_with_primary36.csv")
    _write_csv(pd.DataFrame(cell_rows), target / "corrected_pair_cell_correlations.csv")
    _write_csv(pd.DataFrame(pv_rows), target / "corrected_pair_pv_location_correlations.csv")
    _write_csv(pd.DataFrame(support_rows), target / "corrected_pair_support_audit.csv")


def _session_registered_cell_scope(output: Path) -> tuple[dict[str, np.ndarray], pd.DataFrame]:
    pairs, _ = load_pair_and_chain_scopes()
    cell_sets: dict[str, set[int]] = defaultdict(set)
    rows = []
    for row in pairs.loc[pairs["primary_36"]].itertuples(index=False):
        a = _stats(output, row.session1)
        b = _stats(output, row.session2)
        cimap = load_cimap(row.cimap_path)
        keep = _activity_gate(cimap[:, 0], cimap[:, 1], a, b)
        retained = cimap[keep]
        cell_sets[row.session1].update(int(value) for value in retained[:, 0])
        cell_sets[row.session2].update(int(value) for value in retained[:, 1])
        rows.append(
            {
                "pair_id": row.pair_id,
                "pair_label": row.pair_label,
                "animal": row.animal,
                "n_registered": int(len(cimap)),
                "n_full_session_activity_qualified": int(keep.sum()),
            }
        )
    return {key: np.asarray(sorted(values), dtype=int) for key, values in cell_sets.items()}, pd.DataFrame(rows)


def _accumulate_reliability(
    accumulator: dict[tuple[str, str, str, str, int], list[float]],
    *,
    support_label: str,
    session_id: str,
    comparison: str,
    representation: str,
    cell_ids: np.ndarray,
    correlations: np.ndarray,
) -> None:
    for cell_id, value in zip(cell_ids, correlations, strict=True):
        key = (support_label, session_id, comparison, representation, int(cell_id))
        record = accumulator.setdefault(key, [0.0, 0.0])
        if np.isfinite(value):
            record[0] += float(value)
            record[1] += 1.0


def run_control3_reliability(
    output: Path,
    *,
    n_splits: int,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    if n_splits < 24:
        raise ValueError("Primary reliability run requires at least 24 randomized splits")
    target = output / "03_control3_reliability"
    cell_scope, scope_audit = _session_registered_cell_scope(output)
    _write_csv(scope_audit, target / "registered_activity_scope_by_pair.csv")
    location_maps = representation_location_maps()
    accumulator: dict[tuple[str, str, str, str, int], list[float]] = {}
    canonical_rows: list[dict[str, Any]] = []
    split_summary_rows: list[dict[str, Any]] = []
    balance_rows: list[pd.DataFrame] = []
    support_rows: list[dict[str, Any]] = []
    split_assignments_dir = output / "cache" / "split_assignments"
    split_assignments_dir.mkdir(parents=True, exist_ok=True)

    for session_number, (session_id, cell_ids) in enumerate(sorted(cell_scope.items()), start=1):
        stats_obj = _stats(output, session_id)
        animal = _parse_session(session_id)[0].rstrip("b")
        print(f"[{session_number}/{len(cell_scope)}] reliability {session_id} ({len(cell_ids)} cells)", flush=True)
        split_specs: list[tuple[str, int, bool, int | None]] = [("canonical", -1, True, None)]
        split_specs += [
            ("randomized", split_index, False, stable_seed("control3", session_id, split_index, base_seed=base_seed))
            for split_index in range(n_splits)
        ]
        assignment_payload: dict[str, np.ndarray] = {}
        for split_kind, split_index, canonical, seed in split_specs:
            split = split_location_episodes(
                stats_obj.episode_location,
                stats_obj.episode_duration_sec,
                canonical=canonical,
                seed=seed,
            )
            assignment_payload[f"assignment_{split_index}"] = split.assignment.astype(np.int8)
            audit = split.location_audit.copy()
            audit.insert(0, "session_id", session_id)
            audit.insert(1, "animal", animal)
            audit.insert(2, "split_kind", split_kind)
            audit.insert(3, "split_index", split_index)
            balance_rows.append(audit)
            eligible_locations = np.zeros(N_SPATIAL_BINS, dtype=bool)
            if not audit.empty:
                eligible_locations[audit.loc[audit["eligible_70_30"], "location"].to_numpy(int)] = True
            location_a = aggregate_location_sums(
                stats_obj, cell_ids, assignment=split.assignment, half=0
            )
            location_b = aggregate_location_sums(
                stats_obj, cell_ids, assignment=split.assignment, half=1
            )
            for support_label, min_occupancy in (("primary_2.5s", 2.5), ("strict_5s", 5.0)):
                for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
                    permitted = (
                        common_permitted_locations(level_rep, reference_rep, location_maps=location_maps)
                        & eligible_locations
                    )
                    correlation_by_rep: dict[str, np.ndarray] = {}
                    label_support: dict[str, int] = {}
                    for representation in (level_rep, reference_rep):
                        half_a = fit_representation_from_location_sums(
                            location_a,
                            representation,
                            min_occupancy_sec=min_occupancy,
                            permitted_locations=permitted,
                            location_maps=location_maps,
                        )
                        half_b = fit_representation_from_location_sums(
                            location_b,
                            representation,
                            min_occupancy_sec=min_occupancy,
                            permitted_locations=permitted,
                            location_maps=location_maps,
                        )
                        shared = half_a["valid_mask"] & half_b["valid_mask"]
                        values = columnwise_correlations(
                            half_a["rate_map"],
                            half_b["rate_map"],
                            shared,
                            min_labels=REPRESENTATION_MIN_LABELS[representation],
                        )
                        correlation_by_rep[representation] = values
                        label_support[representation] = int(shared.sum())
                        if split_kind == "randomized":
                            _accumulate_reliability(
                                accumulator,
                                support_label=support_label,
                                session_id=session_id,
                                comparison=comparison,
                                representation=representation,
                                cell_ids=cell_ids,
                                correlations=values,
                            )
                        else:
                            for cell_id, value in zip(cell_ids, values, strict=True):
                                canonical_rows.append(
                                    {
                                        "support_rule": support_label,
                                        "session_id": session_id,
                                        "animal": animal,
                                        "comparison": comparison,
                                        "representation": representation,
                                        "cell_id_zero": int(cell_id),
                                        "canonical_raw_split_correlation": value,
                                    }
                                )
                    level_values = correlation_by_rep[level_rep]
                    reference_values = correlation_by_rep[reference_rep]
                    common_defined = np.isfinite(level_values) & np.isfinite(reference_values)
                    split_summary_rows.extend(
                        [
                            {
                                "support_rule": support_label,
                                "session_id": session_id,
                                "animal": animal,
                                "split_kind": split_kind,
                                "split_index": split_index,
                                "comparison": comparison,
                                "representation": representation,
                                "mean_raw_split_correlation_common_cells": float(np.nanmean(values[common_defined])) if common_defined.any() else np.nan,
                                "n_common_defined_cells": int(common_defined.sum()),
                                "n_shared_labels": label_support[representation],
                                "n_permitted_locations": int(permitted.sum()),
                            }
                            for representation, values in correlation_by_rep.items()
                        ]
                    )
                    support_rows.append(
                        {
                            "support_rule": support_label,
                            "session_id": session_id,
                            "animal": animal,
                            "split_kind": split_kind,
                            "split_index": split_index,
                            "comparison": comparison,
                            "n_scope_cells": int(len(cell_ids)),
                            "n_common_defined_cells": int(common_defined.sum()),
                            "n_eligible_locations_70_30": int(eligible_locations.sum()),
                            "n_level_labels": label_support[level_rep],
                            "n_reference_labels": label_support[reference_rep],
                            "episode_overlap_count": 0,
                            "frame_overlap_count": 0,
                        }
                    )
        np.savez_compressed(split_assignments_dir / f"{session_id}.npz", **assignment_payload)

    balance = pd.concat(balance_rows, ignore_index=True) if balance_rows else pd.DataFrame()
    _write_csv(balance, target / "location_duration_balance_by_split.csv")
    _write_csv(pd.DataFrame(support_rows), target / "split_support_and_disjointness_audit.csv")
    _write_csv(pd.DataFrame(split_summary_rows), target / "split_session_representation_summaries.csv")
    _write_csv(pd.DataFrame(canonical_rows), target / "canonical_split_neuron_reliability.csv")

    reliability_rows = []
    minimum_valid_splits = int(math.ceil(n_splits * 20 / 24))
    for key, (value_sum, valid_count) in accumulator.items():
        support_label, session_id, comparison, representation, cell_id = key
        mean_raw = value_sum / valid_count if valid_count else np.nan
        reliability_rows.append(
            {
                "support_rule": support_label,
                "session_id": session_id,
                "animal": _parse_session(session_id)[0].rstrip("b"),
                "comparison": comparison,
                "representation": representation,
                "cell_id_zero": cell_id,
                "n_valid_randomized_splits": int(valid_count),
                "meets_20_of_24": bool(valid_count >= 20),
                "minimum_valid_randomized_splits": minimum_valid_splits,
                "meets_minimum_valid_splits": bool(valid_count >= minimum_valid_splits),
                "mean_raw_split_correlation": mean_raw,
                "spearman_brown_extrapolation": spearman_brown(mean_raw) if valid_count >= minimum_valid_splits else np.nan,
            }
        )
    reliability = pd.DataFrame(reliability_rows)
    _write_csv(reliability, target / "split_averaged_neuron_reliability.csv")

    inference_rows = []
    session_contrast_rows = []
    for support_label, support_frame in reliability.groupby("support_rule", sort=False):
        for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
            work = support_frame.loc[
                support_frame["comparison"].eq(comparison) & support_frame["meets_minimum_valid_splits"]
            ].copy()
            pivot = work.pivot_table(
                index=["session_id", "animal", "cell_id_zero"],
                columns="representation",
                values="mean_raw_split_correlation",
                aggfunc="first",
            ).reset_index()
            pivot = pivot.dropna(subset=[level_rep, reference_rep])
            pivot["difference"] = pivot[level_rep] - pivot[reference_rep]
            sessions = (
                pivot.groupby(["session_id", "animal"], as_index=False)
                .agg(
                    level_mean=(level_rep, "mean"),
                    reference_mean=(reference_rep, "mean"),
                    difference=("difference", "mean"),
                    n_common_cells=("cell_id_zero", "size"),
                )
            )
            sessions["support_rule"] = support_label
            sessions["comparison"] = comparison
            session_contrast_rows.append(sessions)
            fit = _intercept_test(sessions["difference"], sessions["animal"])
            boot = _animal_bootstrap_mean(
                sessions,
                value_col="difference",
                animal_col="animal",
                repeats=bootstrap_repeats,
                seed=stable_seed("control3_boot", support_label, comparison, base_seed=base_seed),
            )
            inference_rows.append(
                {
                    "support_rule": support_label,
                    "comparison": comparison,
                    "level_representation": level_rep,
                    "reference_representation": reference_rep,
                    **fit,
                    "bootstrap_ci_low": boot["bootstrap_ci_low"],
                    "bootstrap_ci_high": boot["bootstrap_ci_high"],
                    "bootstrap_sd": boot["bootstrap_sd"],
                }
            )
    inference = pd.DataFrame(inference_rows)
    primary_index = inference["support_rule"].eq("primary_2.5s")
    inference.loc[primary_index, "p_bh4"] = benjamini_hochberg(
        inference.loc[primary_index, "p_two_sided"].to_numpy(float)
    )
    _write_csv(inference, target / "reliability_contrast_inference.csv")
    session_contrasts = pd.concat(session_contrast_rows, ignore_index=True)
    _write_csv(session_contrasts, target / "paired_session_reliability_contrasts.csv")

    # Day-role summaries use the exact 36 pair memberships, with repeated pairs
    # clustered later rather than treating unique sessions as independent animals.
    pairs, _ = load_pair_and_chain_scopes()
    role_rows = []
    primary_sessions = session_contrasts.loc[session_contrasts["support_rule"].eq("primary_2.5s")]
    for row in pairs.loc[pairs["primary_36"]].itertuples(index=False):
        for role, session_id in (("Day_i", row.session1), ("Day_i_plus_1", row.session2)):
            subset = primary_sessions.loc[primary_sessions["session_id"].eq(session_id)]
            for record in subset.itertuples(index=False):
                role_rows.append(
                    {
                        "pair_id": row.pair_id,
                        "animal": row.animal,
                        "day_role": role,
                        "session_id": session_id,
                        "comparison": record.comparison,
                        "level_mean": record.level_mean,
                        "reference_mean": record.reference_mean,
                    }
                )
    role_frame = pd.DataFrame(role_rows)
    _write_csv(role_frame, target / "day_role_pair_joined_reliability.csv")
    role_summary = []
    for (comparison, role, representation), group in (
        role_frame.melt(
            id_vars=["pair_id", "animal", "day_role", "session_id", "comparison"],
            value_vars=["level_mean", "reference_mean"],
            var_name="representation_role",
            value_name="reliability",
        ).groupby(["comparison", "day_role", "representation_role"], sort=False)
    ):
        boot = _animal_bootstrap_mean(
            group,
            value_col="reliability",
            animal_col="animal",
            repeats=bootstrap_repeats,
            seed=stable_seed("control3_dayrole", comparison, role, representation, base_seed=base_seed),
        )
        role_summary.append({"comparison": comparison, "day_role": role, "representation_role": representation, **boot})
    _write_csv(pd.DataFrame(role_summary), target / "day_role_reliability_descriptive_bootstrap.csv")

    # Join split reliability to the corrected long-gap per-neuron correlations.
    pair_cells = pd.read_csv(output / "02_corrected_baseline" / "corrected_pair_cell_correlations.csv", dtype={"animal": str})
    primary_rel = reliability.loc[
        reliability["support_rule"].eq("primary_2.5s")
        & reliability["comparison"].eq("level_minus_place")
        & reliability["meets_minimum_valid_splits"]
    ].copy()
    adjusted_rows = []
    pairs_by_id = pairs.set_index("pair_id")
    for metric, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        cells = pair_cells.loc[pair_cells["metric"].eq(metric) & pair_cells["primary_36"]].copy()
        source_rel = primary_rel.loc[primary_rel["representation"].eq(representation), ["session_id", "cell_id_zero", "mean_raw_split_correlation", "spearman_brown_extrapolation"]].rename(
            columns={
                "session_id": "source_session",
                "cell_id_zero": "src_cell_id_zero",
                "mean_raw_split_correlation": "source_raw_reliability",
                "spearman_brown_extrapolation": "source_sb_reliability",
            }
        )
        target_rel = primary_rel.loc[primary_rel["representation"].eq(representation), ["session_id", "cell_id_zero", "mean_raw_split_correlation", "spearman_brown_extrapolation"]].rename(
            columns={
                "session_id": "target_session",
                "cell_id_zero": "dst_cell_id_zero",
                "mean_raw_split_correlation": "target_raw_reliability",
                "spearman_brown_extrapolation": "target_sb_reliability",
            }
        )
        cells["source_session"] = cells["pair_id"].map(pairs_by_id["session1"])
        cells["target_session"] = cells["pair_id"].map(pairs_by_id["session2"])
        cells = cells.merge(source_rel, on=["source_session", "src_cell_id_zero"], how="left", validate="many_to_one")
        cells = cells.merge(target_rel, on=["target_session", "dst_cell_id_zero"], how="left", validate="many_to_one")
        cells["eligible_sb_ge_0.2"] = (cells["source_sb_reliability"] >= 0.2) & (cells["target_sb_reliability"] >= 0.2)
        cells["classical_attenuation_factor"] = np.sqrt(cells["source_sb_reliability"] * cells["target_sb_reliability"])
        cells["reliability_adjusted_stability"] = cells["correlation"] / cells["classical_attenuation_factor"]
        adjusted_rows.append(cells)
    adjusted = pd.concat(adjusted_rows, ignore_index=True)
    _write_csv(adjusted, target / "exploratory_reliability_adjusted_neuron_stability.csv")
    adjusted_pair = (
        adjusted.loc[adjusted["eligible_sb_ge_0.2"]]
        .groupby(["pair_id", "animal", "metric"], as_index=False)
        .agg(
            median_adjusted_stability=("reliability_adjusted_stability", "median"),
            median_raw_stability=("correlation", "median"),
            n_neurons=("correlation", "size"),
        )
    )
    _write_csv(adjusted_pair, target / "exploratory_reliability_adjusted_pair_medians.csv")

    # Coefficient-blind numerical convergence checks.
    random_summary = pd.DataFrame(split_summary_rows)
    random_summary = random_summary.loc[
        random_summary["split_kind"].eq("randomized")
        & random_summary["support_rule"].eq("primary_2.5s")
    ].copy()
    convergence_rows = []
    for (comparison, representation), group in random_summary.groupby(["comparison", "representation"], sort=False):
        seed_means = group.groupby("split_index")["mean_raw_split_correlation_common_cells"].mean()
        first12 = seed_means.loc[seed_means.index < 12]
        first24 = seed_means.loc[seed_means.index < 24]
        convergence_rows.append(
            {
                "comparison": comparison,
                "representation": representation,
                "estimate_first12": float(first12.mean()),
                "estimate_first24": float(first24.mean()),
                "absolute_change_12_to_24": abs(float(first24.mean() - first12.mean())),
                "across_seed_sd_first24": float(first24.std(ddof=1)),
                "monte_carlo_se_first24": float(first24.std(ddof=1) / np.sqrt(len(first24))),
                "reliability_change_le_0.01": bool(abs(float(first24.mean() - first12.mean())) <= 0.01),
            }
        )
    _write_csv(pd.DataFrame(convergence_rows), target / "split_convergence_12_vs_24.csv")


def _cache_full_event_rate(output: Path, session_id: str) -> np.ndarray:
    path = output / "cache" / "session_sufficient_stats" / f"{session_id}.npz"
    with np.load(path, allow_pickle=False) as payload:
        return np.asarray(payload["full_event_rate_per_min"], dtype=float)


def _eligible_locations_for_assignment(
    stats_obj: SessionSufficientStats,
    assignment: np.ndarray,
) -> np.ndarray:
    eligible = np.zeros(N_SPATIAL_BINS, dtype=bool)
    for location in np.unique(stats_obj.episode_location):
        use = stats_obj.episode_location == int(location)
        duration_a = float(stats_obj.episode_duration_sec[use & (assignment == 0)].sum())
        duration_b = float(stats_obj.episode_duration_sec[use & (assignment == 1)].sum())
        total = duration_a + duration_b
        eligible[int(location)] = bool(
            total > 0 and max(duration_a, duration_b) / total <= 0.70
        )
    return eligible


def run_control3_panel_fidelity_sensitivity(
    output: Path,
    *,
    n_splits: int,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    """Repeat reliability using the existing panels' own eligibility logic.

    The canonical 36-pair roster remains frozen.  Place/level observations use
    the general full-session activity gate.  The matched-resolution controls
    use all registered cells, as in their existing panel, and each
    representation uses its own fixed spatial mask rather than the primary
    common-frame intersection.
    """

    if n_splits < 24:
        raise ValueError("Panel-fidelity sensitivity requires at least 24 splits")
    target = output / "03_control3_reliability"
    pairs, _ = load_pair_and_chain_scopes()
    pairs = pairs.loc[pairs["primary_36"]].copy()
    location_maps = representation_location_maps()
    requests: dict[str, list[dict[str, Any]]] = defaultdict(list)
    scope_rows: list[dict[str, Any]] = []
    for row in pairs.itertuples(index=False):
        cimap = load_cimap(row.cimap_path)
        rate_a = _cache_full_event_rate(output, row.session1)
        rate_b = _cache_full_event_rate(output, row.session2)
        activity_keep = (
            (rate_a[cimap[:, 0]] >= 0.1)
            & (rate_b[cimap[:, 1]] >= 0.1)
            & np.isfinite(rate_a[cimap[:, 0]])
            & np.isfinite(rate_b[cimap[:, 1]])
        )
        for side, session_id, ids in (
            ("source", row.session1, cimap[:, 0]),
            ("target", row.session2, cimap[:, 1]),
        ):
            requests[session_id].append(
                {
                    "pair_id": row.pair_id,
                    "pair_label": row.pair_label,
                    "animal": row.animal,
                    "side": side,
                    "all_cell_ids": np.asarray(ids, dtype=int),
                    "activity_cell_ids": np.asarray(ids[activity_keep], dtype=int),
                    "activity_positions": np.flatnonzero(activity_keep),
                }
            )
        scope_rows.append(
            {
                "pair_id": row.pair_id,
                "pair_label": row.pair_label,
                "animal": row.animal,
                "n_registered_original_coarse_population": int(len(cimap)),
                "n_activity_qualified_original_place_level_population": int(activity_keep.sum()),
                "roster": "frozen canonical 36 d1v1 pairs",
            }
        )
    _write_csv(pd.DataFrame(scope_rows), target / "panel_fidelity_pair_scope.csv")

    accumulator: dict[tuple[str, str, str, str, str, str, int], list[float]] = {}
    support_rows: list[dict[str, Any]] = []
    assignment_dir = output / "cache" / "split_assignments"
    for session_number, (session_id, session_requests) in enumerate(sorted(requests.items()), start=1):
        print(
            f"[{session_number}/{len(requests)}] panel-fidelity reliability {session_id} "
            f"({len(session_requests)} pair-side requests)",
            flush=True,
        )
        stats_obj = _stats(output, session_id)
        assignment_path = assignment_dir / f"{session_id}.npz"
        if not assignment_path.exists():
            raise FileNotFoundError(f"Missing shared split assignments: {assignment_path}")
        with np.load(assignment_path, allow_pickle=False) as assignments:
            split_assignments = {
                split_index: np.asarray(assignments[f"assignment_{split_index}"], dtype=np.int8)
                for split_index in range(n_splits)
            }
        for request in session_requests:
            for split_index, assignment in split_assignments.items():
                eligible_locations = _eligible_locations_for_assignment(stats_obj, assignment)
                half_a_all = aggregate_location_sums(
                    stats_obj,
                    request["all_cell_ids"],
                    assignment=assignment,
                    half=0,
                )
                half_b_all = aggregate_location_sums(
                    stats_obj,
                    request["all_cell_ids"],
                    assignment=assignment,
                    half=1,
                )
                activity_positions = np.asarray(request["activity_positions"], dtype=int)
                half_a_activity = {
                    "count_by_location": half_a_all["count_by_location"][:, activity_positions],
                    "occupancy_by_location_sec": half_a_all["occupancy_by_location_sec"],
                    "neuron_ids": request["activity_cell_ids"],
                }
                half_b_activity = {
                    "count_by_location": half_b_all["count_by_location"][:, activity_positions],
                    "occupancy_by_location_sec": half_b_all["occupancy_by_location_sec"],
                    "neuron_ids": request["activity_cell_ids"],
                }
                for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
                    original_general_gate = comparison == "level_minus_place"
                    cell_ids = (
                        request["activity_cell_ids"]
                        if original_general_gate
                        else request["all_cell_ids"]
                    )
                    half_a = half_a_activity if original_general_gate else half_a_all
                    half_b = half_b_activity if original_general_gate else half_b_all
                    correlations: dict[str, np.ndarray] = {}
                    n_labels: dict[str, int] = {}
                    for representation in (level_rep, reference_rep):
                        permitted = (
                            np.asarray(location_maps[representation], dtype=int) >= 0
                        ) & eligible_locations
                        map_a = fit_representation_from_location_sums(
                            half_a,
                            representation,
                            min_occupancy_sec=2.5,
                            permitted_locations=permitted,
                            location_maps=location_maps,
                        )
                        map_b = fit_representation_from_location_sums(
                            half_b,
                            representation,
                            min_occupancy_sec=2.5,
                            permitted_locations=permitted,
                            location_maps=location_maps,
                        )
                        shared = map_a["valid_mask"] & map_b["valid_mask"]
                        values = columnwise_correlations(
                            map_a["rate_map"],
                            map_b["rate_map"],
                            shared,
                            min_labels=REPRESENTATION_MIN_LABELS[representation],
                        )
                        correlations[representation] = values
                        n_labels[representation] = int(shared.sum())
                        for cell_id, value in zip(cell_ids, values, strict=True):
                            key = (
                                request["pair_id"],
                                request["animal"],
                                session_id,
                                request["side"],
                                comparison,
                                representation,
                                int(cell_id),
                            )
                            record = accumulator.setdefault(key, [0.0, 0.0])
                            if np.isfinite(value):
                                record[0] += float(value)
                                record[1] += 1.0
                    common = np.isfinite(correlations[level_rep]) & np.isfinite(
                        correlations[reference_rep]
                    )
                    support_rows.append(
                        {
                            "pair_id": request["pair_id"],
                            "animal": request["animal"],
                            "session_id": session_id,
                            "side": request["side"],
                            "comparison": comparison,
                            "split_index": split_index,
                            "eligibility_population": (
                                "original_general_activity_gate"
                                if original_general_gate
                                else "original_matched_resolution_no_general_activity_gate"
                            ),
                            "spatial_mask": "representation_specific_original_mask",
                            "n_input_cells": int(len(cell_ids)),
                            "n_common_defined_cells": int(common.sum()),
                            "n_level_labels": n_labels[level_rep],
                            "n_reference_labels": n_labels[reference_rep],
                        }
                    )

    reliability_rows: list[dict[str, Any]] = []
    for key, (value_sum, valid_count) in accumulator.items():
        pair_id, animal, session_id, side, comparison, representation, cell_id = key
        reliability_rows.append(
            {
                "pair_id": pair_id,
                "animal": animal,
                "session_id": session_id,
                "side": side,
                "comparison": comparison,
                "representation": representation,
                "cell_id_zero": cell_id,
                "n_valid_randomized_splits": int(valid_count),
                "meets_20_of_24": bool(valid_count >= 20),
                "mean_raw_split_correlation": (
                    float(value_sum / valid_count) if valid_count else np.nan
                ),
            }
        )
    reliability = pd.DataFrame(reliability_rows)
    _write_csv(
        reliability,
        target / "panel_fidelity_pair_specific_neuron_reliability.csv",
    )
    _write_csv(
        pd.DataFrame(support_rows),
        target / "panel_fidelity_split_support.csv",
    )

    pair_session_rows: list[pd.DataFrame] = []
    pair_rows: list[pd.DataFrame] = []
    inference_rows: list[dict[str, Any]] = []
    for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
        work = reliability.loc[
            reliability["comparison"].eq(comparison)
            & reliability["meets_20_of_24"]
        ]
        pivot = work.pivot_table(
            index=["pair_id", "animal", "session_id", "side", "cell_id_zero"],
            columns="representation",
            values="mean_raw_split_correlation",
            aggfunc="first",
        ).reset_index()
        pivot = pivot.dropna(subset=[level_rep, reference_rep])
        pivot["difference"] = pivot[level_rep] - pivot[reference_rep]
        session_summary = (
            pivot.groupby(["pair_id", "animal", "session_id", "side"], as_index=False)
            .agg(
                level_mean=(level_rep, "mean"),
                reference_mean=(reference_rep, "mean"),
                difference=("difference", "mean"),
                n_common_cells=("cell_id_zero", "size"),
            )
        )
        session_summary["comparison"] = comparison
        pair_session_rows.append(session_summary)
        pair_summary = (
            session_summary.groupby(["pair_id", "animal"], as_index=False)
            .agg(
                level_mean=("level_mean", "mean"),
                reference_mean=("reference_mean", "mean"),
                difference=("difference", "mean"),
                n_pair_sides=("side", "size"),
                minimum_common_cells=("n_common_cells", "min"),
            )
        )
        pair_summary["comparison"] = comparison
        pair_rows.append(pair_summary)
        fit = _intercept_test(pair_summary["difference"], pair_summary["animal"])
        boot = _animal_bootstrap_mean(
            pair_summary,
            value_col="difference",
            animal_col="animal",
            repeats=bootstrap_repeats,
            seed=stable_seed("control3_fidelity", comparison, base_seed=base_seed),
        )
        inference_rows.append(
            {
                "comparison": comparison,
                "level_representation": level_rep,
                "reference_representation": reference_rep,
                **fit,
                "bootstrap_ci_low": boot["bootstrap_ci_low"],
                "bootstrap_ci_high": boot["bootstrap_ci_high"],
                "bootstrap_sd": boot["bootstrap_sd"],
                "inference_status": "fidelity sensitivity; no additional multiplicity family",
            }
        )
    _write_csv(
        pd.concat(pair_session_rows, ignore_index=True),
        target / "panel_fidelity_pair_session_contrasts.csv",
    )
    _write_csv(
        pd.concat(pair_rows, ignore_index=True),
        target / "panel_fidelity_pair_contrasts.csv",
    )
    _write_csv(
        pd.DataFrame(inference_rows),
        target / "panel_fidelity_contrast_inference.csv",
    )


def _correlate_map_pair(
    map_a: Mapping[str, np.ndarray],
    map_b: Mapping[str, np.ndarray],
    *,
    min_labels: int,
) -> np.ndarray:
    shared = np.asarray(map_a["valid_mask"], bool) & np.asarray(map_b["valid_mask"], bool)
    return columnwise_correlations(
        np.asarray(map_a["rate_map"], float),
        np.asarray(map_b["rate_map"], float),
        shared,
        min_labels=min_labels,
    )


def _chain_split_rows(
    output: Path,
    chain_row: Any,
    *,
    split_index: int,
    half_support_sec: float,
    base_seed: int,
    prepared: Mapping[str, Any] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    b = _stats(output, chain_row.session_b)
    if prepared is None:
        a = _stats(output, chain_row.session_a)
        c = _stats(output, chain_row.session_c)
        linked = compose_chain(chain_row.cimap_ab, chain_row.cimap_bc)
        keep = (
            (a.full_event_rate_per_min[linked[:, 0]] >= 0.1)
            & (b.full_event_rate_per_min[linked[:, 1]] >= 0.1)
            & (c.full_event_rate_per_min[linked[:, 2]] >= 0.1)
        )
        linked = linked[keep]
        location_a_full = aggregate_location_sums(a, linked[:, 0])
        location_b_full = aggregate_location_sums(b, linked[:, 1])
        location_c_full = aggregate_location_sums(c, linked[:, 2])
        full_rate_a = rate_vector(a, linked[:, 0])
        full_rate_b = rate_vector(b, linked[:, 1])
        full_rate_c = rate_vector(c, linked[:, 2])
    else:
        linked = np.asarray(prepared["linked"], dtype=int)
        location_a_full = prepared["location_a_full"]
        location_b_full = prepared["location_b_full"]
        location_c_full = prepared["location_c_full"]
        full_rate_a = np.asarray(prepared["full_rate_a"], dtype=float)
        full_rate_b = np.asarray(prepared["full_rate_b"], dtype=float)
        full_rate_c = np.asarray(prepared["full_rate_c"], dtype=float)
    if split_index < 0:
        split = split_location_episodes(
            b.episode_location, b.episode_duration_sec, canonical=True
        )
        block_assignment = split_retained_blocks(b.block_n_samples, canonical=True)
    else:
        seed = stable_seed("control1", chain_row.session_b, split_index, base_seed=base_seed)
        split = split_location_episodes(
            b.episode_location, b.episode_duration_sec, canonical=False, seed=seed
        )
        block_assignment = split_retained_blocks(
            b.block_n_samples,
            canonical=False,
            seed=stable_seed("control1_rate", chain_row.session_b, split_index, base_seed=base_seed),
        )
    eligible_locations = np.zeros(N_SPATIAL_BINS, dtype=bool)
    audit = split.location_audit
    if not audit.empty:
        eligible_locations[audit.loc[audit["eligible_70_30"], "location"].to_numpy(int)] = True
    ids_a, ids_b, ids_c = linked.T if len(linked) else (np.array([], int),) * 3
    location_ba = aggregate_location_sums(b, ids_b, assignment=split.assignment, half=0)
    location_bb = aggregate_location_sums(b, ids_b, assignment=split.assignment, half=1)
    orientation_rows: list[dict[str, Any]] = []
    full_rows: list[dict[str, Any]] = []
    support_rows: list[dict[str, Any]] = []
    maps_by_readout: dict[str, dict[str, Mapping[str, np.ndarray]]] = {}
    for readout, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        map_a = fit_representation_from_location_sums(location_a_full, representation, min_occupancy_sec=5.0)
        map_c = fit_representation_from_location_sums(location_c_full, representation, min_occupancy_sec=5.0)
        map_b_full = fit_representation_from_location_sums(location_b_full, representation, min_occupancy_sec=5.0)
        map_ba = fit_representation_from_location_sums(
            location_ba,
            representation,
            min_occupancy_sec=half_support_sec,
            permitted_locations=eligible_locations,
        )
        map_bb = fit_representation_from_location_sums(
            location_bb,
            representation,
            min_occupancy_sec=half_support_sec,
            permitted_locations=eligible_locations,
        )
        maps_by_readout[readout] = {"a": map_a, "b": map_b_full, "c": map_c, "ba": map_ba, "bb": map_bb}
        min_labels = REPRESENTATION_MIN_LABELS[representation]
        x_a = _correlate_map_pair(map_a, map_ba, min_labels=min_labels)
        x_b = _correlate_map_pair(map_a, map_bb, min_labels=min_labels)
        y_a = _correlate_map_pair(map_ba, map_c, min_labels=min_labels)
        y_b = _correlate_map_pair(map_bb, map_c, min_labels=min_labels)
        full_x = _correlate_map_pair(map_a, map_b_full, min_labels=min_labels)
        full_y = _correlate_map_pair(map_b_full, map_c, min_labels=min_labels)
        common = np.isfinite(x_a) & np.isfinite(x_b) & np.isfinite(y_a) & np.isfinite(y_b)
        full_valid = np.isfinite(full_x) & np.isfinite(full_y)
        for index in np.flatnonzero(common):
            unit_id = f"{int(ids_a[index])}->{int(ids_b[index])}->{int(ids_c[index])}"
            values = {"AA": (x_a[index], y_a[index]), "BB": (x_b[index], y_b[index]), "AB": (x_a[index], y_b[index]), "BA": (x_b[index], y_a[index])}
            for orientation, (predictor, outcome) in values.items():
                orientation_rows.append(
                    {
                        "readout": readout,
                        "triplet": chain_row.triplet,
                        "animal": chain_row.animal_id,
                        "session_a": chain_row.session_a,
                        "session_b": chain_row.session_b,
                        "session_c": chain_row.session_c,
                        "unit_id": unit_id,
                        "orientation": orientation,
                        "predictor": predictor,
                        "outcome": outcome,
                    }
                )
        for index in np.flatnonzero(full_valid):
            full_rows.append(
                {
                    "readout": readout,
                    "triplet": chain_row.triplet,
                    "animal": chain_row.animal_id,
                    "unit_id": f"{int(ids_a[index])}->{int(ids_b[index])}->{int(ids_c[index])}",
                    "predictor": full_x[index],
                    "outcome": full_y[index],
                    "on_split_common_support": bool(common[index]),
                }
            )
        support_rows.append(
            {
                "readout": readout,
                "triplet": chain_row.triplet,
                "animal": chain_row.animal_id,
                "n_composed_registered": int(len(compose_chain(chain_row.cimap_ab, chain_row.cimap_bc))),
                "n_activity_qualified": int(len(linked)),
                "n_full_defined": int(full_valid.sum()),
                "n_all_four_split_defined": int(common.sum()),
                "split_index": split_index,
                "half_support_sec": half_support_sec,
            }
        )

    # Population vectors use the same linked neurons and only locations valid in
    # A, C and both B halves, making all four orientations share one location set.
    place_maps = maps_by_readout["place"]
    common_locations = (
        place_maps["a"]["valid_mask"]
        & place_maps["c"]["valid_mask"]
        & place_maps["ba"]["valid_mask"]
        & place_maps["bb"]["valid_mask"]
    )
    x_a_pv = rowwise_correlations(place_maps["a"]["rate_map"], place_maps["ba"]["rate_map"], common_locations, min_neurons=3)
    x_b_pv = rowwise_correlations(place_maps["a"]["rate_map"], place_maps["bb"]["rate_map"], common_locations, min_neurons=3)
    y_a_pv = rowwise_correlations(place_maps["ba"]["rate_map"], place_maps["c"]["rate_map"], common_locations, min_neurons=3)
    y_b_pv = rowwise_correlations(place_maps["bb"]["rate_map"], place_maps["c"]["rate_map"], common_locations, min_neurons=3)
    common_pv = np.isfinite(x_a_pv) & np.isfinite(x_b_pv) & np.isfinite(y_a_pv) & np.isfinite(y_b_pv)
    full_common_locations = (
        place_maps["a"]["valid_mask"] & place_maps["b"]["valid_mask"] & place_maps["c"]["valid_mask"]
    )
    full_x_pv = rowwise_correlations(place_maps["a"]["rate_map"], place_maps["b"]["rate_map"], full_common_locations, min_neurons=3)
    full_y_pv = rowwise_correlations(place_maps["b"]["rate_map"], place_maps["c"]["rate_map"], full_common_locations, min_neurons=3)
    for location in np.flatnonzero(common_pv):
        values = {"AA": (x_a_pv[location], y_a_pv[location]), "BB": (x_b_pv[location], y_b_pv[location]), "AB": (x_a_pv[location], y_b_pv[location]), "BA": (x_b_pv[location], y_a_pv[location])}
        for orientation, (predictor, outcome) in values.items():
            orientation_rows.append(
                {
                    "readout": "pv",
                    "triplet": chain_row.triplet,
                    "animal": chain_row.animal_id,
                    "session_a": chain_row.session_a,
                    "session_b": chain_row.session_b,
                    "session_c": chain_row.session_c,
                    "unit_id": str(int(location)),
                    "orientation": orientation,
                    "predictor": predictor,
                    "outcome": outcome,
                }
            )
    full_pv_valid = np.isfinite(full_x_pv) & np.isfinite(full_y_pv)
    for location in np.flatnonzero(full_pv_valid):
        full_rows.append(
            {
                "readout": "pv",
                "triplet": chain_row.triplet,
                "animal": chain_row.animal_id,
                "unit_id": str(int(location)),
                "predictor": full_x_pv[location],
                "outcome": full_y_pv[location],
                "on_split_common_support": bool(common_pv[location]),
            }
        )
    support_rows.append(
        {
            "readout": "pv",
            "triplet": chain_row.triplet,
            "animal": chain_row.animal_id,
            "n_composed_registered": int(len(compose_chain(chain_row.cimap_ab, chain_row.cimap_bc))),
            "n_activity_qualified": int(len(linked)),
            "n_full_defined": int(full_pv_valid.sum()),
            "n_all_four_split_defined": int(common_pv.sum()),
            "split_index": split_index,
            "half_support_sec": half_support_sec,
        }
    )

    rate_a = full_rate_a
    rate_c = full_rate_c
    rate_b = full_rate_b
    rate_ba = rate_vector(b, ids_b, block_assignment=block_assignment, half=0)
    rate_bb = rate_vector(b, ids_b, block_assignment=block_assignment, half=1)
    x_a_rate, x_b_rate = safe_pearson(rate_a, rate_ba), safe_pearson(rate_a, rate_bb)
    y_a_rate, y_b_rate = safe_pearson(rate_ba, rate_c), safe_pearson(rate_bb, rate_c)
    rate_common = np.isfinite([x_a_rate, x_b_rate, y_a_rate, y_b_rate]).all()
    if rate_common:
        values = {"AA": (x_a_rate, y_a_rate), "BB": (x_b_rate, y_b_rate), "AB": (x_a_rate, y_b_rate), "BA": (x_b_rate, y_a_rate)}
        for orientation, (predictor, outcome) in values.items():
            orientation_rows.append(
                {
                    "readout": "rate",
                    "triplet": chain_row.triplet,
                    "animal": chain_row.animal_id,
                    "session_a": chain_row.session_a,
                    "session_b": chain_row.session_b,
                    "session_c": chain_row.session_c,
                    "unit_id": chain_row.triplet,
                    "orientation": orientation,
                    "predictor": predictor,
                    "outcome": outcome,
                }
            )
    full_x_rate, full_y_rate = safe_pearson(rate_a, rate_b), safe_pearson(rate_b, rate_c)
    if np.isfinite(full_x_rate) and np.isfinite(full_y_rate):
        full_rows.append(
            {
                "readout": "rate",
                "triplet": chain_row.triplet,
                "animal": chain_row.animal_id,
                "unit_id": chain_row.triplet,
                "predictor": full_x_rate,
                "outcome": full_y_rate,
                "on_split_common_support": bool(rate_common),
            }
        )
    support_rows.append(
        {
            "readout": "rate",
            "triplet": chain_row.triplet,
            "animal": chain_row.animal_id,
            "n_composed_registered": int(len(compose_chain(chain_row.cimap_ab, chain_row.cimap_bc))),
            "n_activity_qualified": int(len(linked)),
            "n_full_defined": int(np.isfinite(full_x_rate) and np.isfinite(full_y_rate)),
            "n_all_four_split_defined": int(rate_common),
            "split_index": split_index,
            "half_support_sec": half_support_sec,
        }
    )
    balance = audit.assign(
        triplet=chain_row.triplet,
        animal=chain_row.animal_id,
        session_b=chain_row.session_b,
        split_index=split_index,
        half_support_sec=half_support_sec,
    )
    metadata = {
        "n_composed_registered": int(len(compose_chain(chain_row.cimap_ab, chain_row.cimap_bc))),
        "n_activity_qualified": int(len(linked)),
    }
    return pd.DataFrame(orientation_rows), pd.DataFrame(full_rows), pd.DataFrame(support_rows), {"balance": balance, **metadata}


def _fit_stacked_readout(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, np.ndarray]]:
    X, names = stacked_recurrence_design(frame)
    fit = cr1_ols(frame["outcome"], X, frame["animal"].astype(str))
    contrasts = stacked_recurrence_contrasts(names)
    rows = []
    for name, contrast in contrasts.items():
        rows.append({"contrast": name, **linear_contrast(fit, contrast), "n_rows": int(fit["n"]), "n_animals": int(fit["g"])})
    return pd.DataFrame(rows), contrasts


def _mark_reuse_difference_descriptive(inference: pd.DataFrame) -> pd.DataFrame:
    """Suppress a null test for the prespecified reuse-magnitude diagnostic."""

    out = inference.copy()
    use = out["contrast"].eq("shared_minus_disjoint")
    for column in ("t", "p_two_sided"):
        if column in out:
            out.loc[use, column] = np.nan
    out.loc[use, "inference_status"] = (
        "paired animal-bootstrap interval; no hypothesis test"
    )
    out.loc[~use, "inference_status"] = "CR1 animal-clustered coefficient test"
    return out


def run_control1_recurrence(
    output: Path,
    *,
    n_splits: int,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    target = output / "04_control1_disjoint_recurrence"
    _, chains = load_pair_and_chain_scopes()
    canonical_orientations: list[pd.DataFrame] = []
    canonical_full: list[pd.DataFrame] = []
    all_support: list[pd.DataFrame] = []
    all_balance: list[pd.DataFrame] = []
    split_coefficient_rows = []
    prepared_by_chain: dict[tuple[str, str], dict[str, Any]] = {}
    for row in chains.itertuples(index=False):
        a = _stats(output, row.session_a)
        b = _stats(output, row.session_b)
        c = _stats(output, row.session_c)
        linked = compose_chain(row.cimap_ab, row.cimap_bc)
        activity = (
            (a.full_event_rate_per_min[linked[:, 0]] >= 0.1)
            & (b.full_event_rate_per_min[linked[:, 1]] >= 0.1)
            & (c.full_event_rate_per_min[linked[:, 2]] >= 0.1)
        )
        linked = linked[activity]
        prepared_by_chain[(str(row.animal_id), str(row.triplet))] = {
            "linked": linked,
            "location_a_full": aggregate_location_sums(a, linked[:, 0]),
            "location_b_full": aggregate_location_sums(b, linked[:, 1]),
            "location_c_full": aggregate_location_sums(c, linked[:, 2]),
            "full_rate_a": rate_vector(a, linked[:, 0]),
            "full_rate_b": rate_vector(b, linked[:, 1]),
            "full_rate_c": rate_vector(c, linked[:, 2]),
        }

    for split_index in [-1, *range(n_splits)]:
        split_frames = []
        full_frames = []
        for chain_number, row in enumerate(chains.itertuples(index=False), start=1):
            if split_index == -1:
                print(f"[{chain_number}/{len(chains)}] canonical recurrence {row.animal_id} {row.triplet}", flush=True)
            orientation, full, support, metadata = _chain_split_rows(
                output,
                row,
                split_index=split_index,
                half_support_sec=2.5,
                base_seed=base_seed,
                prepared=prepared_by_chain[(str(row.animal_id), str(row.triplet))],
            )
            split_frames.append(orientation)
            full_frames.append(full)
            all_support.append(support)
            all_balance.append(metadata["balance"])
        split_frame = pd.concat(split_frames, ignore_index=True)
        full_frame = pd.concat(full_frames, ignore_index=True)
        for readout, group in split_frame.groupby("readout", sort=False):
            fit_rows, _ = _fit_stacked_readout(group)
            for fit_row in fit_rows.itertuples(index=False):
                split_coefficient_rows.append(
                    {
                        "split_kind": "canonical" if split_index == -1 else "randomized",
                        "split_index": split_index,
                        "readout": readout,
                        **fit_row._asdict(),
                    }
                )
        if split_index == -1:
            canonical_orientations.append(split_frame)
            canonical_full.append(full_frame)

    canonical = pd.concat(canonical_orientations, ignore_index=True)
    full = pd.concat(canonical_full, ignore_index=True)
    _write_csv(canonical, target / "canonical_stacked_orientation_observations.csv")
    _write_csv(full, target / "corrected_full_session_recurrence_observations.csv")
    _write_csv(pd.concat(all_support, ignore_index=True), target / "recurrence_common_support_audit_all_splits.csv")
    _write_csv(pd.concat(all_balance, ignore_index=True), target / "middle_session_duration_balance_all_splits.csv")
    coefficients = pd.DataFrame(split_coefficient_rows)
    _write_csv(coefficients, target / "canonical_and_randomized_split_coefficients.csv")

    current_stats = pd.read_csv(CURRENT_CHAIN_ROOT / "consecutive_gap_clean_long_gap_corrected_stats.csv")
    current_name = {
        "place": "place_map_correlation",
        "level": "level_map_correlation",
        "pv": "pv_correlation",
        "rate": "ensemble_rate_correlation",
    }
    ladder_rows = []
    canonical_inference = []
    bootstrap_rows = []
    for readout in ("place", "level", "pv", "rate"):
        current = current_stats.loc[current_stats["metric"].eq(current_name[readout])].iloc[0]
        ladder_rows.append(
            {
                "readout": readout,
                "rung": "1_original_executed_full_session",
                "estimate": float(current["slope"]),
                "se": float(current["slope_se"]),
                "p_two_sided": float(current["p_two_sided"]),
                "n_rows": int(current["n_rows"]),
                "n_animals": int(current["n_animals"]),
            }
        )
        corrected = full.loc[full["readout"].eq(readout)]
        corrected_fit = _pair_fit(corrected, "predictor", "outcome", "animal")
        ladder_rows.append({"readout": readout, "rung": "2_corrected_full_session", **corrected_fit})
        common_full = corrected.loc[corrected["on_split_common_support"]]
        common_fit = _pair_fit(common_full, "predictor", "outcome", "animal")
        ladder_rows.append({"readout": readout, "rung": "2b_corrected_full_on_canonical_split_common_support", **common_fit})
        stacked = canonical.loc[canonical["readout"].eq(readout)]
        fit_rows, contrasts = _fit_stacked_readout(stacked)
        for contrast_name in ("shared", "disjoint", "shared_minus_disjoint"):
            record = fit_rows.loc[fit_rows["contrast"].eq(contrast_name)].iloc[0].to_dict()
            canonical_inference.append({"readout": readout, **record})
            if contrast_name in ("shared", "disjoint"):
                ladder_rows.append(
                    {
                        "readout": readout,
                        "rung": "3_symmetrized_shared_half" if contrast_name == "shared" else "4_symmetrized_disjoint_half",
                        **{key: value for key, value in record.items() if key != "contrast"},
                    }
                )
        boot = animal_bootstrap_contrasts(
            stacked,
            outcome_col="outcome",
            cluster_col="animal",
            contrasts=contrasts,
            n_bootstrap=bootstrap_repeats,
            seed=stable_seed("control1_boot", readout, base_seed=base_seed),
        )
        boot.insert(0, "readout", readout)
        bootstrap_rows.append(boot)
    ladder = pd.DataFrame(ladder_rows)
    _write_csv(ladder, target / "recurrence_coefficient_ladder.csv")
    inference = _mark_reuse_difference_descriptive(pd.DataFrame(canonical_inference))
    support = pd.concat(all_support, ignore_index=True)
    canonical_support = support.loc[support["split_index"].eq(-1)]
    rate_chains = canonical_support.loc[
        canonical_support["readout"].eq("rate") & canonical_support["n_all_four_split_defined"].astype(bool)
    ]
    rate_supported = len(rate_chains) >= 18 and rate_chains["animal"].nunique() >= 9
    family_readouts = ["place", "level", "pv", "rate"] if rate_supported else ["place", "level", "pv"]
    family_mask = inference["contrast"].eq("disjoint") & inference["readout"].isin(family_readouts)
    inference.loc[family_mask, f"p_bh{len(family_readouts)}"] = benjamini_hochberg(
        inference.loc[family_mask, "p_two_sided"].to_numpy(float)
    )
    inference["rate_family_support_passed"] = rate_supported
    inference["primary_family"] = f"BH{len(family_readouts)}: " + ";".join(family_readouts)
    _write_csv(inference, target / "canonical_stacked_recurrence_inference.csv")
    _write_csv(pd.concat(bootstrap_rows, ignore_index=True), target / "canonical_animal_bootstrap_intervals.csv")

    random_coefficients = coefficients.loc[coefficients["split_kind"].eq("randomized")]
    convergence_rows = []
    bootstrap_frame = pd.concat(bootstrap_rows, ignore_index=True)
    for readout, group in random_coefficients.loc[random_coefficients["contrast"].eq("disjoint")].groupby("readout", sort=False):
        values = group.set_index("split_index")["estimate"].sort_index()
        first12 = values.loc[values.index < 12]
        first24 = values.loc[values.index < 24]
        canonical_boot = bootstrap_frame.loc[
            bootstrap_frame["readout"].eq(readout) & bootstrap_frame["contrast"].eq("disjoint")
        ].iloc[0]
        animal_bootstrap_se = float(canonical_boot["bootstrap_sd"])
        mcse = float(first24.std(ddof=1) / np.sqrt(len(first24)))
        convergence_rows.append(
            {
                "readout": readout,
                "estimate_first12": float(first12.mean()),
                "estimate_first24": float(first24.mean()),
                "absolute_change_12_to_24": abs(float(first24.mean() - first12.mean())),
                "across_seed_sd_first24": float(first24.std(ddof=1)),
                "monte_carlo_se_first24": mcse,
                "animal_bootstrap_se_approx": animal_bootstrap_se,
                "coefficient_change_le_0.02": bool(abs(float(first24.mean() - first12.mean())) <= 0.02),
                "mcse_le_10pct_bootstrap_se": bool(mcse <= 0.1 * animal_bootstrap_se) if animal_bootstrap_se > 0 else False,
            }
        )
    _write_csv(pd.DataFrame(convergence_rows), target / "split_convergence_12_vs_24.csv")


def _metric_from_selected_indices(metrics: Mapping[str, Any], indices: np.ndarray) -> dict[str, float]:
    indices = np.asarray(indices, dtype=int)
    if indices.size < 3:
        return {"place": np.nan, "level": np.nan, "pv": np.nan, "rate": np.nan}
    output = {
        "place": float(np.nanmean(np.asarray(metrics["place_correlation"])[indices])),
        "level": float(np.nanmean(np.asarray(metrics["level_correlation"])[indices])),
    }
    place_a = np.asarray(metrics["place_map_a"])[:, indices]
    place_b = np.asarray(metrics["place_map_b"])[:, indices]
    pv = rowwise_correlations(place_a, place_b, np.asarray(metrics["place_shared"]), min_neurons=3)
    output["pv"] = float(np.nanmean(pv)) if np.isfinite(pv).any() else np.nan
    output["rate"] = safe_pearson(np.asarray(metrics["rate_a"])[indices], np.asarray(metrics["rate_b"])[indices])
    return output


def _standardized_cross_correlation_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    x = np.asarray(a, dtype=float)
    y = np.asarray(b, dtype=float)
    if x.shape[0] < 2:
        return np.full((x.shape[1], y.shape[1]), np.nan)
    x = x - np.nanmean(x, axis=0, keepdims=True)
    y = y - np.nanmean(y, axis=0, keepdims=True)
    x_norm = np.sqrt(np.nansum(x * x, axis=0))
    y_norm = np.sqrt(np.nansum(y * y, axis=0))
    denominator = np.outer(x_norm, y_norm)
    result = x.T @ y
    return np.divide(result, denominator, out=np.full_like(result, np.nan), where=denominator > 0)


def _strict_pair_shuffle_null(
    metrics: Mapping[str, Any],
    indices: np.ndarray,
    *,
    repeats: int,
    seed: int,
) -> dict[str, np.ndarray]:
    indices = np.asarray(indices, dtype=int)
    n = int(indices.size)
    result = {name: np.full(repeats, np.nan) for name in ("place", "level", "pv", "rate")}
    if n < 3:
        return result
    rng = np.random.default_rng(seed)
    place_shared = np.asarray(metrics["place_shared"], bool)
    level_shared = np.asarray(metrics["level_shared"], bool)
    place_a = np.asarray(metrics["place_map_a"])[place_shared][:, indices]
    place_b = np.asarray(metrics["place_map_b"])[place_shared][:, indices]
    level_a = np.asarray(metrics["level_map_a"])[level_shared][:, indices]
    level_b = np.asarray(metrics["level_map_b"])[level_shared][:, indices]
    place_cross = _standardized_cross_correlation_matrix(place_a, place_b)
    level_cross = _standardized_cross_correlation_matrix(level_a, level_b)
    rate_a = np.asarray(metrics["rate_a"])[indices]
    rate_b = np.asarray(metrics["rate_b"])[indices]
    place_a_row = place_a - place_a.mean(axis=1, keepdims=True)
    place_b_row = place_b - place_b.mean(axis=1, keepdims=True)
    place_row_denominator = np.sqrt(
        np.sum(place_a_row * place_a_row, axis=1)
        * np.sum(place_b_row * place_b_row, axis=1)
    )
    for repeat in range(repeats):
        permutation = rng.permutation(n)
        result["place"][repeat] = np.nanmean(place_cross[np.arange(n), permutation])
        pv_values = np.divide(
            np.sum(place_a_row * place_b_row[:, permutation], axis=1),
            place_row_denominator,
            out=np.full(place_a_row.shape[0], np.nan),
            where=place_row_denominator > 0,
        )
        result["pv"][repeat] = np.nanmean(pv_values)
        result["rate"][repeat] = safe_pearson(rate_a, rate_b[permutation])
        level_permutation = rng.permutation(n)
        result["level"][repeat] = np.nanmean(level_cross[np.arange(n), level_permutation])
    return result


def _chain_full_rows_from_linked(
    output: Path,
    chain_row: Any,
    linked: np.ndarray,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    a = _stats(output, chain_row.session_a)
    b = _stats(output, chain_row.session_b)
    c = _stats(output, chain_row.session_c)
    linked = np.asarray(linked, dtype=int)
    rows = []
    support = []
    maps: dict[str, dict[str, Mapping[str, np.ndarray]]] = {}
    for readout, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        map_a = fit_representation_map(a, representation, linked[:, 0], min_occupancy_sec=5.0)
        map_b = fit_representation_map(b, representation, linked[:, 1], min_occupancy_sec=5.0)
        map_c = fit_representation_map(c, representation, linked[:, 2], min_occupancy_sec=5.0)
        maps[readout] = {"a": map_a, "b": map_b, "c": map_c}
        min_labels = REPRESENTATION_MIN_LABELS[representation]
        x = _correlate_map_pair(map_a, map_b, min_labels=min_labels)
        y = _correlate_map_pair(map_b, map_c, min_labels=min_labels)
        valid = np.isfinite(x) & np.isfinite(y)
        for index in np.flatnonzero(valid):
            rows.append(
                {
                    "readout": readout,
                    "triplet": chain_row.triplet,
                    "animal": chain_row.animal_id,
                    "unit_id": f"{linked[index,0]}->{linked[index,1]}->{linked[index,2]}",
                    "predictor": x[index],
                    "outcome": y[index],
                }
            )
        support.append({"readout": readout, "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(linked), "n_defined": int(valid.sum())})
    place = maps["place"]
    shared = place["a"]["valid_mask"] & place["b"]["valid_mask"] & place["c"]["valid_mask"]
    x_pv = rowwise_correlations(place["a"]["rate_map"], place["b"]["rate_map"], shared, min_neurons=3)
    y_pv = rowwise_correlations(place["b"]["rate_map"], place["c"]["rate_map"], shared, min_neurons=3)
    valid_pv = np.isfinite(x_pv) & np.isfinite(y_pv)
    for location in np.flatnonzero(valid_pv):
        rows.append({"readout": "pv", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "unit_id": str(location), "predictor": x_pv[location], "outcome": y_pv[location]})
    support.append({"readout": "pv", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(linked), "n_defined": int(valid_pv.sum())})
    rate_a = rate_vector(a, linked[:, 0])
    rate_b = rate_vector(b, linked[:, 1])
    rate_c = rate_vector(c, linked[:, 2])
    x_rate, y_rate = safe_pearson(rate_a, rate_b), safe_pearson(rate_b, rate_c)
    if len(linked) >= 3 and np.isfinite(x_rate) and np.isfinite(y_rate):
        rows.append({"readout": "rate", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "unit_id": chain_row.triplet, "predictor": x_rate, "outcome": y_rate})
    support.append({"readout": "rate", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(linked), "n_defined": int(len(linked) >= 3 and np.isfinite(x_rate) and np.isfinite(y_rate))})
    return pd.DataFrame(rows), pd.DataFrame(support)


def _prepare_chain_full_metrics(output: Path, chain_row: Any) -> dict[str, Any]:
    a = _stats(output, chain_row.session_a)
    b = _stats(output, chain_row.session_b)
    c = _stats(output, chain_row.session_c)
    linked = compose_chain(chain_row.cimap_ab, chain_row.cimap_bc)
    activity = (
        (a.full_event_rate_per_min[linked[:, 0]] >= 0.1)
        & (b.full_event_rate_per_min[linked[:, 1]] >= 0.1)
        & (c.full_event_rate_per_min[linked[:, 2]] >= 0.1)
    )
    linked = linked[activity]
    locations = {
        "a": aggregate_location_sums(a, linked[:, 0]),
        "b": aggregate_location_sums(b, linked[:, 1]),
        "c": aggregate_location_sums(c, linked[:, 2]),
    }
    maps = {}
    for readout, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        maps[readout] = {
            label: fit_representation_from_location_sums(value, representation, min_occupancy_sec=5.0)
            for label, value in locations.items()
        }
    return {
        "linked": linked,
        "maps": maps,
        "rate_a": rate_vector(a, linked[:, 0]),
        "rate_b": rate_vector(b, linked[:, 1]),
        "rate_c": rate_vector(c, linked[:, 2]),
    }


def _chain_full_rows_from_prepared(
    chain_row: Any,
    prepared: Mapping[str, Any],
    indices: np.ndarray,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    indices = np.asarray(indices, dtype=int)
    linked = np.asarray(prepared["linked"], dtype=int)[indices]
    rows = []
    support = []
    selected_maps: dict[str, dict[str, dict[str, np.ndarray]]] = {}
    for readout, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        selected_maps[readout] = {}
        for label in ("a", "b", "c"):
            original = prepared["maps"][readout][label]
            selected_maps[readout][label] = {
                "rate_map": np.asarray(original["rate_map"])[:, indices],
                "valid_mask": np.asarray(original["valid_mask"]),
            }
        map_a, map_b, map_c = (
            selected_maps[readout]["a"],
            selected_maps[readout]["b"],
            selected_maps[readout]["c"],
        )
        x = _correlate_map_pair(map_a, map_b, min_labels=REPRESENTATION_MIN_LABELS[representation])
        y = _correlate_map_pair(map_b, map_c, min_labels=REPRESENTATION_MIN_LABELS[representation])
        valid = np.isfinite(x) & np.isfinite(y)
        for index in np.flatnonzero(valid):
            rows.append(
                {
                    "readout": readout,
                    "triplet": chain_row.triplet,
                    "animal": chain_row.animal_id,
                    "unit_id": f"{linked[index,0]}->{linked[index,1]}->{linked[index,2]}",
                    "predictor": x[index],
                    "outcome": y[index],
                }
            )
        support.append({"readout": readout, "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(indices), "n_defined": int(valid.sum())})
    place = selected_maps["place"]
    shared = place["a"]["valid_mask"] & place["b"]["valid_mask"] & place["c"]["valid_mask"]
    x_pv = rowwise_correlations(place["a"]["rate_map"], place["b"]["rate_map"], shared, min_neurons=3)
    y_pv = rowwise_correlations(place["b"]["rate_map"], place["c"]["rate_map"], shared, min_neurons=3)
    valid_pv = np.isfinite(x_pv) & np.isfinite(y_pv)
    for location in np.flatnonzero(valid_pv):
        rows.append({"readout": "pv", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "unit_id": str(location), "predictor": x_pv[location], "outcome": y_pv[location]})
    support.append({"readout": "pv", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(indices), "n_defined": int(valid_pv.sum())})
    rate_a = np.asarray(prepared["rate_a"])[indices]
    rate_b = np.asarray(prepared["rate_b"])[indices]
    rate_c = np.asarray(prepared["rate_c"])[indices]
    x_rate, y_rate = safe_pearson(rate_a, rate_b), safe_pearson(rate_b, rate_c)
    if len(indices) >= 3 and np.isfinite(x_rate) and np.isfinite(y_rate):
        rows.append({"readout": "rate", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "unit_id": chain_row.triplet, "predictor": x_rate, "outcome": y_rate})
    support.append({"readout": "rate", "triplet": chain_row.triplet, "animal": chain_row.animal_id, "n_linked": len(indices), "n_defined": int(len(indices) >= 3 and np.isfinite(x_rate) and np.isfinite(y_rate))})
    return pd.DataFrame(rows), pd.DataFrame(support)


def _pair_registration_table() -> pd.DataFrame:
    features = pd.read_csv(REGISTRATION_ROOT / "registered_pair_features_long.csv", dtype={"animal": str})
    numeric = [
        "cluster_index",
        "session1_cell_id_corrected",
        "session2_cell_id_corrected",
        "cellreg_registration_score",
        "centroid_distance_um",
        "spatial_footprint_correlation",
    ]
    for column in numeric:
        features[column] = pd.to_numeric(features[column], errors="coerce")
    features["src_cell_id_zero"] = features["session1_cell_id_corrected"].astype(int) - 1
    features["dst_cell_id_zero"] = features["session2_cell_id_corrected"].astype(int) - 1
    margins = pd.read_csv(
        REGISTRATION_EXTRA_ROOT / "hard_negative_registration_conservative_margins.csv",
        dtype={"animal": str},
    )
    for column in ("cluster_index", "conservative_distance_advantage_um", "conservative_correlation_advantage", "n_informative_directions"):
        margins[column] = pd.to_numeric(margins[column], errors="coerce")
    return features.merge(
        margins[
            [
                "pair_label",
                "cluster_index",
                "n_informative_directions",
                "conservative_distance_advantage_um",
                "conservative_correlation_advantage",
            ]
        ],
        on=["pair_label", "cluster_index"],
        how="left",
        validate="one_to_one",
    )


def _strict_pair_outputs(
    output: Path,
    *,
    thresholds: Sequence[float],
    count_draws: int,
    shuffle_repeats: int,
    base_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pairs, _ = load_pair_and_chain_scopes()
    registrations = _pair_registration_table()
    result_rows = []
    support_rows = []
    count_rows = []
    null_pair_arrays: dict[str, list[np.ndarray]] = defaultdict(list)
    for pair_number, row in enumerate(pairs.loc[pairs["primary_36"]].itertuples(index=False), start=1):
        print(f"[{pair_number}/36] CellReg pair {row.pair_label}", flush=True)
        a = _stats(output, row.session1)
        b = _stats(output, row.session2)
        metrics = full_pair_metrics(a, b, load_cimap(row.cimap_path))
        active_coordinates = pd.DataFrame(
            {
                "active_index": np.arange(len(metrics["ids_a"])),
                "src_cell_id_zero": metrics["ids_a"],
                "dst_cell_id_zero": metrics["ids_b"],
            }
        )
        pair_reg = registrations.loc[
            registrations["pair_label"].eq(row.pair_label),
            ["src_cell_id_zero", "dst_cell_id_zero", "cellreg_registration_score"],
        ]
        active_coordinates = active_coordinates.merge(pair_reg, on=["src_cell_id_zero", "dst_cell_id_zero"], how="left", validate="one_to_one")
        if active_coordinates["cellreg_registration_score"].isna().any():
            raise AssertionError(f"Missing CellReg scores after one-to-one join: {row.pair_label}")
        for threshold in thresholds:
            strict_all = active_coordinates.loc[active_coordinates["cellreg_registration_score"] >= threshold, "active_index"].to_numpy(int)
            eligible_by_readout = {
                "place": np.flatnonzero(np.isfinite(metrics["place_correlation"])),
                "level": np.flatnonzero(np.isfinite(metrics["level_correlation"])),
                "pv": np.arange(len(active_coordinates), dtype=int),
                "rate": np.arange(len(active_coordinates), dtype=int),
            }
            for readout, eligible in eligible_by_readout.items():
                strict = np.intersect1d(strict_all, eligible, assume_unique=True)
                value = _metric_from_selected_indices(metrics, strict)[readout]
                result_rows.append(
                    {
                        "threshold": threshold,
                        "pair_id": row.pair_id,
                        "pair_label": row.pair_label,
                        "animal": row.animal,
                        "readout": readout,
                        "pair_value": value,
                        "n_full_readout_eligible": int(eligible.size),
                        "n_strict_readout_eligible": int(strict.size),
                        "retains_at_least_100": bool(strict.size >= 100),
                    }
                )
                support_rows.append(
                    {
                        "threshold": threshold,
                        "pair_id": row.pair_id,
                        "pair_label": row.pair_label,
                        "animal": row.animal,
                        "readout": readout,
                        "n_full_activity_registered": int(len(active_coordinates)),
                        "n_full_readout_eligible": int(eligible.size),
                        "n_strict_readout_eligible": int(strict.size),
                        "strict_fraction_of_readout_eligible": float(strict.size / eligible.size) if eligible.size else np.nan,
                        "retains_at_least_100": bool(strict.size >= 100),
                    }
                )
                rng = np.random.default_rng(stable_seed("cellreg_count", row.pair_label, threshold, readout, base_seed=base_seed))
                for draw in range(count_draws):
                    sampled = rng.choice(eligible, size=len(strict), replace=False) if len(strict) else np.array([], int)
                    value = _metric_from_selected_indices(metrics, sampled)[readout]
                    count_rows.append(
                        {
                            "threshold": threshold,
                            "pair_id": row.pair_id,
                            "pair_label": row.pair_label,
                            "animal": row.animal,
                            "draw": draw,
                            "readout": readout,
                            "pair_value": value,
                            "n_sampled": int(len(sampled)),
                        }
                    )
            if math.isclose(float(threshold), 0.95):
                pair_null = _strict_pair_shuffle_null(
                    metrics,
                    strict_all,
                    repeats=shuffle_repeats,
                    seed=stable_seed("cellreg_null", row.pair_label, base_seed=base_seed),
                )
                for readout, values in pair_null.items():
                    null_pair_arrays[readout].append(values)
    null_rows = []
    strict_results = pd.DataFrame(result_rows)
    for readout, arrays in null_pair_arrays.items():
        cohort = np.nanmean(np.vstack(arrays), axis=0)
        observed = strict_results.loc[
            np.isclose(strict_results["threshold"], 0.95) & strict_results["readout"].eq(readout), "pair_value"
        ].mean()
        p_right = (1 + int(np.sum(cohort >= observed))) / (1 + int(np.isfinite(cohort).sum()))
        null_rows.append(
            {
                "threshold": 0.95,
                "readout": readout,
                "observed_equal_pair_mean": observed,
                "shuffle_equal_pair_mean": float(np.nanmean(cohort)),
                "observed_minus_shuffle": float(observed - np.nanmean(cohort)),
                "right_tailed_plus_one_p": p_right,
                "n_shuffles": int(np.isfinite(cohort).sum()),
            }
        )
    return strict_results, pd.DataFrame(support_rows), pd.DataFrame(count_rows), pd.DataFrame(null_rows)


def _strict_chain_outputs(
    output: Path,
    *,
    thresholds: Sequence[float],
    count_draws: int,
    base_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    _, chains = load_pair_and_chain_scopes()
    registrations = _pair_registration_table()
    result_rows = []
    support_rows = []
    count_slope_rows = []
    prepared_by_chain = {
        (str(row.animal_id), str(row.triplet)): _prepare_chain_full_metrics(output, row)
        for row in chains.itertuples(index=False)
    }
    for threshold in thresholds:
        threshold_frames = []
        draw_frames: dict[int, list[pd.DataFrame]] = defaultdict(list)
        for row in chains.itertuples(index=False):
            prepared = prepared_by_chain[(str(row.animal_id), str(row.triplet))]
            linked = np.asarray(prepared["linked"], dtype=int)
            score_ab = registrations.loc[registrations["pair_label"].eq(row.pair_ab), ["src_cell_id_zero", "dst_cell_id_zero", "cellreg_registration_score"]].rename(
                columns={"src_cell_id_zero": "a", "dst_cell_id_zero": "b", "cellreg_registration_score": "score_ab"}
            )
            score_bc = registrations.loc[registrations["pair_label"].eq(row.pair_bc), ["src_cell_id_zero", "dst_cell_id_zero", "cellreg_registration_score"]].rename(
                columns={"src_cell_id_zero": "b", "dst_cell_id_zero": "c", "cellreg_registration_score": "score_bc"}
            )
            linked_frame = pd.DataFrame(linked, columns=["a", "b", "c"])
            linked_frame.insert(0, "active_index", np.arange(len(linked_frame), dtype=int))
            linked_frame = linked_frame.merge(score_ab, on=["a", "b"], how="left", validate="one_to_one").merge(score_bc, on=["b", "c"], how="left", validate="one_to_one")
            if linked_frame[["score_ab", "score_bc"]].isna().any().any():
                raise AssertionError(f"Missing chain registration score: {row.animal_id} {row.triplet}")
            strict_indices = linked_frame.loc[(linked_frame["score_ab"] >= threshold) & (linked_frame["score_bc"] >= threshold), "active_index"].to_numpy(int)
            frame, support = _chain_full_rows_from_prepared(row, prepared, strict_indices)
            frame["threshold"] = threshold
            threshold_frames.append(frame)
            support["threshold"] = threshold
            support["n_full_activity_chain"] = int(len(linked_frame))
            support["n_strict_chain"] = int(len(strict_indices))
            support_rows.append(support)

            rng = np.random.default_rng(stable_seed("cellreg_chain_count", row.animal_id, row.triplet, threshold, base_seed=base_seed))
            for draw in range(count_draws):
                sampled_rows = rng.choice(len(linked_frame), size=len(strict_indices), replace=False) if len(strict_indices) else np.array([], int)
                draw_frame, _ = _chain_full_rows_from_prepared(row, prepared, sampled_rows)
                draw_frame["threshold"] = threshold
                draw_frame["draw"] = draw
                # The same sampled three-session identities enter both edges;
                # inference is deferred until the same draw is pooled over chains.
                draw_frames[draw].append(draw_frame)
        combined = pd.concat(threshold_frames, ignore_index=True)
        for readout, group in combined.groupby("readout", sort=False):
            fit = _pair_fit(group, "predictor", "outcome", "animal")
            result_rows.append({"threshold": threshold, "readout": readout, **fit})
        for draw, frames in draw_frames.items():
            combined_draw = pd.concat(frames, ignore_index=True)
            for readout, group in combined_draw.groupby("readout", sort=False):
                fit = _pair_fit(group, "predictor", "outcome", "animal")
                count_slope_rows.append(
                    {
                        "threshold": threshold,
                        "draw": draw,
                        "readout": readout,
                        "count_matched_slope": fit["estimate"],
                        "n_rows": fit["n_rows"],
                        "n_animals": fit["n_animals"],
                    }
                )
    return pd.DataFrame(result_rows), pd.concat(support_rows, ignore_index=True), pd.DataFrame(count_slope_rows)


def _within_pair_spearman_associations(cell_frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    predictor_columns = {
        "cellreg_score_percentile": "cellreg_score_percentile",
        "distance_advantage": "conservative_distance_advantage_um",
        "footprint_advantage": "conservative_correlation_advantage",
    }
    diagnostics = []
    pair_coefficients = []
    qualification = []
    for pair_label, pair in cell_frame.groupby("pair_label", sort=False):
        score = pair["cellreg_registration_score"]
        diagnostics.append(
            {
                "pair_label": pair_label,
                "animal": str(pair["animal"].iloc[0]),
                "n_rows": int(len(pair)),
                "score_iqr": float(score.quantile(0.75) - score.quantile(0.25)),
                "score_unique_values": int(score.nunique()),
                "score_min": float(score.min()),
                "score_median": float(score.median()),
                "score_max": float(score.max()),
                "distance_margin_nonmissing": int(pair["conservative_distance_advantage_um"].notna().sum()),
                "footprint_margin_nonmissing": int(pair["conservative_correlation_advantage"].notna().sum()),
            }
        )
    for (metric, pair_label), pair in cell_frame.groupby(["metric", "pair_label"], sort=False):
        pair = pair.copy()
        pair["cellreg_score_percentile"] = pair["cellreg_registration_score"].rank(method="average", pct=True)
        animal = str(pair["animal"].iloc[0])
        for predictor_name, predictor_col in predictor_columns.items():
            eligible = pair[[predictor_col, "correlation"]].dropna()
            qualifies = len(eligible) >= 20 and eligible[predictor_col].nunique() > 1
            rho = np.nan
            z = np.nan
            exact = False
            if qualifies:
                rho = float(stats.spearmanr(eligible[predictor_col], eligible["correlation"]).statistic)
                exact = bool(np.isclose(abs(rho), 1.0))
                if np.isfinite(rho) and not exact:
                    z = float(np.arctanh(rho))
            pair_coefficients.append(
                {
                    "metric": metric,
                    "pair_label": pair_label,
                    "animal": animal,
                    "predictor": predictor_name,
                    "n_eligible": int(len(eligible)),
                    "qualifies_n20_nonzero_variance": qualifies,
                    "spearman_rho": rho,
                    "exact_abs_rho_one_omitted_from_inference": exact,
                    "fisher_z": z,
                }
            )
            qualification.append(
                {
                    "metric": metric,
                    "pair_label": pair_label,
                    "animal": animal,
                    "predictor": predictor_name,
                    "qualifies": qualifies and not exact and np.isfinite(z),
                    "baseline_stability_mean": float(pair["correlation"].mean()),
                    "n_total_cells": int(len(pair)),
                }
            )
    coefficients = pd.DataFrame(pair_coefficients)
    inference_rows = []
    for (metric, predictor), group in coefficients.groupby(["metric", "predictor"], sort=False):
        use = group.loc[group["fisher_z"].notna()]
        fit = _intercept_test(use["fisher_z"], use["animal"])
        inference_rows.append({"metric": metric, "predictor": predictor, **fit})
    inference = pd.DataFrame(inference_rows)
    inference["p_bh6"] = benjamini_hochberg(inference["p_two_sided"].to_numpy(float))
    qualification_frame = pd.DataFrame(qualification)
    qualification_rows = []
    for (metric, predictor), group in qualification_frame.groupby(["metric", "predictor"], sort=False):
        qualifies = group.loc[group["qualifies"]]
        does_not = group.loc[~group["qualifies"]]
        qualification_rows.append(
            {
                "metric": metric,
                "predictor": predictor,
                "n_qualifying_pairs": int(qualifies["pair_label"].nunique()),
                "n_nonqualifying_pairs": int(does_not["pair_label"].nunique()),
                "mean_baseline_stability_qualifying": float(qualifies["baseline_stability_mean"].mean()) if len(qualifies) else np.nan,
                "mean_baseline_stability_nonqualifying": float(does_not["baseline_stability_mean"].mean()) if len(does_not) else np.nan,
            }
        )
    return (
        pd.DataFrame(diagnostics),
        coefficients,
        inference.merge(pd.DataFrame(qualification_rows), on=["metric", "predictor"], how="left", validate="one_to_one"),
    )


def _weighted_pair_fixed_effect_fit(
    frame: pd.DataFrame,
    *,
    focal: str,
    quality_terms: list[str],
) -> dict[str, Any]:
    data = frame[["pair_label", "animal", "correlation", focal, *quality_terms]].dropna().copy()
    pair_counts = data.groupby("pair_label")["correlation"].transform("size").to_numpy(float)
    weights = 1.0 / pair_counts
    dummies = pd.get_dummies(data["pair_label"], dtype=float).to_numpy(float)
    terms = [focal, *quality_terms]
    numeric = data[terms].to_numpy(float)
    X = np.column_stack([dummies, numeric])
    sqrt_w = np.sqrt(weights)
    rank = np.linalg.matrix_rank(X * sqrt_w[:, None])
    if rank < X.shape[1]:
        raise np.linalg.LinAlgError("weighted fixed-effect design is rank deficient")
    fit = cr1_ols(data["correlation"].to_numpy(float) * sqrt_w, X * sqrt_w[:, None], data["animal"].astype(str))
    contrast = np.zeros(X.shape[1])
    contrast[dummies.shape[1]] = 1.0
    result = linear_contrast(fit, contrast)
    return {**result, "n_neurons": int(len(data)), "n_pairs": int(data["pair_label"].nunique()), "n_animals": int(data["animal"].nunique()), "quality_terms": ";".join(quality_terms), "equal_pair_total_weight": True}


def _sampling_quality_models(output: Path, cells: pd.DataFrame) -> pd.DataFrame:
    reliability = pd.read_csv(output / "03_control3_reliability" / "split_averaged_neuron_reliability.csv")
    validity_column = (
        "meets_minimum_valid_splits"
        if "meets_minimum_valid_splits" in reliability.columns
        else "meets_20_of_24"
    )
    reliability = reliability.loc[
        reliability["support_rule"].eq("primary_2.5s")
        & reliability["comparison"].eq("level_minus_place")
        & reliability[validity_column].astype(bool)
    ]
    pairs, _ = load_pair_and_chain_scopes()
    pairs_by_label = pairs.set_index("pair_label")
    rows = []
    occupancy_support_cache: dict[tuple[str, str], int] = {}
    for metric, representation in (("place", "place15x15"), ("level", "tree_depth7")):
        work = cells.loc[cells["metric"].eq(metric)].copy()
        work["source_session"] = work["pair_label"].map(pairs_by_label["session1"])
        work["target_session"] = work["pair_label"].map(pairs_by_label["session2"])
        source = reliability.loc[reliability["representation"].eq(representation), ["session_id", "cell_id_zero", "mean_raw_split_correlation"]].rename(
            columns={"session_id": "source_session", "cell_id_zero": "src_cell_id_zero", "mean_raw_split_correlation": "source_raw_reliability"}
        )
        target = reliability.loc[reliability["representation"].eq(representation), ["session_id", "cell_id_zero", "mean_raw_split_correlation"]].rename(
            columns={"session_id": "target_session", "cell_id_zero": "dst_cell_id_zero", "mean_raw_split_correlation": "target_raw_reliability"}
        )
        work = work.merge(source, on=["source_session", "src_cell_id_zero"], how="left", validate="many_to_one").merge(target, on=["target_session", "dst_cell_id_zero"], how="left", validate="many_to_one")
        work["source_log_activity"] = np.log1p(work["src_event_rate_per_min"])
        work["target_log_activity"] = np.log1p(work["dst_event_rate_per_min"])
        # Occupancy support is representation/session specific but common to all
        # cells in a pair; it remains separate for source and target as required.
        source_support = []
        target_support = []
        for record in work.itertuples(index=False):
            src_key = (record.source_session, representation)
            dst_key = (record.target_session, representation)
            if src_key not in occupancy_support_cache:
                src_map = fit_representation_map(
                    _stats(output, record.source_session),
                    representation,
                    [int(record.src_cell_id_zero)],
                    min_occupancy_sec=5.0,
                )
                occupancy_support_cache[src_key] = int(src_map["valid_mask"].sum())
            if dst_key not in occupancy_support_cache:
                dst_map = fit_representation_map(
                    _stats(output, record.target_session),
                    representation,
                    [int(record.dst_cell_id_zero)],
                    min_occupancy_sec=5.0,
                )
                occupancy_support_cache[dst_key] = int(dst_map["valid_mask"].sum())
            source_support.append(occupancy_support_cache[src_key])
            target_support.append(occupancy_support_cache[dst_key])
        work["source_log_occupancy_support"] = np.log1p(source_support)
        work["target_log_occupancy_support"] = np.log1p(target_support)
        work["cellreg_score_percentile"] = work.groupby("pair_label")["cellreg_registration_score"].rank(method="average", pct=True)
        quality = [
            "source_raw_reliability",
            "target_raw_reliability",
            "source_log_activity",
            "target_log_activity",
            "source_log_occupancy_support",
            "target_log_occupancy_support",
        ]
        for focal in ("cellreg_score_percentile", "conservative_distance_advantage_um", "conservative_correlation_advantage"):
            terms = quality.copy()
            hierarchy_step = "full"
            while True:
                try:
                    fit = _weighted_pair_fixed_effect_fit(work, focal=focal, quality_terms=terms)
                    rows.append({"metric": metric, "focal": focal, "hierarchy_step": hierarchy_step, **fit})
                    break
                except (np.linalg.LinAlgError, ValueError):
                    if any("occupancy" in term for term in terms):
                        terms = [term for term in terms if "occupancy" not in term]
                        hierarchy_step = "occupancy_terms_removed_for_collinearity"
                    elif any("activity" in term for term in terms):
                        terms = [term for term in terms if "activity" not in term]
                        hierarchy_step = "occupancy_and_activity_terms_removed_for_collinearity"
                    else:
                        rows.append({"metric": metric, "focal": focal, "hierarchy_step": "failed_after_predeclared_hierarchy", "estimate": np.nan, "se": np.nan, "p_two_sided": np.nan})
                        break
    return pd.DataFrame(rows)


def _fov_displacement_models(output: Path) -> pd.DataFrame:
    fov = pd.read_csv(REGISTRATION_EXTRA_ROOT / "physical_fov_exact_36_source.csv", dtype={"animal": str})
    pair_summary = pd.read_csv(output / "02_corrected_baseline" / "corrected_pair_metric_summary_37_with_primary36.csv", dtype={"animal": str})
    pair_summary = pair_summary.loc[pair_summary["primary_36"].astype(bool)]
    merged = pair_summary.merge(
        fov[["pair_label", "displacement_percent_source_fov_diagonal", "experience"]],
        on="pair_label",
        how="inner",
        validate="many_to_one",
    )
    rows = []
    for metric, group in merged.groupby("metric", sort=False):
        y = group["pair_value"].to_numpy(float)
        displacement = pd.to_numeric(group["displacement_percent_source_fov_diagonal"]).to_numpy(float)
        gap_position = pd.to_numeric(group["experience"]).to_numpy(float)
        X = np.column_stack([np.ones(len(group)), displacement, gap_position])
        fit = cr1_ols(y, X, group["animal"].astype(str))
        rows.append(
            {
                "metric": metric,
                "predictor": "adjacent_displacement_percent_earlier_fov_diagonal",
                **linear_contrast(fit, [0, 1, 0]),
                "gap_position_adjusted": True,
                "n_pairs": int(fit["n"]),
                "n_animals": int(fit["g"]),
                "inferential_family": "descriptive_no_new_hypothesis_family",
            }
        )
    return pd.DataFrame(rows)


def run_control2_cellreg(
    output: Path,
    *,
    count_draws: int,
    shuffle_repeats: int,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    target = output / "05_control2_cellreg"
    thresholds = (0.90, 0.95, 0.99)
    pair_results, pair_support, count_results, null_results = _strict_pair_outputs(
        output,
        thresholds=thresholds,
        count_draws=count_draws,
        shuffle_repeats=shuffle_repeats,
        base_seed=base_seed,
    )
    _write_csv(pair_results, target / "strict_threshold_pair_metrics.csv")
    _write_csv(pair_support, target / "strict_threshold_pair_support.csv")
    _write_csv(count_results, target / "within_pair_count_matched_draws.csv")
    _write_csv(null_results, target / "strict_095_identity_shuffle_nulls.csv")
    pair_summary_rows = []
    count_averaged = count_results.groupby(["threshold", "pair_id", "pair_label", "animal", "readout"], as_index=False)["pair_value"].mean()
    for (threshold, readout), group in pair_results.groupby(["threshold", "readout"], sort=False):
        for scope, use in (("all_surviving_pairs", group), ("pairs_retaining_at_least_100", group.loc[group["retains_at_least_100"]])):
            match = count_averaged.loc[np.isclose(count_averaged["threshold"], threshold) & count_averaged["readout"].eq(readout)]
            joined = use.merge(match[["pair_id", "pair_value"]].rename(columns={"pair_value": "count_matched_value"}), on="pair_id", how="left", validate="one_to_one")
            pair_summary_rows.append(
                {
                    "threshold": threshold,
                    "readout": readout,
                    "scope": scope,
                    "strict_equal_pair_mean": float(joined["pair_value"].mean()),
                    "count_matched_equal_pair_mean": float(joined["count_matched_value"].mean()),
                    "strict_minus_count_matched": float((joined["pair_value"] - joined["count_matched_value"]).mean()),
                    "n_pairs": int(joined["pair_id"].nunique()),
                    "n_animals": int(joined["animal"].nunique()),
                    "inference_status": "0.95 robustness estimate; 0.90/0.99 descriptive; strict-minus-count-matched descriptive",
                }
            )
    _write_csv(pd.DataFrame(pair_summary_rows), target / "strict_threshold_pair_summary.csv")

    chain_results, chain_support, chain_count = _strict_chain_outputs(
        output,
        thresholds=thresholds,
        count_draws=count_draws,
        base_seed=base_seed,
    )
    _write_csv(chain_results, target / "strict_threshold_recurrence_slopes.csv")
    _write_csv(chain_support, target / "strict_threshold_chain_joint_pass_audit.csv")
    _write_csv(chain_count, target / "within_chain_count_matched_draws.csv")

    refresh_control2_summaries(
        output,
        bootstrap_repeats=bootstrap_repeats,
        base_seed=base_seed,
    )

    run_control2_postprocessing(output)


def refresh_control2_summaries(
    output: Path,
    *,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    """Add biological-unit intervals and count-match summaries to Control 2."""

    target = output / "05_control2_cellreg"
    pair_results = pd.read_csv(
        target / "strict_threshold_pair_metrics.csv", dtype={"animal": str}
    )
    count_results = pd.read_csv(
        target / "within_pair_count_matched_draws.csv", dtype={"animal": str}
    )
    count_averaged = count_results.groupby(
        ["threshold", "pair_id", "pair_label", "animal", "readout"],
        as_index=False,
    )["pair_value"].mean()
    rows: list[dict[str, Any]] = []
    for (threshold, readout), group in pair_results.groupby(
        ["threshold", "readout"], sort=False
    ):
        for scope, use in (
            ("all_surviving_pairs", group),
            (
                "pairs_retaining_at_least_100",
                group.loc[group["retains_at_least_100"].astype(bool)],
            ),
        ):
            match = count_averaged.loc[
                np.isclose(count_averaged["threshold"], threshold)
                & count_averaged["readout"].eq(readout)
            ]
            joined = use.merge(
                match[["pair_id", "pair_value"]].rename(
                    columns={"pair_value": "count_matched_value"}
                ),
                on="pair_id",
                how="left",
                validate="one_to_one",
            )
            joined["strict_minus_count_matched"] = (
                joined["pair_value"] - joined["count_matched_value"]
            )
            strict_boot = _animal_bootstrap_mean(
                joined,
                value_col="pair_value",
                animal_col="animal",
                repeats=bootstrap_repeats,
                seed=stable_seed(
                    "control2_strict_pair",
                    threshold,
                    readout,
                    scope,
                    base_seed=base_seed,
                ),
            )
            matched_boot = _animal_bootstrap_mean(
                joined,
                value_col="count_matched_value",
                animal_col="animal",
                repeats=bootstrap_repeats,
                seed=stable_seed(
                    "control2_count_pair",
                    threshold,
                    readout,
                    scope,
                    base_seed=base_seed,
                ),
            )
            difference_boot = _animal_bootstrap_mean(
                joined,
                value_col="strict_minus_count_matched",
                animal_col="animal",
                repeats=bootstrap_repeats,
                seed=stable_seed(
                    "control2_pair_difference",
                    threshold,
                    readout,
                    scope,
                    base_seed=base_seed,
                ),
            )
            rows.append(
                {
                    "threshold": threshold,
                    "readout": readout,
                    "scope": scope,
                    "strict_equal_pair_mean": strict_boot["estimate"],
                    "strict_bootstrap_ci_low": strict_boot["bootstrap_ci_low"],
                    "strict_bootstrap_ci_high": strict_boot["bootstrap_ci_high"],
                    "count_matched_equal_pair_mean": matched_boot["estimate"],
                    "count_matched_bootstrap_ci_low": matched_boot["bootstrap_ci_low"],
                    "count_matched_bootstrap_ci_high": matched_boot["bootstrap_ci_high"],
                    "strict_minus_count_matched": difference_boot["estimate"],
                    "difference_bootstrap_ci_low": difference_boot["bootstrap_ci_low"],
                    "difference_bootstrap_ci_high": difference_boot["bootstrap_ci_high"],
                    "bootstrap_repeats": bootstrap_repeats,
                    "n_pairs": int(joined["pair_id"].nunique()),
                    "n_animals": int(joined["animal"].nunique()),
                    "inference_status": (
                        "0.95 robustness estimate with animal-bootstrap interval; "
                        "0.90/0.99 and strict-minus-count-matched descriptive"
                    ),
                }
            )
    _write_csv(pd.DataFrame(rows), target / "strict_threshold_pair_summary.csv")

    chain_results = pd.read_csv(target / "strict_threshold_recurrence_slopes.csv")
    chain_draws = pd.read_csv(target / "within_chain_count_matched_draws.csv")
    chain_support = pd.read_csv(
        target / "strict_threshold_chain_joint_pass_audit.csv",
        dtype={"animal": str},
    )
    chain_summary_rows = []
    for (threshold, readout), group in chain_draws.groupby(
        ["threshold", "readout"], sort=False
    ):
        strict = chain_results.loc[
            np.isclose(chain_results["threshold"], threshold)
            & chain_results["readout"].eq(readout)
        ].iloc[0]
        estimate = float(strict["estimate"])
        se = float(strict["se"])
        critical = float(stats.t.ppf(0.975, df=float(strict["df"])))
        chain_summary_rows.append(
            {
                "threshold": threshold,
                "readout": readout,
                "strict_recurrence_slope": estimate,
                "strict_cr1_ci_low": estimate - critical * se,
                "strict_cr1_ci_high": estimate + critical * se,
                "count_matched_mean_slope": float(group["count_matched_slope"].mean()),
                "count_matched_across_draw_sd": float(group["count_matched_slope"].std(ddof=1)),
                "strict_minus_count_matched_mean": estimate
                - float(group["count_matched_slope"].mean()),
                "n_count_matched_draws": int(group["draw"].nunique()),
                "n_chains": int(
                    len(
                        chain_support.loc[
                            np.isclose(chain_support["threshold"], threshold)
                            & chain_support["readout"].eq(readout)
                            & (chain_support["n_defined"] > 0)
                        ]
                    )
                ),
                "n_observations": int(strict["n_rows"]),
                "n_animals": int(strict["n_animals"]),
                "inference_status": (
                    "strict coefficient uses CR1 interval; count-matched draw spread descriptive"
                ),
            }
        )
    _write_csv(
        pd.DataFrame(chain_summary_rows),
        target / "strict_threshold_recurrence_count_matched_summary.csv",
    )


def run_control2_postprocessing(output: Path) -> None:
    """Run association, quality and FOV diagnostics from saved control tables."""

    target = output / "05_control2_cellreg"

    registrations = _pair_registration_table()
    cells = pd.read_csv(output / "02_corrected_baseline" / "corrected_pair_cell_correlations.csv", dtype={"animal": str})
    cells = cells.loc[cells["primary_36"].astype(bool)].merge(
        registrations[
            [
                "pair_label",
                "cluster_index",
                "src_cell_id_zero",
                "dst_cell_id_zero",
                "cellreg_registration_score",
                "conservative_distance_advantage_um",
                "conservative_correlation_advantage",
                "n_informative_directions",
            ]
        ],
        on=["pair_label", "src_cell_id_zero", "dst_cell_id_zero"],
        how="left",
        validate="many_to_one",
    )
    if cells["cellreg_registration_score"].isna().any():
        raise AssertionError("Cell-level stability did not join one-to-one to CellReg scores")
    _write_csv(cells, target / "cell_stability_registration_quality_join.csv")
    diagnostics, coefficients, association_inference = _within_pair_spearman_associations(cells)
    _write_csv(diagnostics, target / "within_pair_score_and_margin_spread.csv")
    _write_csv(coefficients, target / "pair_balanced_spearman_coefficients.csv")
    _write_csv(association_inference, target / "pair_balanced_association_inference_bh6.csv")

    _write_csv(_sampling_quality_models(output, cells), target / "sampling_quality_diagnostic_models.csv")
    _write_csv(_fov_displacement_models(output), target / "adjacent_fov_displacement_descriptive_models.csv")

    margin_formula = {
        "candidate_radius_um": 14,
        "distance_advantage": "nearest nonselected candidate distance minus accepted-match distance",
        "footprint_advantage": "accepted-match correlation minus maximum nonselected-candidate correlation",
        "directions": "computed in both registration directions",
        "conservative_combination": "minimum across informative directions; one informative direction retained",
        "no_alternative": "retained in threshold analyses, omitted and counted in margin analyses",
        "source_candidate_table": str(REGISTRATION_ROOT / "candidate_features_directed_long.csv"),
        "source_margin_table": str(REGISTRATION_EXTRA_ROOT / "hard_negative_registration_conservative_margins.csv"),
        "source_margin_sha256": sha256_file(REGISTRATION_EXTRA_ROOT / "hard_negative_registration_conservative_margins.csv"),
    }
    _write_json(margin_formula, target / "ambiguity_margin_formula_and_provenance.json")


def refresh_control2_chain_outputs(
    output: Path,
    *,
    count_draws: int,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    """Refresh strict-chain outputs after chain-level eligibility changes."""

    target = output / "05_control2_cellreg"
    chain_results, chain_support, chain_count = _strict_chain_outputs(
        output,
        thresholds=(0.90, 0.95, 0.99),
        count_draws=count_draws,
        base_seed=base_seed,
    )
    _write_csv(chain_results, target / "strict_threshold_recurrence_slopes.csv")
    _write_csv(chain_support, target / "strict_threshold_chain_joint_pass_audit.csv")
    _write_csv(chain_count, target / "within_chain_count_matched_draws.csv")
    refresh_control2_summaries(
        output,
        bootstrap_repeats=bootstrap_repeats,
        base_seed=base_seed,
    )


def refresh_bootstrap_and_family_inference(
    output: Path,
    *,
    bootstrap_repeats: int,
    base_seed: int,
) -> None:
    """Refresh inference from saved biological-unit tables, without rerunning splits."""

    reliability_target = output / "03_control3_reliability"
    session_contrasts = pd.read_csv(reliability_target / "paired_session_reliability_contrasts.csv", dtype={"animal": str})
    reliability_rows = []
    for (support_rule, comparison), group in session_contrasts.groupby(["support_rule", "comparison"], sort=False):
        level_rep, reference_rep = CONTROL3_COMPARISONS[comparison]
        fit = _intercept_test(group["difference"], group["animal"])
        boot = _animal_bootstrap_mean(
            group,
            value_col="difference",
            animal_col="animal",
            repeats=bootstrap_repeats,
            seed=stable_seed("control3_boot", support_rule, comparison, base_seed=base_seed),
        )
        reliability_rows.append(
            {
                "support_rule": support_rule,
                "comparison": comparison,
                "level_representation": level_rep,
                "reference_representation": reference_rep,
                **fit,
                "bootstrap_ci_low": boot["bootstrap_ci_low"],
                "bootstrap_ci_high": boot["bootstrap_ci_high"],
                "bootstrap_sd": boot["bootstrap_sd"],
                "bootstrap_repeats": bootstrap_repeats,
            }
        )
    reliability = pd.DataFrame(reliability_rows)
    primary = reliability["support_rule"].eq("primary_2.5s")
    reliability.loc[primary, "p_bh4"] = benjamini_hochberg(
        reliability.loc[primary, "p_two_sided"].to_numpy(float)
    )
    _write_csv(reliability, reliability_target / "reliability_contrast_inference.csv")

    role_frame = pd.read_csv(
        reliability_target / "day_role_pair_joined_reliability.csv",
        dtype={"animal": str},
    )
    role_summary = []
    melted_roles = role_frame.melt(
        id_vars=["pair_id", "animal", "day_role", "session_id", "comparison"],
        value_vars=["level_mean", "reference_mean"],
        var_name="representation_role",
        value_name="reliability",
    )
    for (comparison, role, representation), group in melted_roles.groupby(
        ["comparison", "day_role", "representation_role"], sort=False
    ):
        boot = _animal_bootstrap_mean(
            group,
            value_col="reliability",
            animal_col="animal",
            repeats=bootstrap_repeats,
            seed=stable_seed(
                "control3_dayrole",
                comparison,
                role,
                representation,
                base_seed=base_seed,
            ),
        )
        role_summary.append(
            {
                "comparison": comparison,
                "day_role": role,
                "representation_role": representation,
                **boot,
                "bootstrap_repeats": bootstrap_repeats,
                "inference_status": "descriptive; no additional hypothesis family",
            }
        )
    _write_csv(
        pd.DataFrame(role_summary),
        reliability_target / "day_role_reliability_descriptive_bootstrap.csv",
    )

    split_summary = pd.read_csv(
        reliability_target / "split_session_representation_summaries.csv",
        dtype={"animal": str},
    )
    split_summary = split_summary.loc[
        split_summary["split_kind"].eq("randomized")
        & split_summary["support_rule"].eq("primary_2.5s")
        & (pd.to_numeric(split_summary["split_index"], errors="coerce") < 24)
    ].copy()
    contrast_convergence_rows = []
    for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
        use = split_summary.loc[split_summary["comparison"].eq(comparison)]
        pivot = use.pivot_table(
            index=["session_id", "animal", "split_index"],
            columns="representation",
            values="mean_raw_split_correlation_common_cells",
            aggfunc="first",
        ).dropna(subset=[level_rep, reference_rep])
        pivot["difference"] = pivot[level_rep] - pivot[reference_rep]
        seed_estimates = pivot.groupby("split_index")["difference"].mean().sort_index()
        first12 = seed_estimates.loc[seed_estimates.index < 12]
        first24 = seed_estimates.loc[seed_estimates.index < 24]
        bootstrap_sd = float(
            reliability.loc[
                reliability["support_rule"].eq("primary_2.5s")
                & reliability["comparison"].eq(comparison),
                "bootstrap_sd",
            ].iloc[0]
        )
        mcse = float(first24.std(ddof=1) / np.sqrt(len(first24)))
        change = abs(float(first24.mean() - first12.mean()))
        contrast_convergence_rows.append(
            {
                "comparison": comparison,
                "estimate_first12": float(first12.mean()),
                "estimate_first24": float(first24.mean()),
                "absolute_change_12_to_24": change,
                "across_seed_sd_first24": float(first24.std(ddof=1)),
                "monte_carlo_se_first24": mcse,
                "animal_bootstrap_se": bootstrap_sd,
                "reliability_change_le_0.01": bool(change <= 0.01),
                "mcse_le_10pct_bootstrap_se": bool(
                    mcse <= 0.1 * bootstrap_sd
                ) if bootstrap_sd > 0 else False,
            }
        )
    _write_csv(
        pd.DataFrame(contrast_convergence_rows),
        reliability_target / "primary_contrast_split_convergence_12_vs_24.csv",
    )

    all_random = pd.read_csv(
        reliability_target / "split_session_representation_summaries.csv",
        dtype={"animal": str},
    )
    all_random = all_random.loc[
        all_random["split_kind"].eq("randomized")
        & all_random["support_rule"].eq("primary_2.5s")
    ].copy()
    available_splits = int(all_random["split_index"].max()) + 1
    checkpoints = [value for value in (12, 24, 48, 96) if value <= available_splits]
    latest_n = max(checkpoints)
    previous_n = checkpoints[-2] if len(checkpoints) > 1 else latest_n
    latest_rows = []
    for comparison, (level_rep, reference_rep) in CONTROL3_COMPARISONS.items():
        use = all_random.loc[all_random["comparison"].eq(comparison)]
        pivot = use.pivot_table(
            index=["session_id", "animal", "split_index"],
            columns="representation",
            values="mean_raw_split_correlation_common_cells",
            aggfunc="first",
        ).dropna(subset=[level_rep, reference_rep])
        pivot["difference"] = pivot[level_rep] - pivot[reference_rep]
        seed_estimates = pivot.groupby("split_index")["difference"].mean().sort_index()
        previous = seed_estimates.loc[seed_estimates.index < previous_n]
        latest = seed_estimates.loc[seed_estimates.index < latest_n]
        bootstrap_sd = float(
            reliability.loc[
                reliability["support_rule"].eq("primary_2.5s")
                & reliability["comparison"].eq(comparison),
                "bootstrap_sd",
            ].iloc[0]
        )
        change = abs(float(latest.mean() - previous.mean()))
        mcse = float(latest.std(ddof=1) / np.sqrt(len(latest)))
        latest_rows.append(
            {
                "comparison": comparison,
                "previous_n_splits": previous_n,
                "latest_n_splits": latest_n,
                "estimate_previous": float(previous.mean()),
                "estimate_latest": float(latest.mean()),
                "absolute_change_previous_to_latest": change,
                "across_seed_sd_latest": float(latest.std(ddof=1)),
                "monte_carlo_se_latest": mcse,
                "animal_bootstrap_se": bootstrap_sd,
                "reliability_change_le_0.01": bool(change <= 0.01),
                "mcse_le_10pct_bootstrap_se": bool(
                    mcse <= 0.1 * bootstrap_sd
                ) if bootstrap_sd > 0 else False,
            }
        )
    _write_csv(
        pd.DataFrame(latest_rows),
        reliability_target / "primary_contrast_split_convergence_latest.csv",
    )

    recurrence_target = output / "04_control1_disjoint_recurrence"
    canonical = pd.read_csv(recurrence_target / "canonical_stacked_orientation_observations.csv", dtype={"animal": str})
    support = pd.read_csv(recurrence_target / "recurrence_common_support_audit_all_splits.csv", dtype={"animal": str})
    inference_rows = []
    bootstrap_rows = []
    for readout, group in canonical.groupby("readout", sort=False):
        fit_rows, contrasts = _fit_stacked_readout(group)
        for record in fit_rows.loc[fit_rows["contrast"].isin(["shared", "disjoint", "shared_minus_disjoint"])].to_dict("records"):
            inference_rows.append({"readout": readout, **record})
        boot = animal_bootstrap_contrasts(
            group,
            outcome_col="outcome",
            cluster_col="animal",
            contrasts=contrasts,
            n_bootstrap=bootstrap_repeats,
            seed=stable_seed("control1_boot", readout, base_seed=base_seed),
        )
        boot.insert(0, "readout", readout)
        boot["requested_bootstrap_repeats"] = bootstrap_repeats
        bootstrap_rows.append(boot)
    inference = _mark_reuse_difference_descriptive(pd.DataFrame(inference_rows))
    canonical_support = support.loc[support["split_index"].eq(-1)]
    rate_chains = canonical_support.loc[
        canonical_support["readout"].eq("rate")
        & (pd.to_numeric(canonical_support["n_all_four_split_defined"], errors="coerce") > 0)
    ]
    rate_supported = len(rate_chains) >= 18 and rate_chains["animal"].nunique() >= 9
    family_readouts = ["place", "level", "pv", "rate"] if rate_supported else ["place", "level", "pv"]
    family_mask = inference["contrast"].eq("disjoint") & inference["readout"].isin(family_readouts)
    inference.loc[family_mask, f"p_bh{len(family_readouts)}"] = benjamini_hochberg(
        inference.loc[family_mask, "p_two_sided"].to_numpy(float)
    )
    inference["rate_family_support_passed"] = rate_supported
    inference["primary_family"] = f"BH{len(family_readouts)}: " + ";".join(family_readouts)
    _write_csv(inference, recurrence_target / "canonical_stacked_recurrence_inference.csv")
    bootstrap_frame = pd.concat(bootstrap_rows, ignore_index=True)
    _write_csv(bootstrap_frame, recurrence_target / "canonical_animal_bootstrap_intervals.csv")

    convergence = pd.read_csv(recurrence_target / "split_convergence_12_vs_24.csv")
    for index, row in convergence.iterrows():
        boot = bootstrap_frame.loc[
            bootstrap_frame["readout"].eq(row["readout"])
            & bootstrap_frame["contrast"].eq("disjoint")
        ].iloc[0]
        se = float(boot["bootstrap_sd"])
        convergence.loc[index, "animal_bootstrap_se_approx"] = se
        convergence.loc[index, "mcse_le_10pct_bootstrap_se"] = bool(
            float(row["monte_carlo_se_first24"]) <= 0.1 * se
        ) if se > 0 else False
    _write_csv(convergence, recurrence_target / "split_convergence_12_vs_24.csv")


def _format_estimate(value: float) -> str:
    if not np.isfinite(value):
        return "undefined"
    return f"{value:.3f}"


def run_report_and_validation(output: Path) -> None:
    required = [
        output / "00_baseline_audit" / "audit_decision.json",
        output / "01_cache" / "session_cache_audit.csv",
        output / "02_corrected_baseline" / "corrected_pair_metric_summary_37_with_primary36.csv",
        output / "03_control3_reliability" / "reliability_contrast_inference.csv",
        output / "03_control3_reliability" / "panel_fidelity_contrast_inference.csv",
        output / "04_control1_disjoint_recurrence" / "canonical_stacked_recurrence_inference.csv",
        output / "05_control2_cellreg" / "strict_threshold_pair_summary.csv",
        output / "05_control2_cellreg" / "pair_balanced_association_inference_bh6.csv",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Cannot build report; missing outputs: {missing}")
    report_dir = output / "06_report"
    report_dir.mkdir(parents=True, exist_ok=True)
    reliability = pd.read_csv(required[3])
    recurrence = pd.read_csv(required[5])
    strict = pd.read_csv(required[6])
    associations = pd.read_csv(required[7])
    ladder = pd.read_csv(output / "04_control1_disjoint_recurrence" / "recurrence_coefficient_ladder.csv")
    day_roles = pd.read_csv(output / "03_control3_reliability" / "day_role_reliability_descriptive_bootstrap.csv")
    convergence_rel = pd.read_csv(output / "03_control3_reliability" / "split_convergence_12_vs_24.csv")
    convergence_rel_contrasts = pd.read_csv(
        output
        / "03_control3_reliability"
        / "primary_contrast_split_convergence_latest.csv"
    )
    convergence_rec = pd.read_csv(output / "04_control1_disjoint_recurrence" / "split_convergence_12_vs_24.csv")
    final_split_count = int(convergence_rel_contrasts["latest_n_splits"].max())
    final_valid_split_minimum = int(math.ceil(final_split_count * 20 / 24))

    import matplotlib

    matplotlib.use("Agg", force=True)
    matplotlib.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 7,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
        }
    )
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(2, 3, figsize=(7.2, 4.8), constrained_layout=True)
    ax = axes[0, 0]
    primary_rel = reliability.loc[reliability["support_rule"].eq("primary_2.5s")]
    x = np.arange(len(primary_rel))
    ax.errorbar(
        x,
        primary_rel["estimate"],
        yerr=[
            primary_rel["estimate"] - primary_rel["bootstrap_ci_low"],
            primary_rel["bootstrap_ci_high"] - primary_rel["estimate"],
        ],
        fmt="o",
        color="#315a8c",
        capsize=3,
    )
    ax.axhline(0, color="0.65", lw=0.8)
    ax.set_xticks(x, [value.replace("level_minus_", "") for value in primary_rel["comparison"]], rotation=25, ha="right")
    ax.set_ylabel("Level minus comparison\nraw split correlation")
    ax.set_title("a  Within-session repeatability", loc="left", fontweight="bold", fontsize=8)

    ax = axes[0, 1]
    role_plot = day_roles.loc[day_roles["comparison"].eq("level_minus_place")]
    for representation, color in (("level_mean", "#315a8c"), ("reference_mean", "#a85b3b")):
        group = role_plot.loc[role_plot["representation_role"].eq(representation)]
        positions = np.arange(len(group)) + (-0.08 if representation == "level_mean" else 0.08)
        ax.errorbar(
            positions,
            group["estimate"],
            yerr=[group["estimate"] - group["bootstrap_ci_low"], group["bootstrap_ci_high"] - group["estimate"]],
            fmt="o",
            color=color,
            label="Level" if representation == "level_mean" else "Place",
            capsize=3,
        )
    ax.set_xticks(range(2), ["Day i", "Day i+1"])
    ax.set_ylabel("Raw split correlation")
    ax.legend(frameon=False, fontsize=8)
    ax.set_title("b  Reliability by day role", loc="left", fontweight="bold", fontsize=8)

    ax = axes[0, 2]
    rung_order = [
        "1_original_executed_full_session",
        "2_corrected_full_session",
        "2b_corrected_full_on_canonical_split_common_support",
        "3_symmetrized_shared_half",
        "4_symmetrized_disjoint_half",
    ]
    for readout, color in zip(("place", "level", "pv", "rate"), ("#315a8c", "#5b8f51", "#9b6cb4", "#d07a3f"), strict=True):
        group = ladder.loc[ladder["readout"].eq(readout)].set_index("rung").reindex(rung_order)
        ax.plot(range(len(rung_order)), group["estimate"], marker="o", label=readout, color=color)
    ax.axhline(0, color="0.65", lw=0.8)
    ax.set_xticks(range(len(rung_order)), ["Original", "Corrected", "Common", "Shared", "Disjoint"], rotation=25, ha="right")
    ax.set_ylabel("Recurrence slope")
    ax.legend(frameon=False, fontsize=7, ncol=2)
    ax.set_title("c  Recurrence ladder", loc="left", fontweight="bold", fontsize=8)

    ax = axes[1, 0]
    reuse = recurrence.loc[recurrence["contrast"].isin(["shared", "disjoint", "shared_minus_disjoint"])]
    readouts = [value for value in ("place", "level", "pv", "rate") if value in set(reuse["readout"])]
    width = 0.25
    for offset, contrast_name in enumerate(("shared", "disjoint", "shared_minus_disjoint")):
        group = reuse.loc[reuse["contrast"].eq(contrast_name)].set_index("readout").reindex(readouts)
        ax.bar(np.arange(len(readouts)) + (offset - 1) * width, group["estimate"], width=width, label=contrast_name.replace("shared_minus_disjoint", "reuse difference"))
    ax.axhline(0, color="0.5", lw=0.8)
    ax.set_xticks(range(len(readouts)), readouts)
    ax.set_ylabel("Slope or slope difference")
    ax.legend(frameon=False, fontsize=7)
    ax.set_title("d  Shared versus disjoint", loc="left", fontweight="bold", fontsize=8)

    ax = axes[1, 1]
    strict95 = strict.loc[np.isclose(strict["threshold"], 0.95) & strict["scope"].eq("all_surviving_pairs")]
    x = np.arange(len(strict95))
    ax.plot(x, strict95["strict_equal_pair_mean"], "o-", label="Strict 0.95", color="#315a8c")
    ax.plot(x, strict95["count_matched_equal_pair_mean"], "s--", label="Count matched", color="#888888")
    ax.set_xticks(x, strict95["readout"])
    ax.set_ylabel("Equal-pair stability")
    ax.legend(frameon=False, fontsize=8)
    ax.set_title("e  Strict CellReg threshold", loc="left", fontweight="bold", fontsize=8)

    ax = axes[1, 2]
    label_alias = {
        "cellreg_score_percentile": "score",
        "distance_advantage": "distance",
        "footprint_advantage": "footprint",
    }
    labels = associations["metric"] + ":" + associations["predictor"].map(label_alias)
    x = np.arange(len(associations))
    ax.bar(x, associations["estimate"], color=np.where(associations["estimate"] >= 0, "#5b8f51", "#a85b3b"))
    ax.axhline(0, color="0.5", lw=0.8)
    ax.set_xticks(x, labels, rotation=45, ha="right", fontsize=7)
    ax.set_ylabel("Mean Fisher-z Spearman association")
    ax.set_title("f  Match-quality associations", loc="left", fontweight="bold", fontsize=8)

    for ax in axes.ravel():
        ax.spines[["top", "right"]].set_visible(False)
    figure.savefig(
        report_dir / "extended_data_longitudinal_controls_review.png",
        dpi=300,
        bbox_inches="tight",
    )
    figure.savefig(
        report_dir / "extended_data_longitudinal_controls_review.pdf",
        bbox_inches="tight",
    )
    figure.savefig(
        report_dir / "extended_data_longitudinal_controls_review.svg",
        bbox_inches="tight",
    )
    figure.savefig(
        report_dir / "extended_data_longitudinal_controls_review.tiff",
        dpi=600,
        pil_kwargs={"compression": "tiff_lzw"},
        bbox_inches="tight",
    )
    plt.close(figure)

    figure_contract = """# Figure contract and QA

- **Core conclusion:** the long-gap stability and recurrence results survive direct controls for within-session sampling repeatability, reused middle-session samples and accepted-match confidence.
- **Evidence chain:** panel a compares within-session repeatability across representations; b checks day-role dependence; c and d separate corrected, shared-half and disjoint-half recurrence; e compares strict CellReg matches with neuron-count-matched references; f reports pair-balanced match-quality associations.
- **Archetype:** quantitative robustness grid with Control 3 as the lead evidence panel.
- **Backend:** Python/matplotlib exclusively for rendering, previews and exports.
- **Export contract:** 183-mm-wide double-column layout; editable SVG and TrueType PDF; 300-dpi PNG preview; 600-dpi LZW TIFF.
- **Statistics:** biological units and intervals are defined in `methods_draft.md` and `multiplicity_ledger.csv`; panel source values are the CSV outputs in the three control directories.
- **Visual QA:** white background, no rainbow scale, redundant color/marker encodings in panels c and e, bold lowercase panel labels, and no clipped titles or tick labels in the rendered preview.
"""
    (report_dir / "figure_contract_and_qa.md").write_text(
        figure_contract, encoding="utf-8"
    )

    rel_lookup = primary_rel.set_index("comparison")
    rec_lookup = recurrence.loc[recurrence["contrast"].eq("disjoint")].set_index("readout")
    strict_lookup = strict95.set_index("readout")
    methods = r"""# Publication-facing Methods draft (two paragraphs)

Within-session split-sample reliability was estimated from location episodes, defined as maximal sequences of consecutive retained acquisition frames assigned to one body-centre grid location; acquisition gaps broke episodes. Within each location, chronological episodes were allocated intact to interleaved halves while balancing retained duration, and locations with allocations more imbalanced than 70/30 were omitted. The neuronal activity criterion was applied to the full session before splitting. Primary half maps required at least 2.5 s occupancy per label in each half, and a sensitivity required 5 s. Raw Pearson correlations between half maps were averaged across at least 20 of 24 fixed randomized splits for each neuron and then within session. Paired session-level contrasts compared tree-level maps with place maps and three eight-category spatial partitions on identical neurons, frames and masks, using animal-clustered CR1 inference and Benjamini--Hochberg adjustment across four contrasts. Fidelity sensitivities retained the frozen long-gap pair roster but reinstated each existing panel's activity and spatial-mask eligibility rules. Spearman--Brown extrapolations and reliability-adjusted long-gap correlations were descriptive.

To test whether recurrence reused the same middle-session samples, the middle session of each registered three-session chain was divided with the same episode splitter. Four correlations were formed for each unit from the two middle-session halves. The two same-half and two cross-half slopes were estimated jointly in a stacked model containing orientation, condition and their interactions; symmetrized shared, disjoint and shared-minus-disjoint coefficients were linear contrasts from one animal-clustered covariance matrix. Animal bootstraps refitted the complete model. Separately, accepted CellReg matches were restricted at a score threshold of 0.95, with 0.90 and 0.99 descriptive, and compared with 50 within-pair or within-chain neuron-count-matched draws after readout-specific eligibility. Within-pair Spearman associations related map stability to CellReg-score percentile and conservative distance and footprint-correlation margins; pair coefficients were Fisher-z transformed, pairs received equal weight and six associations were adjusted together. Diagnostic sampling-quality models used raw split correlation and activity separately for source and target sessions; occupancy terms were removed by the predeclared hierarchy because they were collinear with pair fixed effects.
"""
    methods = methods.replace(
        "at least 20 of 24 fixed randomized splits",
        f"at least {final_valid_split_minimum} of {final_split_count} fixed randomized splits",
    )
    (report_dir / "methods_draft.md").write_text(methods, encoding="utf-8")

    results = "# Publication-facing Results draft (three sentences)\n\n"
    results += "Within-session level-map repeatability exceeded place-map repeatability by " + _format_estimate(
        float(rel_lookup.loc["level_minus_place", "estimate"])
    ) + " raw correlation units, but was slightly below geometric-8 and lower than horizontal-8 and vertical-8 repeatability (level-minus-control " + ", ".join(
        _format_estimate(float(rel_lookup.loc[name, "estimate"]))
        for name in (
            "level_minus_geometric8",
            "level_minus_horizontal8",
            "level_minus_vertical8",
        )
    ) + "), arguing against a general sampling-repeatability explanation for higher long-gap level-map stability. "
    results += "In the disjoint-middle-session analysis, all four slopes remained positive with animal-bootstrap intervals excluding zero (place " + ", ".join(
        [
            _format_estimate(float(rec_lookup.loc["place", "estimate"])),
            "level " + _format_estimate(float(rec_lookup.loc["level", "estimate"])),
            "population vector " + _format_estimate(float(rec_lookup.loc["pv", "estimate"])),
            "ensemble rate " + _format_estimate(float(rec_lookup.loc["rate", "estimate"])),
        ]
    ) + "), showing recurrence after removal of reused middle-session activity and occupancy samples. "
    results += "At the strict CellReg threshold, equal-pair estimates (with count-matched references in parentheses) were " + ", ".join(
        f"{readout} {_format_estimate(float(strict_lookup.loc[readout, 'strict_equal_pair_mean']))} ({_format_estimate(float(strict_lookup.loc[readout, 'count_matched_equal_pair_mean']))})"
        for readout in strict_lookup.index
    ) + "; none of the six CellReg-score or ambiguity-margin associations survived BH6 correction, so these diagnostics support threshold robustness but neither estimate a false-match rate nor establish a mathematical lower bound.\n"
    (report_dir / "results_draft.md").write_text(results, encoding="utf-8")

    multiplicity = pd.DataFrame(
        [
            {"analysis": "Control 3 primary raw-reliability contrasts", "family": "BH4", "members": "level-place; level-geometric8; level-horizontal8; level-vertical8"},
            {"analysis": "Control 1 disjoint recurrence", "family": str(recurrence["primary_family"].dropna().iloc[0]), "members": "support-decided before coefficient fitting"},
            {"analysis": "Control 1 shared-minus-disjoint", "family": "none", "members": "paired bootstrap interval; magnitude diagnostic"},
            {"analysis": "Control 2 pair-balanced confidence associations", "family": "BH6", "members": "place/level by score/distance/footprint margin"},
            {"analysis": "CellReg threshold sweep and count matches", "family": "none", "members": "0.95 robustness; 0.90/0.99 and differences descriptive"},
            {"analysis": "14-day influence sensitivity", "family": "none", "members": "reports 37-pair estimand and 36-pair influence sensitivity"},
        ]
    )
    _write_csv(multiplicity, report_dir / "multiplicity_ledger.csv")

    pair_scope = pd.read_csv(
        output / "00_baseline_audit" / "canonical_37_pair_scope_with_primary36_flag.csv",
        dtype={"animal": str},
    )
    chain_scope = pd.read_csv(
        output / "00_baseline_audit" / "canonical_22_chain_scope.csv",
        dtype={"animal_id": str},
    )
    reliability_neurons = pd.read_csv(
        output / "03_control3_reliability" / "split_averaged_neuron_reliability.csv"
    )
    location_balance = pd.read_csv(
        output / "03_control3_reliability" / "location_duration_balance_by_split.csv",
        usecols=[
            "session_id",
            "split_kind",
            "split_index",
            "location",
            "max_half_fraction",
            "eligible_70_30",
        ],
    )
    split_support = pd.read_csv(
        output
        / "03_control3_reliability"
        / "split_support_and_disjointness_audit.csv"
    )
    recurrence_support = pd.read_csv(
        output
        / "04_control1_disjoint_recurrence"
        / "recurrence_common_support_audit_all_splits.csv",
        dtype={"animal": str},
    )
    recurrence_orientations = pd.read_csv(
        output
        / "04_control1_disjoint_recurrence"
        / "canonical_stacked_orientation_observations.csv",
        dtype={"animal": str, "unit_id": str},
    )
    cellreg_support = pd.read_csv(
        output / "05_control2_cellreg" / "strict_threshold_pair_support.csv",
        dtype={"animal": str},
    )
    shuffle_nulls = pd.read_csv(
        output / "05_control2_cellreg" / "strict_095_identity_shuffle_nulls.csv"
    )
    count_pair = pd.read_csv(
        output / "05_control2_cellreg" / "within_pair_count_matched_draws.csv"
    )
    count_chain = pd.read_csv(
        output / "05_control2_cellreg" / "within_chain_count_matched_draws.csv"
    )

    attrition_rows = [
        {
            "stage": "baseline pairs",
            "readout": "all",
            "input_units": int(len(pair_scope)),
            "retained_units": int(pair_scope["primary_36"].astype(bool).sum()),
            "unit": "session pair",
            "rule": "exclude the 14-day transition from canonical long-gap summaries",
        },
        {
            "stage": "baseline chains",
            "readout": "all",
            "input_units": int(len(chain_scope)),
            "retained_units": int(len(chain_scope)),
            "unit": "three-session chain",
            "rule": "clean registered chain scope",
        },
    ]
    for (support_rule, comparison, representation), group in reliability_neurons.groupby(
        ["support_rule", "comparison", "representation"], sort=False
    ):
        attrition_rows.append(
            {
                "stage": f"Control 3 {support_rule}",
                "readout": f"{comparison}:{representation}",
                "input_units": int(len(group)),
                "retained_units": int(group["meets_minimum_valid_splits"].astype(bool).sum()),
                "unit": "neuron-session representation",
                "rule": "minimum valid split count and defined nonconstant maps",
            }
        )
    canonical_rec_support = recurrence_support.loc[
        recurrence_support["split_index"].eq(-1)
    ]
    for readout, group in canonical_rec_support.groupby("readout", sort=False):
        attrition_rows.append(
            {
                "stage": "Control 1 canonical disjoint support",
                "readout": readout,
                "input_units": int(group["n_activity_qualified"].sum()),
                "retained_units": int(group["n_all_four_split_defined"].sum()),
                "unit": "neuron or location; rate uses chain",
                "rule": "all four middle-session correlations defined",
            }
        )
    strict95_support = cellreg_support.loc[np.isclose(cellreg_support["threshold"], 0.95)]
    for readout, group in strict95_support.groupby("readout", sort=False):
        attrition_rows.append(
            {
                "stage": "Control 2 strict 0.95",
                "readout": readout,
                "input_units": int(group["n_full_readout_eligible"].sum()),
                "retained_units": int(group["n_strict_readout_eligible"].sum()),
                "unit": "readout-eligible neuron or pair-specific unit",
                "rule": "accepted CellReg score at least 0.95 after readout eligibility",
            }
        )
    _write_csv(
        pd.DataFrame(attrition_rows),
        report_dir / "attrition_accounting_summary.csv",
    )

    conversion_index = pd.DataFrame(
        [
            {
                "analysis": "shared episode sufficient statistics",
                "source_representation": "retained acquisition frames and denoised activity",
                "transformation": "location-pure episodes to per-location activity sums and occupancy",
                "support_or_mask": "full-session activity gate; acquisition gaps break episodes",
                "audit_path": "01_cache/session_cache_audit.csv",
            },
            {
                "analysis": "Control 3 reliability",
                "source_representation": "A/B location sums",
                "transformation": "place, tree-level and fixed eight-category maps to raw split correlations",
                "support_or_mask": "70/30 balance; 2.5 s per half; minimum valid split fraction",
                "audit_path": "03_control3_reliability/split_support_and_disjointness_audit.csv",
            },
            {
                "analysis": "Control 1 recurrence",
                "source_representation": "four cross-gap correlations per unit",
                "transformation": "covariance-aware stacked slopes and linear contrasts",
                "support_or_mask": "identical all-four support for shared and disjoint orientations",
                "audit_path": "04_control1_disjoint_recurrence/canonical_stacked_orientation_observations.csv",
            },
            {
                "analysis": "Control 2 CellReg",
                "source_representation": "accepted matches with scores and directed alternatives",
                "transformation": "strict thresholds, count matches and pair-balanced rank associations",
                "support_or_mask": "registration, activity and readout eligibility before count matching",
                "audit_path": "05_control2_cellreg/strict_threshold_pair_support.csv",
            },
        ]
    )
    _write_csv(conversion_index, report_dir / "conversion_audit_index.csv")
    alignment_report = """# Alignment and timebase report

- Session matching uses the corrected sorted-neuron pair manifest and explicit pairwise CIMaps; three-session identities are composed through the two adjacent explicit CIMaps.
- The baseline scope is 36 canonical long-gap Day i--Day i pairs (14 animals); recurrence uses 22 clean three-session chains (11 animals). Every control-specific loss is recorded after these baseline scopes are reproduced.
- Split location episodes use retained body-centre 15x15-grid frames on absolute 25-Hz acquisition-frame indices. Acquisition-frame gaps and invalid locations break episodes.
- Frame filtering does not compress timestamps. Episode exposure is retained frame count multiplied by 0.04 s; no cross-modality merge or identity-by-index matching is used.
"""
    (report_dir / "alignment_and_timebase_report.md").write_text(
        alignment_report, encoding="utf-8"
    )

    orientation_group = recurrence_orientations.groupby(
        ["readout", "triplet", "animal", "unit_id"], sort=False
    )["orientation"].agg(["size", "nunique"])
    eligible_balance = location_balance.loc[location_balance["eligible_70_30"].astype(bool)]

    validation = {
        "baseline_36_pairs_reproduced": bool(
            len(pair_scope) == 37 and pair_scope["primary_36"].astype(bool).sum() == 36
        ),
        "baseline_22_chains_reproduced": bool(len(chain_scope) == 22),
        "one_to_one_registration_join": bool(
            pd.read_csv(output / "00_baseline_audit" / "one_to_one_registration_join_audit.csv")[["exact_coordinate_set_match", "one_to_one_cimap"]].all().all()
        ),
        "control3_panel_fidelity_sensitivity_completed": True,
        "split_episode_and_frame_overlap_zero": bool(
            (split_support[["episode_overlap_count", "frame_overlap_count"]] == 0)
            .all()
            .all()
        ),
        "eligible_location_allocations_within_70_30": bool(
            (eligible_balance["max_half_fraction"] <= 0.7000000001).all()
        ),
        "control3_final_minimum_valid_split_count_enforced": bool(
            reliability_neurons.loc[
                reliability_neurons["meets_minimum_valid_splits"].astype(bool),
                "n_valid_randomized_splits",
            ].min()
            >= final_valid_split_minimum
        ),
        "control1_common_four_orientation_support": bool(
            (orientation_group["size"] == 4).all()
            and (orientation_group["nunique"] == 4).all()
        ),
        "cellreg_identity_nulls_use_10000_shuffles": bool(
            (shuffle_nulls["n_shuffles"] == 10_000).all()
        ),
        "cellreg_pair_and_chain_count_matching_use_50_draws": bool(
            count_pair["draw"].nunique() == 50
            and count_chain["draw"].nunique() == 50
        ),
        "split_draws_are_not_biological_replicates": True,
        "control3_reliability_change_12_to_24_all_le_0_01": bool(convergence_rel["reliability_change_le_0.01"].all()),
        "control3_primary_contrast_mcse_all_le_10pct_bootstrap_se": bool(
            convergence_rel_contrasts["mcse_le_10pct_bootstrap_se"].all()
        ),
        "control1_coefficient_change_12_to_24_all_le_0_02": bool(convergence_rec["coefficient_change_le_0.02"].all()),
        "control1_mcse_all_le_10pct_bootstrap_se": bool(convergence_rec["mcse_le_10pct_bootstrap_se"].all()),
        "maintained_figures_or_manuscripts_modified": False,
    }
    _write_json(validation, report_dir / "validation_summary.json")
    required_validation = {
        key: value
        for key, value in validation.items()
        if key != "maintained_figures_or_manuscripts_modified"
    }
    if not all(required_validation.values()):
        failures = [key for key, value in required_validation.items() if not value]
        raise AssertionError(f"Longitudinal-control validation failed: {failures}")
    readme = """# Longitudinal neural controls review bundle

This append-only bundle implements the three preregistered robustness controls without promoting any figure, caption or Methods edit. Read `00_baseline_audit` first: it records the current 36-pair/22-chain reproduction and the executed-code versus written-Methods divergences. `02_corrected_baseline` is the candidate 5-s/0.1-min/full-duration correction on which the controls operate. Direct transformation and support records are retained in each control folder; algorithmic splits, bootstraps, shuffles and count-matched draws are never treated as biological replicates.

The compact figure and publication-facing drafts are review aids only. Detailed support diagnostics belong in Source Data or a supplementary table if the controls are promoted.
"""
    (output / "README.md").write_text(readme, encoding="utf-8")

    manifest_rows = []
    for path in sorted(value for value in output.rglob("*") if value.is_file() and value.name != "FILE_MANIFEST.csv"):
        manifest_rows.append(
            {
                "relative_path": path.relative_to(output).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    _write_csv(pd.DataFrame(manifest_rows), output / "FILE_MANIFEST.csv")


def _primary_convergence_passes(output: Path) -> bool:
    reliability_path = output / "03_control3_reliability" / "split_convergence_12_vs_24.csv"
    reliability_contrast_path = (
        output
        / "03_control3_reliability"
        / "primary_contrast_split_convergence_latest.csv"
    )
    recurrence_path = output / "04_control1_disjoint_recurrence" / "split_convergence_12_vs_24.csv"
    if (
        not reliability_path.exists()
        or not reliability_contrast_path.exists()
        or not recurrence_path.exists()
    ):
        return False
    reliability = pd.read_csv(reliability_path)
    reliability_contrasts = pd.read_csv(reliability_contrast_path)
    recurrence = pd.read_csv(recurrence_path)
    return bool(
        reliability["reliability_change_le_0.01"].all()
        and reliability_contrasts["reliability_change_le_0.01"].all()
        and reliability_contrasts["mcse_le_10pct_bootstrap_se"].all()
        and recurrence["coefficient_change_le_0.02"].all()
        and recurrence["mcse_le_10pct_bootstrap_se"].all()
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "stage",
        choices=("audit", "cache", "baseline", "control3", "control3fidelity", "control1", "control2", "control2chain", "control2post", "control2summary", "refresh", "report", "all"),
        nargs="?",
        default="all",
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--selected-root", type=Path, default=Path(r"D:\combineddata\selected_data"))
    parser.add_argument("--neural-root", type=Path, default=Path(r"D:\neuralData_sort"))
    parser.add_argument("--n-splits", type=int, default=24)
    parser.add_argument("--bootstrap-repeats", type=int, default=2_000)
    parser.add_argument("--count-draws", type=int, default=50)
    parser.add_argument("--shuffle-repeats", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260817)
    parser.add_argument("--overwrite-cache", action="store_true")
    parser.add_argument("--max-sessions", type=int, default=0, help="Cache-stage benchmark only; zero means all sessions")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    stages = (
        ["audit", "cache", "baseline", "control3", "control3fidelity", "control1", "control2", "refresh", "report"]
        if args.stage == "all"
        else [args.stage]
    )
    for stage in stages:
        print(f"STAGE {stage}", flush=True)
        if stage == "audit":
            run_baseline_audit(output)
        elif stage == "cache":
            build_session_cache(
                output,
                selected_root=args.selected_root,
                neural_root=args.neural_root,
                overwrite=args.overwrite_cache,
                max_sessions=args.max_sessions,
            )
        elif stage == "baseline":
            build_corrected_pair_baseline(output)
        elif stage == "control3":
            run_control3_reliability(
                output,
                n_splits=args.n_splits,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "control3fidelity":
            run_control3_panel_fidelity_sensitivity(
                output,
                n_splits=args.n_splits,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "control1":
            run_control1_recurrence(
                output,
                n_splits=args.n_splits,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "control2":
            run_control2_cellreg(
                output,
                count_draws=args.count_draws,
                shuffle_repeats=args.shuffle_repeats,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "control2post":
            run_control2_postprocessing(output)
        elif stage == "control2chain":
            refresh_control2_chain_outputs(
                output,
                count_draws=args.count_draws,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "control2summary":
            refresh_control2_summaries(
                output,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "refresh":
            refresh_bootstrap_and_family_inference(
                output,
                bootstrap_repeats=args.bootstrap_repeats,
                base_seed=args.seed,
            )
        elif stage == "report":
            run_report_and_validation(output)
    if args.stage == "all" and not _primary_convergence_passes(output):
        for expanded in (48, 96):
            if expanded <= args.n_splits:
                continue
            print(f"Coefficient-blind convergence extension to {expanded} fixed seeds", flush=True)
            run_control3_reliability(output, n_splits=expanded, bootstrap_repeats=args.bootstrap_repeats, base_seed=args.seed)
            run_control1_recurrence(output, n_splits=expanded, bootstrap_repeats=args.bootstrap_repeats, base_seed=args.seed)
            if _primary_convergence_passes(output):
                run_report_and_validation(output)
                break
        else:
            raise RuntimeError("Primary convergence thresholds failed through 96 fixed seeds")
