"""Neural-dynamics estimators for the rapid-learning analysis.

The primary metric in this module is excess lagged population coordination
(ELPC).  It measures lagged cross-cell covariance after each neuron's own
autoregressive history has been removed.  It is deliberately not named a
criticality estimator: the statistic can be elevated to that interpretation
only through the separately gated ``dist_arcrit_S`` analysis.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import numpy as np


@dataclass(frozen=True)
class ELPCSpec:
    """Frozen settings for one ELPC estimate."""

    sample_rate_hz: float = 25.0
    min_lag_s: float = 0.2
    max_lag_s: float = 2.0
    n_lags: int = 10
    max_cells: int = 150
    n_offdiag_pairs: int = 512
    n_null: int = 100
    ar_orders: tuple[int, ...] = (1, 2)
    min_finite_fraction: float = 0.95
    seed: int = 0

    def lag_frames(self) -> np.ndarray:
        lo = max(1, int(round(float(self.min_lag_s) * float(self.sample_rate_hz))))
        hi = max(lo, int(round(float(self.max_lag_s) * float(self.sample_rate_hz))))
        n = max(1, min(int(self.n_lags), hi - lo + 1))
        return np.unique(np.rint(np.linspace(lo, hi, n)).astype(int))


def select_segmented_explore_window(
    selected_frames: Any,
    transition_starts: Any,
    transition_ends: Any,
    transition_modes: Any,
    transition_maze_seconds: Any,
    transition_clip_ids: Any,
    *,
    target_frames: int,
    max_maze_seconds: float,
    explore_label: str = "explore",
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Select an early fixed-exposure window without bridging tracking gaps."""

    frames = np.asarray(selected_frames)
    starts = np.asarray(transition_starts, dtype=float)
    ends = np.asarray(transition_ends, dtype=float)
    modes = np.asarray(transition_modes)
    maze_seconds = np.asarray(transition_maze_seconds, dtype=float)
    clips = np.asarray(transition_clip_ids)
    if frames.ndim != 1 or not np.all(np.diff(frames) >= 0):
        raise ValueError("selected_frames must be a sorted one-dimensional array")
    n_transition = len(starts)
    if not all(
        len(values) == n_transition for values in [ends, modes, maze_seconds, clips]
    ):
        raise ValueError("transition arrays must have equal lengths")
    if n_transition == 0:
        return (
            np.zeros(0, dtype=int),
            np.zeros(0, dtype=int),
            {
                "status": "no_transitions",
                "n_selected": 0,
            },
        )
    order = np.argsort(starts, kind="stable")
    starts, ends = starts[order], ends[order]
    modes, maze_seconds, clips = modes[order], maze_seconds[order], clips[order]
    index = np.searchsorted(starts, frames, side="right") - 1
    clipped = np.clip(index, 0, n_transition - 1)
    valid = (
        (index >= 0)
        & (frames < ends[clipped])
        & (modes[clipped].astype(str) == str(explore_label))
        & (maze_seconds[clipped] <= float(max_maze_seconds))
    )
    eligible = np.flatnonzero(valid)
    take = eligible[: max(0, int(target_frames))]
    if take.size:
        chosen_frames = frames[take].astype(int)
        chosen_clips = clips[clipped[take]]
        boundary = np.r_[
            True,
            (np.diff(chosen_frames) != 1) | (chosen_clips[1:] != chosen_clips[:-1]),
        ]
        segment_ids = np.cumsum(boundary) - 1
    else:
        segment_ids = np.zeros(0, dtype=int)
    audit = {
        "status": "ok"
        if take.size >= int(target_frames)
        else "insufficient_usable_frames",
        "target_frames": int(target_frames),
        "n_eligible_before_targeting": int(eligible.size),
        "n_selected": int(take.size),
        "n_segments": int(np.unique(segment_ids).size),
        "selected_frame_min": int(frames[take[0]]) if take.size else None,
        "selected_frame_max": int(frames[take[-1]]) if take.size else None,
        "max_maze_seconds": float(max_maze_seconds),
    }
    return take.astype(int), segment_ids.astype(int), audit


def select_full_frame_explore_window(
    transition_starts: Any,
    transition_ends: Any,
    transition_modes: Any,
    transition_maze_seconds: Any,
    transition_clip_ids: Any,
    *,
    target_frames: int,
    max_maze_seconds: float,
    explore_label: str = "explore",
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Expand early explore intervals to full-rate C frames by mode clip."""

    starts = np.asarray(transition_starts, dtype=float)
    ends = np.asarray(transition_ends, dtype=float)
    modes = np.asarray(transition_modes)
    maze_seconds = np.asarray(transition_maze_seconds, dtype=float)
    clips = np.asarray(transition_clip_ids)
    n_transition = len(starts)
    if not all(
        len(values) == n_transition for values in [ends, modes, maze_seconds, clips]
    ):
        raise ValueError("transition arrays must have equal lengths")
    order = np.argsort(starts, kind="stable")
    records: list[tuple[int, Any]] = []
    seen: set[int] = set()
    for idx in order:
        if (
            str(modes[idx]) != str(explore_label)
            or maze_seconds[idx] > float(max_maze_seconds)
            or not np.isfinite(starts[idx])
            or not np.isfinite(ends[idx])
        ):
            continue
        first = int(np.ceil(starts[idx]))
        stop = int(np.ceil(ends[idx]))
        for frame in range(first, stop):
            if frame in seen:
                continue
            seen.add(frame)
            records.append((frame, clips[idx]))
            if len(records) >= int(target_frames):
                break
        if len(records) >= int(target_frames):
            break
    if records:
        frames = np.asarray([record[0] for record in records], dtype=int)
        chosen_clips = np.asarray([record[1] for record in records])
        boundary = np.r_[
            True,
            (np.diff(frames) != 1) | (chosen_clips[1:] != chosen_clips[:-1]),
        ]
        segment_ids = np.cumsum(boundary) - 1
    else:
        frames = np.zeros(0, dtype=int)
        segment_ids = np.zeros(0, dtype=int)
    audit = {
        "status": "ok"
        if frames.size >= int(target_frames)
        else "insufficient_usable_frames",
        "target_frames": int(target_frames),
        "n_eligible_before_targeting": int(len(seen)),
        "n_selected": int(frames.size),
        "n_segments": int(np.unique(segment_ids).size),
        "selected_frame_min": int(frames[0]) if frames.size else None,
        "selected_frame_max": int(frames[-1]) if frames.size else None,
        "max_maze_seconds": float(max_maze_seconds),
    }
    return frames, segment_ids.astype(int), audit


def _as_time_by_cell(activity: Any) -> np.ndarray:
    arr = np.asarray(activity, dtype=float)
    if arr.ndim != 2:
        raise ValueError("activity must be a 2D time-by-cell array")
    if arr.shape[0] < 4 or arr.shape[1] < 2:
        raise ValueError("activity needs at least four time points and two cells")
    return arr


def _eligible_elpc_cells(activity: np.ndarray, spec: ELPCSpec) -> np.ndarray:
    """Return columns passing the frozen finite-support and variance QC."""

    arr = _as_time_by_cell(activity)
    finite_fraction = np.mean(np.isfinite(arr), axis=0)
    variance = np.nanvar(arr, axis=0)
    return np.flatnonzero(
        (finite_fraction >= float(spec.min_finite_fraction))
        & np.isfinite(variance)
        & (variance > np.finfo(float).eps)
    )


def select_elpc_cells(
    activity: Any, spec: ELPCSpec
) -> tuple[np.ndarray, dict[str, Any]]:
    """Select a deterministic fixed-size cell subset after minimal QC."""

    arr = _as_time_by_cell(activity)
    eligible = _eligible_elpc_cells(arr, spec)
    rng = np.random.default_rng(int(spec.seed))
    if eligible.size > int(spec.max_cells):
        chosen = np.sort(rng.choice(eligible, size=int(spec.max_cells), replace=False))
    else:
        chosen = eligible.astype(int, copy=True)
    audit = {
        "n_time": int(arr.shape[0]),
        "n_cells_input": int(arr.shape[1]),
        "n_cells_eligible": int(eligible.size),
        "n_cells_selected": int(chosen.size),
        "selected_cell_indices": chosen.tolist(),
    }
    return chosen, audit


def select_elpc_cells_common_support(
    activity_blocks: Iterable[Any], spec: ELPCSpec
) -> tuple[np.ndarray, dict[str, Any]]:
    """Select one seeded subset from cells eligible in every supplied block.

    The returned indices refer to the shared input-column coordinate system and
    are suitable for freezing cell identities across matched reliability halves.
    """

    blocks = tuple(_as_time_by_cell(block) for block in activity_blocks)
    if len(blocks) < 2:
        raise ValueError("common-support selection requires at least two blocks")
    n_cells = int(blocks[0].shape[1])
    if any(int(block.shape[1]) != n_cells for block in blocks[1:]):
        raise ValueError("all common-support blocks must have equal cell columns")
    eligible_by_block = tuple(_eligible_elpc_cells(block, spec) for block in blocks)
    common = eligible_by_block[0]
    for eligible in eligible_by_block[1:]:
        common = np.intersect1d(common, eligible, assume_unique=True)
    rng = np.random.default_rng(int(spec.seed))
    if common.size > int(spec.max_cells):
        chosen = np.sort(rng.choice(common, size=int(spec.max_cells), replace=False))
    else:
        chosen = common.astype(int, copy=True)
    audit = {
        "selection_mode": "exact_common_support_across_blocks",
        "n_blocks": int(len(blocks)),
        "n_cells_input": n_cells,
        "n_cells_eligible_by_block": [
            int(eligible.size) for eligible in eligible_by_block
        ],
        "n_cells_common_eligible": int(common.size),
        "n_cells_selected": int(chosen.size),
        "selected_cell_indices": chosen.tolist(),
    }
    return chosen, audit


def _fill_nonfinite_per_cell(activity: np.ndarray) -> tuple[np.ndarray, int]:
    out = np.asarray(activity, dtype=float).copy()
    n_filled = int(np.sum(~np.isfinite(out)))
    for cell in range(out.shape[1]):
        bad = ~np.isfinite(out[:, cell])
        if not np.any(bad):
            continue
        good = ~bad
        fill = float(np.nanmedian(out[good, cell])) if np.any(good) else 0.0
        out[bad, cell] = fill
    return out, n_filled


def _ar_design(x: np.ndarray, order: int) -> tuple[np.ndarray, np.ndarray]:
    order = int(order)
    if order < 1 or x.size <= order + 2:
        raise ValueError("insufficient samples for requested AR order")
    y = x[order:]
    columns = [x[order - lag : x.size - lag] for lag in range(1, order + 1)]
    design = np.column_stack([np.ones(y.size), *columns])
    return design, y


def whiten_own_history(
    activity: Any,
    *,
    ar_orders: Iterable[int] = (1, 2),
) -> tuple[np.ndarray, dict[str, Any]]:
    """Remove each neuron's own AR history, choosing AR order by BIC.

    Residuals are returned on the common time support after the largest
    candidate AR order.  Each cell is standardized to unit residual variance.
    """

    arr = _as_time_by_cell(activity)
    arr, n_filled = _fill_nonfinite_per_cell(arr)
    orders = tuple(sorted({int(v) for v in ar_orders if int(v) >= 1}))
    if not orders:
        raise ValueError("ar_orders must contain at least one positive order")
    max_order = max(orders)
    if arr.shape[0] <= max_order + 3:
        raise ValueError("insufficient samples for AR whitening")

    residuals = np.empty((arr.shape[0] - max_order, arr.shape[1]), dtype=float)
    chosen_orders = np.empty(arr.shape[1], dtype=int)
    bics = np.empty((arr.shape[1], len(orders)), dtype=float)
    coefficients: list[list[float]] = []

    for cell in range(arr.shape[1]):
        x = arr[:, cell]
        fits: list[tuple[float, int, np.ndarray]] = []
        for j, order in enumerate(orders):
            design, y = _ar_design(x, order)
            beta, *_ = np.linalg.lstsq(design, y, rcond=None)
            err = y - design @ beta
            rss = max(float(np.dot(err, err)), np.finfo(float).tiny)
            bic = float(
                y.size * np.log(rss / y.size) + design.shape[1] * np.log(y.size)
            )
            bics[cell, j] = bic
            fits.append((bic, order, beta))
        _, order, beta = min(fits, key=lambda item: item[0])
        chosen_orders[cell] = int(order)
        coefficients.append(beta.astype(float).tolist())
        target = x[max_order:]
        pred = np.full(target.shape, float(beta[0]), dtype=float)
        for lag in range(1, order + 1):
            pred += float(beta[lag]) * x[max_order - lag : x.size - lag]
        resid = target - pred
        resid -= float(np.mean(resid))
        scale = float(np.std(resid, ddof=1))
        residuals[:, cell] = resid / scale if np.isfinite(scale) and scale > 0 else 0.0

    audit = {
        "n_nonfinite_filled": n_filled,
        "candidate_ar_orders": list(orders),
        "chosen_ar_orders": chosen_orders.tolist(),
        "ar_order_counts": {
            str(order): int(np.sum(chosen_orders == order)) for order in orders
        },
        "bic": bics.tolist(),
        "coefficients": coefficients,
        "n_time_residual": int(residuals.shape[0]),
    }
    return residuals, audit


def _segment_slices(segment_ids: Any, n_time: int) -> list[slice]:
    ids = np.asarray(segment_ids)
    if ids.ndim != 1 or ids.size != int(n_time):
        raise ValueError("segment_ids must be one-dimensional and match activity rows")
    if ids.size == 0:
        return []
    boundaries = np.flatnonzero(ids[1:] != ids[:-1]) + 1
    starts = np.concatenate([[0], boundaries])
    stops = np.concatenate([boundaries, [ids.size]])
    return [slice(int(start), int(stop)) for start, stop in zip(starts, stops)]


def whiten_own_history_segmented(
    activity: Any,
    segment_ids: Any,
    *,
    ar_orders: Iterable[int] = (1, 2),
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Pool AR fits across clips without creating artificial clip boundaries."""

    arr = _as_time_by_cell(activity)
    arr, n_filled = _fill_nonfinite_per_cell(arr)
    slices = _segment_slices(segment_ids, arr.shape[0])
    orders = tuple(sorted({int(v) for v in ar_orders if int(v) >= 1}))
    if not orders:
        raise ValueError("ar_orders must contain at least one positive order")
    max_order = max(orders)
    usable = [part for part in slices if part.stop - part.start > max_order + 3]
    if not usable:
        raise ValueError("no segment is long enough for AR whitening")

    chosen_orders = np.empty(arr.shape[1], dtype=int)
    bics = np.empty((arr.shape[1], len(orders)), dtype=float)
    coefficients: list[list[float]] = []
    residual_parts: list[np.ndarray] = [
        np.empty((part.stop - part.start - max_order, arr.shape[1]), dtype=float)
        for part in usable
    ]

    for cell in range(arr.shape[1]):
        fits: list[tuple[float, int, np.ndarray]] = []
        for j, order in enumerate(orders):
            designs: list[np.ndarray] = []
            targets: list[np.ndarray] = []
            for part in usable:
                design, target = _ar_design(arr[part, cell], order)
                designs.append(design)
                targets.append(target)
            design = np.vstack(designs)
            target = np.concatenate(targets)
            beta, *_ = np.linalg.lstsq(design, target, rcond=None)
            err = target - design @ beta
            rss = max(float(np.dot(err, err)), np.finfo(float).tiny)
            bic = float(
                target.size * np.log(rss / target.size)
                + design.shape[1] * np.log(target.size)
            )
            bics[cell, j] = bic
            fits.append((bic, order, beta))
        _, order, beta = min(fits, key=lambda item: item[0])
        chosen_orders[cell] = int(order)
        coefficients.append(beta.astype(float).tolist())
        for part_index, part in enumerate(usable):
            x = arr[part, cell]
            target = x[max_order:]
            pred = np.full(target.shape, float(beta[0]), dtype=float)
            for lag in range(1, order + 1):
                pred += float(beta[lag]) * x[max_order - lag : x.size - lag]
            residual_parts[part_index][:, cell] = target - pred

    residuals = np.vstack(residual_parts)
    residuals -= np.mean(residuals, axis=0, keepdims=True)
    scale = np.std(residuals, axis=0, ddof=1, keepdims=True)
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    residuals /= scale
    residual_segment_ids = np.concatenate(
        [
            np.full(part.shape[0], idx, dtype=int)
            for idx, part in enumerate(residual_parts)
        ]
    )
    audit = {
        "n_nonfinite_filled": n_filled,
        "candidate_ar_orders": list(orders),
        "chosen_ar_orders": chosen_orders.tolist(),
        "ar_order_counts": {
            str(order): int(np.sum(chosen_orders == order)) for order in orders
        },
        "bic": bics.tolist(),
        "coefficients": coefficients,
        "n_segments_input": int(len(slices)),
        "n_segments_usable": int(len(usable)),
        "segment_lengths_input": [int(part.stop - part.start) for part in slices],
        "segment_lengths_residual": [int(part.shape[0]) for part in residual_parts],
        "n_time_residual": int(residuals.shape[0]),
    }
    return residuals, residual_segment_ids, audit


def residualize_activity(
    activity: Any, covariates: Any, *, ridge: float = 1e-8
) -> np.ndarray:
    """Remove measured behavioral/trajectory covariates from each cell.

    The function is intended for the conservative L3 interpretation bound,
    not as the sole primary representation.
    """

    arr = _as_time_by_cell(activity)
    arr, _ = _fill_nonfinite_per_cell(arr)
    x = np.asarray(covariates, dtype=float)
    if x.ndim == 1:
        x = x[:, None]
    if x.ndim != 2 or x.shape[0] != arr.shape[0]:
        raise ValueError("covariates must have the same number of rows as activity")
    x, _ = _fill_nonfinite_per_cell(x)
    x -= np.mean(x, axis=0, keepdims=True)
    scale = np.std(x, axis=0, ddof=1, keepdims=True)
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    x /= scale
    design = np.column_stack([np.ones(x.shape[0]), x])
    gram = design.T @ design
    penalty = np.eye(gram.shape[0], dtype=float) * float(ridge)
    penalty[0, 0] = 0.0
    beta = np.linalg.solve(gram + penalty, design.T @ arr)
    return arr - design @ beta


def sample_offdiagonal_pairs(
    n_cells: int,
    n_pairs: int,
    *,
    seed: int,
) -> np.ndarray:
    """Sample ordered off-diagonal cell pairs without replacement."""

    n_cells = int(n_cells)
    if n_cells < 2:
        raise ValueError("at least two cells are required")
    total = n_cells * (n_cells - 1)
    take = min(max(1, int(n_pairs)), total)
    rng = np.random.default_rng(int(seed))
    flat = rng.choice(total, size=take, replace=False)
    i = flat // (n_cells - 1)
    j0 = flat % (n_cells - 1)
    j = j0 + (j0 >= i)
    return np.column_stack([i, j]).astype(int)


def lagged_offdiagonal_power(
    residuals: Any,
    pairs: Any,
    lag_frames: Iterable[int],
    *,
    segment_ids: Any | None = None,
) -> tuple[float, np.ndarray]:
    """Estimate normalized off-diagonal covariance power over specified lags."""

    arr = _as_time_by_cell(residuals)
    pair_arr = np.asarray(pairs, dtype=int)
    if pair_arr.ndim != 2 or pair_arr.shape[1] != 2 or pair_arr.shape[0] == 0:
        raise ValueError("pairs must be a nonempty n-by-2 array")
    if np.any(pair_arr < 0) or np.any(pair_arr >= arr.shape[1]):
        raise ValueError("pair index out of range")
    if np.any(pair_arr[:, 0] == pair_arr[:, 1]):
        raise ValueError("pairs must be off-diagonal")
    ids = (
        np.zeros(arr.shape[0], dtype=int)
        if segment_ids is None
        else np.asarray(segment_ids)
    )
    _segment_slices(ids, arr.shape[0])
    powers: list[float] = []
    for lag in np.asarray(list(lag_frames), dtype=int):
        if lag < 1 or lag >= arr.shape[0] - 1:
            continue
        within = ids[:-lag] == ids[lag:]
        if not np.any(within):
            continue
        left = arr[:-lag][within][:, pair_arr[:, 0]]
        right = arr[lag:][within][:, pair_arr[:, 1]]
        cov = np.mean(left * right, axis=0)
        powers.append(float(np.mean(np.square(cov))))
    if not powers:
        raise ValueError("no requested lag is supported by the time series")
    by_lag = np.asarray(powers, dtype=float)
    return float(np.mean(by_lag)), by_lag


def _independent_cell_shift(
    residuals: np.ndarray,
    rng: np.random.Generator,
    segment_ids: Any | None = None,
) -> np.ndarray:
    out = np.empty_like(residuals)
    ids = (
        np.zeros(residuals.shape[0], dtype=int)
        if segment_ids is None
        else np.asarray(segment_ids)
    )
    for part in _segment_slices(ids, residuals.shape[0]):
        length = int(part.stop - part.start)
        for cell in range(residuals.shape[1]):
            shift = int(rng.integers(1, length)) if length > 1 else 0
            out[part, cell] = np.roll(residuals[part, cell], shift)
    return out


def _joint_time_shuffle(
    residuals: np.ndarray,
    rng: np.random.Generator,
    segment_ids: Any | None = None,
) -> np.ndarray:
    """Preserve instantaneous population vectors while destroying lag order."""

    out = np.empty_like(residuals)
    ids = (
        np.zeros(residuals.shape[0], dtype=int)
        if segment_ids is None
        else np.asarray(segment_ids)
    )
    for part in _segment_slices(ids, residuals.shape[0]):
        index = np.arange(part.start, part.stop)
        out[part] = residuals[rng.permutation(index)]
    return out


def _null_summary(observed: float, values: np.ndarray) -> dict[str, float]:
    mean = float(np.mean(values))
    sd = float(np.std(values, ddof=1)) if values.size > 1 else np.nan
    z = float((observed - mean) / sd) if np.isfinite(sd) and sd > 0 else np.nan
    p_greater = float((1 + np.sum(values >= observed)) / (values.size + 1))
    return {
        "null_mean": mean,
        "null_sd": sd,
        "excess": float(observed - mean),
        "z": z,
        "p_greater": p_greater,
    }


def compute_elpc(
    activity: Any,
    spec: ELPCSpec = ELPCSpec(),
    *,
    segment_ids: Any | None = None,
    selected_cell_indices: Any | None = None,
    offdiagonal_pairs: Any | None = None,
) -> dict[str, Any]:
    """Compute the L0-L2 ELPC interpretation ladder.

    L0 is the observed lagged off-diagonal power after own-history whitening.
    L1 compares it with independently shifted cells.  L2, the primary metric,
    compares it with joint time shuffles that preserve the complete zero-lag
    population covariance distribution while removing temporal ordering.
    """

    arr = _as_time_by_cell(activity)
    if selected_cell_indices is None:
        selected, selection_audit = select_elpc_cells(arr, spec)
    else:
        raw_selected = np.asarray(selected_cell_indices)
        selected = raw_selected.astype(int)
        if (
            selected.ndim != 1
            or selected.size < 2
            or not np.array_equal(raw_selected, selected)
            or np.any(selected < 0)
            or np.any(selected >= arr.shape[1])
            or np.unique(selected).size != selected.size
        ):
            raise ValueError(
                "selected_cell_indices must be unique valid input-column indices"
            )
        eligible = _eligible_elpc_cells(arr, spec)
        selection_audit = {
            "selection_mode": "preselected_exact",
            "n_time": int(arr.shape[0]),
            "n_cells_input": int(arr.shape[1]),
            "n_cells_eligible": int(eligible.size),
            "n_preselected_currently_eligible": int(
                np.count_nonzero(np.isin(selected, eligible))
            ),
            "n_cells_selected": int(selected.size),
            "selected_cell_indices": selected.tolist(),
        }
    if selected.size < 2:
        return {
            "status": "insufficient_cells",
            "spec": asdict(spec),
            "selection": selection_audit,
        }
    if segment_ids is None:
        residuals, whitening_audit = whiten_own_history(
            arr[:, selected], ar_orders=spec.ar_orders
        )
        residual_segment_ids = np.zeros(residuals.shape[0], dtype=int)
    else:
        residuals, residual_segment_ids, whitening_audit = whiten_own_history_segmented(
            arr[:, selected], segment_ids, ar_orders=spec.ar_orders
        )
    lags = spec.lag_frames()
    if offdiagonal_pairs is None:
        pairs = sample_offdiagonal_pairs(
            residuals.shape[1], spec.n_offdiag_pairs, seed=int(spec.seed) + 17
        )
        pair_source = "sampled_from_seed"
    else:
        raw_pairs = np.asarray(offdiagonal_pairs)
        pairs = raw_pairs.astype(int)
        if (
            pairs.ndim != 2
            or pairs.shape[1] != 2
            or pairs.shape[0] == 0
            or not np.array_equal(raw_pairs, pairs)
            or np.any(pairs < 0)
            or np.any(pairs >= residuals.shape[1])
            or np.any(pairs[:, 0] == pairs[:, 1])
            or np.unique(pairs, axis=0).shape[0] != pairs.shape[0]
        ):
            raise ValueError(
                "offdiagonal_pairs must be unique valid positions in the frozen cell subset"
            )
        pair_source = "preselected_exact"
    observed, observed_by_lag = lagged_offdiagonal_power(
        residuals, pairs, lags, segment_ids=residual_segment_ids
    )

    rng_shift = np.random.default_rng(int(spec.seed) + 101)
    rng_zero = np.random.default_rng(int(spec.seed) + 202)
    n_null = max(1, int(spec.n_null))
    shifted = np.empty(n_null, dtype=float)
    zero_lag_preserved = np.empty(n_null, dtype=float)
    for idx in range(n_null):
        shifted[idx], _ = lagged_offdiagonal_power(
            _independent_cell_shift(residuals, rng_shift, residual_segment_ids),
            pairs,
            lags,
            segment_ids=residual_segment_ids,
        )
        zero_lag_preserved[idx], _ = lagged_offdiagonal_power(
            _joint_time_shuffle(residuals, rng_zero, residual_segment_ids),
            pairs,
            lags,
            segment_ids=residual_segment_ids,
        )

    return {
        "status": "ok",
        "metric_name": "excess_lagged_population_coordination",
        "primary_value": _null_summary(observed, zero_lag_preserved)["excess"],
        "primary_z": _null_summary(observed, zero_lag_preserved)["z"],
        "spec": asdict(spec),
        "selection": selection_audit,
        "whitening": whitening_audit,
        "lag_frames": lags.tolist(),
        "lag_seconds": (lags / float(spec.sample_rate_hz)).tolist(),
        "offdiagonal_pairs": pairs.tolist(),
        "offdiagonal_pair_source": pair_source,
        "offdiagonal_pairs_input_columns": selected[pairs].tolist(),
        "l0_observed_power": observed,
        "l0_observed_power_by_lag": observed_by_lag.tolist(),
        "l1_cell_shift": {
            **_null_summary(observed, shifted),
            "null_values": shifted.tolist(),
        },
        "l2_zero_lag_preserved": {
            **_null_summary(observed, zero_lag_preserved),
            "null_values": zero_lag_preserved.tolist(),
        },
    }


def compute_elpc_ladder(
    activity: Any,
    spec: ELPCSpec = ELPCSpec(),
    *,
    behavior_covariates: Any | None = None,
    segment_ids: Any | None = None,
    selected_cell_indices: Any | None = None,
    offdiagonal_pairs: Any | None = None,
) -> dict[str, Any]:
    """Compute primary ELPC and an optional behavior-residualized L3 bound."""

    primary = compute_elpc(
        activity,
        spec,
        segment_ids=segment_ids,
        selected_cell_indices=selected_cell_indices,
        offdiagonal_pairs=offdiagonal_pairs,
    )
    out: dict[str, Any] = {"primary": primary, "l3_behavior_residualized": None}
    if behavior_covariates is not None:
        residualized = residualize_activity(activity, behavior_covariates)
        out["l3_behavior_residualized"] = compute_elpc(
            residualized,
            spec,
            segment_ids=segment_ids,
            selected_cell_indices=selected_cell_indices,
            offdiagonal_pairs=offdiagonal_pairs,
        )
    return out


__all__ = [
    "ELPCSpec",
    "compute_elpc",
    "compute_elpc_ladder",
    "lagged_offdiagonal_power",
    "residualize_activity",
    "sample_offdiagonal_pairs",
    "select_elpc_cells",
    "select_elpc_cells_common_support",
    "select_full_frame_explore_window",
    "select_segmented_explore_window",
    "whiten_own_history",
    "whiten_own_history_segmented",
]
