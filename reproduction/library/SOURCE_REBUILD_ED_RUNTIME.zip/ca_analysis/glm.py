from __future__ import annotations

import importlib
import sys
from pathlib import Path

import numpy as np
from scipy import sparse
from sklearn.preprocessing import OneHotEncoder

try:
    import statsmodels.api as sm
except Exception:
    sm = None


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _ensure_external_glm_path() -> Path:
    glm_code_dir = _repo_root() / "external" / "GLM_Tensorflow_2-main" / "code"
    if glm_code_dir.exists():
        p = str(glm_code_dir.resolve())
        if p not in sys.path:
            sys.path.append(p)
    return glm_code_dir


def _import_tf_glm_modules():
    try:
        glm_mod = importlib.import_module("glm_class")
    except ModuleNotFoundError:
        _ensure_external_glm_path()
        glm_mod = importlib.import_module("glm_class")
    try:
        mixglm_mod = importlib.import_module("mixglm_class")
    except ModuleNotFoundError:
        _ensure_external_glm_path()
        mixglm_mod = importlib.import_module("mixglm_class")
    return glm_mod, mixglm_mod


def create_cosine_bump_centers_2d(
    n_bases_x: int,
    n_bases_y: int,
    xlim: tuple[float, float] = (0.0, 1.0),
    ylim: tuple[float, float] = (0.0, 1.0),
    width_to_spacing_ratio: float = 4.0,
):
    centers_x = np.linspace(float(xlim[0]), float(xlim[1]), int(n_bases_x))
    centers_y = np.linspace(float(ylim[0]), float(ylim[1]), int(n_bases_y))
    gx, gy = np.meshgrid(centers_x, centers_y)
    centers = np.column_stack([gx.ravel(), gy.ravel()])
    dx = float(np.diff(centers_x)[0]) if len(centers_x) > 1 else 1.0
    dy = float(np.diff(centers_y)[0]) if len(centers_y) > 1 else 1.0
    widths = np.column_stack(
        [
            np.full(len(centers), width_to_spacing_ratio * dx, dtype=float),
            np.full(len(centers), width_to_spacing_ratio * dy, dtype=float),
        ]
    )
    return centers, widths


def compute_2d_cosine_basis(positions, bump_centers, bump_widths):
    pos = np.asarray(positions, dtype=float)
    ctr = np.asarray(bump_centers, dtype=float)
    wid = np.asarray(bump_widths, dtype=float)
    if pos.ndim != 2 or pos.shape[1] != 2:
        raise ValueError("positions must be (n,2)")
    out = np.zeros((pos.shape[0], ctr.shape[0]), dtype=float)
    for i in range(ctr.shape[0]):
        cx, cy = ctr[i]
        wx, wy = np.maximum(wid[i], 1e-9)
        bx = 0.5 * (1.0 + np.cos(np.pi * (pos[:, 0] - cx) / wx)) * (np.abs(pos[:, 0] - cx) < wx / 2.0)
        by = 0.5 * (1.0 + np.cos(np.pi * (pos[:, 1] - cy) / wy)) * (np.abs(pos[:, 1] - cy) < wy / 2.0)
        out[:, i] = bx * by
    return out


def make_segment_ids(edge_bin, u_bin, u_bins: int):
    edge_bin = np.asarray(edge_bin, dtype=int).ravel()
    u_bin = np.asarray(u_bin, dtype=int).ravel()
    seg = edge_bin * int(u_bins) + u_bin
    bad = (edge_bin < 0) | (u_bin < 0)
    seg = seg.astype(int, copy=False)
    seg[bad] = -1
    return seg


def one_hot_sparse(col, drop_neg: bool = True):
    x = np.asarray(col, dtype=int).reshape(-1, 1)
    if drop_neg:
        x = np.where(x < 0, -1, x)
    enc = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    X = enc.fit_transform(x)
    return X.tocsr(), enc


def zscore_safe(x):
    x = np.asarray(x, dtype=float).ravel()
    m = np.nanmean(x)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(x)
    return (x - m) / s


def _run_depth_from_edge(edge_bin, ma):
    edge_bin = np.asarray(edge_bin, dtype=int).ravel()
    out = np.zeros_like(edge_bin, dtype=int)
    for i, e in enumerate(edge_bin):
        if int(e) < 0:
            out[i] = -1
            continue
        d = 0
        parent = int(ma.pa[int(e)])
        while parent >= 0:
            d += 1
            parent = int(ma.pa[parent])
        out[i] = int(d)
    return out


def _mode_int(values, *, allow_neg: bool = True, default: int = -1) -> int:
    arr = np.asarray(values, dtype=int).ravel()
    if arr.size == 0:
        return int(default)
    if not allow_neg:
        arr = arr[arr >= 0]
        if arr.size == 0:
            return int(default)
    uniq, cnt = np.unique(arr, return_counts=True)
    return int(uniq[np.argmax(cnt)])


def build_stablecode_binned_table(
    selected_df,
    event_mat,
    edge_id,
    u,
    prev_choice,
    next_choice,
    *,
    frame_rate: float = 25.0,
    bin_size_sec: float = 0.2,
    u_bins: int = 20,
    frame_col: str = "frame",
    speed_col: str = "speed",
    head_dir_col: str = "head_dir",
):
    """
    Build frame-binned arrays used by 260128_stablecode GLM design construction.

    Returns binned neural counts and aligned categorical/kinematic covariates.
    """
    if event_mat is None:
        raise ValueError("event_mat is required")
    S = np.asarray(event_mat, dtype=float)
    if S.ndim != 2:
        raise ValueError("event_mat must be 2D (frames x neurons or neurons x frames)")

    edge_id = np.asarray(edge_id, dtype=int).ravel()
    u = np.asarray(u, dtype=float).ravel()
    prev_choice = np.asarray(prev_choice, dtype=int).ravel()
    next_choice = np.asarray(next_choice, dtype=int).ravel()

    n_ref = min(edge_id.size, u.size, prev_choice.size, next_choice.size)
    if S.shape[0] == n_ref:
        S_frame = S
    elif S.shape[1] == n_ref:
        S_frame = S.T
    else:
        n_ref = min(n_ref, S.shape[0])
        S_frame = S[:n_ref]
    edge_id = edge_id[:n_ref]
    u = u[:n_ref]
    prev_choice = prev_choice[:n_ref]
    next_choice = next_choice[:n_ref]

    if frame_col in selected_df.columns:
        frame_idx = np.asarray(selected_df[frame_col].to_numpy(dtype=float), dtype=float)
        frame_idx = frame_idx[:n_ref]
    else:
        frame_idx = np.arange(n_ref, dtype=float)

    valid = (edge_id >= 0) & np.isfinite(u)
    frame_idx_valid = frame_idx[valid]
    if frame_idx_valid.size == 0:
        raise ValueError("No valid edge/u samples for stable-code binning")

    event_mat_valid = S_frame[valid]
    edge_valid = edge_id[valid]
    u_valid = u[valid]
    prev_valid = prev_choice[valid]
    next_valid = next_choice[valid]

    if speed_col in selected_df.columns:
        speed = np.asarray(selected_df[speed_col].to_numpy(dtype=float), dtype=float)[:n_ref][valid]
    else:
        speed = np.full(frame_idx_valid.shape[0], np.nan, dtype=float)
    if head_dir_col in selected_df.columns:
        head_dir = np.asarray(selected_df[head_dir_col].to_numpy(dtype=float), dtype=float)[:n_ref][valid]
    else:
        head_dir = np.full(frame_idx_valid.shape[0], np.nan, dtype=float)

    bin_frames = max(1, int(round(float(bin_size_sec) * float(frame_rate))))
    bin_id = ((frame_idx_valid - np.nanmin(frame_idx_valid)) // bin_frames).astype(int)
    n_bins = int(np.nanmax(bin_id)) + 1
    n_neurons = int(event_mat_valid.shape[1])

    y_counts = np.zeros((n_bins, n_neurons), dtype=float)
    edge_bin = np.full(n_bins, -1, dtype=int)
    u_bin = np.full(n_bins, -1, dtype=int)
    prev_bin = np.full(n_bins, -1, dtype=int)
    next_bin = np.full(n_bins, -1, dtype=int)
    speed_bin = np.full(n_bins, np.nan, dtype=float)
    hd_bin = np.full(n_bins, np.nan, dtype=float)

    for b in range(n_bins):
        idx = np.where(bin_id == b)[0]
        if idx.size == 0:
            continue
        y_counts[b] = np.nansum(event_mat_valid[idx], axis=0)
        edge_bin[b] = _mode_int(edge_valid[idx], allow_neg=False, default=-1)
        prev_bin[b] = _mode_int(prev_valid[idx], allow_neg=False, default=-1)
        next_bin[b] = _mode_int(next_valid[idx], allow_neg=False, default=-1)
        u_mean = float(np.nanmean(u_valid[idx]))
        u_bin[b] = int(np.clip(np.floor(u_mean * int(u_bins)), 0, int(u_bins) - 1))
        speed_bin[b] = float(np.nanmean(speed[idx])) if idx.size else np.nan
        hd_bin[b] = float(np.nanmean(head_dir[idx])) if idx.size else np.nan

    return {
        "y_counts": y_counts,
        "edge_bin": edge_bin,
        "u_bin": u_bin,
        "prev_bin": prev_bin,
        "next_bin": next_bin,
        "speed_bin": speed_bin,
        "hd_bin": hd_bin,
        "bin_id": bin_id,
        "n_bins": int(n_bins),
        "n_neurons": int(n_neurons),
        "bin_frames": int(bin_frames),
    }


def build_stablecode_design_matrices(
    edge_bin,
    u_bin,
    prev_bin,
    next_bin,
    speed_bin,
    hd_bin,
    u_bins: int,
    ma,
):
    """
    Reproduces 260128 stable-code design blocks:
    X_pos, X_kin, X_depth, X_prev, X_next, X_pos_prev, X_pos_next.
    """
    seg_id = make_segment_ids(edge_bin, u_bin, int(u_bins))
    X_pos, enc_pos = one_hot_sparse(seg_id)

    speed_filled = np.nan_to_num(np.asarray(speed_bin, dtype=float), nan=np.nanmedian(speed_bin))
    speed_z = zscore_safe(speed_filled)
    hd = np.asarray(hd_bin, dtype=float)
    hd_filled = np.nan_to_num(hd, nan=np.nanmedian(hd))
    hd_rad = np.deg2rad(hd_filled) if np.nanmax(np.abs(hd_filled)) > 2 * np.pi else hd_filled
    sin_hd = np.sin(hd_rad)
    cos_hd = np.cos(hd_rad)
    X_kin = sparse.csr_matrix(np.vstack([speed_z, sin_hd, cos_hd]).T)

    run_depth = _run_depth_from_edge(edge_bin, ma=ma)
    X_depth, enc_depth = one_hot_sparse(run_depth)
    X_prev, enc_prev = one_hot_sparse(prev_bin)
    X_next, enc_next = one_hot_sparse(next_bin)

    X_pos_next = sparse.hstack([X_pos.multiply(X_next[:, k]) for k in range(X_next.shape[1])]).tocsr()
    X_pos_prev = sparse.hstack([X_pos.multiply(X_prev[:, k]) for k in range(X_prev.shape[1])]).tocsr()

    return {
        "X_pos": X_pos,
        "X_kin": X_kin,
        "X_depth": X_depth,
        "X_prev": X_prev,
        "X_next": X_next,
        "X_pos_next": X_pos_next,
        "X_pos_prev": X_pos_prev,
        "enc_pos": enc_pos,
        "enc_depth": enc_depth,
        "enc_prev": enc_prev,
        "enc_next": enc_next,
    }


def assemble_stablecode_full_matrix(parts: dict):
    return sparse.hstack(
        [
            parts["X_pos"],
            parts["X_kin"],
            parts["X_depth"],
            parts["X_prev"],
            parts["X_next"],
            parts["X_pos_prev"],
            parts["X_pos_next"],
        ]
    ).tocsr()


def run_stablecode_synthetic_glm_sanity(
    *,
    ma,
    n_samples: int = 5000,
    u_bins_sim: int = 8,
    random_state: int = 0,
):
    """
    Reproduces the 260128_stablecode synthetic GLM recovery sanity check.
    """
    glm_mod, _ = _import_tf_glm_modules()
    rng = np.random.default_rng(int(random_state))
    n_edges_sim = min(10, len(ma.ru))

    edges_sim = rng.integers(0, n_edges_sim, size=int(n_samples))
    u_sim = rng.integers(0, int(u_bins_sim), size=int(n_samples))
    prev_sim = rng.integers(0, 3, size=int(n_samples))
    next_sim = rng.integers(0, 3, size=int(n_samples))
    speed_sim = rng.normal(10.0, 2.0, size=int(n_samples))
    hd_sim = rng.uniform(-np.pi, np.pi, size=int(n_samples))

    parts = build_stablecode_design_matrices(
        edge_bin=edges_sim,
        u_bin=u_sim,
        prev_bin=prev_sim,
        next_bin=next_sim,
        speed_bin=speed_sim,
        hd_bin=hd_sim,
        u_bins=int(u_bins_sim),
        ma=ma,
    )
    X_pos = parts["X_pos"].tocsr()
    X_kin = parts["X_kin"].tocsr()
    X_depth = parts["X_depth"].tocsr()
    X_prev = parts["X_prev"].tocsr()
    X_next = parts["X_next"].tocsr()
    X_pos_prev = parts["X_pos_prev"].tocsr()
    X_pos_next = parts["X_pos_next"].tocsr()
    X_full = assemble_stablecode_full_matrix(parts).tocsr()

    n_features = int(X_full.shape[1])
    w_true = np.zeros(n_features, dtype=float)
    idx = 0
    pos_dim = X_pos.shape[1]
    kin_dim = X_kin.shape[1]
    depth_dim = X_depth.shape[1]
    prev_dim = X_prev.shape[1]
    next_dim = X_next.shape[1]
    pos_prev_dim = X_pos_prev.shape[1]
    pos_next_dim = X_pos_next.shape[1]

    w_true[idx : idx + pos_dim] = rng.normal(0.0, 0.6, size=pos_dim)
    idx += pos_dim
    w_true[idx : idx + kin_dim] = np.array([0.2, -0.1, 0.15])
    idx += kin_dim
    w_true[idx : idx + depth_dim] = rng.normal(0.0, 0.3, size=depth_dim)
    idx += depth_dim
    w_true[idx : idx + prev_dim] = rng.normal(0.0, 0.2, size=prev_dim)
    idx += prev_dim
    w_true[idx : idx + next_dim] = rng.normal(0.0, 0.2, size=next_dim)
    idx += next_dim
    w_true[idx : idx + pos_prev_dim] = rng.normal(0.0, 0.15, size=pos_prev_dim)
    idx += pos_prev_dim
    w_true[idx : idx + pos_next_dim] = rng.normal(0.0, 0.15, size=pos_next_dim)

    bias_true = -1.0
    eta = X_full.dot(w_true) + bias_true
    mu = np.exp(eta)
    y = rng.poisson(mu).astype(float)

    n = len(y)
    train_end = int(n * 0.7)
    val_end = int(n * 0.85)
    train_idx = np.arange(train_end)
    val_idx = np.arange(train_end, val_end)
    test_idx = np.arange(val_end, n)

    X_train = X_full[train_idx].toarray()
    y_train = y[train_idx].reshape(-1, 1)
    X_val = X_full[val_idx].toarray()
    y_val = y[val_idx].reshape(-1, 1)
    X_test = X_full[test_idx].toarray()
    y_test = y[test_idx].reshape(-1, 1)

    model = glm_mod.GLM(
        activation="exp",
        loss_type="poisson",
        regularization="elastic_net",
        lambda_series=10.0 ** np.linspace(-2, -4, 5),
        l1_ratio=0.0,
        optimizer="adam",
        learning_rate=1e-2,
        min_iter_per_lambda=200,
        max_iter_per_lambda=2000,
    )
    model.fit(X_train, y_train, verbose=False)
    model.select_model(X_val, y_val, min_lambda=0.0, make_fig=False)
    y_pred = model.predict(X_test)
    frac_dev_expl, _, _ = glm_mod.deviance(y_pred, y_test, loss_type="poisson")
    w_hat = model.selected_w[:, 0]

    def _corr(a, b):
        if np.std(a) == 0 or np.std(b) == 0:
            return np.nan
        return float(np.corrcoef(a, b)[0, 1])

    idx = 0
    corr_pos = _corr(w_true[idx : idx + pos_dim], w_hat[idx : idx + pos_dim])
    idx += pos_dim
    corr_kin = _corr(w_true[idx : idx + kin_dim], w_hat[idx : idx + kin_dim])
    idx += kin_dim
    corr_depth = _corr(w_true[idx : idx + depth_dim], w_hat[idx : idx + depth_dim])
    idx += depth_dim
    corr_prev = _corr(w_true[idx : idx + prev_dim], w_hat[idx : idx + prev_dim])
    idx += prev_dim
    corr_next = _corr(w_true[idx : idx + next_dim], w_hat[idx : idx + next_dim])
    idx += next_dim
    corr_pos_prev = _corr(w_true[idx : idx + pos_prev_dim], w_hat[idx : idx + pos_prev_dim])
    idx += pos_prev_dim
    corr_pos_next = _corr(w_true[idx : idx + pos_next_dim], w_hat[idx : idx + pos_next_dim])

    return {
        "backend": "tensorflow_glm",
        "frac_dev_expl": float(np.ravel(frac_dev_expl)[0]) if np.size(frac_dev_expl) else np.nan,
        "corr_pos": corr_pos,
        "corr_kin": corr_kin,
        "corr_depth": corr_depth,
        "corr_prev": corr_prev,
        "corr_next": corr_next,
        "corr_pos_prev": corr_pos_prev,
        "corr_pos_next": corr_pos_next,
        "n_features": n_features,
        "n_samples": int(n_samples),
    }


def build_behavior_design_matrix(
    selected_df,
    covariates: tuple[str, ...] = ("speed", "x", "y", "maze_time"),
    y=None,
):
    cols = [c for c in covariates if c in selected_df.columns]
    if not cols:
        raise ValueError("No requested covariates available in selected_df")
    X = selected_df[cols].to_numpy(dtype=float)
    mask = np.all(np.isfinite(X), axis=1)
    yv = None
    if y is not None:
        yv = np.asarray(y, dtype=float).ravel()
        if yv.shape[0] != X.shape[0]:
            n = min(yv.shape[0], X.shape[0])
            yv = yv[:n]
            X = X[:n]
            mask = mask[:n]
        mask = mask & np.isfinite(yv)
    groups = selected_df["run_id"].to_numpy() if "run_id" in selected_df.columns else (np.arange(len(selected_df)) // 200)
    groups = np.asarray(groups)
    if groups.shape[0] != X.shape[0]:
        groups = np.arange(X.shape[0]) // 200
    return {
        "X": X,
        "y": yv,
        "mask": mask,
        "groups": groups,
        "covariates": cols,
    }


def fit_poisson_glm_statsmodels(X, y, *, maxiter: int = 200):
    if sm is None:
        raise ImportError("statsmodels is unavailable")
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).ravel()
    fit = sm.GLM(
        y,
        sm.add_constant(X, has_constant="add"),
        family=sm.families.Poisson(),
    ).fit(maxiter=int(maxiter))
    mu = np.asarray(fit.fittedvalues, dtype=float)
    null_dev = float(getattr(fit, "null_deviance", np.nan))
    dev = float(getattr(fit, "deviance", np.nan))
    pseudo_r2 = np.nan
    if np.isfinite(null_dev) and null_dev > 0 and np.isfinite(dev):
        pseudo_r2 = float(1.0 - dev / null_dev)
    return {
        "backend": "statsmodels_glm",
        "fit": fit,
        "prediction": mu,
        "model_deviance": dev,
        "null_deviance": null_dev,
        "frac_dev_expl": pseudo_r2,
        "aic": float(getattr(fit, "aic", np.nan)),
        "n_obs": int(X.shape[0]),
        "n_features": int(X.shape[1]),
    }


def fit_poisson_glm_holdout_tf(
    X_train,
    y_train,
    X_val,
    y_val,
    X_test,
    y_test,
    *,
    regularization: str = "elastic_net",
    lambda_series=None,
    l1_ratio: float = 0.0,
    optimizer: str = "adam",
    learning_rate: float = 1e-2,
    min_iter_per_lambda: int = 200,
    max_iter_per_lambda: int = 2000,
    min_lambda: float = 0.0,
    verbose: bool = False,
):
    """
    Direct GLM holdout fit mirroring 260128_stablecode.ipynb (GLM + val select).
    """
    glm_mod, _ = _import_tf_glm_modules()
    X_train = np.asarray(X_train, dtype=float)
    y_train = np.asarray(y_train, dtype=float).reshape(-1, 1)
    X_val = np.asarray(X_val, dtype=float)
    y_val = np.asarray(y_val, dtype=float).reshape(-1, 1)
    X_test = np.asarray(X_test, dtype=float)
    y_test = np.asarray(y_test, dtype=float).reshape(-1, 1)
    if lambda_series is None:
        lambda_series = 10.0 ** np.linspace(-2, -4, 5)
    model = glm_mod.GLM(
        activation="exp",
        loss_type="poisson",
        regularization=str(regularization),
        lambda_series=np.asarray(lambda_series, dtype=float),
        l1_ratio=float(l1_ratio),
        optimizer=str(optimizer),
        learning_rate=float(learning_rate),
        min_iter_per_lambda=int(min_iter_per_lambda),
        max_iter_per_lambda=int(max_iter_per_lambda),
    )
    model.fit(X_train, y_train, verbose=bool(verbose))
    model.select_model(X_val, y_val, min_lambda=float(min_lambda), make_fig=False)
    y_pred = np.asarray(model.predict(X_test), dtype=float).reshape(-1, 1)
    frac_dev_expl, d_model, d_null = glm_mod.deviance(y_pred, y_test, loss_type="poisson")
    return {
        "backend": "tensorflow_glm_holdout",
        "model": model,
        "prediction_test": y_pred.reshape(-1),
        "frac_dev_expl": float(np.ravel(frac_dev_expl)[0]) if np.size(frac_dev_expl) else np.nan,
        "model_deviance": float(np.ravel(d_model)[0]) if np.size(d_model) else np.nan,
        "null_deviance": float(np.ravel(d_null)[0]) if np.size(d_null) else np.nan,
        "selected_lambda": float(np.ravel(model.selected_lambda)[0]) if hasattr(model, "selected_lambda") else np.nan,
        "n_train": int(X_train.shape[0]),
        "n_val": int(X_val.shape[0]),
        "n_test": int(X_test.shape[0]),
        "n_features": int(X_train.shape[1]),
    }


def _default_lambda_series():
    return 10.0 ** np.linspace(-1, -6, 14)


def _coerce_feature_group_size(feature_group_size, n_features: int):
    if feature_group_size is None:
        return [1] * int(n_features)
    fgs = [int(v) for v in feature_group_size]
    if sum(fgs) != int(n_features):
        raise ValueError(f"feature_group_size sums to {sum(fgs)} but n_features={n_features}")
    return fgs


def fit_poisson_glm_cv(
    X,
    y,
    *,
    groups=None,
    n_folds: int = 5,
    random_state: int = 0,
    regularization: str = "group_lasso",
    lambda_series=None,
    feature_group_size=None,
    min_iter_per_lambda: int = 100,
    max_iter_per_lambda: int = 2000,
    se_fraction: float = 1.0,
    min_lambda: float = 0.0,
    learning_rate: float = 1e-3,
    verbose: bool = False,
    allow_statsmodels_fallback: bool = True,
):
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).ravel()
    n = min(X.shape[0], y.shape[0])
    X = X[:n]
    y = y[:n]
    y2 = y.reshape(-1, 1)
    g = None if groups is None else np.asarray(groups)[:n]
    if X.shape[0] < 20:
        raise ValueError("Need at least 20 observations for stable GLM-CV fit")
    try:
        glm_mod, _ = _import_tf_glm_modules()
        lambda_series = _default_lambda_series() if lambda_series is None else np.asarray(lambda_series, dtype=float)
        split_by_group = g is not None
        model = glm_mod.GLM_CV(
            n_folds=int(n_folds),
            auto_split=True,
            split_by_group=bool(split_by_group),
            split_random_state=int(random_state),
            activation="exp",
            loss_type="poisson",
            regularization=str(regularization),
            lambda_series=lambda_series,
            learning_rate=float(learning_rate),
            min_iter_per_lambda=int(min_iter_per_lambda),
            max_iter_per_lambda=int(max_iter_per_lambda),
        )
        fit_kwargs = {
            "X": X,
            "Y": y2,
            "group_idx": g if split_by_group else None,
            "verbose": bool(verbose),
        }
        if str(regularization) == "group_lasso":
            fit_kwargs["feature_group_size"] = _coerce_feature_group_size(feature_group_size, X.shape[1])
        model.fit(**fit_kwargs)
        model.select_model(se_fraction=float(se_fraction), min_lambda=float(min_lambda), make_fig=False)
        pred = np.asarray(model.predict(X), dtype=float).reshape(-1)
        frac_dev_expl, d_model, d_null = model.evaluate(X, y2, make_fig=False)
        return {
            "backend": "tensorflow_glm_cv",
            "model": model,
            "prediction": pred,
            "frac_dev_expl": float(np.ravel(frac_dev_expl)[0]) if np.size(frac_dev_expl) else np.nan,
            "model_deviance": float(np.ravel(d_model)[0]) if np.size(d_model) else np.nan,
            "null_deviance": float(np.ravel(d_null)[0]) if np.size(d_null) else np.nan,
            "selected_lambda": float(np.ravel(model.selected_lambda)[0]) if hasattr(model, "selected_lambda") else np.nan,
            "selected_lambda_index": int(np.ravel(model.selected_lambda_ind)[0]) if hasattr(model, "selected_lambda_ind") else -1,
            "n_obs": int(X.shape[0]),
            "n_features": int(X.shape[1]),
        }
    except Exception as exc:
        if not allow_statsmodels_fallback:
            raise
        out = fit_poisson_glm_statsmodels(X, y)
        out["backend_error"] = str(exc)
        return out


def fit_mixedlm_statsmodels(X, y, groups, *, maxiter: int = 300):
    if sm is None:
        raise ImportError("statsmodels is unavailable")
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).ravel()
    g = np.asarray(groups)
    fit = sm.MixedLM(
        y,
        sm.add_constant(X, has_constant="add"),
        groups=g,
    ).fit(reml=False, method="lbfgs", maxiter=int(maxiter), disp=False)
    # MixedLM can fail to compute random-effects fitted values when covariance is singular.
    # Fall back to fixed-effects-only prediction so notebook pipelines remain executable.
    pred_source = "fittedvalues_with_random_effects"
    try:
        pred = np.asarray(fit.fittedvalues, dtype=float)
    except Exception:
        pred_source = "fixed_effect_only_fallback"
        exog = np.asarray(getattr(fit.model, "exog", sm.add_constant(X, has_constant="add")), dtype=float)
        fe = np.asarray(getattr(fit, "fe_params", np.zeros(exog.shape[1], dtype=float)), dtype=float).ravel()
        k = min(int(exog.shape[1]), int(fe.shape[0]))
        pred = exog[:, :k] @ fe[:k]
    return {
        "backend": "statsmodels_mixedlm",
        "fit": fit,
        "prediction": pred,
        "prediction_source": pred_source,
        "converged": bool(getattr(fit, "converged", False)),
        "aic": float(getattr(fit, "aic", np.nan)),
        "n_obs": int(X.shape[0]),
        "n_features": int(X.shape[1]),
        "n_groups": int(np.unique(g).size),
    }


def fit_mixed_switch_glm_cv(
    X,
    y,
    t=None,
    *,
    groups=None,
    n_folds: int = 5,
    random_state: int = 0,
    regularization: str = "group_lasso",
    lambda_series=None,
    feature_group_size=None,
    min_iter_per_lambda: int = 100,
    max_iter_per_lambda: int = 2000,
    se_fraction: float = 1.0,
    min_lambda: float = 0.0,
    learning_rate: float = 1e-3,
    verbose: bool = False,
    allow_statsmodels_fallback: bool = True,
):
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).ravel()
    n = min(X.shape[0], y.shape[0])
    X = X[:n]
    y = y[:n]
    y2 = y.reshape(-1, 1)
    if t is None:
        t = np.linspace(0.0, 1.0, num=n, endpoint=False, dtype=float)
    else:
        t = np.asarray(t, dtype=float).ravel()[:n]
    g = None if groups is None else np.asarray(groups)[:n]
    if X.shape[0] < 20:
        raise ValueError("Need at least 20 observations for stable mixGLM-CV fit")
    try:
        _, mixglm_mod = _import_tf_glm_modules()
        lambda_series = _default_lambda_series() if lambda_series is None else np.asarray(lambda_series, dtype=float)
        split_by_group = g is not None
        model = mixglm_mod.mixGLM_CV(
            n_folds=int(n_folds),
            auto_split=True,
            split_by_group=bool(split_by_group),
            split_random_state=int(random_state),
            activation="exp",
            loss_type="poisson",
            regularization=str(regularization),
            lambda_series=lambda_series,
            learning_rate=float(learning_rate),
            min_iter_per_lambda=int(min_iter_per_lambda),
            max_iter_per_lambda=int(max_iter_per_lambda),
        )
        fit_kwargs = {
            "X": X,
            "Y": y2,
            "t": t,
            "group_idx": g if split_by_group else None,
            "verbose": bool(verbose),
        }
        if str(regularization) == "group_lasso":
            fit_kwargs["feature_group_size"] = _coerce_feature_group_size(feature_group_size, X.shape[1])
        model.fit(**fit_kwargs)
        model.select_model(se_fraction=float(se_fraction), min_lambda=float(min_lambda), make_fig=False)
        pred = np.asarray(model.predict(X, t), dtype=float).reshape(-1)
        frac_dev_expl, d_model, d_null, dev_expl = model.evaluate(X, y2, t, make_fig=False)
        return {
            "backend": "tensorflow_mixglm_cv",
            "model": model,
            "prediction": pred,
            "frac_dev_expl": float(np.ravel(frac_dev_expl)[0]) if np.size(frac_dev_expl) else np.nan,
            "model_deviance": float(np.ravel(d_model)[0]) if np.size(d_model) else np.nan,
            "null_deviance": float(np.ravel(d_null)[0]) if np.size(d_null) else np.nan,
            "deviance_explained": float(np.ravel(dev_expl)[0]) if np.size(dev_expl) else np.nan,
            "selected_lambda": float(np.ravel(model.selected_lambda)[0]) if hasattr(model, "selected_lambda") else np.nan,
            "selected_lambda_index": int(np.ravel(model.selected_lambda_ind)[0]) if hasattr(model, "selected_lambda_ind") else -1,
            "n_obs": int(X.shape[0]),
            "n_features": int(X.shape[1]),
        }
    except Exception as exc:
        if not allow_statsmodels_fallback:
            raise
        if g is None:
            g = np.arange(X.shape[0]) // 200
        out = fit_mixedlm_statsmodels(X, y, g)
        out["backend_error"] = str(exc)
        return out
