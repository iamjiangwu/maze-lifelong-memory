from __future__ import annotations

import json
import math
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

from .behavior import default_behavior_groups_260113
from .behavior_models import fit_four_bias_model
from .exploration import compute_scalar_efficiency_metrics, extract_explore_endnode_sequence
from .jw_utils import process_behav_data
from .maze import NewMaze
from .mode_analysis import split_mode_clips
from .trajectory import FindPathsToNode, LoadTraj, TimeInMaze


@dataclass(frozen=True)
class ComparisonConfig:
    group_a_name: str
    group_b_name: str
    group_a_sessions: list[str]
    group_b_sessions: list[str]
    reward_node: int = 94
    long_path_min: int = 7
    time_bin_sec: int = 300
    equivalence_low: float = 0.8
    equivalence_high: float = 1.25
    consecutive_bins: int = 3
    maze_id: int = 6
    fps: float = 25.0

    def __post_init__(self) -> None:
        if int(self.reward_node) != 94:
            raise ValueError(
                "Primary reward location is fixed to node 94. "
                "Node 116 is legacy-only and cannot be used as the reward target."
            )


def default_comparison_config() -> ComparisonConfig:
    groups = default_behavior_groups_260113()
    return ComparisonConfig(
        group_a_name="ChemoUBIday2",
        group_b_name="AllUnrewardedDay2",
        group_a_sessions=list(groups.get("ChemoUBIday2", [])),
        group_b_sessions=list(groups.get("AllUnrewardedDay2", [])),
    )


def _safe_numeric(x: np.ndarray | pd.Series | list[float]) -> np.ndarray:
    arr = np.asarray(x, dtype=float).ravel()
    return arr[np.isfinite(arr)]


def _session_day1_alias(day2_session: str) -> str:
    return re.sub(r"day2$", "day1", str(day2_session))


def build_video_lookup(working_dir: str | Path) -> dict[str, str]:
    working_dir = Path(working_dir)
    meta_path = working_dir / "experiment_metafile.csv"
    df = pd.read_csv(meta_path)
    df = df.dropna(subset=["animal", "ID"])
    return {str(a): str(i) for a, i in zip(df["animal"], df["ID"])}


def validate_session_context(config: ComparisonConfig, working_dir: str | Path) -> pd.DataFrame:
    working_dir = Path(working_dir)
    meta = pd.read_csv(working_dir / "experiment_metafile.csv")
    rows: list[dict[str, Any]] = []

    for group_name, sessions in [
        (config.group_a_name, config.group_a_sessions),
        (config.group_b_name, config.group_b_sessions),
    ]:
        for day2 in sessions:
            day1 = _session_day1_alias(day2)
            r2 = meta.loc[meta["animal"] == day2]
            r1 = meta.loc[meta["animal"] == day1]

            day2_found = not r2.empty
            day1_found = not r1.empty

            day2_reward_scheme = str(r2["Reward_Scheme"].iloc[0]) if day2_found else ""
            day2_reward_cfg = str(r2["reward_config"].iloc[0]) if day2_found else ""
            day1_reward_scheme = str(r1["Reward_Scheme"].iloc[0]) if day1_found else ""

            rows.append(
                {
                    "group": group_name,
                    "session_day2": day2,
                    "session_day1": day1,
                    "day2_found": bool(day2_found),
                    "day1_found": bool(day1_found),
                    "day2_reward_scheme": day2_reward_scheme,
                    "day2_reward_config": day2_reward_cfg,
                    "day1_reward_scheme": day1_reward_scheme,
                    "day2_reward_ok": bool(day2_found and str(day2_reward_cfg).lower() == "port2"),
                    "day1_no_reward_ok": bool(day1_found and "no reward" in day1_reward_scheme.lower()),
                }
            )
    return pd.DataFrame(rows)


def ensure_selected_data_exists(
    sessions: list[str],
    working_dir: str | Path,
    ma: Any,
    video_lookup: dict[str, str],
    *,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> pd.DataFrame:
    working_dir = Path(working_dir)
    out_rows: list[dict[str, Any]] = []
    selected_dir = working_dir / "selected_data"
    selected_dir.mkdir(parents=True, exist_ok=True)

    for session in [str(s) for s in sessions]:
        selected_csv = selected_dir / f"{session}_selected_data.csv"
        nose_csv = selected_dir / f"{session}_nose_interp_data.csv"
        selected_before = selected_csv.exists()
        nose_before = nose_csv.exists()

        attempted = False
        ok = bool(selected_before and nose_before)
        error = ""

        if not ok:
            attempted = True
            try:
                if session not in video_lookup:
                    raise KeyError(f"missing video lookup for session {session}")
                tr = load_traj_fn(f"{session}-tf")
                process_behav_data(str(working_dir), video_lookup, session, tr, ma)
                ok = bool(selected_csv.exists() and nose_csv.exists())
                if not ok:
                    error = "regeneration completed but csv still missing"
            except Exception as exc:
                ok = False
                error = str(exc)

        out_rows.append(
            {
                "session": session,
                "selected_exists_before": bool(selected_before),
                "nose_exists_before": bool(nose_before),
                "attempted_regen": bool(attempted),
                "regen_ok": bool(ok),
                "error": error,
            }
        )

    return pd.DataFrame(out_rows)


def _extract_reward_frames(tf: Any) -> np.ndarray:
    out: list[float] = []
    re_all = getattr(tf, "re", [])
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    if len(re_all) == 0 or fr.ndim != 2 or fr.shape[1] < 2:
        return np.asarray([], dtype=float)

    for i, bout_rewards in enumerate(re_all):
        if i >= fr.shape[0]:
            continue
        start = float(fr[i, 0])
        arr = np.asarray(bout_rewards, dtype=object)
        if arr.size == 0:
            continue
        if np.isscalar(bout_rewards):
            out.append(float(bout_rewards) + start)
            continue
        for r in bout_rewards:
            if r is None:
                continue
            if np.isscalar(r):
                out.append(float(r) + start)
            else:
                rv = np.asarray(r).ravel()
                if rv.size:
                    out.append(float(rv[0]) + start)

    if not out:
        return np.asarray([], dtype=float)
    return np.sort(np.asarray(out, dtype=float))


def extract_reward_events(
    tf: Any,
    *,
    session: str = "",
    time_in_maze_fn: Callable[[Any, Any], float] = TimeInMaze,
) -> pd.DataFrame:
    frames = _extract_reward_frames(tf)
    if frames.size == 0:
        return pd.DataFrame(columns=["session", "abs_frame", "maze_seconds", "event_type"])
    maze_sec = np.asarray([time_in_maze_fn(float(f), tf) for f in frames], dtype=float)
    return pd.DataFrame(
        {
            "session": str(session),
            "abs_frame": frames.astype(float),
            "maze_seconds": maze_sec,
            "event_type": "reward",
        }
    )


def _path_table(x: Any) -> np.ndarray:
    arr = np.asarray(x)
    if arr.size == 0:
        return np.zeros((0, 4), dtype=float)
    if arr.ndim == 1:
        if arr.size % 4 != 0:
            return np.zeros((0, 4), dtype=float)
        arr = arr.reshape(-1, 4)
    if arr.ndim != 2 or arr.shape[1] < 4:
        return np.zeros((0, 4), dtype=float)
    return arr[:, :4].astype(float)


def extract_long_path_events(
    tf: Any,
    ma: Any,
    *,
    reward_node: int = 94,
    long_path_min: int = 7,
    session: str = "",
    find_paths_to_node_fn: Callable[..., Any] = FindPathsToNode,
    time_in_maze_fn: Callable[[Any, Any], float] = TimeInMaze,
) -> pd.DataFrame:
    if int(reward_node) != 94:
        raise ValueError("Reward node must be 94 in primary analysis.")
    ptn = _path_table(find_paths_to_node_fn(int(reward_node), tf, ma))
    if ptn.size == 0:
        return pd.DataFrame(columns=["session", "abs_frame", "maze_seconds", "node_distance", "event_type"])

    keep = ptn[:, 2] >= float(long_path_min)
    ptn = ptn[keep]
    if ptn.size == 0:
        return pd.DataFrame(columns=["session", "abs_frame", "maze_seconds", "node_distance", "event_type"])

    frames = ptn[:, 3]
    maze_sec = np.asarray([time_in_maze_fn(float(f), tf) for f in frames], dtype=float)
    return pd.DataFrame(
        {
            "session": str(session),
            "abs_frame": frames.astype(float),
            "maze_seconds": maze_sec,
            "node_distance": ptn[:, 2].astype(float),
            "event_type": "long_path_reward",
        }
    )


def extract_control_path_events(
    tf: Any,
    ma: Any,
    *,
    control_nodes: tuple[int, int, int] = (116, 95, 73),
    long_path_min: int = 7,
    session: str = "",
    find_paths_to_node_fn: Callable[..., Any] = FindPathsToNode,
    time_in_maze_fn: Callable[[Any, Any], float] = TimeInMaze,
) -> pd.DataFrame:
    parts: list[pd.DataFrame] = []
    for node in control_nodes:
        ptn = _path_table(find_paths_to_node_fn(int(node), tf, ma))
        if ptn.size == 0:
            continue
        ptn = ptn[ptn[:, 2] >= float(long_path_min)]
        if ptn.size == 0:
            continue
        frames = ptn[:, 3]
        maze_sec = np.asarray([time_in_maze_fn(float(f), tf) for f in frames], dtype=float)
        parts.append(
            pd.DataFrame(
                {
                    "session": str(session),
                    "abs_frame": frames.astype(float),
                    "maze_seconds": maze_sec,
                    "node_distance": ptn[:, 2].astype(float),
                    "control_node": int(node),
                    "event_type": "control_path",
                }
            )
        )
    if not parts:
        return pd.DataFrame(columns=["session", "abs_frame", "maze_seconds", "node_distance", "control_node", "event_type"])
    return pd.concat(parts, ignore_index=True)


def _session_maze_duration(tf: Any, fps: float = 25.0) -> float:
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    if fr.ndim != 2 or fr.shape[1] < 2 or fr.shape[0] == 0:
        return np.nan
    return float(np.sum(np.maximum(0.0, fr[:, 1] - fr[:, 0])) / float(max(fps, 1e-9)))


def collect_session_records(
    config: ComparisonConfig,
    ma: Any,
    *,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> tuple[dict[str, Any], pd.DataFrame]:
    _ = ma
    all_sessions = [(config.group_a_name, s) for s in config.group_a_sessions] + [
        (config.group_b_name, s) for s in config.group_b_sessions
    ]

    store: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    for group, session in all_sessions:
        try:
            tf = load_traj_fn(f"{session}-tf")
            dur = _session_maze_duration(tf, fps=config.fps)
            store[str(session)] = tf
            rows.append(
                {
                    "session": str(session),
                    "group": str(group),
                    "load_ok": True,
                    "maze_duration_sec": float(dur),
                    "error": "",
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "session": str(session),
                    "group": str(group),
                    "load_ok": False,
                    "maze_duration_sec": np.nan,
                    "error": str(exc),
                }
            )
    return store, pd.DataFrame(rows)


def build_event_table(
    config: ComparisonConfig,
    ma: Any,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> pd.DataFrame:
    if int(config.reward_node) != 94:
        raise ValueError("Primary analysis requires reward_node=94.")

    store, qc = collect_session_records(config, ma, load_traj_fn=load_traj_fn)
    rows: list[pd.DataFrame] = []

    session_to_group = {
        **{s: config.group_a_name for s in config.group_a_sessions},
        **{s: config.group_b_name for s in config.group_b_sessions},
    }

    for session, tf in store.items():
        group = session_to_group.get(session, "")
        rew = extract_reward_events(tf, session=session)
        lp = extract_long_path_events(
            tf,
            ma,
            reward_node=config.reward_node,
            long_path_min=config.long_path_min,
            session=session,
        )
        cp = extract_control_path_events(
            tf,
            ma,
            long_path_min=config.long_path_min,
            session=session,
        )
        for d in [rew, lp, cp]:
            if not d.empty:
                d["group"] = group
                rows.append(d)

    if not rows:
        out = pd.DataFrame(columns=["session", "group", "abs_frame", "maze_seconds", "event_type"])
    else:
        out = pd.concat(rows, ignore_index=True)
        out = out.sort_values(["group", "session", "maze_seconds", "event_type"]).reset_index(drop=True)

    out.attrs["session_qc"] = qc
    return out


def _all_event_types(df: pd.DataFrame) -> list[str]:
    types = ["reward", "long_path_reward", "control_path"]
    if "event_type" in df.columns:
        for t in sorted(df["event_type"].dropna().astype(str).unique()):
            if t not in types:
                types.append(t)
    return types


def build_binned_rates(
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    *,
    time_bin_sec: int,
) -> pd.DataFrame:
    if session_qc.empty:
        return pd.DataFrame(
            columns=[
                "group",
                "session",
                "event_type",
                "time_bin",
                "time_bin_start",
                "time_bin_end",
                "count",
                "rate",
                "bin_width",
            ]
        )

    keep_qc = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712
    event_types = _all_event_types(event_table)
    out_rows: list[dict[str, Any]] = []

    for _, r in keep_qc.iterrows():
        session = str(r["session"])
        group = str(r["group"])
        dur = float(r["maze_duration_sec"])
        if not np.isfinite(dur) or dur <= 0:
            continue
        n_bins = int(max(1, math.ceil(dur / float(time_bin_sec))))
        edges = np.arange(n_bins + 1, dtype=float) * float(time_bin_sec)
        edges[-1] = max(edges[-1], dur)

        ses_events = event_table.loc[event_table["session"] == session] if not event_table.empty else pd.DataFrame()
        for et in event_types:
            if ses_events.empty:
                times = np.asarray([], dtype=float)
            else:
                times = _safe_numeric(ses_events.loc[ses_events["event_type"] == et, "maze_seconds"].to_numpy())
            counts, _ = np.histogram(times, bins=edges)
            for i in range(n_bins):
                lo = float(edges[i])
                hi = float(edges[i + 1])
                width = max(hi - lo, 1e-9)
                c = int(counts[i]) if i < counts.size else 0
                out_rows.append(
                    {
                        "group": group,
                        "session": session,
                        "event_type": et,
                        "time_bin": int(i),
                        "time_bin_start": lo,
                        "time_bin_end": hi,
                        "count": c,
                        "rate": float(c / width),
                        "bin_width": float(width),
                    }
                )

    return pd.DataFrame(out_rows)


def _bootstrap_ratio_by_bin(
    binned_rates: pd.DataFrame,
    *,
    event_type: str,
    group_a: str,
    group_b: str,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(int(seed))
    sub = binned_rates.loc[binned_rates["event_type"] == str(event_type)].copy()
    if sub.empty:
        return pd.DataFrame(
            columns=[
                "event_type",
                "time_bin",
                "time_bin_start",
                "mean_rate_a",
                "mean_rate_b",
                "ratio_mean",
                "ratio_ci_low",
                "ratio_ci_high",
            ]
        )

    rows: list[dict[str, Any]] = []
    for (tb, tbs), block in sub.groupby(["time_bin", "time_bin_start"], sort=True):
        a = _safe_numeric(block.loc[block["group"] == group_a, "rate"].to_numpy())
        b = _safe_numeric(block.loc[block["group"] == group_b, "rate"].to_numpy())
        if a.size == 0 or b.size == 0:
            continue

        boot = np.zeros(int(max(10, n_boot)), dtype=float)
        for i in range(boot.size):
            ra = float(rng.choice(a, size=a.size, replace=True).mean())
            rb = float(rng.choice(b, size=b.size, replace=True).mean())
            boot[i] = ra / (rb + 1e-9)

        rows.append(
            {
                "event_type": str(event_type),
                "time_bin": int(tb),
                "time_bin_start": float(tbs),
                "mean_rate_a": float(np.mean(a)),
                "mean_rate_b": float(np.mean(b)),
                "ratio_mean": float(np.mean(boot)),
                "ratio_ci_low": float(np.quantile(boot, 0.025)),
                "ratio_ci_high": float(np.quantile(boot, 0.975)),
            }
        )

    return pd.DataFrame(rows).sort_values("time_bin_start").reset_index(drop=True)


def _bootstrap_cumulative_gap_by_time(
    curve_session: pd.DataFrame,
    *,
    event_type: str,
    group_a: str,
    group_b: str,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    if curve_session.empty:
        return pd.DataFrame(
            columns=[
                "event_type",
                "maze_seconds",
                "mean_cum_a",
                "mean_cum_b",
                "gap_mean",
                "gap_ci_low",
                "gap_ci_high",
                "n_a",
                "n_b",
            ]
        )
    req = {"group", "session", "event_type", "maze_seconds", "cum_count"}
    if not req.issubset(set(curve_session.columns)):
        return pd.DataFrame(
            columns=[
                "event_type",
                "maze_seconds",
                "mean_cum_a",
                "mean_cum_b",
                "gap_mean",
                "gap_ci_low",
                "gap_ci_high",
                "n_a",
                "n_b",
            ]
        )

    sub = curve_session.loc[curve_session["event_type"] == str(event_type)].copy()
    if sub.empty:
        return pd.DataFrame(
            columns=[
                "event_type",
                "maze_seconds",
                "mean_cum_a",
                "mean_cum_b",
                "gap_mean",
                "gap_ci_low",
                "gap_ci_high",
                "n_a",
                "n_b",
            ]
        )

    rng = np.random.default_rng(int(seed))
    rows: list[dict[str, Any]] = []
    for t, block in sub.groupby("maze_seconds", sort=True):
        a = _safe_numeric(block.loc[block["group"] == str(group_a), "cum_count"].to_numpy())
        b = _safe_numeric(block.loc[block["group"] == str(group_b), "cum_count"].to_numpy())
        if a.size == 0 or b.size == 0:
            continue
        n_iter = int(max(200, n_boot))
        boot = np.zeros(n_iter, dtype=float)
        for i in range(n_iter):
            ma = float(rng.choice(a, size=a.size, replace=True).mean())
            mb = float(rng.choice(b, size=b.size, replace=True).mean())
            boot[i] = ma - mb
        rows.append(
            {
                "event_type": str(event_type),
                "maze_seconds": float(t),
                "mean_cum_a": float(np.mean(a)),
                "mean_cum_b": float(np.mean(b)),
                "gap_mean": float(np.mean(boot)),
                "gap_ci_low": float(np.quantile(boot, 0.025)),
                "gap_ci_high": float(np.quantile(boot, 0.975)),
                "n_a": int(a.size),
                "n_b": int(b.size),
            }
        )

    return pd.DataFrame(rows).sort_values("maze_seconds").reset_index(drop=True)


def estimate_divergence_breakpoint(
    binned_rates: pd.DataFrame,
    config: ComparisonConfig,
    n_boot: int = 5000,
    seed: int = 0,
    *,
    event_type: str = "reward",
) -> dict[str, Any]:
    ratio_df = _bootstrap_ratio_by_bin(
        binned_rates,
        event_type=event_type,
        group_a=config.group_a_name,
        group_b=config.group_b_name,
        n_boot=int(n_boot),
        seed=int(seed),
    )

    out = {
        "event_type": str(event_type),
        "t_break": np.nan,
        "found": False,
        "fallback_used": False,
        "fallback_reason": "",
        "ratio_df": ratio_df,
    }

    if ratio_df.empty:
        out["fallback_used"] = True
        out["fallback_reason"] = "no ratio rows"
        out["t_break"] = 3000.0
        return out

    outside = (ratio_df["ratio_ci_high"] < float(config.equivalence_low)) | (
        ratio_df["ratio_ci_low"] > float(config.equivalence_high)
    )
    outside = outside.to_numpy(dtype=bool)

    k = int(max(1, config.consecutive_bins))
    idx = -1
    for i in range(0, len(outside) - k + 1):
        if bool(np.all(outside[i : i + k])):
            idx = i
            break

    if idx >= 0:
        out["t_break"] = float(ratio_df.iloc[idx]["time_bin_start"])
        out["found"] = True
        return out

    out["fallback_used"] = True
    out["fallback_reason"] = "no sustained CI departure"
    out["t_break"] = 3000.0 if float(ratio_df["time_bin_start"].max()) >= 3000.0 else float(ratio_df["time_bin_start"].max())
    return out


def estimate_divergence_breakpoint_from_cumulative(
    cumulative_gap_df: pd.DataFrame,
    config: ComparisonConfig,
) -> dict[str, Any]:
    out = {
        "event_type": "reward",
        "t_break": np.nan,
        "found": False,
        "fallback_used": False,
        "fallback_reason": "",
        "gap_df": cumulative_gap_df,
    }
    if cumulative_gap_df is None or cumulative_gap_df.empty:
        out["fallback_used"] = True
        out["fallback_reason"] = "no cumulative-gap rows"
        out["t_break"] = 3000.0
        return out

    s = cumulative_gap_df.sort_values("maze_seconds").reset_index(drop=True)
    outside = (s["gap_ci_low"] > 0.0) | (s["gap_ci_high"] < 0.0)
    outside = outside.to_numpy(dtype=bool)
    k = int(max(1, config.consecutive_bins))

    idx = -1
    for i in range(0, len(outside) - k + 1):
        if bool(np.all(outside[i : i + k])):
            idx = i
            break

    if idx >= 0:
        out["t_break"] = float(s.iloc[idx]["maze_seconds"])
        out["found"] = True
        return out

    out["fallback_used"] = True
    out["fallback_reason"] = "no sustained cumulative-gap departure"
    mx = float(pd.to_numeric(s["maze_seconds"], errors="coerce").max())
    out["t_break"] = 3000.0 if np.isfinite(mx) and mx >= 3000.0 else mx
    return out


def _early_equivalence_summary(
    ratio_df: pd.DataFrame,
    *,
    t_break: float,
    eq_low: float,
    eq_high: float,
) -> dict[str, Any]:
    sub = ratio_df.loc[ratio_df["time_bin_start"] < float(t_break)].copy()
    if sub.empty:
        return {
            "n_bins": 0,
            "equivalent": False,
            "mean_ratio": np.nan,
            "ci_low_min": np.nan,
            "ci_high_max": np.nan,
        }

    inside = (sub["ratio_ci_low"] >= float(eq_low)) & (sub["ratio_ci_high"] <= float(eq_high))
    return {
        "n_bins": int(len(sub)),
        "equivalent": bool(inside.all()),
        "mean_ratio": float(sub["ratio_mean"].mean()),
        "ci_low_min": float(sub["ratio_ci_low"].min()),
        "ci_high_max": float(sub["ratio_ci_high"].max()),
    }


def _early_equivalence_summary_gap(
    gap_df: pd.DataFrame,
    *,
    t_break: float,
) -> dict[str, Any]:
    sub = gap_df.loc[pd.to_numeric(gap_df["maze_seconds"], errors="coerce") < float(t_break)].copy()
    if sub.empty:
        return {
            "n_bins": 0,
            "equivalent": False,
            "mean_gap": np.nan,
            "ci_low_min": np.nan,
            "ci_high_max": np.nan,
        }
    inside = (pd.to_numeric(sub["gap_ci_low"], errors="coerce") <= 0.0) & (
        pd.to_numeric(sub["gap_ci_high"], errors="coerce") >= 0.0
    )
    return {
        "n_bins": int(len(sub)),
        "equivalent": bool(inside.all()),
        "mean_gap": float(pd.to_numeric(sub["gap_mean"], errors="coerce").mean()),
        "ci_low_min": float(pd.to_numeric(sub["gap_ci_low"], errors="coerce").min()),
        "ci_high_max": float(pd.to_numeric(sub["gap_ci_high"], errors="coerce").max()),
    }


def _cliffs_delta(x: np.ndarray, y: np.ndarray) -> float:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan
    gt = 0
    lt = 0
    for v in a:
        gt += int(np.sum(v > b))
        lt += int(np.sum(v < b))
    return float((gt - lt) / (a.size * b.size))


def _perm_pvalue(x: np.ndarray, y: np.ndarray, *, n_perm: int, seed: int) -> tuple[float, float]:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan, np.nan
    obs = float(np.nanmedian(a) - np.nanmedian(b))
    pool = np.concatenate([a, b])
    n_a = a.size
    rng = np.random.default_rng(int(seed))
    n_iter = int(max(100, n_perm))
    more_extreme = 0
    for _ in range(n_iter):
        perm = rng.permutation(pool)
        d = float(np.nanmedian(perm[:n_a]) - np.nanmedian(perm[n_a:]))
        if abs(d) >= abs(obs):
            more_extreme += 1
    p = float((more_extreme + 1) / (n_iter + 1))
    return obs, p


def _bootstrap_diff_ci(x: np.ndarray, y: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(int(seed))
    n_iter = int(max(200, n_boot))
    diffs = np.zeros(n_iter, dtype=float)
    for i in range(n_iter):
        xa = rng.choice(a, size=a.size, replace=True)
        xb = rng.choice(b, size=b.size, replace=True)
        diffs[i] = float(np.nanmedian(xa) - np.nanmedian(xb))
    return float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))


def _safe_rate(n: int, duration_sec: float) -> float:
    d = float(duration_sec)
    if not np.isfinite(d) or d <= 0:
        return np.nan
    return float(n / d)


def _split_duration(total: float, t_break: float) -> tuple[float, float]:
    total = float(total)
    if not np.isfinite(total) or total <= 0:
        return np.nan, np.nan
    pre = min(total, max(0.0, float(t_break)))
    post = max(0.0, total - pre)
    return float(pre), float(post)


def _frames_to_maze_seconds(abs_frames: np.ndarray, tf: Any, *, fps: float = 25.0) -> np.ndarray:
    frames = np.asarray(abs_frames, dtype=float).ravel()
    if frames.size == 0:
        return np.asarray([], dtype=float)
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    if fr.ndim != 2 or fr.shape[1] < 2 or fr.shape[0] == 0:
        return frames / float(max(fps, 1e-9))

    starts = fr[:, 0].astype(float, copy=False)
    ends = fr[:, 1].astype(float, copy=False)
    lengths = np.maximum(0.0, ends - starts)
    cum = np.zeros(fr.shape[0], dtype=float)
    if cum.size > 1:
        cum[1:] = np.cumsum(lengths[:-1])
    idx = np.searchsorted(starts, frames, side="right") - 1
    out = np.full(frames.size, np.nan, dtype=float)
    ok = (idx >= 0) & (idx < fr.shape[0])
    if np.any(ok):
        ii = idx[ok]
        ff = frames[ok]
        valid = ff <= ends[ii]
        jj = np.where(ok)[0][valid]
        if jj.size:
            iii = idx[jj]
            out[jj] = (cum[iii] + (frames[jj] - starts[iii])) / float(max(fps, 1e-9))
    bad = ~np.isfinite(out)
    if np.any(bad):
        out[bad] = frames[bad] / float(max(fps, 1e-9))
    return out


def _count_in_window(times: np.ndarray, lo: float, hi: float) -> int:
    t = _safe_numeric(times)
    if t.size == 0:
        return 0
    return int(np.sum((t >= float(lo)) & (t < float(hi))))


def _ratio_or_nan(a: float, b: float) -> float:
    a = float(a)
    b = float(b)
    if not np.isfinite(a) or not np.isfinite(b) or b <= 0:
        return np.nan
    return float(a / b)


def _load_optional_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def _event_time_lookup(event_table: pd.DataFrame, session: str, event_type: str) -> np.ndarray:
    if event_table.empty:
        return np.asarray([], dtype=float)
    sub = event_table.loc[
        (event_table["session"].astype(str) == str(session))
        & (event_table["event_type"].astype(str) == str(event_type)),
        "maze_seconds",
    ]
    return _safe_numeric(sub.to_numpy())


def _mode_clip_intervals(tf: Any, ma: Any) -> pd.DataFrame:
    cl = np.asarray(split_mode_clips(tf, ma, include_reward=True))
    if cl.size == 0:
        return pd.DataFrame(columns=["mode", "t0", "t1", "duration"])

    rows: list[dict[str, Any]] = []
    no = getattr(tf, "no", [])
    fr = np.asarray(getattr(tf, "fr", []), dtype=float)
    for row in cl:
        bout = int(row[0])
        start = int(row[1])
        nstep = int(max(1, row[2]))
        mode = int(row[3])
        if bout < 0 or bout >= len(no):
            continue
        bout_arr = np.asarray(no[bout])
        if bout_arr.ndim != 2 or bout_arr.shape[1] < 2 or bout_arr.shape[0] <= 1:
            continue
        s = int(np.clip(start, 0, max(0, bout_arr.shape[0] - 1)))
        e = int(np.clip(start + nstep, s + 1, bout_arr.shape[0] - 1))
        start_abs = float(bout_arr[s, 1] + fr[bout, 0]) if bout < fr.shape[0] else float(bout_arr[s, 1])
        end_abs = float(bout_arr[e, 1] + fr[bout, 0]) if bout < fr.shape[0] else float(bout_arr[e, 1])
        t0 = float(TimeInMaze(start_abs, tf))
        t1 = float(TimeInMaze(end_abs, tf))
        if not np.isfinite(t0) or not np.isfinite(t1):
            continue
        if t1 < t0:
            t0, t1 = t1, t0
        if t1 <= t0:
            t1 = t0 + 1e-3
        rows.append({"mode": mode, "t0": t0, "t1": t1, "duration": float(t1 - t0)})
    return pd.DataFrame(rows)


def _interval_overlap(t0: float, t1: float, lo: float, hi: float) -> float:
    return float(max(0.0, min(float(t1), float(hi)) - max(float(t0), float(lo))))


def _mode_fraction_between(intervals: pd.DataFrame, lo: float, hi: float) -> tuple[float, float, float]:
    if intervals.empty:
        return np.nan, np.nan, np.nan
    dur = {0: 0.0, 1: 0.0, 2: 0.0}
    for _, row in intervals.iterrows():
        o = _interval_overlap(float(row["t0"]), float(row["t1"]), float(lo), float(hi))
        if o <= 0:
            continue
        m = int(row["mode"])
        if m in dur:
            dur[m] += o
    den = dur[0] + dur[1] + dur[2]
    if den <= 0:
        return np.nan, np.nan, np.nan
    return float(dur[0] / den), float(dur[1] / den), float(dur[2] / den)


def _split_nodes_by_break(tf: Any, ma: Any, t_break: float, fps: float) -> tuple[np.ndarray, np.ndarray]:
    nodes, frames = extract_explore_endnode_sequence(tf, ma, return_frames=True)
    if len(nodes) == 0 or len(frames) == 0:
        return np.asarray([], dtype=int), np.asarray([], dtype=int)
    times = _frames_to_maze_seconds(np.asarray(frames, dtype=float), tf, fps=fps)
    keep = np.isfinite(times)
    nodes = np.asarray(nodes, dtype=int)[keep]
    times = times[keep]
    return nodes[times < float(t_break)], nodes[times >= float(t_break)]


def _sequence_scalar_metrics(seq: np.ndarray) -> dict[str, float]:
    if len(seq) < 5:
        return {"outer_inner_preference": np.nan, "entropy_norm": np.nan}
    out = compute_scalar_efficiency_metrics(np.asarray(seq, dtype=int))
    return {
        "outer_inner_preference": float(out.get("outer_inner_preference_mean", np.nan)),
        "entropy_norm": float(out.get("entropy_norm_mean", np.nan)),
    }


def _sequence_bias_metrics(seq: np.ndarray, ma: Any) -> dict[str, float]:
    keys = ("bias_in_left", "bias_in_right", "bias_out_left", "bias_out_right")
    if len(seq) < 5:
        return {k: np.nan for k in keys}
    try:
        model = fit_four_bias_model(np.asarray(seq, dtype=int), ma)
        p = np.asarray(model.probs, dtype=float).ravel()
        if p.size < 4:
            return {k: np.nan for k in keys}
        return {
            "bias_in_left": float(p[0]),
            "bias_in_right": float(p[1]),
            "bias_out_left": float(p[2]),
            "bias_out_right": float(p[3]),
        }
    except Exception:
        return {k: np.nan for k in keys}


def _speed_metrics_by_window(nose_df: pd.DataFrame, tf: Any, t_break: float, fps: float) -> dict[str, float]:
    out = {
        "speed_mean_pre": np.nan,
        "speed_mean_post": np.nan,
        "run_fraction_gt2_pre": np.nan,
        "run_fraction_gt2_post": np.nan,
    }
    if nose_df.empty or not {"frame", "speed"}.issubset(set(nose_df.columns)):
        return out
    frames = pd.to_numeric(nose_df["frame"], errors="coerce").to_numpy(dtype=float)
    speed = pd.to_numeric(nose_df["speed"], errors="coerce").to_numpy(dtype=float)
    times = _frames_to_maze_seconds(frames, tf, fps=fps)
    ok = np.isfinite(times) & np.isfinite(speed)
    if not np.any(ok):
        return out
    times = times[ok]
    speed = speed[ok]
    pre = times < float(t_break)
    post = times >= float(t_break)
    if np.any(pre):
        out["speed_mean_pre"] = float(np.nanmean(speed[pre]))
        out["run_fraction_gt2_pre"] = float(np.mean(speed[pre] > 2.0))
    if np.any(post):
        out["speed_mean_post"] = float(np.nanmean(speed[post]))
        out["run_fraction_gt2_post"] = float(np.mean(speed[post] > 2.0))
    return out


def build_session_metric_table(
    config: ComparisonConfig,
    ma: Any,
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    *,
    working_dir: str | Path,
    t_break: float,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> pd.DataFrame:
    working_dir = Path(working_dir)
    selected_dir = working_dir / "selected_data"
    out_rows: list[dict[str, Any]] = []
    keep_qc = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712

    for _, q in keep_qc.iterrows():
        session = str(q["session"])
        group = str(q["group"])
        duration = float(q["maze_duration_sec"])
        tf = load_traj_fn(f"{session}-tf")
        pre_dur, post_dur = _split_duration(duration, float(t_break))

        reward_t = _event_time_lookup(event_table, session, "reward")
        long_t = _event_time_lookup(event_table, session, "long_path_reward")
        ctrl_t = _event_time_lookup(event_table, session, "control_path")

        reward_pre = _count_in_window(reward_t, 0.0, t_break)
        reward_post = _count_in_window(reward_t, t_break, duration + 1e-9)
        long_pre = _count_in_window(long_t, 0.0, t_break)
        long_post = _count_in_window(long_t, t_break, duration + 1e-9)
        ctrl_pre = _count_in_window(ctrl_t, 0.0, t_break)
        ctrl_post = _count_in_window(ctrl_t, t_break, duration + 1e-9)

        intervals = _mode_clip_intervals(tf, ma)
        leave_pre, drink_pre, explore_pre = _mode_fraction_between(intervals, 0.0, t_break)
        leave_post, drink_post, explore_post = _mode_fraction_between(intervals, t_break, duration + 1e-9)

        nodes_pre, nodes_post = _split_nodes_by_break(tf, ma, float(t_break), config.fps)
        seq_pre = _sequence_scalar_metrics(nodes_pre)
        seq_post = _sequence_scalar_metrics(nodes_post)
        bias_pre = _sequence_bias_metrics(nodes_pre, ma)
        bias_post = _sequence_bias_metrics(nodes_post, ma)

        selected_df = _load_optional_csv(selected_dir / f"{session}_selected_data.csv")
        nose_df = _load_optional_csv(selected_dir / f"{session}_nose_interp_data.csv")
        speed = _speed_metrics_by_window(nose_df, tf, float(t_break), config.fps)

        out_rows.append(
            {
                "session": session,
                "group": group,
                "maze_duration_sec": duration,
                "pre_duration_sec": pre_dur,
                "post_duration_sec": post_dur,
                "reward_rate_pre": _safe_rate(reward_pre, pre_dur),
                "reward_rate_post": _safe_rate(reward_post, post_dur),
                "long_path_reward_rate_pre": _safe_rate(long_pre, pre_dur),
                "long_path_reward_rate_post": _safe_rate(long_post, post_dur),
                "reward_per_long_path_pre": _ratio_or_nan(reward_pre, long_pre),
                "reward_per_long_path_post": _ratio_or_nan(reward_post, long_post),
                "control_path_rate_pre": _safe_rate(ctrl_pre, pre_dur),
                "control_path_rate_post": _safe_rate(ctrl_post, post_dur),
                "mode_leave_frac_pre": leave_pre,
                "mode_leave_frac_post": leave_post,
                "mode_drink_frac_pre": drink_pre,
                "mode_drink_frac_post": drink_post,
                "mode_explore_frac_pre": explore_pre,
                "mode_explore_frac_post": explore_post,
                "outer_inner_preference_pre": seq_pre["outer_inner_preference"],
                "outer_inner_preference_post": seq_post["outer_inner_preference"],
                "entropy_norm_pre": seq_pre["entropy_norm"],
                "entropy_norm_post": seq_post["entropy_norm"],
                "bias_in_left_pre": bias_pre["bias_in_left"],
                "bias_in_left_post": bias_post["bias_in_left"],
                "bias_in_right_pre": bias_pre["bias_in_right"],
                "bias_in_right_post": bias_post["bias_in_right"],
                "bias_out_left_pre": bias_pre["bias_out_left"],
                "bias_out_left_post": bias_post["bias_out_left"],
                "bias_out_right_pre": bias_pre["bias_out_right"],
                "bias_out_right_post": bias_post["bias_out_right"],
                "speed_mean_pre": speed["speed_mean_pre"],
                "speed_mean_post": speed["speed_mean_post"],
                "run_fraction_gt2_pre": speed["run_fraction_gt2_pre"],
                "run_fraction_gt2_post": speed["run_fraction_gt2_post"],
                "selected_data_present": bool(not selected_df.empty),
                "nose_data_present": bool(not nose_df.empty),
            }
        )
    return pd.DataFrame(out_rows)


def _group_gap_reduction(reward_post: pd.Series, metric_post: pd.Series, group_is_a: pd.Series) -> float:
    y = pd.to_numeric(reward_post, errors="coerce").to_numpy(dtype=float)
    x = pd.to_numeric(metric_post, errors="coerce").to_numpy(dtype=float)
    g = pd.to_numeric(group_is_a, errors="coerce").to_numpy(dtype=float)
    ok = np.isfinite(y) & np.isfinite(x) & np.isfinite(g)
    y = y[ok]
    x = x[ok]
    g = g[ok]
    if y.size < 6 or np.unique(g).size < 2:
        return np.nan

    xz = (x - np.nanmean(x)) / (np.nanstd(x) + 1e-9)
    X0 = np.column_stack([np.ones(y.size), g])
    X1 = np.column_stack([np.ones(y.size), g, xz])
    try:
        b0, *_ = np.linalg.lstsq(X0, y, rcond=None)
        b1, *_ = np.linalg.lstsq(X1, y, rcond=None)
    except Exception:
        return np.nan
    beta0 = float(b0[1]) if len(b0) > 1 else np.nan
    beta1 = float(b1[1]) if len(b1) > 1 else np.nan
    if not np.isfinite(beta0) or abs(beta0) < 1e-9 or not np.isfinite(beta1):
        return np.nan
    return float((abs(beta0) - abs(beta1)) / abs(beta0))


def compute_mechanism_table(
    config: ComparisonConfig,
    t_break: float,
    session_metric_table: pd.DataFrame,
    *,
    n_perm: int = 5000,
    n_boot: int = 5000,
    seed: int = 0,
) -> pd.DataFrame:
    _ = t_break
    if session_metric_table.empty:
        return pd.DataFrame(
            columns=[
                "metric",
                "n_a",
                "n_b",
                "delta_median_a",
                "delta_median_b",
                "delta_of_deltas",
                "perm_p",
                "cliffs_delta",
                "ci_low",
                "ci_high",
                "effect_std",
                "gap_reduction_reward_rate",
                "rank_score",
                "rank",
            ]
        )

    metrics = [
        "reward_rate",
        "long_path_reward_rate",
        "reward_per_long_path",
        "control_path_rate",
        "mode_explore_frac",
        "mode_drink_frac",
        "outer_inner_preference",
        "entropy_norm",
        "bias_in_left",
        "bias_in_right",
        "bias_out_left",
        "bias_out_right",
        "speed_mean",
        "run_fraction_gt2",
    ]

    rng_seed = int(seed)
    rows: list[dict[str, Any]] = []
    base = session_metric_table.copy()
    gflag = (base["group"].astype(str) == str(config.group_a_name)).astype(float)
    reward_post = pd.to_numeric(base.get("reward_rate_post", np.nan), errors="coerce")

    for i, m in enumerate(metrics):
        pre = f"{m}_pre"
        post = f"{m}_post"
        if pre not in base.columns or post not in base.columns:
            continue
        dd = base[["session", "group", pre, post]].copy()
        dd["delta"] = pd.to_numeric(dd[post], errors="coerce") - pd.to_numeric(dd[pre], errors="coerce")
        a = _safe_numeric(dd.loc[dd["group"].astype(str) == str(config.group_a_name), "delta"].to_numpy())
        b = _safe_numeric(dd.loc[dd["group"].astype(str) == str(config.group_b_name), "delta"].to_numpy())
        obs, p = _perm_pvalue(a, b, n_perm=int(n_perm), seed=rng_seed + 1000 * i + 1)
        ci_lo, ci_hi = _bootstrap_diff_ci(a, b, n_boot=int(n_boot), seed=rng_seed + 1000 * i + 2)
        cliffs = _cliffs_delta(a, b)
        pooled_std = float(np.nanstd(np.r_[a, b], ddof=1)) if (a.size + b.size) > 2 else np.nan
        effect_std = float(obs / pooled_std) if np.isfinite(obs) and np.isfinite(pooled_std) and pooled_std > 0 else np.nan
        gap_red = _group_gap_reduction(reward_post, pd.to_numeric(base.get(post, np.nan), errors="coerce"), gflag)
        rows.append(
            {
                "metric": m,
                "n_a": int(a.size),
                "n_b": int(b.size),
                "delta_median_a": float(np.nanmedian(a)) if a.size else np.nan,
                "delta_median_b": float(np.nanmedian(b)) if b.size else np.nan,
                "delta_of_deltas": float(obs),
                "perm_p": float(p),
                "cliffs_delta": float(cliffs),
                "ci_low": float(ci_lo),
                "ci_high": float(ci_hi),
                "effect_std": float(effect_std),
                "gap_reduction_reward_rate": float(gap_red),
            }
        )

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["rank_score"] = np.abs(pd.to_numeric(out["effect_std"], errors="coerce")).fillna(0.0) + np.maximum(
        0.0, pd.to_numeric(out["gap_reduction_reward_rate"], errors="coerce").fillna(0.0)
    )
    out = out.sort_values("rank_score", ascending=False).reset_index(drop=True)
    out["rank"] = np.arange(1, len(out) + 1, dtype=int)
    return out


def _common_time_grid(session_qc: pd.DataFrame, time_bin_sec: float) -> np.ndarray:
    if session_qc.empty:
        return np.asarray([0.0], dtype=float)
    max_dur = float(pd.to_numeric(session_qc["maze_duration_sec"], errors="coerce").max())
    if not np.isfinite(max_dur) or max_dur <= 0:
        return np.asarray([0.0], dtype=float)
    step = float(max(1.0, time_bin_sec))
    grid = np.arange(0.0, max_dur + step, step, dtype=float)
    if grid[-1] < max_dur:
        grid = np.append(grid, max_dur)
    return grid


def _bootstrap_mean_curve(values: np.ndarray, n_boot: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(values, dtype=float)
    if arr.ndim != 2:
        return np.asarray([], dtype=float), np.asarray([], dtype=float)
    rng = np.random.default_rng(int(seed))
    n_sess, n_t = arr.shape
    if n_sess == 0:
        return np.full(n_t, np.nan), np.full(n_t, np.nan)
    out_lo = np.full(n_t, np.nan, dtype=float)
    out_hi = np.full(n_t, np.nan, dtype=float)
    n_iter = int(max(200, n_boot))
    for j in range(n_t):
        col = arr[:, j]
        col = col[np.isfinite(col)]
        if col.size == 0:
            continue
        boot = np.zeros(n_iter, dtype=float)
        for i in range(n_iter):
            boot[i] = float(np.nanmean(rng.choice(col, size=col.size, replace=True)))
        out_lo[j] = float(np.quantile(boot, 0.025))
        out_hi[j] = float(np.quantile(boot, 0.975))
    return out_lo, out_hi


def build_cumulative_curve_table(
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    config: ComparisonConfig,
    *,
    n_boot: int = 5000,
    seed: int = 0,
    time_step_sec: float | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    keep_qc = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712
    if keep_qc.empty:
        return pd.DataFrame(), pd.DataFrame()
    step = float(config.time_bin_sec) if time_step_sec is None else float(time_step_sec)
    grid = _common_time_grid(keep_qc, step)
    event_types = ["reward", "long_path_reward", "control_path"]

    sess_rows: list[dict[str, Any]] = []
    grp_rows: list[dict[str, Any]] = []
    for event_type in event_types:
        for group, gq in keep_qc.groupby("group"):
            vals = []
            for _, qr in gq.iterrows():
                s = str(qr["session"])
                dur = float(qr["maze_duration_sec"])
                times = _event_time_lookup(event_table, s, event_type)
                cum = np.full(grid.size, np.nan, dtype=float)
                mask = grid <= dur + 1e-9
                if np.any(mask):
                    g2 = grid[mask]
                    cum[mask] = np.searchsorted(np.sort(times), g2, side="right").astype(float)
                vals.append(cum)
                for t, v in zip(grid, cum):
                    sess_rows.append(
                        {
                            "group": str(group),
                            "session": s,
                            "event_type": event_type,
                            "maze_seconds": float(t),
                            "cum_count": float(v) if np.isfinite(v) else np.nan,
                        }
                    )
            mat = np.asarray(vals, dtype=float)
            mean = np.nanmean(mat, axis=0) if mat.size else np.full(grid.size, np.nan)
            lo, hi = _bootstrap_mean_curve(mat, n_boot=int(n_boot), seed=int(seed) + abs(hash((event_type, group))) % 10000)
            n_by_t = np.sum(np.isfinite(mat), axis=0) if mat.size else np.zeros(grid.size, dtype=int)
            for t, m, l, h, n in zip(grid, mean, lo, hi, n_by_t):
                grp_rows.append(
                    {
                        "group": str(group),
                        "event_type": event_type,
                        "maze_seconds": float(t),
                        "cum_mean": float(m) if np.isfinite(m) else np.nan,
                        "cum_ci_low": float(l) if np.isfinite(l) else np.nan,
                        "cum_ci_high": float(h) if np.isfinite(h) else np.nan,
                        "n_sessions": int(n),
                    }
                )
    return pd.DataFrame(grp_rows), pd.DataFrame(sess_rows)


def build_conversion_curve(
    binned_rates: pd.DataFrame,
    config: ComparisonConfig,
    *,
    n_boot: int = 5000,
    seed: int = 0,
) -> pd.DataFrame:
    _ = config
    if binned_rates.empty:
        return pd.DataFrame()
    rew = binned_rates.loc[binned_rates["event_type"] == "reward", ["group", "session", "time_bin", "time_bin_start", "count"]]
    lng = binned_rates.loc[
        binned_rates["event_type"] == "long_path_reward", ["group", "session", "time_bin", "time_bin_start", "count"]
    ]
    if rew.empty or lng.empty:
        return pd.DataFrame()
    m = rew.merge(lng, on=["group", "session", "time_bin", "time_bin_start"], suffixes=("_reward", "_long"))
    m["conversion"] = np.where(m["count_long"] > 0, m["count_reward"] / m["count_long"], np.nan)
    out_rows: list[dict[str, Any]] = []
    for (group, tb, tbs), sub in m.groupby(["group", "time_bin", "time_bin_start"], sort=True):
        x = _safe_numeric(sub["conversion"].to_numpy())
        if x.size == 0:
            continue
        rng = np.random.default_rng(int(seed) + int(tb) + abs(hash(str(group))) % 10000)
        boot = np.zeros(int(max(200, n_boot)), dtype=float)
        for i in range(boot.size):
            boot[i] = float(np.nanmean(rng.choice(x, size=x.size, replace=True)))
        out_rows.append(
            {
                "group": str(group),
                "time_bin": int(tb),
                "time_bin_start": float(tbs),
                "conversion_mean": float(np.nanmean(x)),
                "conversion_ci_low": float(np.quantile(boot, 0.025)),
                "conversion_ci_high": float(np.quantile(boot, 0.975)),
                "n_sessions": int(x.size),
            }
        )
    out = pd.DataFrame(out_rows)
    if out.empty:
        return pd.DataFrame(
            columns=["group", "time_bin", "time_bin_start", "conversion_mean", "conversion_ci_low", "conversion_ci_high", "n_sessions"]
        )
    return out.sort_values(["group", "time_bin_start"]).reset_index(drop=True)


def build_mode_fraction_curve(
    config: ComparisonConfig,
    ma: Any,
    session_qc: pd.DataFrame,
    *,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
    n_boot: int = 5000,
    seed: int = 0,
) -> pd.DataFrame:
    keep_qc = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712
    if keep_qc.empty:
        return pd.DataFrame()

    rows: list[dict[str, Any]] = []
    for _, qr in keep_qc.iterrows():
        session = str(qr["session"])
        group = str(qr["group"])
        dur = float(qr["maze_duration_sec"])
        tf = load_traj_fn(f"{session}-tf")
        intervals = _mode_clip_intervals(tf, ma)
        n_bins = int(max(1, math.ceil(dur / float(config.time_bin_sec))))
        edges = np.arange(n_bins + 1, dtype=float) * float(config.time_bin_sec)
        edges[-1] = max(edges[-1], dur)
        for bi in range(n_bins):
            lo = float(edges[bi])
            hi = float(edges[bi + 1])
            leave, drink, explore = _mode_fraction_between(intervals, lo, hi)
            rows.append(
                {
                    "group": group,
                    "session": session,
                    "time_bin": int(bi),
                    "time_bin_start": lo,
                    "mode_leave": leave,
                    "mode_drink": drink,
                    "mode_explore": explore,
                }
            )
    raw = pd.DataFrame(rows)
    if raw.empty:
        return raw

    out_rows: list[dict[str, Any]] = []
    for (group, tb, tbs), sub in raw.groupby(["group", "time_bin", "time_bin_start"], sort=True):
        for metric in ("mode_leave", "mode_drink", "mode_explore"):
            x = _safe_numeric(sub[metric].to_numpy())
            if x.size == 0:
                continue
            rng = np.random.default_rng(int(seed) + int(tb) + abs(hash((group, metric))) % 10000)
            boot = np.zeros(int(max(200, n_boot)), dtype=float)
            for i in range(boot.size):
                boot[i] = float(np.nanmean(rng.choice(x, size=x.size, replace=True)))
            out_rows.append(
                {
                    "group": str(group),
                    "time_bin": int(tb),
                    "time_bin_start": float(tbs),
                    "metric": metric,
                    "mean": float(np.nanmean(x)),
                    "ci_low": float(np.quantile(boot, 0.025)),
                    "ci_high": float(np.quantile(boot, 0.975)),
                    "n_sessions": int(x.size),
                }
            )
    return pd.DataFrame(out_rows).sort_values(["group", "metric", "time_bin_start"]).reset_index(drop=True)


def _linear_curve(t: np.ndarray, a: float, b: float) -> np.ndarray:
    return a + b * t


def _exp_curve(t: np.ndarray, a: float, b: float, c: float) -> np.ndarray:
    return c + a * (np.exp(b * t) - 1.0)


def _power_curve(t: np.ndarray, a: float, b: float, c: float) -> np.ndarray:
    return c + a * np.power(np.maximum(0.0, t) + 1.0, b)


def _fit_curve_model(name: str, t: np.ndarray, y: np.ndarray) -> dict[str, Any]:
    t = _safe_numeric(t)
    y = _safe_numeric(y)
    if t.size != y.size or t.size < 6:
        return {"ok": False, "model": name, "params": [], "aic": np.nan, "bic": np.nan, "sse": np.nan}
    try:
        if name == "linear":
            p0 = [float(np.nanmin(y)), float((np.nanmax(y) - np.nanmin(y)) / (np.nanmax(t) + 1e-9))]
            popt, _ = curve_fit(_linear_curve, t, y, p0=p0, maxfev=200000)
            pred = _linear_curve(t, *popt)
        elif name == "exponential":
            p0 = [max(1e-6, float(np.nanmax(y) - np.nanmin(y))), 1e-4, float(np.nanmin(y))]
            bounds = ([0.0, -1.0, -np.inf], [np.inf, 1.0, np.inf])
            popt, _ = curve_fit(_exp_curve, t, y, p0=p0, bounds=bounds, maxfev=200000)
            pred = _exp_curve(t, *popt)
        elif name == "power_law":
            p0 = [max(1e-6, float(np.nanmax(y) - np.nanmin(y))), 0.5, float(np.nanmin(y))]
            bounds = ([0.0, -2.0, -np.inf], [np.inf, 4.0, np.inf])
            popt, _ = curve_fit(_power_curve, t, y, p0=p0, bounds=bounds, maxfev=200000)
            pred = _power_curve(t, *popt)
        else:
            return {"ok": False, "model": name, "params": [], "aic": np.nan, "bic": np.nan, "sse": np.nan}
        resid = y - pred
        sse = float(np.sum(resid**2))
        n = int(y.size)
        k = int(len(popt))
        sigma2 = max(sse / max(1, n), 1e-12)
        loglik = -0.5 * n * (math.log(2 * math.pi * sigma2) + 1.0)
        aic = float(2 * k - 2 * loglik)
        bic = float(k * math.log(max(2, n)) - 2 * loglik)
        return {
            "ok": True,
            "model": name,
            "params": [float(v) for v in np.asarray(popt).ravel().tolist()],
            "aic": aic,
            "bic": bic,
            "sse": sse,
            "n": n,
            "k": k,
        }
    except Exception:
        return {"ok": False, "model": name, "params": [], "aic": np.nan, "bic": np.nan, "sse": np.nan}


def fit_growth_models(curve_df: pd.DataFrame) -> pd.DataFrame:
    if curve_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for (group, event_type), sub in curve_df.groupby(["group", "event_type"]):
        ss = sub.sort_values("maze_seconds")
        t = pd.to_numeric(ss["maze_seconds"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(ss["cum_mean"], errors="coerce").to_numpy(dtype=float)
        ok = np.isfinite(t) & np.isfinite(y)
        t = t[ok]
        y = y[ok]
        if t.size < 6:
            continue
        for model_name in ("linear", "exponential", "power_law"):
            fit = _fit_curve_model(model_name, t, y)
            rows.append(
                {
                    "group": str(group),
                    "event_type": str(event_type),
                    "model": model_name,
                    "ok": bool(fit.get("ok", False)),
                    "params_json": json.dumps(fit.get("params", [])),
                    "aic": float(fit.get("aic", np.nan)),
                    "bic": float(fit.get("bic", np.nan)),
                    "sse": float(fit.get("sse", np.nan)),
                    "n": int(fit.get("n", 0)) if np.isfinite(fit.get("n", np.nan)) else 0,
                    "k": int(fit.get("k", 0)) if np.isfinite(fit.get("k", np.nan)) else 0,
                }
            )
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["best_aic"] = False
    out["best_bic"] = False
    for _, sub in out.groupby(["group", "event_type"]):
        sub_ok = sub.loc[sub["ok"] == True]  # noqa: E712
        if sub_ok.empty:
            continue
        ia = sub_ok["aic"].idxmin()
        ib = sub_ok["bic"].idxmin()
        out.loc[ia, "best_aic"] = True
        out.loc[ib, "best_bic"] = True
    return out.sort_values(["event_type", "group", "aic"]).reset_index(drop=True)


def _predict_from_growth_model(model: str, params: list[float], t: np.ndarray) -> np.ndarray:
    tt = np.asarray(t, dtype=float)
    p = np.asarray(params, dtype=float).ravel()
    if model == "linear" and p.size >= 2:
        return _linear_curve(tt, float(p[0]), float(p[1]))
    if model == "exponential" and p.size >= 3:
        return _exp_curve(tt, float(p[0]), float(p[1]), float(p[2]))
    if model == "power_law" and p.size >= 3:
        return _power_curve(tt, float(p[0]), float(p[1]), float(p[2]))
    return np.full(tt.shape, np.nan, dtype=float)


def build_growth_overlay_table(curve_df: pd.DataFrame, growth_df: pd.DataFrame) -> pd.DataFrame:
    if curve_df.empty or growth_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for (group, event_type), sub in curve_df.groupby(["group", "event_type"]):
        t = pd.to_numeric(sub["maze_seconds"], errors="coerce").to_numpy(dtype=float)
        t = t[np.isfinite(t)]
        if t.size == 0:
            continue
        for _, fit in growth_df.loc[
            (growth_df["group"] == str(group))
            & (growth_df["event_type"] == str(event_type))
            & (growth_df["ok"] == True)  # noqa: E712
        ].iterrows():
            params = json.loads(str(fit.get("params_json", "[]")))
            pred = _predict_from_growth_model(str(fit["model"]), list(params), t)
            for tt, yy in zip(t, pred):
                rows.append(
                    {
                        "group": str(group),
                        "event_type": str(event_type),
                        "model": str(fit["model"]),
                        "maze_seconds": float(tt),
                        "pred_cum": float(yy) if np.isfinite(yy) else np.nan,
                    }
                )
    return pd.DataFrame(rows)


def _rate_early_summary(
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    *,
    group_a: str,
    group_b: str,
    t_break: float,
) -> pd.DataFrame:
    keep_qc = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712
    rows: list[dict[str, Any]] = []
    for _, r in keep_qc.iterrows():
        session = str(r["session"])
        group = str(r["group"])
        dur = float(r["maze_duration_sec"])
        pre = min(float(t_break), dur)
        if pre <= 0:
            continue
        for et in ("reward", "long_path_reward"):
            times = _event_time_lookup(event_table, session, et)
            c = _count_in_window(times, 0.0, pre)
            rows.append(
                {
                    "session": session,
                    "group": group,
                    "event_type": et,
                    "early_window_sec": float(pre),
                    "early_rate": _safe_rate(c, pre),
                }
            )
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    add_rows: list[dict[str, Any]] = []
    for et, sub in out.groupby("event_type"):
        a = _safe_numeric(sub.loc[sub["group"] == str(group_a), "early_rate"].to_numpy())
        b = _safe_numeric(sub.loc[sub["group"] == str(group_b), "early_rate"].to_numpy())
        if a.size == 0 or b.size == 0:
            continue
        add_rows.append(
            {
                "session": "__ratio__",
                "group": f"{group_a}/{group_b}",
                "event_type": et,
                "early_window_sec": float(t_break),
                "early_rate": float(np.nanmean(a) / (np.nanmean(b) + 1e-9)),
            }
        )
    if add_rows:
        out = pd.concat([out, pd.DataFrame(add_rows)], ignore_index=True)
    return out


def summarize_top_findings(
    mechanism_table: pd.DataFrame,
    breakpoint_info: dict[str, Any],
    eq_reward: dict[str, Any],
    eq_long: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    rows.append(
        {
            "type": "breakpoint",
            "item": "reward_rate_breakpoint",
            "value": float(breakpoint_info.get("t_break", np.nan)),
            "note": str("fallback" if breakpoint_info.get("fallback_used", False) else "data_driven"),
        }
    )
    rows.append(
        {
            "type": "equivalence",
            "item": "reward_rate_early_equivalent",
            "value": bool(eq_reward.get("equivalent", False)),
            "note": f"bins={eq_reward.get('n_bins', 0)}",
        }
    )
    rows.append(
        {
            "type": "equivalence",
            "item": "long_path_rate_early_equivalent",
            "value": bool(eq_long.get("equivalent", False)),
            "note": f"bins={eq_long.get('n_bins', 0)}",
        }
    )
    if mechanism_table is not None and not mechanism_table.empty:
        top = mechanism_table.sort_values("rank_score", ascending=False).head(5)
        for _, r in top.iterrows():
            rows.append(
                {
                    "type": "mechanism",
                    "item": str(r["metric"]),
                    "value": float(r.get("delta_of_deltas", np.nan)),
                    "note": f"rank={int(r.get('rank', -1))}, p={float(r.get('perm_p', np.nan)):.4g}",
                }
            )
    return pd.DataFrame(rows)


def export_analysis_tables(result: dict[str, Any], output_dir: str | Path) -> dict[str, str]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, str] = {}
    for key in (
        "validation_table",
        "regen_qc",
        "session_qc",
        "event_table",
        "binned_rates",
        "cumulative_gap_reward",
        "cumulative_gap_long",
        "curve_group",
        "curve_session",
        "growth_table",
        "growth_overlay",
        "session_metric_table",
        "mechanism_table",
        "conversion_curve",
        "mode_curve",
        "early_rate_table",
        "summary_table",
    ):
        df = result.get(key, None)
        if isinstance(df, pd.DataFrame):
            path = output_dir / f"{key}.csv"
            df.to_csv(path, index=False)
            manifest[key] = str(path)
    ratio_reward = result.get("ratio_reward", pd.DataFrame())
    ratio_long = result.get("ratio_long", pd.DataFrame())
    if isinstance(ratio_reward, pd.DataFrame):
        p = output_dir / "ratio_reward.csv"
        ratio_reward.to_csv(p, index=False)
        manifest["ratio_reward"] = str(p)
    if isinstance(ratio_long, pd.DataFrame):
        p = output_dir / "ratio_long_path.csv"
        ratio_long.to_csv(p, index=False)
        manifest["ratio_long_path"] = str(p)
    json_path = output_dir / "analysis_manifest.json"
    payload = {
        "manifest": manifest,
        "breakpoint": {
            "t_break": float(result.get("breakpoint", {}).get("t_break", np.nan)),
            "fallback_used": bool(result.get("breakpoint", {}).get("fallback_used", False)),
            "fallback_reason": str(result.get("breakpoint", {}).get("fallback_reason", "")),
        },
        "equivalence_reward": result.get("equivalence_reward", {}),
        "equivalence_long_path": result.get("equivalence_long_path", {}),
        "config": asdict(result.get("config")),
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    manifest["analysis_manifest"] = str(json_path)
    return manifest


def run_full_analysis(
    config: ComparisonConfig,
    *,
    working_dir: str | Path,
    ma: Any,
    regen_selected_data: bool = True,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
    n_boot: int = 5000,
    n_perm: int = 5000,
    seed: int = 0,
) -> dict[str, Any]:
    if int(config.reward_node) != 94:
        raise ValueError("Primary analysis requires reward_node=94.")
    working_dir = Path(working_dir)
    all_sessions = list(dict.fromkeys([*config.group_a_sessions, *config.group_b_sessions]))

    validation_table = validate_session_context(config, working_dir)
    video_lookup = build_video_lookup(working_dir)
    if regen_selected_data:
        regen_qc = ensure_selected_data_exists(all_sessions, working_dir, ma, video_lookup, load_traj_fn=load_traj_fn)
    else:
        regen_qc = pd.DataFrame(
            {
                "session": all_sessions,
                "selected_exists_before": [np.nan] * len(all_sessions),
                "nose_exists_before": [np.nan] * len(all_sessions),
                "attempted_regen": [False] * len(all_sessions),
                "regen_ok": [np.nan] * len(all_sessions),
                "error": [""] * len(all_sessions),
            }
        )

    event_table = build_event_table(config, ma, load_traj_fn=load_traj_fn)
    session_qc = event_table.attrs.get("session_qc", pd.DataFrame())
    if session_qc.empty:
        raise RuntimeError("No sessions could be loaded for trajectory metrics.")

    binned_rates = build_binned_rates(event_table, session_qc, time_bin_sec=config.time_bin_sec)
    curve_group, curve_session = build_cumulative_curve_table(event_table, session_qc, config, n_boot=int(n_boot), seed=int(seed))

    cumulative_gap_reward = _bootstrap_cumulative_gap_by_time(
        curve_session,
        event_type="reward",
        group_a=config.group_a_name,
        group_b=config.group_b_name,
        n_boot=int(n_boot),
        seed=int(seed),
    )
    cumulative_gap_long = _bootstrap_cumulative_gap_by_time(
        curve_session,
        event_type="long_path_reward",
        group_a=config.group_a_name,
        group_b=config.group_b_name,
        n_boot=int(n_boot),
        seed=int(seed) + 17,
    )

    bp = estimate_divergence_breakpoint_from_cumulative(cumulative_gap_reward, config)
    t_break = float(bp.get("t_break", np.nan))
    eq_reward = _early_equivalence_summary_gap(cumulative_gap_reward, t_break=t_break)
    eq_long = _early_equivalence_summary_gap(cumulative_gap_long, t_break=t_break)

    session_metric_table = build_session_metric_table(
        config,
        ma,
        event_table,
        session_qc,
        working_dir=working_dir,
        t_break=t_break,
        load_traj_fn=load_traj_fn,
    )
    mechanism_table = compute_mechanism_table(
        config,
        t_break,
        session_metric_table,
        n_perm=int(n_perm),
        n_boot=int(n_boot),
        seed=int(seed),
    )
    growth_table = fit_growth_models(curve_group)
    growth_overlay = build_growth_overlay_table(curve_group, growth_table)
    conversion_curve = build_conversion_curve(binned_rates, config, n_boot=int(n_boot), seed=int(seed))
    mode_curve = build_mode_fraction_curve(config, ma, session_qc, load_traj_fn=load_traj_fn, n_boot=int(n_boot), seed=int(seed))
    early_rate_table = _rate_early_summary(
        event_table,
        session_qc,
        group_a=config.group_a_name,
        group_b=config.group_b_name,
        t_break=t_break,
    )
    summary_table = summarize_top_findings(mechanism_table, bp, eq_reward, eq_long)

    return {
        "config": config,
        "validation_table": validation_table,
        "regen_qc": regen_qc,
        "session_qc": session_qc,
        "event_table": event_table,
        "binned_rates": binned_rates,
        "breakpoint": bp,
        "equivalence_reward": eq_reward,
        "equivalence_long_path": eq_long,
        "ratio_reward": cumulative_gap_reward,
        "ratio_long": cumulative_gap_long,
        "cumulative_gap_reward": cumulative_gap_reward,
        "cumulative_gap_long": cumulative_gap_long,
        "session_metric_table": session_metric_table,
        "mechanism_table": mechanism_table,
        "curve_group": curve_group,
        "curve_session": curve_session,
        "growth_table": growth_table,
        "growth_overlay": growth_overlay,
        "conversion_curve": conversion_curve,
        "mode_curve": mode_curve,
        "early_rate_table": early_rate_table,
        "summary_table": summary_table,
    }


__all__ = [
    "ComparisonConfig",
    "default_comparison_config",
    "build_video_lookup",
    "validate_session_context",
    "ensure_selected_data_exists",
    "extract_reward_events",
    "extract_long_path_events",
    "extract_control_path_events",
    "build_event_table",
    "build_binned_rates",
    "estimate_divergence_breakpoint",
    "estimate_divergence_breakpoint_from_cumulative",
    "build_session_metric_table",
    "compute_mechanism_table",
    "build_cumulative_curve_table",
    "fit_growth_models",
    "build_growth_overlay_table",
    "build_conversion_curve",
    "build_mode_fraction_curve",
    "summarize_top_findings",
    "run_full_analysis",
    "export_analysis_tables",
]
