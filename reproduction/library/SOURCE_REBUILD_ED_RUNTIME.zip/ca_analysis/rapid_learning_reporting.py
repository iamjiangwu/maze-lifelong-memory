"""Integrated reporting for the rapid-learning structure/reward project.

The report deliberately separates an analysis being *estimated* from its
hypothesis being supported. It also keeps estimator failures distinct from
biological null results and records the diagnostic/rescue path required before
a negative interpretation is allowed.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class AnalysisCard:
    hypothesis_id: str
    family: str
    hypothesis: str
    why: str
    execution: str
    primary_output: str
    positive_rival_checks: str
    negative_diagnostic_ladder: str


ANALYSIS_CARDS: tuple[AnalysisCard, ...] = (
    AnalysisCard(
        "H-S0",
        "structure",
        "The gain in maintained graph-relative policies is not produced mechanically by changing decision support under a fixed history-only policy.",
        "Arrival relations, depth, and available alternatives change with exploration, so support-driven predictability must be removed before interpreting a policy gain.",
        "For variable-outdegree all-neighbor choices, simulate one stable pooled-B+C policy per animal on the exact observed support, then null-correct the held-out M1-minus-M0 graph-policy score. Retain the childward trajectory generator only as a rejected diagnostic because it cannot reproduce from-child/backtrack support.",
        "phase1/all_neighbor_primary_graph_policy_null_delta.csv",
        "Inspect animal-fit convergence/fallback, exact feature equality, cohort strata, common-node policy estimates, and arrival/depth/degree balance.",
        "Increase null precision; inspect individual-policy fit, feature scaling, decision support, regularization, and exposure-window sensitivity before calling the estimator or biology null.",
    ),
    AnalysisCard(
        "H-S1",
        "structure",
        "During Day 1 exploration, the four maintained graph-relative policies become increasingly predictive beyond motor/side and local-history effects.",
        "This is the primary behavioral structure-acquisition estimand and is distinct from the stronger claim that mice track the global unvisited frontier.",
        "Fit leave-one-mouse-out variable-outdegree conditional-logit models on exposure-matched B/C choices: M0 contains side and local-history nuisance terms; M1 adds the exact P_SF, P_SA, P_BF, and P_BS utilities. Analyze null-corrected M1-minus-M0 gain, pooled and in latent/dry reward-free strata.",
        "phase1/all_neighbor_primary_graph_policy_gain.csv",
        "Require consistency with common-node P_BF/P_BS changes, reward-free strata, arrival/depth/degree balance, influence checks, and regularization sensitivity.",
        "Check support, convergence, null precision, early ceiling, common-node denominators, penalty sensitivity, and alternative exposure windows before interpreting a null or opposite sign.",
    ),
    AnalysisCard(
        "H-S1P",
        "structure policy",
        "The prespecified from-child policies P_BF and P_BS change in their efficient-exploration directions; P_SF and P_SA are from-parent controls.",
        "These maintained, interpretable policies establish which graph-relative behavior changes, rather than relying only on one composite log score.",
        "Compute node-balanced policy probabilities in B and C, repeat P_BF/P_BS on the exact common B/C node support, and report each policy separately without significance-versus-nonsignificance comparisons.",
        "phase1/all_neighbor_primary_local_policy_common_node_gain_stats.csv",
        "Inspect denominator support, node composition, arrival proportions, depth, graph degree, and whether only one policy or one context drives the result.",
        "If a policy is null or opposite, inspect denominator floors, common-node support, ceiling, depth-stratified effects, and influence before interpreting the biology.",
    ),
    AnalysisCard(
        "H-S1G",
        "global frontier planning",
        "Choices increasingly align with the objectively unvisited frontier and routes to it beyond exact local graph policies and static maze geometry.",
        "This tests a stronger global-planning account; failure does not adjudicate the separate local structural-policy estimands.",
        "Compare M2 against M1g, where M1g contains M1 plus static component size and nearest-terminal distance and M2 adds dynamic q_frontier/q_route. Use a bounded 20-null exact-support analysis and frontier/route component diagnostics.",
        "phase1/all_neighbor_global_frontier_gain.csv",
        "Inspect frontier-only, route-only, unique contributions, support balance, reward-free contexts, and alternative regularization.",
        "Treat the result as secondary and preliminary; opposite or null direction means no incremental global-frontier evidence under this estimator, never no structure learning.",
    ),
    AnalysisCard(
        "H-S2",
        "structure transfer",
        "Among latent mice, stronger reward-free Day 1 structure acquisition forecasts more efficient target search after reward is introduced on Day 2.",
        "Only the latent cohort isolates structure experience from Day 1 reward learning; the between-group contrast alone cannot identify a structural mechanism.",
        "Relate latent-only Day 1 S_local graph-policy gain to actual-tf.re Day 2 discovery latency and target-directed search measures, preserving censoring and reporting the small animal-level sample.",
        "phase1/all_neighbor_primary_structure_reward_association_stats.csv",
        "Adjust for early coverage/engagement and verify that results are not driven by one mouse or by baseline policy score.",
        "Inspect endpoint support, censoring, influential animals, rank ties, and alternative target-search measures; retain an underpowered classification when uncertainty spans meaningful effects.",
    ),
    AnalysisCard(
        "H-R1",
        "reward",
        "Reward discovery and reward binding are separate rapid-learning events, and legacy first-long-bout onset is not a valid reward-learning onset when it precedes first reward.",
        "Separating these events prevents structure learning or pre-reward efficient runs from being mislabeled as reward learning.",
        "Take discovery from the first actual tf.re event; define binding as the first post-reward long path initiating a sustained 3-of-5 successful-bout cluster; report legacy lb0 only as a separate execution endpoint.",
        "phase1/reward_learning_endpoints.csv",
        "Check outcome support, visit order, pre-reward long bouts, context, and alternative sustained-cluster definitions.",
        "If binding is sparse, inspect reward-event alignment and path reconstruction, then use censored time-to-event analysis rather than dropping nonbinders or relaxing the definition silently.",
    ),
    AnalysisCard(
        "H-N0",
        "neural dynamics setup",
        "Early Day 1 excess lagged population coordination (ELPC) is reproducibly measurable in these calcium recordings.",
        "A prospective neural hypothesis is uninterpretable if its predictor is dominated by calcium kinetics, trajectory, common input, or sampling noise.",
        "Whiten each neuron's own C history, use only off-diagonal lagged coordination, compare observed activity with independent-cell and zero-lag-preserving nulls, and assess interleaved-block split reliability across mice.",
        "phase2_elpc_exact_support_rescue/elpc_split_half_reliability.csv",
        "Inspect the raw-to-null-to-map-residual ladder, engagement, context, lag range, cell subsets, and ordinary temporal alternatives.",
        "Try the prespecified support/resolution and 400-s named rescue, then lag-range/null-precision diagnostics; if reliability still fails, classify the metric unresolved rather than the biology null.",
    ),
    AnalysisCard(
        "H-N1",
        "neural dynamics to structure",
        "Higher early Day 1 ELPC forecasts greater subsequent S_local graph-policy acquisition, beyond baseline policy and engagement.",
        "This prospective ordering is the calcium-appropriate test of whether early population dynamics index capacity for rapid structure learning.",
        "Run rank ANCOVA on late policy score with context, baseline score, ELPC, and engagement, plus a raw change-score model; use context-restricted Freedman-Lane permutations and require concordant direction.",
        "phase4_hn1/hypothesis_status.csv",
        "Test context-by-ELPC heterogeneity, engagement, influential mice, ordinary temporal metrics, and alternative structure outcomes; keep the claim associative.",
        "Do not run confirmatorily unless H-N0 passes; if models disagree, inspect baseline-score reliability and errors-in-variables sensitivity before classifying the association.",
    ),
    AnalysisCard(
        "H-NS1",
        "neural structure code",
        "A C-based neural representation of tree depth/topology becomes more accessible from early to late Day 1 and generalizes across physically distant equivalent subtrees.",
        "This tests a neural structural code directly rather than inferring it only from behavior.",
        "Use occupancy-balanced C decoders in exposure-matched early/late windows; for abstraction, train and test on physically distant equivalent subtrees and compare against position-to-depth and XY/behavior controls on identical folds.",
        "phase3_neural_codes/hypothesis_status.csv",
        "Require topology generalization to exceed both shuffle and the same-split position comparator; inspect reward context and place-field interpolation.",
        "Use prespecified support rescue folds/windows, then report not-testable sessions explicitly; do not lower occupancy floors post hoc to manufacture a result.",
    ),
    AnalysisCard(
        "H-NR1",
        "neural reward code",
        "After actual reward discovery, C activity acquires reward-node-specific organization beyond generic terminal-node, occupancy, and trajectory effects.",
        "This separates reward binding in the neural population from structural coding and from simple visits to a salient terminal.",
        "Compare supported pre/post node-94 revisits with matched pseudo-terminal nodes using visit-count matching and a difference-in-differences; retain distributed reward-coordinate analyses as fallback, not a replacement endpoint.",
        "phase3_neural_codes/hypothesis_status.csv",
        "Check realized pre-visit support, speed/heading/trajectory matching, pseudo-node robustness, context, and distributed goal-distance alternatives.",
        "If node-94 support is inadequate, expand only through the prespecified 30/60-min ladder and report the distributed-code fallback separately; never pool the first reward event into post-learning visits.",
    ),
    AnalysisCard(
        "H-N2a",
        "criticality appendix",
        "A smaller early S-based Hengen Euclidean AR-boundary distance forecasts greater later structure-policy acquisition.",
        "This is the direct geometric target used in the learning preprint, adapted to OASIS-inferred calcium event mass rather than electrophysiological spike counts.",
        "Fit the frozen segmented AR(10) model to the first 300 s of Day-1 explore S at 40-ms resolution, compute abs(1-sum(phi))/sqrt(p), gate on split-half and fixed-cell-subset reliability, then relate it prospectively to delta_psi and the supported delta_P_BS endpoint in pooled and reward-free tiers.",
        "phase4_dist_arcrit_S/hypothesis_status.csv",
        "Check context, fully-prereward windows, event mass, AR timescale, influence, and order/bin sensitivity; retain an associative claim only.",
        "If reliability or reference QC fails, classify measurement unresolved; if the composite outcome is null, inspect delta_P_BS and outcome validity before interpreting the estimator.",
    ),
    AnalysisCard(
        "H-N2b",
        "criticality appendix robustness",
        "The Sooter beta=2 KL-divergence-rate distance gives a convergent prospective structure-learning association.",
        "This asks whether the result survives an information-theoretic distance geometry rather than relying only on Hengen's Euclidean boundary distance.",
        "Use the authors' verified calc_db implementation on the same segmented S AR fit, report bits/s, apply the same measurement gates and cohort tiers, and treat agreement with H-N2a as shared-input robustness rather than independent replication.",
        "phase4_dist_arcrit_S/hypothesis_status.csv",
        "Check deterministic parity, split-half reliability, cell subsets, AR/bin sensitivities, event-rate/timescale rivals, and whether both metrics merely index the same AR kernel.",
        "If the reference implementation, reliability, or outcome support fails, preserve the exact failed stage and do not convert it into a biological null.",
    ),
)


CARD_METADATA: dict[str, dict[str, str]] = {
    "H-S0": {
        "implementation_status": "implemented for all-neighbor variable-outdegree choices with a fixed-policy exact-support primary null and a separately gated generative diagnostic",
        "primary_cohort": "all naive Day-1 behavioral sessions",
        "expected_direction": "observed gain should exceed the fixed-policy null",
        "temporal_order": "validity gate before H-S1 interpretation",
        "inference_tier": "confirmatory validity gate",
    },
    "H-S1": {
        "implementation_status": "M0 history to M1 exact four-policy all-neighbor primary implemented; entered-from-parent child-choice score retained as a labeled diagnostic",
        "primary_cohort": "pooled naive Day-1, with latent/dry reward-free validation",
        "expected_direction": "C-minus-B S_local graph-policy score greater than zero",
        "temporal_order": "within-Day1 early B to late C",
        "inference_tier": "primary behavioral",
    },
    "H-S1P": {
        "implementation_status": "node-balanced and exact-common-node P_SF/P_SA/P_BF/P_BS audits implemented",
        "primary_cohort": "all naive Day-1, with reward-free structural interpretation",
        "expected_direction": "P_BF and P_BS increase; P_SF and P_SA reported as controls",
        "temporal_order": "within-Day1 early B to late C",
        "inference_tier": "primary interpretable policy decomposition",
    },
    "H-S1G": {
        "implementation_status": "M1g static geometry to M2 dynamic frontier/route secondary branch implemented with bounded null precision",
        "primary_cohort": "pooled naive Day-1 with reward-free diagnostics",
        "expected_direction": "C-minus-B S_global greater than zero",
        "temporal_order": "within-Day1 early B to late C",
        "inference_tier": "secondary stronger global-planning hypothesis",
    },
    "H-S2": {
        "implementation_status": "small-n association plus bootstrap, leave-one-out, baseline/engagement, and detectable-effect diagnostics implemented",
        "primary_cohort": "latent no-water animals only",
        "expected_direction": "larger Day-1 gain predicts shorter Day-2 discovery latency",
        "temporal_order": "Day-1 structure before Day-2 reward discovery",
        "inference_tier": "structure-specific secondary",
    },
    "H-R1": {
        "implementation_status": "implemented from frozen actual reward onsets",
        "primary_cohort": "session in which reward is first available",
        "expected_direction": "discovery precedes binding; legacy lb0 may precede discovery",
        "temporal_order": "discovery then sustained post-reward binding",
        "inference_tier": "primary endpoint definition",
    },
    "H-N0": {
        "implementation_status": "implemented with the bounded exact-support reliability rescue; current gate outcome is reported from the selected Phase-2 bundle",
        "primary_cohort": "22 neural-ready naive Day-1 sessions",
        "expected_direction": "Spearman-Brown reliability at least 0.75",
        "temporal_order": "setup gate before H-N1",
        "inference_tier": "confirmatory measurement gate",
    },
    "H-N1": {
        "implementation_status": "implemented but locked behind H-N0",
        "primary_cohort": "pooled neural-ready Day-1 with context strata",
        "expected_direction": "positive ELPC coefficient in both ANCOVA and change-score models",
        "temporal_order": "early learning-state ELPC before late structure outcome",
        "inference_tier": "confirmatory prospective association",
    },
    "H-NS1": {
        "implementation_status": "within-Day1, distant-subtree, Day1-to-prereward-Day2 transfer, and animal-level inference implemented",
        "primary_cohort": "C-structure-ready Day-1 sessions",
        "expected_direction": "late exceeds early and distant-subtree topology exceeds position comparator",
        "temporal_order": "early B to late C; cross-subtree held-out test",
        "inference_tier": "primary neural-code analysis",
    },
    "H-NR1": {
        "implementation_status": "node-94 visit-template DiD, matched pseudo-terminal controls, animal bootstrap, and distributed fallback implemented",
        "primary_cohort": "reward-introduction sessions, separated from rewarded-Day1 branch",
        "expected_direction": "node-94 post-minus-pre exceeds matched pseudo terminals",
        "temporal_order": "pre-discovery visits then post-discovery revisits",
        "inference_tier": "secondary neural reward analysis",
    },
    "H-N2a": {
        "implementation_status": "verified S-only reference runner, deterministic parity, split-half, fixed-cell-subset, and AR/bin diagnostics implemented",
        "primary_cohort": "22 S-ready naive Day-1 sessions; reward-free n=12 and fully-prereward n=20 sensitivities",
        "expected_direction": "smaller Euclidean boundary distance predicts greater later structure gain",
        "temporal_order": "early S estimate before late structure outcome",
        "inference_tier": "exploratory appendix",
    },
    "H-N2b": {
        "implementation_status": "verified Sooter calc_db beta=2 KL-rate estimator and diagnostics implemented separately from H-N2a",
        "primary_cohort": "22 S-ready naive Day-1 sessions; reward-free n=12 and fully-prereward n=20 sensitivities",
        "expected_direction": "smaller KL-rate distance predicts greater later structure gain",
        "temporal_order": "early S estimate before late structure outcome",
        "inference_tier": "exploratory shared-input robustness appendix",
    },
}


def analysis_cards_frame() -> pd.DataFrame:
    rows = []
    for card in ANALYSIS_CARDS:
        row = asdict(card)
        row.update(CARD_METADATA.get(card.hypothesis_id, {}))
        rows.append(row)
    return pd.DataFrame(rows)


def _read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def _fmt(value: Any, digits: int = 3) -> str:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return "NA" if value is None else str(value)
    return "NA" if not np.isfinite(numeric) else f"{numeric:.{digits}g}"


def _phase2_dir(root: Path) -> Path:
    """Prefer the bounded exact-support rescue over the superseded first run."""

    exact = root / "phase2_elpc_exact_support_rescue"
    return exact if (exact / "phase2_manifest.json").exists() else root / "phase2_elpc"


def _phase_status_rows(root: Path) -> pd.DataFrame:
    pieces: list[pd.DataFrame] = []
    candidates = (
        ("phase1", root / "phase1" / "hypothesis_status.csv"),
        ("phase2", _phase2_dir(root) / "hypothesis_status.csv"),
        ("phase3", root / "phase3_neural_codes" / "hypothesis_status.csv"),
        ("phase4", root / "phase4_hn1" / "hypothesis_status.csv"),
        ("phase4_appendix", root / "phase4_dist_arcrit_S" / "hypothesis_status.csv"),
    )
    for phase, path in candidates:
        table = _read_csv(path)
        if len(table):
            table.insert(0, "source_phase", phase)
            table["source_path"] = str(path)
            pieces.append(table)
    return (
        pd.concat(pieces, ignore_index=True, sort=False) if pieces else pd.DataFrame()
    )


def _attempt_rows(root: Path) -> pd.DataFrame:
    pieces: list[pd.DataFrame] = []
    for phase_dir in sorted(root.glob("phase*")):
        path = phase_dir / "analysis_attempt_registry.csv"
        table = _read_csv(path)
        if len(table):
            table.insert(0, "source_phase", phase_dir.name)
            table["source_path"] = str(path)
            pieces.append(table)
    return (
        pd.concat(pieces, ignore_index=True, sort=False) if pieces else pd.DataFrame()
    )


def _phase1_summary(root: Path) -> list[str]:
    phase = root / "phase1"
    manifest = _read_json(phase / "phase1_manifest.json")
    stats_path = phase / "all_neighbor_primary_h_s1_structure_gain_stats.csv"
    if not stats_path.exists():
        stats_path = phase / "h_s1_structure_gain_stats.csv"
    stats = _read_csv(stats_path)
    assoc_path = phase / "all_neighbor_primary_structure_reward_association_stats.csv"
    if not assoc_path.exists():
        assoc_path = phase / "structure_reward_association_stats.csv"
    assoc = _read_csv(assoc_path)
    policy_stats = _read_csv(phase / "all_neighbor_primary_local_policy_gain_stats.csv")
    common_policy_stats = _read_csv(
        phase / "all_neighbor_primary_local_policy_common_node_gain_stats.csv"
    )
    global_stats = _read_csv(phase / "all_neighbor_global_frontier_h_s1_gain_stats.csv")
    hypothesis_status = _read_csv(phase / "hypothesis_status.csv")
    floor_sensitivity = _read_csv(
        phase / "phase1_policy_denominator_floor_sensitivity.csv"
    )
    frontier_support = _read_csv(
        phase / "phase1_global_frontier_support_diagnostic.csv"
    )
    coverage_overlap = _read_csv(phase / "phase1_global_frontier_coverage_overlap.csv")
    penalty_sensitivity = _read_csv(
        phase / "phase1_graph_policy_penalty_sensitivity.csv"
    )
    chosen_feature = _read_csv(phase / "phase1_null_chosen_feature_calibration.csv")
    early_policy = _read_csv(phase / "phase1_early_policy_level_diagnostic.csv")
    h_s2_components = _read_csv(phase / "phase1_h_s2_component_specificity.csv")
    reward = _read_csv(phase / "reward_learning_endpoints.csv")
    lines = ["### Structure and reward behavior (Phase 1)", ""]
    if stats.empty:
        return lines + ["Phase 1 has not produced a final output bundle.", ""]
    if manifest:
        lines.extend(
            [
                f"- Primary structure role: `all-neighbor variable-outdegree`; policy null: `{manifest.get('primary_null_model_used', manifest.get('null_model_used', 'unspecified'))}`; null precision tier: `{manifest.get('null_precision_tier', 'unspecified')}`.",
                f"- Exposure epochs use the first and last K={manifest.get('primary_chosen_k', 'NA')} eligible all-neighbor decisions within the primary 60-min window as B and C, leaving the intervening decisions as a buffer.",
                f"- Root-to-terminal generative diagnostic: `{manifest.get('primary_generative_walk_status', 'unspecified')}`; it is not substituted for the exact-support primary null when from-child/backtrack support is missing by construction.",
            ]
        )
    for _, row in stats.iterrows():
        direction = (
            "positive"
            if float(row["median"]) > 0
            else "opposite to the positive hypothesis"
        )
        lines.append(
            f"- `{row['contrast']}`: n={int(row['n'])}, median change={_fmt(row['median'])}, "
            f"mean={_fmt(row['mean'])}, two-sided sign-flip p={_fmt(row['p_sign_flip_two_sided'])}; observed direction: {direction}."
        )
    lines.extend(
        [
            "",
            "These rows are estimates, not automatic support. The entered-from-parent child-choice output is a diagnostic only; biological interpretation follows the all-neighbor S_local score and exact maintained P_SF/P_SA/P_BF/P_BS audits. A negative result triggers the feature/support/null ladder before any claim that structure learning is absent.",
            "",
        ]
    )
    if len(hypothesis_status):
        status_lookup = hypothesis_status.set_index("hypothesis_id")["status"]
        lines.extend(
            [
                "Evidence-aware Phase-1 labels:",
                "",
                *[
                    f"- `{hypothesis_id}`: `{status_lookup[hypothesis_id]}`."
                    for hypothesis_id in (
                        "H-S1",
                        "H-S1RF",
                        "H-S1-PBF",
                        "H-S1-PBS",
                        "H-S1G",
                        "H-S2",
                    )
                    if hypothesis_id in status_lookup.index
                ],
                "",
            ]
        )
    if len(early_policy):
        for scope, label in (
            ("pooled_reward_agnostic", "pooled"),
            ("latent_dry_reward_free", "reward-free"),
        ):
            row = early_policy.loc[
                early_policy["scope"].eq(scope) & early_policy["epoch"].eq("B")
            ]
            if len(row):
                value = row.iloc[0]
                lines.append(
                    f"- Early-B composite level ({label}): n={int(value['n_animals'])}, "
                    f"median null-corrected score={_fmt(value['median_null_corrected_psi'])}, "
                    f"{int(value['n_positive'])} positive, sign-flip p={_fmt(value['sign_flip_p_two_sided'])}."
                )
        lines.extend(
            [
                "",
                "Because the composite is already above its fixed-history null in early B, the unsupported B-to-C increment is compatible with very rapid acquisition before/during B or a pre-existing graph-relative policy; it is not evidence that mice never use structure.",
                "",
            ]
        )
    policy_labels = {
        "P_BF_Lf_from_child_forward": "P_BF (from-child forward)",
        "P_BS_Lo_from_child_outward_given_forward": (
            "P_BS (from-child outward given forward)"
        ),
    }
    for metric, label in policy_labels.items():
        unrestricted = policy_stats.loc[
            policy_stats.get("metric", pd.Series(dtype=str)).eq(metric)
            & policy_stats.get("scope", pd.Series(dtype=str)).eq(
                "pooled_reward_agnostic"
            )
        ]
        same_node = common_policy_stats.loc[
            common_policy_stats.get("metric", pd.Series(dtype=str)).eq(metric)
            & common_policy_stats.get("scope", pd.Series(dtype=str)).eq(
                "pooled_reward_agnostic"
            )
        ]
        if len(unrestricted) and len(same_node):
            u = unrestricted.iloc[0]
            c = same_node.iloc[0]
            lines.append(
                f"- {label}: unrestricted median C-minus-B={_fmt(u['median_delta_C_minus_B'])}; "
                f"two-sided sign-flip p={_fmt(u['p_sign_flip_two_sided'])}; "
                f"same-node-support median={_fmt(c['median_delta_C_minus_B'])} "
                f"(n={int(c['n'])}, p={_fmt(c['p_sign_flip_two_sided'])})."
            )
            if len(floor_sensitivity):
                floor_rows = floor_sensitivity.loc[
                    floor_sensitivity["metric"].eq(metric)
                    & floor_sensitivity["scope"].eq("pooled_reward_agnostic")
                ]
                floor_text = []
                for floor_value in (1, 3, 5):
                    row = floor_rows.loc[
                        floor_rows["opportunity_floor_per_node_epoch"].eq(floor_value)
                    ]
                    if len(row):
                        value = row.iloc[0]
                        floor_text.append(
                            f"floor {floor_value}: n={int(value['n_animals'])}, "
                            f"median={_fmt(value['median_delta_C_minus_B'])}, "
                            f"p={_fmt(value['sign_flip_p_two_sided'])}"
                        )
                if floor_text:
                    lines.append(
                        f"  Denominator-floor sensitivity ({label}): "
                        + "; ".join(floor_text)
                        + "."
                    )
    if len(policy_stats) and len(common_policy_stats):
        lines.extend(
            [
                "",
                "P_BF/P_BS are reported separately because a composite S_local result cannot identify which maintained policy changed. Common-node and denominator-floor estimates expose changing node support; they are not assumed to agree with the unrestricted estimate.",
                "",
            ]
        )
    if len(chosen_feature):
        pbs_rows = chosen_feature.loc[
            chosen_feature["feature"].eq("alt_is_outward_from_child")
        ].set_index("epoch")
        if {"B", "C"}.issubset(pbs_rows.index):
            lines.extend(
                [
                    "The pooled history-only chosen-feature decomposition places outward-from-child activity within its simulated interval in B "
                    f"(observed={_fmt(pbs_rows.loc['B', 'observed_chosen_rate'])}, q97.5={_fmt(pbs_rows.loc['B', 'simulated_q975'])}) "
                    "but above it in C "
                    f"(observed={_fmt(pbs_rows.loc['C', 'observed_chosen_rate'])}, q97.5={_fmt(pbs_rows.loc['C', 'simulated_q975'])}). "
                    "With 50 conditional simulations, this is a residual signal decomposition, not a null-calibration or confirmatory test.",
                    "",
                ]
            )
    if len(global_stats):
        lines.append(
            "The stronger global-frontier result is secondary and is interpreted separately from the local-policy estimands:"
        )
        lines.append("")
        for _, row in global_stats.iterrows():
            lines.append(
                f"- `{row['contrast']}`: n={int(row['n'])}, median change={_fmt(row['median'])}, "
                f"two-sided sign-flip p={_fmt(row['p_sign_flip_two_sided'])}."
            )
        lines.append("")
        if len(frontier_support):
            pooled = frontier_support.loc[
                frontier_support["scope"].eq("pooled_reward_agnostic")
            ].set_index("epoch")
            if {"B", "C"}.issubset(pooled.index):
                lines.append(
                    "Frontier support changed from "
                    f"{_fmt(pooled.loc['B', 'frontier_discriminating_fraction'])} "
                    "of decisions offering discriminating frontier alternatives in B to "
                    f"{_fmt(pooled.loc['C', 'frontier_discriminating_fraction'])} "
                    "in C, while median visited terminals rose from "
                    f"{_fmt(pooled.loc['B', 'median_visited_terminals_before'])} "
                    f"to {_fmt(pooled.loc['C', 'median_visited_terminals_before'])}."
                )
        if len(coverage_overlap):
            n_overlap = int(
                coverage_overlap["coverage_overlap_exists"].astype(bool).sum()
            )
            lines.append(
                f"Coverage-matched B/C support existed for {n_overlap}/{len(coverage_overlap)} animals; therefore the negative global increment is support-depleted rather than evidence that planning declined."
            )
        lines.append("")
    if len(penalty_sensitivity):
        reward_free = penalty_sensitivity.loc[
            penalty_sensitivity["scope"].eq("latent_dry_reward_free")
        ]
        if len(reward_free):
            penalty_values = ", ".join(
                f"L2={_fmt(row.l2_penalty)}: median={_fmt(row.median_raw_delta)}"
                for row in reward_free.itertuples()
            )
            lines.extend(
                [
                    "Reward-free raw composite penalty sensitivity: "
                    + penalty_values
                    + ". Matching null correction was not repeated at alternate penalties, so this is an estimator-sensitivity diagnostic.",
                    "",
                ]
            )
    if len(assoc):
        lines.extend(["Structure-to-reward associations remain context-specific:", ""])
        for _, row in assoc.iterrows():
            lines.append(
                f"- {row['cohort_group']} `{row['contrast']}`: n={int(row['n'])}, rho={_fmt(row['rho'])}, p={_fmt(row['p'])}."
            )
        lines.append("")
    if len(h_s2_components):
        lines.append("H-S2 component specificity (latent n=9; diagnostic, unadjusted):")
        lines.append("")
        for _, row in h_s2_components.iterrows():
            lines.append(
                f"- `{row['analysis']}`: {row['association']} estimate={_fmt(row['estimate'])}, p={_fmt(row['p_two_sided'])}."
            )
        lines.extend(
            [
                "",
                "The stronger P_SF association and loss of the composite association after P_SF rank residualization leave structural-component specificity unresolved.",
                "",
            ]
        )
    if len(reward):
        discovery = pd.to_numeric(reward.get("T_discovery_time_s"), errors="coerce")
        binding = pd.to_numeric(reward.get("T_binding_time_s"), errors="coerce")
        predates = (
            reward.get(
                "legacy_lb0_predates_reward", pd.Series(False, index=reward.index)
            )
            .fillna(False)
            .astype(bool)
        )
        lines.extend(
            [
                f"Actual reward discovery was observed in {int(discovery.notna().sum())}/{len(reward)} sessions; median discovery time={_fmt(discovery.median())} s.",
                f"Binding was observed in {int(binding.notna().sum())}/{len(reward)} sessions; median binding time={_fmt(binding.median())} s.",
                f"Legacy lb0 preceded actual reward in {int(predates.sum())}/{len(reward)} sessions, so it is retained only as an execution endpoint.",
                "",
            ]
        )
    return lines


def _phase2_summary(root: Path) -> list[str]:
    phase = _phase2_dir(root)
    manifest = _read_json(phase / "phase2_manifest.json")
    diagnostics = _read_json(phase / "elpc_reliability_diagnostic_manifest.json")
    lines = ["### Neural-dynamics measurement (Phase 2)", ""]
    if not manifest:
        return lines + ["No final Phase 2 bundle is present.", ""]
    rel = manifest.get("reliability", {})
    lines.extend(
        [
            f"- Status: `{manifest.get('status', 'unknown')}`.",
            f"- Animals estimated: {manifest.get('n_animals_estimated', 'NA')}; median Spearman-Brown reliability={_fmt(rel.get('median_spearman_brown'))} against threshold {_fmt(rel.get('threshold'))}.",
            f"- Configuration: {manifest.get('window_seconds', 'NA')} s within {manifest.get('max_maze_minutes', 'NA')} maze min; frame source `{manifest.get('frame_source', 'NA')}`.",
            "- Interpretation rule: failure of this gate is estimator-unresolved, not evidence that early collective dynamics or criticality are biologically absent.",
            "",
        ]
    )
    if manifest.get("status") != "passed_reliability_gate":
        exact = diagnostics.get("exact_support_verification", {})
        split = diagnostics.get("median_split_block_spearman_brown", {})
        subset = diagnostics.get("median_full_window_cell_subset_rank_stability", {})
        lines.extend(
            [
                "- H-N1 outcome lock: closed. Phase-1 outcome tables and ELPC-to-learning models are not inspected when H-N0 remains unresolved.",
                (
                    "- Exact-support audit: "
                    f"{exact.get('n_verified', 'NA')}/{exact.get('n_session_subset_groups', 'NA')} "
                    "session/subset combinations reused identical cell identities and "
                    "off-diagonal pairs across full, split-1, and split-2 estimates."
                ),
                (
                    "- Reliability-layer diagnostic: median split-half "
                    f"Spearman-Brown was L0={_fmt(split.get('l0_observed_power'))}, "
                    f"L1={_fmt(split.get('l1_cell_shift_excess'))}, and "
                    f"L2={_fmt(split.get('l2_zero_lag_excess'))}."
                ),
                (
                    "- Cell-subset diagnostic: median full-window rank stability was "
                    f"L0={_fmt(subset.get('l0_observed_power'))}, "
                    f"L1={_fmt(subset.get('l1_cell_shift_excess'))}, "
                    f"L2={_fmt(subset.get('l2_zero_lag_excess'))}, and "
                    f"L3={_fmt(subset.get('l3_map_trajectory_elpc'))}."
                ),
                "- Diagnostic conclusion: instability is already present before L2 null correction and across fixed cell subsets; no post-hoc layer replaces the primary metric or unlocks H-N1.",
                "",
            ]
        )
    return lines


def _phase3_summary(root: Path) -> list[str]:
    phase = root / "phase3_neural_codes"
    statuses = _read_csv(phase / "hypothesis_status.csv")
    inference = _read_csv(phase / "phase3_animal_inference_summary.csv")
    posthoc = _read_csv(
        phase / "phase3_cross_subtree_posthoc_interior_depths_2_5_results.csv"
    )
    lines = ["### Neural structure and reward codes (Phase 3)", ""]
    if statuses.empty:
        return lines + ["No final Phase 3 bundle is present.", ""]
    status_lookup = statuses.set_index("hypothesis_id")
    for hypothesis_id in ("H-NS1A", "H-NS1B"):
        if hypothesis_id in status_lookup.index:
            row = status_lookup.loc[hypothesis_id]
            lines.append(
                f"- `{hypothesis_id}`: `{row['status']}` (n={int(row['n'])}); this is a support failure, not a biological null."
            )
    if len(posthoc):
        supported = posthoc.loc[
            posthoc["status"].astype(str).str.startswith("ok")
        ].copy()
        animal_means = (
            supported.groupby("animal_id", as_index=False)[
                [
                    "topology_minus_position",
                    "topology_minus_xy_behavior",
                    "topology_minus_shuffle_q95",
                ]
            ].mean()
            if len(supported)
            else pd.DataFrame()
        )
        lines.append(
            f"- The single post-hoc interior-depth support rescue restored {len(supported)}/{len(posthoc)} fold-directions across {supported['animal_id'].nunique() if len(supported) else 0} animals."
        )
        if len(animal_means):
            lines.append(
                "  Animal-mean margins were "
                f"{_fmt(animal_means['topology_minus_position'].mean())} versus position, "
                f"{_fmt(animal_means['topology_minus_xy_behavior'].mean())} versus XY/behavior, and "
                f"{_fmt(animal_means['topology_minus_shuffle_q95'].mean())} versus shuffle q95. "
                "Because the shuffle margin is not positive, this support-only rescue does not support abstract topology generalization."
            )
    hns2 = inference.loc[inference["hypothesis_id"].eq("H-NS2")]
    if len(hns2):
        lines.extend(["", "Day-1 C to pre-reward Day-2 transfer:", ""])
        for _, row in hns2.iterrows():
            lines.append(
                f"- `{row['estimand']}`: n={int(row['n_animals'])}, mean={_fmt(row['effect_mean'])}, "
                f"95% CI [{_fmt(row['ci_low'])}, {_fmt(row['ci_high'])}], exact sign p={_fmt(row['exact_p_value'])}; `{row['support_classification']}`."
            )
        lines.extend(
            [
                "",
                "The transfer estimator is usable in eight animals, but the topology representation does not outperform all required comparators and performs worse than XY/behavior; H-NS2 is estimated but unsupported.",
            ]
        )
    if "H-NR1" in status_lookup.index:
        row = status_lookup.loc["H-NR1"]
        lines.extend(
            [
                "",
                f"Neural reward code: `{row['status']}`. The displayed n={int(row['n'])} counts animals estimable in any alternative branch; only {int(row['n_any_supported'])} animals ({row['supported_animal_ids']}) support an alternative reward-code label, with zero explore-only location-specific estimates. This permits no pooled, causal, mechanistic, or explore-only claim.",
                "",
            ]
        )
    return lines


def _phase4_arcrit_summary(root: Path) -> list[str]:
    phase = root / "phase4_dist_arcrit_S"
    statuses = _read_csv(phase / "hypothesis_status.csv")
    reliability = _read_csv(phase / "reliability_summary.csv")
    statistics = _read_csv(phase / "statistics.csv")
    adjusted = _read_csv(phase / "adjusted_statistics.csv")
    sensitivity = _read_csv(phase / "ar_bin_rank_sensitivity.csv")
    input_audit = _read_csv(
        root / "phase4_dist_arcrit_S_inputs" / "dist_arcrit_S_input_audit.csv"
    )
    lines = ["### S-only criticality appendix (Phase 4)", ""]
    if statuses.empty:
        return lines + [
            "No completed S-only reference appendix is present. This is an implementation state, not a biological null.",
            "",
        ]
    lines.extend(
        [
            "The appendix keeps two quantities separate: H-N2a is Hengen's dimensionless Euclidean AR-boundary distance; H-N2b is Sooter's beta=2 KL-divergence-rate distance in bits/s. Both reuse the same OASIS-inferred S population series and AR kernel, so agreement is robustness, not independent replication.",
            "Reference methods: Sooter et al., *Defining and measuring proximity to criticality* (bioRxiv 2025, https://doi.org/10.1101/2025.08.03.668332); Hengen et al., *A single dynamical property can account for the capacity to learn* (bioRxiv 2026, https://doi.org/10.64898/2026.07.09.737603). The analysis uses the authors' `prox_crit_toolkit` at frozen commit `f91691f...`.",
            "",
        ]
    )
    if len(input_audit):
        fully_pre = int(
            input_audit["window_entirely_pre_reward"]
            .astype(str)
            .str.lower()
            .isin(["true", "1", "yes"])
            .sum()
        )
        reward_free = int(
            input_audit["cohort_group"]
            .isin(["unrewarded_no_water", "unrewarded_dry_waterport"])
            .sum()
        )
        lines.extend(
            [
                f"- Input support: {len(input_audit)} S-ready animals; reward-free n={reward_free}; fully prereward early windows n={fully_pre}. S is inferred calcium-event mass, not literal spike count.",
                "",
            ]
        )
    reliability_lookup = (
        reliability.set_index("metric") if len(reliability) else pd.DataFrame()
    )
    for status in statuses.itertuples(index=False):
        lines.append(f"- `{status.hypothesis_id}`: `{status.status}`.")
        metric = str(status.metric)
        if len(reliability_lookup) and metric in reliability_lookup.index:
            row = reliability_lookup.loc[metric]
            lines.append(
                "  Measurement diagnostics: "
                f"split-half rho={_fmt(row['split_half_rho'])}, "
                f"Spearman-Brown={_fmt(row['spearman_brown'])}, "
                f"median fixed-150 split Spearman-Brown={_fmt(row.get('median_fixed150_split_spearman_brown'))}, "
                f"median between-subset rho={_fmt(row.get('median_between_fixed150_subset_rho'))}, "
                f"fixed-150 median/all-cell rho={_fmt(row.get('fixed150_median_to_all_cells_rho'))}; "
                f"measurement_pass={bool(row['measurement_pass'])}."
            )
        if len(statistics):
            primary_rows = statistics.loc[
                statistics["hypothesis_id"].eq(status.hypothesis_id)
                & statistics["outcome"].isin(["delta_psi", "delta_p_bs"])
                & statistics["cohort_tier"].isin(
                    ["pooled_S_ready", "reward_free_latent_plus_dry"]
                )
            ]
            for result in primary_rows.itertuples(index=False):
                lines.append(
                    f"  `{result.outcome}`, {result.cohort_tier}, {result.analysis_variant}: n={int(result.n)}, "
                    f"rho={_fmt(result.rho)}, 95% bootstrap CI "
                    f"[{_fmt(result.ci_low)}, {_fmt(result.ci_high)}], "
                    f"p={_fmt(result.p)}, LOO range "
                    f"[{_fmt(result.loo_rho_min)}, {_fmt(result.loo_rho_max)}]; "
                    f"approximate 80%-power detectable |r|={_fmt(result.detectable_abs_r_80pct)}."
                )
            context_rows = statistics.loc[
                statistics["hypothesis_id"].eq(status.hypothesis_id)
                & statistics["analysis_variant"].eq("frozen_all_cell_primary")
                & statistics["outcome"].eq("delta_p_bs")
                & statistics["cohort_tier"].isin(
                    [
                        "latent_no_water_only",
                        "rewarded_from_day1_only",
                        "dry_port_only",
                    ]
                )
            ]
            if len(context_rows):
                context_text = "; ".join(
                    f"{row.cohort_tier}: n={int(row.n)}, rho={_fmt(row.rho)}"
                    for row in context_rows.itertuples(index=False)
                )
                lines.append(
                    "  Context-heterogeneity diagnostic for all-cell delta_P_BS: "
                    + context_text
                    + "."
                )
        if len(adjusted):
            adjusted_rows = adjusted.loc[
                adjusted["hypothesis_id"].eq(status.hypothesis_id)
                & adjusted["cohort_tier"].eq("pooled_S_ready")
            ]
            for result in adjusted_rows.itertuples(index=False):
                lines.append(
                    f"  Baseline/context/event-mass rank ANCOVA for `{result.outcome}` ({result.metric}): "
                    f"n={int(result.n)}, beta={_fmt(result.beta)}, "
                    f"Freedman-Lane p={_fmt(result.p_freedman_lane)}. "
                    "Because the baseline policy estimate is noisy, disagreement with the raw change-score analysis is retained as a diagnostic."
                )
    if len(sensitivity):
        nonprimary = sensitivity.loc[
            ~sensitivity["specification"].eq("primary_AR10_40ms")
        ]
        if len(nonprimary):
            lines.append(
                "- AR/bin variants are rank-sensitivity diagnostics only; none replaces the frozen 300-s, AR(10), 40-ms all-cell primary. Their exact correlations are exported in `ar_bin_rank_sensitivity.csv`."
            )
            for metric, group in nonprimary.groupby("metric", sort=False):
                lines.append(
                    f"  `{metric}` rank concordance range across nonprimary variants: "
                    f"{_fmt(group['rho_to_frozen_primary'].min())} to "
                    f"{_fmt(group['rho_to_frozen_primary'].max())}."
                )
    lines.extend(
        [
            "",
            "Interpretation cap: a reliable negative association would mean that smaller modeled distance precedes greater later policy change, but remains compatible with stable animal ability, circuit health, arousal, or event-rate differences. A reliability failure is measurement-unresolved; neither metric alone establishes a physical phase transition or a causal learning mechanism.",
            "",
        ]
    )
    return lines


def build_integrated_report(root: Path, out_dir: Path) -> dict[str, Any]:
    root = Path(root)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cards = analysis_cards_frame()
    statuses = _phase_status_rows(root)
    attempts = _attempt_rows(root)
    cards.to_csv(out_dir / "analysis_cards.csv", index=False)
    statuses.to_csv(out_dir / "integrated_hypothesis_status.csv", index=False)
    attempts.to_csv(out_dir / "integrated_attempt_registry.csv", index=False)

    p0 = _read_json(root / "phase0" / "phase0_manifest.json")
    lines = [
        "# Rapid learning: structure, reward, and neural dynamics",
        "",
        "## Scientific separation",
        "",
        "The workflow treats structure acquisition, reward discovery, reward binding, neural structural coding, neural reward coding, and early population dynamics as separate estimands. A completed computation is not labeled hypothesis support unless its direction, uncertainty, validity gates, and rival explanations warrant that conclusion.",
        "",
        "## Cohort and alignment",
        "",
        f"Phase 0 froze {p0.get('frozen_pair_count', 'NA')} naive Day1-Day2 pairs: "
        f"{p0.get('cohort_counts', {}).get('unrewarded_no_water', 'NA')} latent/no-water, "
        f"{p0.get('cohort_counts', {}).get('rewarded', 'NA')} rewarded-from-start, and "
        f"{p0.get('cohort_counts', {}).get('unrewarded_dry_waterport', 'NA')} dry-port.",
        f"C/ELPC-ready pairs: {p0.get('readiness_counts', {}).get('ELPC_ready', 'NA')}; forced behavior-only pairs: {', '.join(p0.get('forced_behavior_only_pairs', [])) or 'none'}.",
        f"Timebase: {p0.get('timebase', 'not recorded')}.",
        "Same-visit Day1-Day2 identity is accepted only where joint-deconvolution provenance and equal component support passed; no long-gap identity inference is made.",
        "",
        "## Analysis cards",
        "",
    ]
    for card in ANALYSIS_CARDS:
        metadata = CARD_METADATA.get(card.hypothesis_id, {})
        lines.extend(
            [
                f"### {card.hypothesis_id}: {card.family}",
                "",
                f"**Hypothesis.** {card.hypothesis}",
                "",
                f"**Why this analysis.** {card.why}",
                "",
                f"**How it is performed.** {card.execution}",
                "",
                f"**Cohort and order.** {metadata.get('primary_cohort', 'not specified')}; {metadata.get('temporal_order', 'not specified')}.",
                "",
                f"**Expected direction and tier.** {metadata.get('expected_direction', 'not specified')}; {metadata.get('inference_tier', 'not specified')}.",
                "",
                f"**Implementation status.** {metadata.get('implementation_status', 'not specified')}.",
                "",
                f"**If positive.** {card.positive_rival_checks}",
                "",
                f"**If negative or failed.** {card.negative_diagnostic_ladder}",
                "",
            ]
        )
    lines.extend(["## Current execution results", ""])
    lines.extend(_phase1_summary(root))
    lines.extend(_phase2_summary(root))
    lines.extend(_phase3_summary(root))
    lines.extend(_phase4_arcrit_summary(root))
    if len(statuses):
        lines.extend(["### Integrated hypothesis statuses", ""])
        for _, row in statuses.iterrows():
            lines.append(
                f"- {row.get('hypothesis_id', 'unknown')} ({row.get('source_phase', 'unknown')}): `{row.get('status', 'unknown')}`."
            )
        lines.append("")
    lines.extend(
        [
            "## What can be concluded",
            "",
            "### Structure learning",
            "",
            "The data support rapid refinement of a specific local graph-relative policy, not a unitary global-structure score. The maintained P_BS policy—after moving childward, leave the sampled subtree outward when continuing forward—increased from early to late Day 1 and survived common-node checks and denominator floors through floor 3; floor 5 was support-limited. P_BF did not show comparable robust support. The composite graph-policy score was already positive in early B and showed no reliable B-to-C increment, so its null change cannot be read as absence of structure knowledge. The global-unvisited-frontier analysis is not a valid late acquisition test because most frontier opportunities were exhausted by C.",
            "",
            "In latent/no-water mice, stronger Day-1 composite change prospectively tracked faster Day-2 reward discovery, but the association is small-n and is at least as strongly captured by P_SF; residualizing P_SF removes the composite relation. Therefore prior reward-free experience predicts later search efficiency, while the exact structural component remains unresolved.",
            "",
            "### Reward learning",
            "",
            "Reward discovery and reward binding are empirically distinct. Discovery occurred in every session at a median of 383 s, whereas sustained binding occurred later at a median of 797 s. In 7/23 sessions the legacy first-long-bout endpoint preceded any reward, proving that it cannot serve as reward-learning onset. Neural node-94 analyses remain support-limited and do not establish a reward-specific CA1 code in this dataset.",
            "",
            "### Neural dynamics and criticality",
            "",
            "The C-based ELPC estimator failed its bounded reliability rescue, so the confirmatory ELPC-to-learning hypothesis was correctly not tested. In the separate S-only appendix, the all-cell Hengen and Sooter distances each showed a raw negative relation to P_BS gain, but neither relation survives the full interpretation ladder: the composite outcome is null, reward-free estimates are imprecise, context effects differ, baseline/context/event-mass adjustment removes the association, and the median fixed-150-cell rescue changes the relation to approximately zero or positive. Hengen's metric is measurable but sampling-sensitive; Sooter's KL-rate metric remains measurement-unresolved under fixed subsets.",
            "",
            "The defensible conclusion is therefore that rapid maze learning includes early graph-relative policy expression, later refinement of outward subtree-exit behavior, and reward discovery followed by delayed binding. The present data do not show that a critical neural regime explains these behavioral changes.",
            "",
        ]
    )
    lines.extend(
        [
            "## Claim discipline",
            "",
            "- A reliable prospective association remains observational and may reflect a stable animal trait; it does not establish that ELPC or criticality causes learning.",
            "- An unreliable ELPC estimate blocks H-N1 confirmatory testing but does not erase the behavioral structure/reward study or neural-code analyses.",
            "- A topology decoder must outperform same-split position-based comparators across physically distant subtrees before it is called abstract.",
            "- A reward-node change must survive matched terminal-node and trajectory/occupancy controls before it is called reward-specific.",
            "- Literal criticality remains an S-only appendix and is not inferred from C-based ELPC.",
            "- Hengen Euclidean and Sooter KL-rate distances share the same S/AR input and are never counted as independent replications.",
            "",
            "## Audit artifacts",
            "",
            "- `phase0/rapid_learning_session_inventory.csv`: frozen cohort, signal readiness, and inclusion reasons.",
            "- `phase0/rapid_learning_session_support.csv`: per-session support and neural provenance.",
            "- `phase0/rapid_learning_choice_support.parquet`: decision-level source representation.",
            "- `phase1/all_neighbor_primary_structure_assigned_choices.csv` and `all_neighbor_primary_structure_policy_per_decision.csv`: exposure assignment and transformed all-neighbor choice scores before aggregation.",
            "- `phase1/reward_path_audit.csv`: reward/path reconstruction before endpoint summarization.",
            "- `phase2_elpc_exact_support_rescue/elpc_window_audit.csv`, `elpc_estimates_long.csv`, and `analysis_attempt_registry.csv`: exact frozen-cell/pair neural support, null ladder, and bounded rescue history.",
            "- `phase3_neural_codes/`: occupancy masks, fold support, decoder comparators, reward visits, pseudo-terminal controls, and statuses when executed.",
            "- `phase4_dist_arcrit_S_inputs/`: outcome-blind S windows, segments, input hashes, prereward fractions, and deterministic fixed-cell subsets.",
            "- `phase4_dist_arcrit_S_reference/` and `phase4_dist_arcrit_S_reference_diagnostics/`: exact reference estimates, deterministic parity, split halves, cell subsets, and AR/bin sensitivities.",
            "- `phase4_dist_arcrit_S/`: joined outcomes, tiered associations, reliability summaries, statuses, and interpretation gates.",
            "- `phase4_dist_arcrit_S/audit_figures/`: source-to-estimate conversion, measurement reliability, outcome, and fixed-cell sampling-rescue audit figures.",
            "",
        ]
    )
    report_path = out_dir / "RAPID_LEARNING_ANALYSIS_REPORT.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    manifest = {
        "phase": "rapid_learning_integrated_phase5",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "root": str(root.resolve()),
        "n_analysis_cards": int(len(cards)),
        "n_status_rows": int(len(statuses)),
        "n_attempt_rows": int(len(attempts)),
        "outputs": {
            "report": str(report_path.resolve()),
            "analysis_cards": str((out_dir / "analysis_cards.csv").resolve()),
            "statuses": str((out_dir / "integrated_hypothesis_status.csv").resolve()),
            "attempts": str((out_dir / "integrated_attempt_registry.csv").resolve()),
        },
    }
    (out_dir / "phase5_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    return manifest


__all__ = [
    "ANALYSIS_CARDS",
    "AnalysisCard",
    "analysis_cards_frame",
    "build_integrated_report",
]
