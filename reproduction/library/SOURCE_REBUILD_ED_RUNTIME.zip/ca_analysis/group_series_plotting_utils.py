from __future__ import annotations

# Auto-migrated local copy from source workspace module.

"""
Flexible group-wise extraction, interpolation, averaging, and plotting of time series
from loaded single-session results.

Key features
------------
- Choose which variables to extract (by key or custom getter functions)
- Clean, sort, and de-duplicate time series per subject
- Interpolate onto a common grid ('union' or 'overlap' window)
- Aggregate by mean/median; error bands via SEM / STD / naive 95% CI
- Highly configurable plotting: figsize, x/ylim, labels, legend, grid, etc.
- Color control: dict / list / named colormap / single color -> gradient

Typical pipeline
----------------
from session_loaders import load_single_session_pickles
from group_series_plotting import (
    compute_group_series_averages, plot_group_series_stats
)

loaded = load_single_session_pickles(groups, data_roots=["/data"],
                                     pattern_template="wtn_{name}_spatial.pkl")
stats = compute_group_series_averages(
    loaded,
    x_key="pivot_times_maze",
    y_key="sim_mean",
    window="union",              # or 'overlap'
    how="mean",                  # 'mean' or 'median'
    error="sem"                  # 'sem', 'std', or 'ci95'
)
ax = plot_group_series_stats(
    stats,
    colors={"G1": "tab:blue", "G2": "tab:red"},
    figsize=(8, 5), xlim=(0, 600), ylim=(0.2, 0.9),
    title="sim_mean (mean ± SEM)", xlabel="Time (s)", ylabel="Pearson r"
)
"""


import numpy as np
import matplotlib.pyplot as plt
import warnings
from typing import Dict, List, Tuple, Any, Optional, Mapping, Sequence, Union, Callable
from matplotlib import cm
from matplotlib.colors import to_hex, to_rgb, LinearSegmentedColormap, Colormap, is_color_like

Array = np.ndarray
Series = Tuple[Array, Array]

# ──────────────────────────────────────────────────────────────────────────────
# Utilities
# ──────────────────────────────────────────────────────────────────────────────

def _clean_series(t, y) -> Series:
    """Return sorted, strictly increasing times with aligned values.
       - removes NaNs
       - sorts by time
       - drops duplicate times (keeps first)
       - truncates to min length if lengths mismatch
    """
    t = np.asarray(t).astype(float).ravel()
    y = np.asarray(y).astype(float).ravel()
    m = min(len(t), len(y))
    t, y = t[:m], y[:m]
    ok = np.isfinite(t) & np.isfinite(y)
    t, y = t[ok], y[ok]
    if len(t) == 0:
        return t, y
    order = np.argsort(t)
    t, y = t[order], y[order]
    # drop duplicated times
    uniq, idx = np.unique(t, return_index=True)
    return uniq, y[idx]


def _median_dt(t: Array) -> Optional[float]:
    if t.size < 2:
        return None
    d = np.diff(t)
    d = d[np.isfinite(d) & (d > 0)]
    return float(np.median(d)) if d.size else None


def _nansem(a: Array, axis=0) -> Array:
    """SEM ignoring NaNs; returns 0 where n<=1 so shading doesn’t blow up."""
    n = np.sum(np.isfinite(a), axis=axis)
    with np.errstate(invalid="ignore", divide="ignore"):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            s = np.nanstd(a, axis=axis, ddof=1)
        sem = np.where(n > 1, s / np.sqrt(n), 0.0)
    return sem

# ──────────────────────────────────────────────────────────────────────────────
# Extraction helpers
# ──────────────────────────────────────────────────────────────────────────────

Extractor = Callable[[Any], Optional[Series]]

def make_series_extractor(
    *,
    x_key: Optional[str] = None,
    y_key: Optional[str] = None,
    x_getter: Optional[Callable[[Any], Any]] = None,
    y_getter: Optional[Callable[[Any], Any]] = None,
    series_getter: Optional[Callable[[Any], Tuple[Any, Any]]] = None,
    y_transform: Optional[Callable[[Array], Array]] = None,
    min_points: int = 2,
) -> Extractor:
    """Build a series extractor that returns (t, y) or None to skip.

    Priority:
      1) If `series_getter` provided → (t, y) = series_getter(obj)
      2) Else if x_getter/y_getter provided → t = x_getter(obj); y = y_getter(obj)
      3) Else fall back to dict keys (`x_key`, `y_key`)

    After extraction, series is cleaned and optionally transformed via `y_transform`.
    Subjects with < `min_points` usable samples are skipped (return None).
    """
    def _extract(obj: Any) -> Optional[Series]:
        # Pull raw series
        if series_getter is not None:
            tx, ty = series_getter(obj)
        elif x_getter is not None and y_getter is not None:
            tx, ty = x_getter(obj), y_getter(obj)
        else:
            if x_key is None or y_key is None:
                raise ValueError("Provide (x_key,y_key) or getter functions.")
            if not isinstance(obj, Mapping):
                # try attribute access
                tx = getattr(obj, x_key, None)
                ty = getattr(obj, y_key, None)
            else:
                tx = obj.get(x_key, None)
                ty = obj.get(y_key, None)
        if tx is None or ty is None:
            return None

        t, y = _clean_series(tx, ty)
        if y_transform is not None and y.size:
            y = np.asarray(y, float)
            y = y_transform(y)
        if t.size >= min_points:
            return t, y
        return None

    return _extract

# ──────────────────────────────────────────────────────────────────────────────
# Core: per-group interpolation + averaging
# ──────────────────────────────────────────────────────────────────────────────

def compute_group_series_averages(
    loaded: Dict[str, Dict[str, Any]],
    *,
    # extraction
    x_key: Optional[str] = "pivot_times_maze",
    y_key: Optional[str] = "sim_mean",
    x_getter: Optional[Callable[[Any], Any]] = None,
    y_getter: Optional[Callable[[Any], Any]] = None,
    series_getter: Optional[Callable[[Any], Tuple[Any, Any]]] = None,
    y_transform: Optional[Callable[[Array], Array]] = None,
    min_points: int = 2,
    # interpolation window/grid
    window: str = "union",             # 'union' | 'overlap'
    grid_dt: Optional[float] = None,    # if None, median of per-animal median dts
    # aggregation
    how: str = "mean",                 # 'mean' | 'median'
    error: str = "sem",                 # 'sem' | 'std' | 'ci95'
) -> Dict[str, Dict[str, Array]]:
    """
    Returns per-group stats dict:
      { group: {
          't_grid': np.ndarray,
          'center': np.ndarray,   # mean/median
          'error':  np.ndarray,   # sem/std/ci95
          'n':      np.ndarray,   # subjects contributing at each time
        }, ... }
    """
    # Build extractor according to arguments
    extractor = make_series_extractor(
        x_key=x_key, y_key=y_key,
        x_getter=x_getter, y_getter=y_getter,
        series_getter=series_getter,
        y_transform=y_transform,
        min_points=min_points,
    )

    out: Dict[str, Dict[str, Array]] = {}

    for group, name2obj in loaded.items():
        # collect clean (t, y)
        series: List[Series] = []
        for _, obj in name2obj.items():
            s = extractor(obj)
            if s is not None:
                series.append(s)

        if not series:
            out[group] = dict(t_grid=np.array([]), center=np.array([]), error=np.array([]), n=np.array([]))
            continue

        # choose time window and grid step
        t_mins = [t[0] for (t, _) in series]
        t_maxs = [t[-1] for (t, _) in series]
        if window == "overlap":
            t0 = max(t_mins)
            t1 = min(t_maxs)
            if t1 <= t0:  # no overlap; fall back to union
                t0, t1 = min(t_mins), max(t_maxs)
        else:
            t0, t1 = min(t_mins), max(t_maxs)

        # decide grid_dt if not provided
        if grid_dt is None:
            dts = [dt for (t, _) in series if (dt := _median_dt(t)) is not None and dt > 0]
            grid_dt_use = float(np.median(dts)) if dts else ((t1 - t0) / 100.0 if t1 > t0 else 1.0)
        else:
            grid_dt_use = float(grid_dt)
        if grid_dt_use <= 0:
            grid_dt_use = (t1 - t0) / 100.0 if t1 > t0 else 1.0

        # build grid (inclusive right edge with small epsilon)
        eps = grid_dt_use * 1e-6
        t_grid = np.arange(t0, t1 + eps, grid_dt_use)

        # interpolate (no extrapolation)
        interp_stack = []
        for (t, y) in series:
            yi = np.interp(t_grid, t, y)
            outside = (t_grid < t[0]) | (t_grid > t[-1])
            yi[outside] = np.nan
            interp_stack.append(yi)
        M = np.vstack(interp_stack)  # (n_subjects, n_time)

        # aggregate
        if how == "median":
            center = np.nanmedian(M, axis=0)
            # error options for medians are trickier; still offer sem/std/ci95 of the samples
        else:  # mean
            center = np.nanmean(M, axis=0)

        if error == "std":
            with np.errstate(invalid="ignore"):
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", RuntimeWarning)
                    err = np.nanstd(M, axis=0, ddof=1)
        elif error == "ci95":
            err = 1.96 * _nansem(M, axis=0)
        else:  # 'sem'
            err = _nansem(M, axis=0)

        n = np.sum(np.isfinite(M), axis=0)
        out[group] = dict(t_grid=t_grid, center=center, error=err, n=n)

    return out


def _linear_slope(t: Array, y: Array) -> float:
    """Least-squares slope for a 1D series, ignoring NaNs."""
    t = np.asarray(t, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    keep = np.isfinite(t) & np.isfinite(y)
    if np.count_nonzero(keep) < 2:
        return np.nan
    x = t[keep]
    z = y[keep]
    x_centered = x - float(np.mean(x))
    denom = float(np.sum(x_centered ** 2))
    if denom <= 0:
        return np.nan
    z_centered = z - float(np.mean(z))
    return float(np.sum(x_centered * z_centered) / denom)


def summarize_group_series_curve(
    curve_stats: Mapping[str, Array],
    *,
    n_subjects_total: Optional[int] = None,
    min_support_frac: float = 0.5,
    min_support_count: int = 3,
    max_time: Optional[float] = None,
) -> Dict[str, float]:
    """Summarize an interpolated group curve with support-aware slope estimates.

    The `slope_all` value reflects the full interpolated group curve. The
    `slope_supported` and `slope_supported_horizon` values only use timepoints
    where enough subjects still contribute, which guards against late-session
    tails with very small support dominating the fitted trend.
    """
    t_grid = np.asarray(curve_stats.get("t_grid", np.array([])), dtype=float)
    center = np.asarray(curve_stats.get("center", np.array([])), dtype=float)
    n = np.asarray(curve_stats.get("n", np.array([])), dtype=float)

    if n_subjects_total is None:
        finite_n = n[np.isfinite(n)]
        n_total_use = int(np.nanmax(finite_n)) if finite_n.size else 0
    else:
        n_total_use = int(max(int(n_subjects_total), 0))

    support_required = int(max(int(min_support_count), 1))
    if n_total_use > 0:
        support_required = max(support_required, int(np.ceil(float(min_support_frac) * float(n_total_use))))
        support_required = min(support_required, n_total_use)

    finite_mask = np.isfinite(t_grid) & np.isfinite(center)
    supported_mask = finite_mask & np.isfinite(n) & (n >= float(support_required))
    if max_time is None or not np.isfinite(max_time):
        supported_horizon_mask = supported_mask.copy()
    else:
        supported_horizon_mask = supported_mask & (t_grid <= float(max_time))

    def _start_end(mask: Array) -> Tuple[float, float]:
        if np.count_nonzero(mask) == 0:
            return np.nan, np.nan
        idx = np.flatnonzero(mask)
        return float(t_grid[idx[0]]), float(t_grid[idx[-1]])

    time_start_all, time_end_all = _start_end(finite_mask)
    time_start_supported, time_end_supported = _start_end(supported_mask)
    time_start_supported_h, time_end_supported_h = _start_end(supported_horizon_mask)

    return {
        "n_subjects_total": int(n_total_use),
        "support_count_required": int(support_required),
        "min_support_frac": float(min_support_frac),
        "min_support_count": int(min_support_count),
        "max_time": (float(max_time) if max_time is not None and np.isfinite(max_time) else np.nan),
        "n_points_all": int(np.count_nonzero(finite_mask)),
        "time_start_all": time_start_all,
        "time_end_all": time_end_all,
        "slope_all": _linear_slope(t_grid[finite_mask], center[finite_mask]),
        "n_points_supported": int(np.count_nonzero(supported_mask)),
        "time_start_supported": time_start_supported,
        "time_end_supported": time_end_supported,
        "slope_supported": _linear_slope(t_grid[supported_mask], center[supported_mask]),
        "n_points_supported_horizon": int(np.count_nonzero(supported_horizon_mask)),
        "time_start_supported_horizon": time_start_supported_h,
        "time_end_supported_horizon": time_end_supported_h,
        "slope_supported_horizon": _linear_slope(
            t_grid[supported_horizon_mask],
            center[supported_horizon_mask],
        ),
    }

# ──────────────────────────────────────────────────────────────────────────────
# Plotting utilities
# ──────────────────────────────────────────────────────────────────────────────

def _cmap_from_base(base) -> Colormap:
    """Build a Colormap from a name, a single color, or a list/tuple of colors."""
    if isinstance(base, Colormap):
        return base
    if isinstance(base, (list, tuple)):
        cols = [to_rgb(c) for c in base]
        return LinearSegmentedColormap.from_list("custom", cols)
    # try as a named colormap
    try:
        return cm.get_cmap(str(base))
    except Exception:
        pass
    # fallback: single color -> white→color gradient; else tab10
    if is_color_like(base):
        col = to_rgb(base)
        return LinearSegmentedColormap.from_list("custom", [(1, 1, 1), col])
    return cm.get_cmap("tab10")


def _resolve_colors(labels, colors_arg, default_colors):
    """
    Accepts:
      - dict: {label -> color}
      - list/tuple: sequence of colors (cycled over labels)
      - str/Colormap: a colormap name or object to sample light→dark
      - single color string: creates white→that-color gradient
    Returns {label -> color}.
    """
    if colors_arg is None:
        return {lab: default_colors[i % len(default_colors)] for i, lab in enumerate(labels)}
    if isinstance(colors_arg, dict):
        return {lab: colors_arg.get(lab, default_colors[i % len(default_colors)])
                for i, lab in enumerate(labels)}
    if isinstance(colors_arg, (list, tuple)):
        seq = list(colors_arg)
        return {lab: seq[i % len(seq)] for i, lab in enumerate(labels)}
    cmap = _cmap_from_base(colors_arg)
    n = max(1, len(labels))
    vals = [0.35] if n == 1 else np.linspace(0.35, 0.85, n)
    return {lab: to_hex(cmap(v)) for lab, v in zip(labels, vals)}


def plot_group_series_stats(
    group_stats: Dict[str, Dict[str, Array]],
    *,
    ax: Optional[plt.Axes] = None,
    figsize: Optional[Tuple[float, float]] = (8, 5),
    colors: Optional[Union[dict, list, tuple, str, Colormap]] = None,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    xlim: Optional[Tuple[float, float]] = None,
    ylim: Optional[Tuple[float, float]] = None,
    legend: bool = True,
    legend_loc: str = "best",
    grid: bool = False,
    show_n: bool = False,
    n_height_frac: float = 0.08,         # fraction of y‑range used to draw n(t)
    line_width: float = 2.5,
    line_style: str = "--",
    fill_alpha: float = 0.20,
    line_kwargs: Optional[dict] = None,
    fill_kwargs: Optional[dict] = None,
) -> plt.Axes:
    """Plot center ± error for each group with many styling knobs.

    Returns the matplotlib Axes for further customization.
    """
    if ax is None:
        fig = plt.figure(figsize=figsize) if figsize is not None else plt.figure()
        ax = fig.add_subplot(111)

    default_colors = [
        "tab:blue","tab:red","tab:green","tab:orange","tab:purple",
        "tab:brown","tab:pink","tab:gray","tab:olive","tab:cyan"
    ]
    labels = list(group_stats.keys())
    color_map = _resolve_colors(labels, colors, default_colors)
    line_kwargs = dict(line_kwargs or {})
    fill_kwargs = dict(fill_kwargs or {})

    ymins, ymaxs = [], []

    for lab in labels:
        gs = group_stats[lab]
        t = gs.get("t_grid", np.array([]))
        c = color_map[lab]
        if t.size == 0:
            continue
        m = gs.get("center")
        e = gs.get("error")
        (ln,) = ax.plot(t, m, lw=line_width, ls=line_style, color=c, label=lab, **line_kwargs)
        ax.fill_between(t, m - e, m + e, color=c, alpha=fill_alpha, **fill_kwargs)
        ymins.append(np.nanmin(m - e))
        ymaxs.append(np.nanmax(m + e))
        if show_n:
            n = gs.get("n", None)
            if n is not None and np.size(n) == t.size:
                n = n.astype(float)
                n = n / (np.nanmax(n) if np.nanmax(n) > 0 else 1.0)
                yr = (np.nanmax(m + e) - np.nanmin(m - e))
                baseline = np.nanmin(m - e)
                ax.plot(t, baseline + yr * n_height_frac * n, color=c, alpha=0.6, lw=1.0)

    # labels/limits
    if title is not None:
        ax.set_title(title)
    if xlabel is not None:
        ax.set_xlabel(xlabel)
    if ylabel is not None:
        ax.set_ylabel(ylabel)

    # default limits from data if not provided
    if xlim is not None:
        ax.set_xlim(*xlim)
    if ylim is not None:
        ax.set_ylim(*ylim)
    elif ymins and ymaxs:
        pad = 0.03 * (max(ymaxs) - min(ymins))
        ax.set_ylim(min(ymins) - pad, max(ymaxs) + pad)

    if grid:
        ax.grid(True, which="both", ls=":", lw=0.5, alpha=0.7)

    if legend:
        ax.legend(loc=legend_loc)

    plt.tight_layout()
    return ax
