from .place_map_legacy import (
    arena_binned_legacy,
    generate_placeMap_with_start_and_end_time_single_cell_legacy,
)

