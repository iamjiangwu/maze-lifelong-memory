from __future__ import annotations

import numpy as np
import scipy.sparse as sps


def arena_binned_legacy(x, y, xdim, ydim, pix_cm, pf_cm):
    x = np.asarray(x)
    y = np.asarray(y)
    d_x = xdim[0] - xdim[1]
    d_y = ydim[0] - ydim[1]
    nBnx = int(d_x / (pix_cm * pf_cm))
    nBny = int(d_y / (pix_cm * pf_cm))
    bn_x = np.linspace(xdim[0], xdim[1], nBnx + 1)
    bn_y = np.linspace(ydim[0], ydim[1], nBny + 1)
    bx = ((x - bn_x[0]) / (bn_x[1] - bn_x[0])).astype(int)
    by = ((y - bn_y[0]) / (bn_y[1] - bn_y[0])).astype(int)
    bx = np.clip(bx, 0, nBnx - 1)
    by = np.clip(by, 0, nBny - 1)
    s = np.vstack((bx, by))
    lin_s = np.ravel_multi_index(s, (nBnx, nBny))
    occ_map = sps.csr_matrix(
        (np.ones(len(bx)), (bx, by)),
        shape=(nBnx, nBny),
        dtype=float,
    ).todense()
    return lin_s.astype(float), occ_map, nBnx, nBny, bx, by


def generate_placeMap_with_start_and_end_time_single_cell_legacy(selected_df, S_trans, start_frame, end_frame):
    temp_df = selected_df[
        (selected_df["frame"] > start_frame) & (selected_df["frame"] < end_frame)
    ].copy()
    y = 1 - np.array(temp_df.x)
    x = 1 - np.array(temp_df.y)
    xdim = [1, 0]
    ydim = [1, 0]
    pix_cm = 1 / 15
    pf_cm = 1 / 3
    _, occ_map, nBnx, nBny, bx, by = arena_binned_legacy(
        x=x, y=y, xdim=xdim, ydim=ydim, pix_cm=pix_cm, pf_cm=pf_cm
    )
    s_idx = np.array(temp_df["frame"]).astype(int)
    s_selected = np.asarray(S_trans)[s_idx].T
    nonnan_idx = np.where(~np.isnan(s_selected))[0]
    s_selected = s_selected[nonnan_idx]
    bx = bx[nonnan_idx]
    by = by[nonnan_idx]
    rate_map = sps.csr_matrix(
        (s_selected, (bx, by)),
        shape=(nBnx, nBny),
        dtype=float,
    ).todense()
    with np.errstate(divide="ignore", invalid="ignore"):
        place_map = np.divide(rate_map, occ_map)
    return place_map

