"""Coordinate-space policy for historical session-local neuron exclusions."""

from __future__ import annotations

from pathlib import Path


NO_EXCLUSIONS = "none"
HISTORICAL_PRESORT_EXCLUSION_PROFILE = (
    "sparsity_reviewed_plus_1616_1224_1668_bidirectional"
)
HISTORICAL_PRESORT_MANUAL_CELL_IDS: dict[str, list[int]] = {
    "418RRday1": [775],
    "418RRday2": [775],
    "418-3day1": [510, 641],
    "418-3day2": [510, 641],
    "422-3day1": [585],
    "422-3day2": [585],
    "468-3day1": [583],
    "468-3day2": [583],
    "488-3day2": [297],
    "1616day1": [1224, 1668],
    "1616day2": [1224, 1668],
    "1616bday1": [778],
    "1616bday2": [778],
    "1616b-3day1": [1734],
    "1616b-3day2": [1734],
    "1632Lday2": [176],
}
HISTORICAL_SPARSITY_DIAGNOSTIC_PROFILE = "historical_sparsity_diagnostic_presort"
HISTORICAL_SPARSITY_DIAGNOSTIC_CELL_IDS: dict[str, list[int]] = {
    session: list(ids) for session, ids in HISTORICAL_PRESORT_MANUAL_CELL_IDS.items()
}
HISTORICAL_SPARSITY_DIAGNOSTIC_CELL_IDS["1616day1"] = [1668]
HISTORICAL_SPARSITY_DIAGNOSTIC_CELL_IDS["1616day2"] = [1668]


def infer_neural_id_space(neural_root: str | Path) -> str:
    """Return ``sorted``, ``presort``, or ``unknown`` from a neural-root path."""

    normalized = str(Path(neural_root)).replace("/", "\\").rstrip("\\").lower()
    leaf = normalized.rsplit("\\", 1)[-1]
    if leaf in {"neuraldata_sort", "neural_data_sort", "sorted_neural"} or "sorted_neural" in leaf:
        return "sorted"
    if leaf in {"neuraldata", "neural_data"}:
        return "presort"
    return "unknown"


def validate_exclusion_coordinate_space(
    *,
    exclusion_profile: str,
    neural_root: str | Path,
    confirm_presort_id_space: bool = False,
) -> str:
    """Fail closed when pre-sort cell IDs could be applied to another ID space."""

    id_space = infer_neural_id_space(neural_root)
    if exclusion_profile == NO_EXCLUSIONS:
        return id_space
    if id_space == "sorted":
        raise ValueError(
            f"Exclusion profile {exclusion_profile!r} contains pre-sort session-local cell IDs "
            f"and cannot be applied to sorted neural root {str(neural_root)!r}."
        )
    if id_space == "presort" or confirm_presort_id_space:
        return "presort_confirmed" if id_space == "unknown" else id_space
    raise ValueError(
        f"Neural ID space is unknown for {str(neural_root)!r}. A non-empty historical "
        "exclusion profile requires --confirm-presort-id-space."
    )
