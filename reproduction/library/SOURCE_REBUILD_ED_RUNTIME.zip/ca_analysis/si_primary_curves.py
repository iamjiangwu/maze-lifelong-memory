from __future__ import annotations

"""Primary spatial-information curve helpers.

This module exposes the step-window / interpolate-then-average analysis
surface used by the main SI pipeline without labeling that primary path
as "legacy". Provenance-specific reproduction tooling may continue to use
`ca_analysis.legacy_si_reproduction`, but active analysis code should
import from this module instead.
"""

import warnings

import numpy as np
import pandas as pd

from .legacy_si_reproduction import (
    compute_group_session_curves,
    compute_session_si_stepcurve,
    compute_session_si_timecurve,
    label_selected_frames_by_mode,
    load_current_day1_groups,
    normalize_group_name,
    scaled_nonoverlap_min_time_sec,
)

INTERPOLATE_THEN_AVERAGE_METHOD = "interpolate_then_average"
DEFAULT_MIN_TIME_POLICY = "scaled_nonoverlap"
SPATIAL_BIN_SPEC = "15x15"


def interpolate_then_average_group_curves(
    session_curves: dict[str, list[dict]],
    *,
    grid_dt_sec: float,
    min_support_count: int = 3,
):
    rows: list[dict] = []
    summary_rows: list[dict] = []
    group_tables: dict[str, pd.DataFrame] = {}

    for group_name, curves in session_curves.items():
        usable = []
        for curve in curves:
            t = pd.to_numeric(np.asarray(curve.get("maze_time_rel", np.array([]))), errors="coerce").astype(float)
            y = pd.to_numeric(np.asarray(curve.get("si_mean", np.array([]))), errors="coerce").astype(float)
            mask = np.isfinite(t) & np.isfinite(y)
            t = t[mask]
            y = y[mask]
            if t.size < 2:
                continue
            order = np.argsort(t)
            t = t[order]
            y = y[order]
            uniq, idx = np.unique(t, return_index=True)
            t = uniq
            y = y[idx]
            if t.size < 2:
                continue
            usable.append((curve["session_id"], t, y))

        if not usable:
            group_tables[group_name] = pd.DataFrame(
                columns=["group", "maze_time_rel_sec", "maze_time_rel_min", "mean_si", "sem_si", "n"]
            )
            summary_rows.append(
                {
                    "group": str(group_name),
                    "n_sessions_used": 0,
                    "n_curve_points": 0,
                    "slope_all": np.nan,
                }
            )
            continue

        t0 = min(float(t[0]) for _, t, _ in usable)
        t1 = max(float(t[-1]) for _, t, _ in usable)
        grid = np.arange(float(t0), float(t1) + float(grid_dt_sec) + 1e-9, float(grid_dt_sec), dtype=float)
        mat = np.full((len(usable), grid.size), np.nan, dtype=float)
        for row_i, (_, t, y) in enumerate(usable):
            mat[row_i] = np.interp(grid, t, y, left=np.nan, right=np.nan)
        n = np.sum(np.isfinite(mat), axis=0).astype(int)
        with np.errstate(invalid="ignore", divide="ignore"):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                mean_si = np.nanmean(mat, axis=0)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                sem_si = np.nanstd(mat, axis=0, ddof=1) / np.sqrt(np.maximum(n, 1))
        sem_si[n <= 1] = 0.0
        support_mask = n >= int(min_support_count)
        mean_masked = np.where(support_mask, mean_si, np.nan)
        sem_masked = np.where(support_mask, sem_si, np.nan)
        group_df = pd.DataFrame(
            {
                "group": str(group_name),
                "maze_time_rel_sec": grid,
                "maze_time_rel_min": grid / 60.0,
                "mean_si": mean_masked,
                "sem_si": sem_masked,
                "n": n.astype(int),
            }
        )
        supported_df = group_df.loc[support_mask].reset_index(drop=True)
        group_tables[group_name] = supported_df
        rows.extend(supported_df.to_dict(orient="records"))
        finite_mean = np.isfinite(supported_df["mean_si"].to_numpy(dtype=float))
        if supported_df.empty or not np.any(finite_mean):
            slope = np.nan
        else:
            x = supported_df.loc[finite_mean, "maze_time_rel_sec"].to_numpy(dtype=float)
            y = supported_df.loc[finite_mean, "mean_si"].to_numpy(dtype=float)
            x_center = x - float(np.mean(x))
            denom = float(np.sum(x_center**2))
            slope = np.nan if denom <= 0 else float(np.sum(x_center * (y - float(np.mean(y)))) / denom)
        summary_rows.append(
            {
                "group": str(group_name),
                "n_sessions_used": int(len(usable)),
                "n_curve_points": int(len(supported_df)),
                "slope_all": slope,
            }
        )

    curves_df = pd.DataFrame(rows)
    summary_df = pd.DataFrame(summary_rows)
    return {
        "curves_df": curves_df,
        "summary_df": summary_df,
        "group_tables": group_tables,
    }

__all__ = [
    "DEFAULT_MIN_TIME_POLICY",
    "INTERPOLATE_THEN_AVERAGE_METHOD",
    "SPATIAL_BIN_SPEC",
    "compute_group_session_curves",
    "compute_session_si_stepcurve",
    "compute_session_si_timecurve",
    "interpolate_then_average_group_curves",
    "label_selected_frames_by_mode",
    "load_current_day1_groups",
    "normalize_group_name",
    "scaled_nonoverlap_min_time_sec",
]
