"""Stochastic 4-bias agent simulation on a complete binary-tree maze.

An agent traverses a complete binary tree of depth ``le`` (default 6, giving
127 internal nodes and 64 leaf endpoints) and makes probabilistic decisions
at each internal node based on four bias parameters:

    Bf  - P(forward | arrived from parent)
    Ba  - P(spatial alternation | forward from parent)
    Lf  - P(forward | arrived from child)
    Lo  - P(outward to parent | forward from child)

This module is the canonical home of the simulator. It is reused by:

    scripts/simulate_turning_bias_efficiency.py        (group-mean conditions)
    scripts/counterfactual_turning_bias_efficiency.py  (per-animal counterfactual)

The simulator is intentionally minimal: pure-Python loops over ``n_steps``,
``np.random.Generator`` for RNG, no external dependencies beyond NumPy. This
keeps it cheap enough for nested bootstraps yet exact enough that
:func:`ca_analysis.exploration.compute_scalar_efficiency_metrics` can be
applied to its output sequence to compare simulated and real efficiency on
identical units.
"""

from __future__ import annotations

from typing import overload

import numpy as np

try:  # Optional acceleration; pure-Python fallbacks remain below.
    from numba import njit
except Exception:  # pragma: no cover - depends on local optional dependency
    njit = None


__all__ = [
    "tree_params",
    "simulate_one",
    "simulate_endnode_sequence",
    "simulate_endnode_sequence_depth_stratified",
    "DEPTH_STRATA",
]


# ---------------------------------------------------------------------------
# Depth strata
# ---------------------------------------------------------------------------
# Match ca_analysis.exploration.compute_depth_stratified_lo:
#   shallow = depths 1-2, mid = depths 3-4, deep = depth 5
DEPTH_STRATA = {"shallow": (1, 2), "mid": (3, 4), "deep": (5, 5)}


if njit is not None:
    @njit(cache=True)
    def _simulate_endnode_sequence_jit(
        Ba: float,
        Bf: float,
        Lf: float,
        Lo: float,
        n_target: int,
        le: int,
        max_steps: int,
        seed: int,
    ) -> np.ndarray:
        np.random.seed(seed)
        leaf_start = 2 ** le - 1
        virtual_parent = 2 ** (le + 1) - 1
        seq = np.empty(n_target, dtype=np.int32)
        count = 0
        cur = 0
        prev = virtual_parent
        for _ in range(max_steps):
            if count >= n_target:
                break
            if cur == virtual_parent:
                nxt = 0
            elif cur >= leaf_start:
                seq[count] = cur
                count += 1
                nxt = (cur - 1) // 2
            else:
                parent = (cur - 1) // 2 if cur > 0 else virtual_parent
                lc = 2 * cur + 1
                rc = 2 * cur + 2
                if prev == parent:
                    if cur == 0 or np.random.random() < Bf:
                        if parent == virtual_parent:
                            nxt = lc if np.random.random() < 0.5 else rc
                        elif cur == 2 * ((cur - 1) // 2) + 1:
                            nxt = rc if np.random.random() < Ba else lc
                        else:
                            nxt = lc if np.random.random() < Ba else rc
                    else:
                        nxt = parent
                else:
                    sibling = rc if prev == lc else lc
                    if np.random.random() < Lf:
                        nxt = sibling if cur == 0 else (parent if np.random.random() < Lo else sibling)
                    else:
                        nxt = prev
            prev = cur
            cur = nxt
        return seq[:count].copy()


    @njit(cache=True)
    def _simulate_endnode_sequence_depth_jit(
        Ba: float,
        Bf: float,
        Lf: float,
        lo_per_node: np.ndarray,
        n_target: int,
        le: int,
        max_steps: int,
        seed: int,
    ) -> np.ndarray:
        np.random.seed(seed)
        leaf_start = 2 ** le - 1
        virtual_parent = 2 ** (le + 1) - 1
        seq = np.empty(n_target, dtype=np.int32)
        count = 0
        cur = 0
        prev = virtual_parent
        for _ in range(max_steps):
            if count >= n_target:
                break
            if cur == virtual_parent:
                nxt = 0
            elif cur >= leaf_start:
                seq[count] = cur
                count += 1
                nxt = (cur - 1) // 2
            else:
                parent = (cur - 1) // 2 if cur > 0 else virtual_parent
                lc = 2 * cur + 1
                rc = 2 * cur + 2
                if prev == parent:
                    if cur == 0 or np.random.random() < Bf:
                        if parent == virtual_parent:
                            nxt = lc if np.random.random() < 0.5 else rc
                        elif cur == 2 * ((cur - 1) // 2) + 1:
                            nxt = rc if np.random.random() < Ba else lc
                        else:
                            nxt = lc if np.random.random() < Ba else rc
                    else:
                        nxt = parent
                else:
                    sibling = rc if prev == lc else lc
                    if np.random.random() < Lf:
                        if cur == 0:
                            nxt = sibling
                        else:
                            lo_here = lo_per_node[cur]
                            nxt = parent if np.random.random() < lo_here else sibling
                    else:
                        nxt = prev
            prev = cur
            cur = nxt
        return seq[:count].copy()
else:
    _simulate_endnode_sequence_jit = None
    _simulate_endnode_sequence_depth_jit = None


def _build_lo_per_node(le: int, Lo_shallow: float, Lo_mid: float,
                       Lo_deep: float, Lo_root: float | None = None) -> np.ndarray:
    """Return an array of Lo values indexed by internal node id (0 .. 2^le-2).

    Depth of node n is floor(log2(n+1)). Root (n=0) gets ``Lo_root`` when
    supplied, because the empirical depth strata start at depths 1-2 and do
    not estimate a root-specific value. Root from-child forward moves still
    enter the sibling subtree, because the root has no physical parent.
    """
    n_internal = 2 ** le - 1
    Lo_per = np.empty(n_internal, dtype=float)
    for n in range(n_internal):
        d = 0 if n == 0 else int(np.floor(np.log2(n + 1)))
        if d == 0:
            Lo_per[n] = Lo_shallow if Lo_root is None else Lo_root
        elif d <= 2:
            Lo_per[n] = Lo_shallow
        elif d <= 4:
            Lo_per[n] = Lo_mid
        else:
            Lo_per[n] = Lo_deep
    return Lo_per


def tree_params(le: int = 6) -> dict:
    """Return structural constants for a complete binary tree of depth ``le``.

    Keys: ``le``, ``n_nodes``, ``leaf_start``, ``n_leaves``, ``virtual_parent``.
    """
    return {
        "le": le,
        "n_nodes": 2 ** (le + 1) - 1,
        "leaf_start": 2 ** le - 1,
        "n_leaves": 2 ** le,
        "virtual_parent": 2 ** (le + 1) - 1,
    }


@overload
def simulate_one(
    Ba: float, Bf: float, Lf: float, Lo: float, n_steps: int, le: int = ...,
    rng: np.random.Generator | None = ..., return_sequence: bool = False,
) -> float: ...
@overload
def simulate_one(
    Ba: float, Bf: float, Lf: float, Lo: float, n_steps: int, le: int = ...,
    rng: np.random.Generator | None = ..., return_sequence: bool = True,
) -> tuple[float, np.ndarray]: ...


def simulate_one(
    Ba: float,
    Bf: float,
    Lf: float,
    Lo: float,
    n_steps: int,
    le: int = 6,
    rng: np.random.Generator | None = None,
    return_sequence: bool = False,
):
    """Run one agent for ``n_steps`` transitions on a depth-``le`` binary tree.

    Decision model at internal nodes:

    From parent:
      - P(reverse to parent) = 1 - Bf
      - P(alternate-side child) = Bf * Ba
      - P(same-side child) = Bf * (1 - Ba)

    From child:
      - P(reverse to same child) = 1 - Lf
      - P(outward to parent) = Lf * Lo
      - P(inward to sibling) = Lf * (1 - Lo)

    At leaves the agent always returns to parent.

    Parameters
    ----------
    Ba, Bf, Lf, Lo : float
        Bias parameters (see module docstring).
    n_steps : int
        Number of transitions to simulate.
    le : int
        Tree depth (default 6 -> 64 leaf endpoints).
    rng : np.random.Generator, optional
        RNG; created with default seed if not provided.
    return_sequence : bool
        If True, also return the endnode-only sequence (sequence of leaf node
        IDs in the order they were visited) suitable as input to
        :func:`ca_analysis.exploration.compute_scalar_efficiency_metrics`.

    Returns
    -------
    fraction_visited : float
        Unique leaves visited / total leaves.
    endnode_sequence : np.ndarray, optional
        Returned only when ``return_sequence=True``. Each entry is a leaf
        node ID, in visitation order (with repeats).
    """
    if rng is None:
        rng = np.random.default_rng()

    tp = tree_params(le)
    leaf_start = tp["leaf_start"]
    virtual_parent = tp["virtual_parent"]

    visited: set[int] = set()
    endnode_seq: list[int] = [] if return_sequence else None  # type: ignore[assignment]
    cur = 0
    prev = virtual_parent

    for _ in range(n_steps):
        if cur == virtual_parent:
            nxt = 0
        elif cur >= leaf_start:
            visited.add(cur)
            if return_sequence:
                endnode_seq.append(cur)
            nxt = (cur - 1) // 2
        else:
            parent = (cur - 1) // 2 if cur > 0 else virtual_parent
            lc = 2 * cur + 1
            rc = 2 * cur + 2

            if prev == parent:
                # Arrived from parent
                if cur == 0 or rng.random() < Bf:
                    # Forward: spatial alternation determines child
                    if parent == virtual_parent:
                        nxt = lc if rng.random() < 0.5 else rc
                    elif cur == 2 * ((cur - 1) // 2) + 1:
                        nxt = rc if rng.random() < Ba else lc
                    else:
                        nxt = lc if rng.random() < Ba else rc
                else:
                    nxt = parent
            else:
                # Arrived from a child
                sibling = rc if prev == lc else lc
                if rng.random() < Lf:
                    # Forward: outward vs inward
                    if cur == 0:
                        # Root has no physical parent; once the walker chooses
                        # not to reverse into the same child, the only forward
                        # maze move is into the sibling subtree.
                        nxt = sibling
                    else:
                        nxt = parent if rng.random() < Lo else sibling
                else:
                    # Reverse back to same child
                    nxt = prev

        prev = cur
        cur = nxt

    fraction = len(visited) / tp["n_leaves"]
    if return_sequence:
        return fraction, np.asarray(endnode_seq, dtype=np.int32)
    return fraction


def simulate_endnode_sequence(
    Ba: float,
    Bf: float,
    Lf: float,
    Lo: float,
    n_endnodes_target: int,
    le: int = 6,
    rng: np.random.Generator | None = None,
    initial_step_factor: int = 8,
    max_doublings: int = 6,
) -> np.ndarray:
    """Simulate until at least ``n_endnodes_target`` endnode visits accumulate.

    Repeatedly runs :func:`simulate_one` with growing step budgets and returns
    the first ``n_endnodes_target`` endnode visits. Mirrors the doubling
    strategy used by :func:`ca_analysis.exploration._simulate_null_endnodes`
    so simulator output is length-matched to real animals' endnode counts.

    Parameters
    ----------
    n_endnodes_target : int
        Target number of leaf-node visits in the returned sequence.
    initial_step_factor : int
        First attempt uses ``initial_step_factor * n_endnodes_target`` steps.
    max_doublings : int
        If the first attempt is short, double the budget up to this many times.

    Returns
    -------
    np.ndarray
        Endnode IDs in visitation order, length == ``n_endnodes_target``
        (or shorter if the doubling cap is reached, in which case the
        longest attempt is returned).
    """
    if rng is None:
        rng = np.random.default_rng()
    n_target = int(max(1, n_endnodes_target))
    max_steps = max(1000, initial_step_factor * n_target) * (2 ** int(max_doublings))
    if _simulate_endnode_sequence_jit is not None:
        seed = int(rng.integers(0, 2**31 - 1))
        return _simulate_endnode_sequence_jit(
            float(Ba), float(Bf), float(Lf), float(Lo),
            n_target, int(le), int(max_steps), seed,
        )

    tp = tree_params(le)
    leaf_start = tp["leaf_start"]
    virtual_parent = tp["virtual_parent"]
    cur = 0
    prev = virtual_parent
    endnode_seq: list[int] = []

    for _ in range(max_steps):
        if len(endnode_seq) >= n_target:
            break
        if cur == virtual_parent:
            nxt = 0
        elif cur >= leaf_start:
            endnode_seq.append(cur)
            nxt = (cur - 1) // 2
        else:
            parent = (cur - 1) // 2 if cur > 0 else virtual_parent
            lc = 2 * cur + 1
            rc = 2 * cur + 2

            if prev == parent:
                if cur == 0 or rng.random() < Bf:
                    if parent == virtual_parent:
                        nxt = lc if rng.random() < 0.5 else rc
                    elif cur == 2 * ((cur - 1) // 2) + 1:
                        nxt = rc if rng.random() < Ba else lc
                    else:
                        nxt = lc if rng.random() < Ba else rc
                else:
                    nxt = parent
            else:
                sibling = rc if prev == lc else lc
                if rng.random() < Lf:
                    nxt = sibling if cur == 0 else (parent if rng.random() < Lo else sibling)
                else:
                    nxt = prev
        prev = cur
        cur = nxt

    return np.asarray(endnode_seq[:n_target], dtype=np.int32)


def simulate_endnode_sequence_depth_stratified(
    Ba: float,
    Bf: float,
    Lf: float,
    Lo_shallow: float,
    Lo_mid: float,
    Lo_deep: float,
    n_endnodes_target: int,
    le: int = 6,
    rng: np.random.Generator | None = None,
    initial_step_factor: int = 8,
    max_doublings: int = 6,
    Lo_root: float | None = None,
) -> np.ndarray:
    """Simulate endnode visits with depth-specific from-child outward bias.

    This mirrors :func:`simulate_endnode_sequence`, except the single ``Lo``
    value is replaced by ``Lo_shallow``, ``Lo_mid``, and ``Lo_deep`` according
    to the decision node depth. ``Lo_root`` is retained for compatibility with
    earlier scripts, but root from-child forward moves always enter the sibling
    subtree because there is no physical outward parent at the root.
    """
    if rng is None:
        rng = np.random.default_rng()

    tp = tree_params(le)
    leaf_start = tp["leaf_start"]
    virtual_parent = tp["virtual_parent"]
    lo_per_node = _build_lo_per_node(le, Lo_shallow, Lo_mid, Lo_deep, Lo_root)

    n_target = int(max(1, n_endnodes_target))
    max_steps = max(1000, initial_step_factor * n_target) * (2 ** int(max_doublings))
    if _simulate_endnode_sequence_depth_jit is not None:
        seed = int(rng.integers(0, 2**31 - 1))
        return _simulate_endnode_sequence_depth_jit(
            float(Ba), float(Bf), float(Lf), lo_per_node.astype(np.float64, copy=False),
            n_target, int(le), int(max_steps), seed,
        )
    endnode_seq: list[int] = []
    cur = 0
    prev = virtual_parent
    for _ in range(max_steps):
        if len(endnode_seq) >= n_target:
            break
        if cur == virtual_parent:
            nxt = 0
        elif cur >= leaf_start:
            endnode_seq.append(cur)
            nxt = (cur - 1) // 2
        else:
            parent = (cur - 1) // 2 if cur > 0 else virtual_parent
            lc = 2 * cur + 1
            rc = 2 * cur + 2
            if prev == parent:
                if cur == 0 or rng.random() < Bf:
                    if parent == virtual_parent:
                        nxt = lc if rng.random() < 0.5 else rc
                    elif cur == 2 * ((cur - 1) // 2) + 1:
                        nxt = rc if rng.random() < Ba else lc
                    else:
                        nxt = lc if rng.random() < Ba else rc
                else:
                    nxt = parent
            else:
                sibling = rc if prev == lc else lc
                if rng.random() < Lf:
                    lo_here = float(lo_per_node[cur])
                    nxt = sibling if cur == 0 else (parent if rng.random() < lo_here else sibling)
                else:
                    nxt = prev
        prev = cur
        cur = nxt
    return np.asarray(endnode_seq[:n_target], dtype=np.int32)
