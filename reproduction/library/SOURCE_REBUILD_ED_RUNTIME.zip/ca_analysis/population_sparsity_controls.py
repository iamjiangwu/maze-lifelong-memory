from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scipy.io
from scipy import stats

from .alignment import AlignmentReport, validate_alignment
from .config import DT, FPS, MAZE_ID, get_behav_wd, get_cimap_path, get_neural_wd
from .endnode_sequences import extract_endnode_events, extract_explore_node_walk
from .io import load_behav_neural
from .maze import NewMaze
from .spatial import assign_levels, generate_level_list
from .sparsity_utils_lib import (
    DEFAULT_FILTER_CRITERIA,
    apply_quality_filter_with_ratemap,
    compute_activity_fraction,
    compute_effective_dimensionality,
    compute_gini_coefficient,
    compute_level_combined,
    compute_lifetime_sparsity,
    compute_shannon_entropy,
    compute_windowed_rate_maps,
)

CONTROL_BRANCHES = (
    "all_neurons",
    "legacy_notebook_filter",
    "quality_filter_off",
    "shared_rate_gate",
    "matched_count_bootstrap",
    "occupancy_matched",
    "matched_count_plus_occupancy_bootstrap",
    "cimap_matched_neurons",
    "cimap_matched_neurons_plus_occupancy",
)

SUMMARY_TYPES = (
    "visit_first5_mean",
    "visit_first10_cap_mean",
    "time_first3_window_mean",
)

SKIP_REASONS = (
    "",
    "branch_not_applicable",
    "missing_cimap",
    "insufficient_neurons",
    "insufficient_frames",
    "insufficient_visits",
    "continuity_failure",
    "missing_signal",
    "session_load_failed",
)

TIME_METRICS = (
    "activity_frac",
    "lifetime_spars",
    "gini",
    "entropy_norm",
    "eff_dim",
    "total_rate",
)

VISIT_METRICS = (
    "sparsity",
    "gini",
    "entropy_norm",
    "total_rate",
)

PRIMARY_WINDOW_ROLE = "primary"
SMEARING_WINDOW_ROLE = "smearing_check"

CONTROL_BRANCH_COMPARISON_TYPES = {
    "within_condition": (
        "all_neurons",
        "legacy_notebook_filter",
        "quality_filter_off",
        "shared_rate_gate",
        "matched_count_bootstrap",
        "occupancy_matched",
        "matched_count_plus_occupancy_bootstrap",
    ),
    "cross_condition_same_day": CONTROL_BRANCHES,
}

MEMORY_ALIGNMENT_SIGN = {
    "activity_frac": -1.0,
    "lifetime_spars": 1.0,
    "gini": 1.0,
    "entropy_norm": -1.0,
    "eff_dim": -1.0,
    "total_rate": -1.0,
    "sparsity": 1.0,
}

DELTA_CONTRAST_MAP = {
    "delta_naive_day2_minus_naive_day1": "naive_day1_vs_naive_day2",
    "delta_gap_day2_minus_gap_day1": "gap_day1_vs_gap_day2",
    "delta_gap_day1_minus_naive_day1": "naive_day1_vs_gap_day1",
    "delta_gap_day2_minus_naive_day2": "naive_day2_vs_gap_day2",
}


@dataclass(frozen=True)
class QuartetSpec:
    animal: str
    naive_day1: str
    naive_day2: str
    gap_day1: str = ""
    gap_day2: str = ""
    cimap_path_gap: str | tuple[str, ...] | list[str] = ""
    gap_label: str = "3mo"
    include_naive_within: bool = True
    cohort_group: str = "retained"
    reward_context_note: str = ""


@dataclass(frozen=True)
class PopulationSparsityConfig:
    behav_wd: str = field(default_factory=get_behav_wd)
    neural_wd: str = field(default_factory=get_neural_wd)
    maze_id: int = MAZE_ID
    dt: float = DT
    fps: float = FPS
    window_sec: int = 1200
    step_sec: int = 120
    secondary_window_sec: int = 600
    secondary_step_sec: int = 60
    early_minutes: int = 60
    early_visits: int = 10
    bootstrap_repeats: int = 32
    shared_rate_gate_events_per_min: float = 0.1
    min_bin_occupancy_sec: float = 0.5
    quality_filter_criteria: dict[str, float] | None = None

    def with_defaults(self) -> "PopulationSparsityConfig":
        if self.quality_filter_criteria is not None:
            return self
        return PopulationSparsityConfig(
            **{
                **asdict(self),
                "quality_filter_criteria": dict(DEFAULT_FILTER_CRITERIA),
            }
        )


def default_quartet_specs() -> list[QuartetSpec]:
    mapping = [
        ("418", "418RRday1", "418RRday2", "418-3day1", "418-3day2", ""),
        ("434", "434RRday1", "434RRday2", "434-3day1", "434-3day2", ""),
        ("451", "451Rday1", "451Rday2", "451-3day1", "451-3day2", ""),
        ("488", "488Rday1", "488Rday2", "488-3day1", "488-3day2", ""),
        ("489", "489Lday1", "489Lday2", "489-3day1", "489-3day2", ""),
        ("579", "579RLday1", "579RLday2", "579-3day1", "579-3day2", ""),
        ("468", "468Lday1", "468Lday2", "468-3day1", "468-3day2", ""),
        (
            "422",
            "422RRday1",
            "422RRday2",
            "422-3day1",
            "422-3day2",
            "422 naive day1 is unrewarded in experiment_metafile.csv",
        ),
    ]
    out = []
    for animal, naive_d1, naive_d2, gap_d1, gap_d2, reward_note in mapping:
        out.append(
            QuartetSpec(
                animal=animal,
                naive_day1=naive_d1,
                naive_day2=naive_d2,
                gap_day1=gap_d1,
                gap_day2=gap_d2,
                cimap_path_gap=get_cimap_path(animal=animal, filename="cell_to_index_map_03.mat"),
                reward_context_note=reward_note,
            )
        )
    return out


def default_expanded_cohort_specs() -> list[QuartetSpec]:
    specs: list[QuartetSpec] = []

    def _resolve_cimap_gap(
        animal: str,
        cimap_filename: str | tuple[str, ...] | list[str] = "",
    ) -> str | tuple[str, ...] | list[str]:
        if not cimap_filename:
            return ""
        if isinstance(cimap_filename, (list, tuple)):
            return tuple(get_cimap_path(animal=animal, filename=name) for name in cimap_filename)
        return get_cimap_path(animal=animal, filename=str(cimap_filename))

    def add_retained(
        animal: str,
        naive_day1: str,
        naive_day2: str,
        gap_label: str,
        gap_day1: str,
        gap_day2: str,
        *,
        cimap_filename: str | tuple[str, ...] | list[str] = "",
        include_naive_within: bool = False,
        reward_context_note: str = "",
    ) -> None:
        specs.append(
            QuartetSpec(
                animal=animal,
                naive_day1=naive_day1,
                naive_day2=naive_day2,
                gap_day1=gap_day1,
                gap_day2=gap_day2,
                cimap_path_gap=_resolve_cimap_gap(animal, cimap_filename),
                gap_label=gap_label,
                include_naive_within=include_naive_within,
                cohort_group="retained",
                reward_context_note=str(reward_context_note),
            )
        )

    def add_naive_only(animal: str, naive_day1: str, naive_day2: str) -> None:
        specs.append(
            QuartetSpec(
                animal=animal,
                naive_day1=naive_day1,
                naive_day2=naive_day2,
                gap_label="naive_only",
                include_naive_within=True,
                cohort_group="naive_only",
            )
        )

    add_retained("418", "418RRday1", "418RRday2", "3mo", "418-3day1", "418-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("418", "418RRday1", "418RRday2", "6mo", "418-6day1", "418-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("418", "418RRday1", "418RRday2", "9mo", "418-9day1", "418-9day2", cimap_filename="cell_to_index_map_09.mat")

    add_retained("434", "434RRday1", "434RRday2", "3mo", "434-3day1", "434-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)

    add_retained("451", "451Rday1", "451Rday2", "3mo", "451-3day1", "451-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("451", "451Rday1", "451Rday2", "6mo", "451-6day1", "451-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("451", "451Rday1", "451Rday2", "9mo", "451-9day1", "451-9day2", cimap_filename="cell_to_index_map_09.mat")

    add_retained("488", "488Rday1", "488Rday2", "3mo", "488-3day1", "488-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("488", "488Rday1", "488Rday2", "6mo", "488-6day1", "488-6day2", cimap_filename="cell_to_index_map_06.mat")

    add_retained("489", "489Lday1", "489Lday2", "3mo", "489-3day1", "489-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("489", "489Lday1", "489Lday2", "6mo", "489-6day1", "489-6day2", cimap_filename="cell_to_index_map_06.mat")

    add_retained("579", "579RLday1", "579RLday2", "3mo", "579-3day1", "579-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)

    add_retained("468", "468Lday1", "468Lday2", "3mo", "468-3day1", "468-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("468", "468Lday1", "468Lday2", "6mo", "468-6day1", "468-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("468", "468Lday1", "468Lday2", "9mo", "468-9day1", "468-9day2", cimap_filename="cell_to_index_map_09.mat")
    add_retained("468", "468Lday1", "468Lday2", "12mo", "468-12day1", "468-12day2", cimap_filename="cell_to_index_map_012.mat")

    add_retained("422", "422RRday1", "422RRday2", "3mo", "422-3day1", "422-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True, reward_context_note="422 naive day1 is unrewarded in experiment_metafile.csv")
    add_retained("422", "422RRday1", "422RRday2", "6mo", "422-6day1", "422-6day2", cimap_filename="cell_to_index_map_06.mat", reward_context_note="422 naive day1 is unrewarded in experiment_metafile.csv")

    add_retained("837", "837day1", "837day2", "3mo", "837-3day1", "837-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("837", "837day1", "837day2", "6mo", "837-6day1", "837-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("837", "837day1", "837day2", "9mo", "837-9day1", "837-9day2", cimap_filename="cell_to_index_map_09.mat")

    add_retained("838", "838day1", "838day2", "3mo", "838-3day1", "838-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("838", "838day1", "838day2", "6mo", "838-6day1", "838-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("838", "838day1", "838day2", "9mo", "838-9day1", "838-9day2", cimap_filename="cell_to_index_map_09.mat")

    add_retained("839", "839day1", "839day2", "3mo", "839-3day1", "839-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("839", "839day1", "839day2", "6mo", "839-6day1", "839-6day2", cimap_filename=("cell_to_index_map_03.mat", "cell_to_index_map_36.mat"))
    add_retained("839", "839day1", "839day2", "9mo", "839-9day1", "839-9day2", cimap_filename=("cell_to_index_map_03.mat", "cell_to_index_map_36.mat", "cell_to_index_map_69.mat"))

    add_retained("842", "842day1", "842day2", "3mo", "842-3day1", "842-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("842", "842day1", "842day2", "6mo", "842-6day1", "842-6day2", cimap_filename=("cell_to_index_map_03.mat", "cell_to_index_map_36.mat"))
    add_retained("842", "842day1", "842day2", "9mo", "842-9day1", "842-9day2", cimap_filename=("cell_to_index_map_03.mat", "cell_to_index_map_36.mat", "cell_to_index_map_69.mat"))

    add_retained("862", "862day1", "862day2", "3mo", "862-3day1", "862-3day2", cimap_filename="cell_to_index_map_03.mat", include_naive_within=True)
    add_retained("862", "862day1", "862day2", "6mo", "862-6day1", "862-6day2", cimap_filename="cell_to_index_map_06.mat")
    add_retained("862", "862day1", "862day2", "9mo", "862-9day1", "862-9day2", cimap_filename=("cell_to_index_map_06.mat", "cell_to_index_map_69.mat"))

    # 1616 retest intervals are ~1 week and ~3 months post-naive; per user mapping,
    # these are assigned to the 3mo and 6mo gap buckets respectively.
    add_retained("1616", "1616day1", "1616day2", "3mo", "1616bday1", "1616bday2", cimap_filename="cell_to_index_map_01.mat", include_naive_within=True)
    add_retained("1616", "1616day1", "1616day2", "6mo", "1616b-3day1", "1616b-3day2", cimap_filename="cell_to_index_map_03.mat")

    add_naive_only("163", "163RLday1", "163RLday2")
    add_naive_only("1632", "1632Lday1", "1632Lday2")

    return specs


def load_cimap_pairs(
    path_or_paths: str | Path | list[str | Path] | tuple[str | Path, ...] | None,
    *,
    split: bool = True,
    zero_based: bool = True,
    compose: bool = False,
) -> tuple[np.ndarray, np.ndarray] | np.ndarray:
    def _load_single_matrix(path: str | Path) -> np.ndarray:
        path_obj = Path(path)
        if not path_obj.exists():
            raise FileNotFoundError(f"CIMap not found: {path_obj}")
        mat = scipy.io.loadmat(str(path_obj))
        if "cell_to_index_map" in mat:
            raw = mat["cell_to_index_map"]
        else:
            keys = [k for k in mat.keys() if not k.startswith("__")]
            if not keys:
                raise KeyError(f"No non-private arrays found in {path_obj}")
            raw = mat[keys[0]]
        pairs = np.asarray(raw, dtype=int)
        if pairs.ndim == 1:
            pairs = pairs.reshape(-1, 1)
        if pairs.shape[1] < 2:
            raise ValueError(f"CIMap requires at least two columns, got shape {pairs.shape}")
        pairs = pairs[:, :2]
        keep = (pairs[:, 0] > 0) & (pairs[:, 1] > 0)
        pairs = pairs[keep]
        if zero_based:
            pairs = pairs - 1
        return pairs.astype(int, copy=False)

    def _compose_pair_chain(pair_list: list[np.ndarray]) -> np.ndarray:
        if not pair_list:
            return np.zeros((0, 2), dtype=int)
        current = np.asarray(pair_list[0], dtype=int)
        if current.ndim != 2 or current.shape[1] != 2:
            raise ValueError("CIMap chain items must be 2-column arrays.")
        for nxt in pair_list[1:]:
            nxt = np.asarray(nxt, dtype=int)
            if nxt.ndim != 2 or nxt.shape[1] != 2:
                raise ValueError("CIMap chain items must be 2-column arrays.")
            if current.size == 0 or nxt.size == 0:
                return np.zeros((0, 2), dtype=int)
            right_to_final = {int(mid): int(final) for mid, final in nxt.tolist()}
            chained = []
            for start, mid in current.tolist():
                final = right_to_final.get(int(mid))
                if final is not None:
                    chained.append((int(start), int(final)))
            current = np.asarray(chained, dtype=int)
            if current.size == 0:
                return np.zeros((0, 2), dtype=int)
        return current.reshape(-1, 2)

    if path_or_paths is None or str(path_or_paths).strip() == "":
        empty = np.zeros((0, 2), dtype=int)
        if split:
            return empty[:, 0], empty[:, 1]
        return empty

    is_many = isinstance(path_or_paths, (list, tuple))
    if is_many:
        paths = [p for p in path_or_paths if p is not None and str(p).strip() != ""]
        matrices = [_load_single_matrix(p) for p in paths]
        if compose:
            pairs = _compose_pair_chain(matrices)
        else:
            if len(matrices) != 1:
                raise ValueError("load_cimap_pairs received multiple paths without compose=True.")
            pairs = matrices[0]
    else:
        if compose:
            raise ValueError("compose=True requires a list/tuple of CIMap paths.")
        pairs = _load_single_matrix(path_or_paths)

    if split:
        if pairs.size == 0:
            return np.asarray([], dtype=int), np.asarray([], dtype=int)
        return pairs[:, 0].astype(int), pairs[:, 1].astype(int)
    return pairs.astype(int, copy=False)


def _safe_numeric_mean(values: list[dict[str, float | int | str]]) -> dict[str, float | int | str]:
    if not values:
        return {}
    out: dict[str, float | int | str] = {}
    keys = set().union(*(v.keys() for v in values))
    for key in keys:
        col = [v.get(key) for v in values]
        if all(isinstance(x, (int, float, np.integer, np.floating)) or pd.isna(x) for x in col):
            arr = np.asarray(col, dtype=float)
            out[key] = float(np.nanmean(arr)) if np.isfinite(arr).any() else np.nan
        else:
            first = next((x for x in col if x not in (None, "")), col[0])
            out[key] = first
    return out


def _series_or_empty(df: pd.DataFrame, columns: list[str]) -> pd.Series:
    for col in columns:
        if col in df.columns:
            return pd.to_numeric(df[col], errors="coerce")
    return pd.Series(dtype=float)


def _continuity_audit(selected_df_full: pd.DataFrame, selected_df_early: pd.DataFrame, config: PopulationSparsityConfig) -> dict[str, float | int | str]:
    frames_full = selected_df_full["frame"].to_numpy(dtype=int) if "frame" in selected_df_full.columns else np.asarray([], dtype=int)
    frames_early = selected_df_early["frame"].to_numpy(dtype=int) if "frame" in selected_df_early.columns else np.asarray([], dtype=int)
    full_count = int(len(frames_full))
    early_count = int(len(frames_early))
    retained_row_fraction = float(early_count / full_count) if full_count else np.nan
    if full_count >= 2:
        full_span = float(frames_full[-1] - frames_full[0]) * float(config.dt)
    else:
        full_span = np.nan
    if early_count >= 2:
        early_span = float(frames_early[-1] - frames_early[0]) * float(config.dt)
        diffs = np.diff(frames_early)
        largest_gap_frames = int(np.max(diffs)) if diffs.size else 0
    else:
        early_span = np.nan
        largest_gap_frames = 0
        diffs = np.asarray([], dtype=int)
    retained_time_fraction = float(early_span / full_span) if np.isfinite(full_span) and full_span > 0 else np.nan
    large_gap_threshold_frames = int(round((config.window_sec / 2.0) / config.dt))
    n_large_gaps = int(np.sum(diffs > large_gap_threshold_frames)) if diffs.size else 0
    warn = bool(
        (np.isfinite(retained_row_fraction) and retained_row_fraction < 0.7)
        or largest_gap_frames > large_gap_threshold_frames
    )
    return {
        "continuity_retained_row_fraction": retained_row_fraction,
        "continuity_retained_time_fraction": retained_time_fraction,
        "continuity_largest_frame_gap": int(largest_gap_frames),
        "continuity_n_large_gaps": int(n_large_gaps),
        "continuity_warn": int(warn),
    }


def _reward_context_for_session(session_id: str, behav_wd: str) -> dict[str, str]:
    meta_path = Path(behav_wd) / "experiment_metafile.csv"
    if not meta_path.exists():
        return {"reward_config": "", "reward_scheme": ""}
    meta = pd.read_csv(meta_path)
    if "animal" not in meta.columns:
        return {"reward_config": "", "reward_scheme": ""}
    hit = meta.loc[meta["animal"].astype(str) == str(session_id)]
    if hit.empty:
        return {"reward_config": "", "reward_scheme": ""}
    row = hit.iloc[0]
    return {
        "reward_config": str(row.get("reward_config", "") if pd.notna(row.get("reward_config", "")) else ""),
        "reward_scheme": str(row.get("Reward_Scheme", "") if pd.notna(row.get("Reward_Scheme", "")) else ""),
    }


def _prepare_session_bundle(session_id: str, config: PopulationSparsityConfig, ma: Any, level_list: list[np.ndarray]) -> dict[str, Any]:
    tr, selected_df, _, c_raw, c_arr, s_arr, _ = load_behav_neural(
        session_id,
        behav_wd=config.behav_wd,
        neural_wd=config.neural_wd,
    )
    if c_arr is None:
        raise RuntimeError(f"Missing C matrix for {session_id}")
    if s_arr is None:
        raise RuntimeError(f"Missing S matrix for {session_id}")
    selected_df = selected_df.copy().reset_index(drop=True)
    if "mass_bx" not in selected_df.columns or "mass_by" not in selected_df.columns:
        raise ValueError(f"{session_id} selected_df is missing mass_bx/mass_by columns")
    nan_idx = np.where(np.isnan(c_arr.T))[0]
    if nan_idx.size:
        selected_df = selected_df.loc[~selected_df["frame"].isin(nan_idx)].copy().reset_index(drop=True)
    if "level" not in selected_df.columns:
        selected_df["level"] = assign_levels(selected_df, ma.ce, level_list)
    selected_df = selected_df.loc[~pd.isna(selected_df["level"])].copy().reset_index(drop=True)

    frame = selected_df["frame"].to_numpy(dtype=int)
    frame0 = int(frame[0]) if frame.size else 0
    early_limit_frame = frame0 + int(round((config.early_minutes * 60.0) / config.dt))
    early_mask = frame <= early_limit_frame
    selected_df_early = selected_df.loc[early_mask].copy().reset_index(drop=True)
    early_frame = selected_df_early["frame"].to_numpy(dtype=int)

    c_rows_early = c_arr.T[early_frame]
    s_rows_early = s_arr.T[early_frame]
    if {"mass_x", "mass_y"}.issubset(selected_df_early.columns):
        positions_early = selected_df_early[["mass_x", "mass_y"]].to_numpy(dtype=float)
    else:
        positions_early = np.zeros((len(selected_df_early), 2), dtype=float)
    time_seconds_early = early_frame.astype(float) * float(config.dt)
    continuity = _continuity_audit(selected_df, selected_df_early, config)
    reward_context = _reward_context_for_session(session_id, config.behav_wd)

    return {
        "session_id": session_id,
        "tr": tr,
        "selected_df_full": selected_df,
        "selected_df_early": selected_df_early,
        "signals": {"C": np.asarray(c_rows_early, dtype=float), "S": np.asarray(s_rows_early, dtype=float)},
        "positions_early": positions_early,
        "time_seconds_early": time_seconds_early,
        "continuity": continuity,
        "reward_context": reward_context,
        "frame0": frame0,
        "early_limit_frame": early_limit_frame,
        "n_neurons_C": int(c_rows_early.shape[1]),
        "n_neurons_S": int(s_rows_early.shape[1]),
        "n_rows_early": int(len(selected_df_early)),
        "n_rows_full": int(len(selected_df)),
        "c_raw_present": int(c_raw is not None),
        "window_cache": {},
    }


def _signal_rows(bundle: dict[str, Any], signal_source: str) -> np.ndarray:
    signal_source = str(signal_source).upper()
    if signal_source not in bundle["signals"]:
        raise KeyError(f"Unsupported signal_source={signal_source}")
    return np.asarray(bundle["signals"][signal_source], dtype=float)


def _view_bundle(bundle: dict[str, Any], signal_source: str, neuron_ids: np.ndarray | None = None, row_ids: np.ndarray | None = None) -> dict[str, Any]:
    signal = _signal_rows(bundle, signal_source)
    selected_df = bundle["selected_df_early"]
    resolved_row_ids = None if row_ids is None else np.asarray(row_ids, dtype=int)
    resolved_neuron_ids = None if neuron_ids is None else np.asarray(neuron_ids, dtype=int)
    if row_ids is not None:
        selected_df = selected_df.iloc[resolved_row_ids].copy().reset_index(drop=True)
        signal = signal[resolved_row_ids]
    if neuron_ids is not None:
        signal = signal[:, resolved_neuron_ids]
    out = dict(bundle)
    out["selected_df_early"] = selected_df
    out["view_signal"] = signal
    out["view_signal_source"] = str(signal_source).upper()
    out["view_row_ids"] = resolved_row_ids
    out["view_neuron_ids"] = resolved_neuron_ids
    return out


def _occupancy_resample_indices(df_a: pd.DataFrame, df_b: pd.DataFrame, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    bins_a = (df_a["mass_bx"].to_numpy(dtype=int) + 15 * df_a["mass_by"].to_numpy(dtype=int)).astype(int)
    bins_b = (df_b["mass_bx"].to_numpy(dtype=int) + 15 * df_b["mass_by"].to_numpy(dtype=int)).astype(int)
    idx_a: list[int] = []
    idx_b: list[int] = []
    for bin_id in range(225):
        rows_a = np.where(bins_a == bin_id)[0]
        rows_b = np.where(bins_b == bin_id)[0]
        target = min(int(rows_a.size), int(rows_b.size))
        if target <= 0:
            continue
        pick_a = rng.choice(rows_a, size=target, replace=False)
        pick_b = rng.choice(rows_b, size=target, replace=False)
        idx_a.extend(pick_a.tolist())
        idx_b.extend(pick_b.tolist())
    if not idx_a or not idx_b:
        return np.asarray([], dtype=int), np.asarray([], dtype=int)
    return np.sort(np.asarray(idx_a, dtype=int)), np.sort(np.asarray(idx_b, dtype=int))


def _compute_rate_per_min(signal_rows_s: np.ndarray, dt: float) -> np.ndarray:
    duration_min = max(signal_rows_s.shape[0] * float(dt) / 60.0, 1e-9)
    return np.nansum(np.asarray(signal_rows_s, dtype=float), axis=0) / duration_min


def _compute_legacy_filter_keep_mask(bundle: dict[str, Any], signal_source: str, config: PopulationSparsityConfig) -> tuple[np.ndarray, int]:
    signal = _signal_rows(bundle, signal_source)
    if signal.shape[1] == 0 or signal.shape[0] == 0:
        return np.asarray([], dtype=int), 0
    scale = np.nanmax(signal, axis=0)
    scale = np.where(scale > 0, scale, 1.0)
    signal_norm = signal / scale
    frames = bundle["selected_df_early"]["frame"].to_numpy(dtype=int)
    time_seconds = frames.astype(float) * float(config.dt)
    rate_map_results = compute_windowed_rate_maps(
        signal_norm,
        bundle["positions_early"],
        time_seconds,
        n_bins_x=15,
        n_bins_y=15,
        win_len_sec=int(config.window_sec),
        pivot_step_sec=int(config.step_sec),
        sigma=0.0,
        min_occupancy=float(config.min_bin_occupancy_sec),
    )
    keep_mask, _ = apply_quality_filter_with_ratemap(
        signal_norm,
        bundle["positions_early"],
        rate_map_results,
        criteria=config.quality_filter_criteria,
        dt=float(config.dt),
    )
    if keep_mask.size == 0 or int(np.sum(keep_mask)) == 0:
        return np.arange(signal.shape[1], dtype=int), 1
    return np.where(keep_mask)[0].astype(int), 0


def _build_window_cache(
    signal: np.ndarray,
    positions: np.ndarray,
    time_seconds: np.ndarray,
    *,
    window_sec: int,
    step_sec: int,
    config: PopulationSparsityConfig,
) -> dict[str, Any]:
    if signal.size == 0 or positions.size == 0 or time_seconds.size == 0:
        return {
            "mean_rates": np.empty((0, 0), dtype=np.float32),
            "flat_rate_maps": np.empty((0, 0, 0), dtype=np.float32),
            "valid_masks": np.empty((0, 0), dtype=bool),
            "coverage_curve": np.empty((0,), dtype=np.float32),
            "n_windows": 0,
        }
    if float(time_seconds[-1] - time_seconds[0]) < float(window_sec):
        return {
            "mean_rates": np.empty((0, signal.shape[1]), dtype=np.float32),
            "flat_rate_maps": np.empty((0, signal.shape[1], 225), dtype=np.float32),
            "valid_masks": np.empty((0, 225), dtype=bool),
            "coverage_curve": np.empty((0,), dtype=np.float32),
            "n_windows": 0,
        }
    results = compute_windowed_rate_maps(
        signal,
        positions,
        time_seconds,
        n_bins_x=15,
        n_bins_y=15,
        win_len_sec=int(window_sec),
        pivot_step_sec=int(step_sec),
        sigma=0.0,
        min_occupancy=float(config.min_bin_occupancy_sec),
        dtype=np.float32,
    )
    rate_maps = np.asarray(results["rate_maps"], dtype=np.float32)
    valid_masks = np.asarray(results["valid_masks"], dtype=bool)
    n_windows, n_neurons = rate_maps.shape[:2]
    flat_rate_maps = rate_maps.reshape(n_windows, n_neurons, -1)
    valid_flat = valid_masks.reshape(n_windows, -1)
    mean_rates = np.full((n_windows, n_neurons), np.nan, dtype=np.float32)
    coverage_curve = valid_flat.mean(axis=1).astype(np.float32, copy=False) if n_windows else np.empty((0,), dtype=np.float32)
    for idx in range(n_windows):
        valid = valid_flat[idx]
        if not np.any(valid):
            continue
        mean_rates[idx] = np.nanmean(flat_rate_maps[idx][:, valid], axis=1).astype(np.float32, copy=False)
    return {
        "mean_rates": mean_rates,
        "flat_rate_maps": flat_rate_maps,
        "valid_masks": valid_flat,
        "coverage_curve": coverage_curve,
        "n_windows": int(n_windows),
    }


def _window_cache(bundle: dict[str, Any], signal_source: str, window_role: str, config: PopulationSparsityConfig) -> dict[str, Any]:
    signal_key = str(signal_source).upper()
    role_key = str(window_role)
    cache_root = bundle.setdefault("window_cache", {})
    signal_cache = cache_root.setdefault(signal_key, {})
    if role_key in signal_cache:
        return signal_cache[role_key]
    if role_key == PRIMARY_WINDOW_ROLE:
        window_sec = int(config.window_sec)
        step_sec = int(config.step_sec)
    else:
        window_sec = int(config.secondary_window_sec)
        step_sec = int(config.secondary_step_sec)
    cache_value = _build_window_cache(
        _signal_rows(bundle, signal_key),
        np.asarray(bundle["positions_early"], dtype=float),
        np.asarray(bundle["time_seconds_early"], dtype=float),
        window_sec=window_sec,
        step_sec=step_sec,
        config=config,
    )
    signal_cache[role_key] = cache_value
    return cache_value


def _first_n_mean(curve: np.ndarray, n: int) -> tuple[float, int]:
    arr = np.asarray(curve, dtype=float)
    finite = np.isfinite(arr)
    if not finite.any():
        return np.nan, 0
    arr = arr[finite]
    used = min(int(n), int(arr.size))
    if used <= 0:
        return np.nan, 0
    return float(np.nanmean(arr[:used])), int(used)


def _compute_window_metrics(bundle_view: dict[str, Any], window_sec: int, step_sec: int, config: PopulationSparsityConfig) -> dict[str, float]:
    signal = np.asarray(bundle_view["view_signal"], dtype=float)
    df = bundle_view["selected_df_early"]
    if signal.size == 0 or len(df) == 0:
        return {"n_windows": 0.0}
    frames = df["frame"].to_numpy(dtype=int)
    time_seconds = frames.astype(float) * float(config.dt)
    bx = df["mass_bx"].to_numpy(dtype=int)
    by = df["mass_by"].to_numpy(dtype=int)
    bins = bx + 15 * by
    start = float(time_seconds[0])
    end = float(time_seconds[-1])
    if end - start < float(window_sec):
        return {"n_windows": 0.0}
    pivots = np.arange(
        start + float(window_sec) / 2.0,
        end - float(window_sec) / 2.0 + float(step_sec),
        float(step_sec),
        dtype=float,
    )
    curves = {key: [] for key in TIME_METRICS}
    curves["behavior_bin_coverage_frac"] = []
    half = float(window_sec) / 2.0
    for pivot in pivots:
        mask = (time_seconds >= (pivot - half)) & (time_seconds < (pivot + half))
        if int(np.sum(mask)) == 0:
            for key in curves:
                curves[key].append(np.nan)
            continue
        signal_win = signal[mask]
        bins_win = bins[mask]
        occ_counts = np.bincount(bins_win, minlength=225).astype(float)
        occ_sec = occ_counts * float(config.dt)
        valid = occ_sec >= float(config.min_bin_occupancy_sec)
        if int(np.sum(valid)) == 0:
            for key in curves:
                curves[key].append(np.nan)
            continue
        spike_sums = np.zeros((225, signal.shape[1]), dtype=float)
        np.add.at(spike_sums, bins_win, signal_win)
        rate_map = np.divide(
            spike_sums,
            occ_sec[:, None],
            out=np.full((225, signal.shape[1]), np.nan, dtype=float),
            where=occ_sec[:, None] > 0,
        ).T
        mean_rates = np.nanmean(rate_map[:, valid], axis=1)
        curves["activity_frac"].append(float(compute_activity_fraction(mean_rates, threshold=0.1)))
        curves["lifetime_spars"].append(float(compute_lifetime_sparsity(mean_rates)))
        curves["gini"].append(float(compute_gini_coefficient(mean_rates)))
        curves["entropy_norm"].append(float(compute_shannon_entropy(mean_rates)))
        curves["eff_dim"].append(float(compute_effective_dimensionality(rate_map[:, valid])))
        curves["total_rate"].append(float(np.nansum(mean_rates)))
        curves["behavior_bin_coverage_frac"].append(float(np.mean(valid)))
    out: dict[str, float] = {"n_windows": float(len(pivots))}
    for metric, vals in curves.items():
        vals_arr = np.asarray(vals, dtype=float)
        first3, used = _first_n_mean(vals_arr, 3)
        out[f"{metric}_time_first3_window_mean"] = first3
        out[f"{metric}_n_windows_used"] = float(used)
    return out


def _compute_window_metrics_from_cache(
    bundle_view: dict[str, Any],
    *,
    window_role: str,
    config: PopulationSparsityConfig,
) -> dict[str, float]:
    signal_source = str(bundle_view.get("view_signal_source", "C")).upper()
    cache = _window_cache(bundle_view, signal_source, window_role, config)
    n_windows = int(cache["n_windows"])
    neuron_ids = bundle_view.get("view_neuron_ids")
    if n_windows <= 0:
        return {"n_windows": 0.0}
    mean_rates = np.asarray(cache["mean_rates"], dtype=np.float32)
    flat_rate_maps = np.asarray(cache["flat_rate_maps"], dtype=np.float32)
    valid_masks = np.asarray(cache["valid_masks"], dtype=bool)
    coverage_curve = np.asarray(cache["coverage_curve"], dtype=np.float32)
    if neuron_ids is not None:
        mean_rates = mean_rates[:, neuron_ids]
        flat_rate_maps = flat_rate_maps[:, neuron_ids, :]
    curves = {key: [] for key in TIME_METRICS}
    curves["behavior_bin_coverage_frac"] = []
    for idx in range(n_windows):
        mean_rates_win = np.asarray(mean_rates[idx], dtype=float)
        valid_neurons = mean_rates_win[np.isfinite(mean_rates_win)]
        if valid_neurons.size == 0:
            for key in curves:
                curves[key].append(np.nan)
            continue
        curves["activity_frac"].append(float(compute_activity_fraction(valid_neurons, threshold=0.1)))
        curves["lifetime_spars"].append(float(compute_lifetime_sparsity(valid_neurons)))
        curves["gini"].append(float(compute_gini_coefficient(valid_neurons)))
        curves["entropy_norm"].append(float(compute_shannon_entropy(valid_neurons)))
        valid_bins = valid_masks[idx]
        if np.any(valid_bins):
            curves["eff_dim"].append(float(compute_effective_dimensionality(flat_rate_maps[idx, :, valid_bins])))
        else:
            curves["eff_dim"].append(np.nan)
        curves["total_rate"].append(float(np.nansum(valid_neurons)))
        curves["behavior_bin_coverage_frac"].append(float(coverage_curve[idx]) if idx < coverage_curve.size else np.nan)
    out: dict[str, float] = {"n_windows": float(n_windows)}
    for metric, vals in curves.items():
        vals_arr = np.asarray(vals, dtype=float)
        first3, used = _first_n_mean(vals_arr, 3)
        out[f"{metric}_time_first3_window_mean"] = first3
        out[f"{metric}_n_windows_used"] = float(used)
    return out


def _build_level_visit_cache(
    selected_df: pd.DataFrame,
    ma: Any,
    level_list: list[np.ndarray],
    *,
    min_frames_per_visit: int = 5,
    gap_frames: int = 10,
) -> list[list[list[np.ndarray]]]:
    n_frames = len(selected_df)
    bx = selected_df["mass_bx"].to_numpy(dtype=int)
    by = selected_df["mass_by"].to_numpy(dtype=int)
    frame_idx = selected_df["frame"].to_numpy(dtype=int)
    idx_to_coord = {idx: coord for coord, idx in ma.ce.items()}
    cache: list[list[list[np.ndarray]]] = []
    for level_idx in range(len(level_list)):
        level_mask = level_list[level_idx].astype(bool)
        level_coords = [idx_to_coord[idx] for idx in range(len(level_mask)) if level_mask[idx] and idx in idx_to_coord]
        level_coord_set = set(level_coords)
        visited: set[tuple[int, int]] = set()
        clusters: list[list[tuple[int, int]]] = []
        for coord in level_coords:
            if coord in visited:
                continue
            stack = [coord]
            visited.add(coord)
            comp: list[tuple[int, int]] = []
            while stack:
                i, j = stack.pop()
                comp.append((i, j))
                for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    ncoord = (i + di, j + dj)
                    if ncoord in level_coord_set and ncoord not in visited:
                        visited.add(ncoord)
                        stack.append(ncoord)
            clusters.append(comp)
        frame_cluster = np.full(n_frames, -1, dtype=int)
        coord_to_cluster = {coord: ci for ci, comp in enumerate(clusters) for coord in comp}
        for t in range(n_frames):
            frame_cluster[t] = coord_to_cluster.get((int(by[t]), int(bx[t])), -1)
        level_cache: list[list[np.ndarray]] = []
        for ci, _comp in enumerate(clusters):
            rows_in_cluster = np.where(frame_cluster == ci)[0]
            if rows_in_cluster.size == 0:
                level_cache.append([])
                continue
            frames_in_cluster = frame_idx[rows_in_cluster]
            visit_spans: list[tuple[int, int]] = []
            start = int(frames_in_cluster[0])
            prev = int(frames_in_cluster[0])
            for frame_value in frames_in_cluster[1:]:
                frame_int = int(frame_value)
                if frame_int - prev > int(gap_frames):
                    visit_spans.append((start, prev))
                    start = frame_int
                prev = frame_int
            visit_spans.append((start, prev))
            cluster_rows: list[np.ndarray] = []
            for start_frame, end_frame in visit_spans:
                if end_frame < start_frame:
                    continue
                mask = (frames_in_cluster >= start_frame) & (frames_in_cluster <= end_frame)
                rows = rows_in_cluster[mask]
                if rows.size < int(min_frames_per_visit):
                    continue
                cluster_rows.append(np.asarray(rows, dtype=int))
            level_cache.append(cluster_rows)
        cache.append(level_cache)
    return cache


def _level_visit_cache(bundle: dict[str, Any], ma: Any, level_list: list[np.ndarray]) -> list[list[list[np.ndarray]]]:
    cache = bundle.get("level_visit_cache")
    if cache is None:
        cache = _build_level_visit_cache(bundle["selected_df_early"], ma, level_list)
        bundle["level_visit_cache"] = cache
    return cache


def _compute_visit_metrics_from_cache(bundle_view: dict[str, Any], ma: Any, level_list: list[np.ndarray]) -> dict[str, float]:
    signal = np.asarray(bundle_view["view_signal"], dtype=float)
    if signal.size == 0 or signal.shape[1] == 0:
        return {}
    visit_cache = _level_visit_cache(bundle_view, ma, level_list)
    out: dict[str, float] = {}
    metric_curves: dict[str, list[np.ndarray]] = {metric: [] for metric in VISIT_METRICS}
    for level_clusters in visit_cache:
        cluster_metric_rows = {metric: [] for metric in VISIT_METRICS}
        cluster_weights: list[np.ndarray] = []
        cluster_counts: list[int] = []
        for cluster_visits in level_clusters:
            visit_spars: list[float] = []
            visit_gini: list[float] = []
            visit_total: list[float] = []
            visit_entropy: list[float] = []
            visit_weights: list[float] = []
            for rows in cluster_visits:
                seg = signal[rows]
                if seg.size == 0 or not np.isfinite(seg).any():
                    visit_spars.append(np.nan)
                    visit_gini.append(np.nan)
                    visit_total.append(0.0)
                    visit_entropy.append(np.nan)
                    visit_weights.append(float(rows.size))
                    continue
                pv = np.nanmean(seg, axis=0)
                if pv.size == 0 or np.nansum(pv) == 0:
                    visit_spars.append(np.nan)
                    visit_gini.append(np.nan)
                    visit_total.append(0.0)
                    visit_entropy.append(np.nan)
                    visit_weights.append(float(rows.size))
                    continue
                visit_spars.append(float(compute_lifetime_sparsity(pv)))
                visit_gini.append(float(compute_gini_coefficient(pv)))
                visit_total.append(float(np.nansum(pv)))
                visit_entropy.append(float(compute_shannon_entropy(pv)))
                visit_weights.append(float(rows.size))
            cluster_metric_rows["sparsity"].append(np.asarray(visit_spars, dtype=float))
            cluster_metric_rows["gini"].append(np.asarray(visit_gini, dtype=float))
            cluster_metric_rows["total_rate"].append(np.asarray(visit_total, dtype=float))
            cluster_metric_rows["entropy_norm"].append(np.asarray(visit_entropy, dtype=float))
            cluster_weights.append(np.asarray(visit_weights, dtype=float))
            cluster_counts.append(len(visit_spars))
        max_visits = max(cluster_counts, default=0)
        level_metric_curves = {metric: [] for metric in VISIT_METRICS}
        for visit_idx in range(max_visits):
            level_vals = {metric: [] for metric in VISIT_METRICS}
            weights: list[float] = []
            for cluster_idx, count in enumerate(cluster_counts):
                if count <= visit_idx or count < 5:
                    continue
                weights.append(float(cluster_weights[cluster_idx][visit_idx]))
                for metric in VISIT_METRICS:
                    level_vals[metric].append(float(cluster_metric_rows[metric][cluster_idx][visit_idx]))
            if not weights:
                for metric in VISIT_METRICS:
                    level_metric_curves[metric].append(np.nan)
                continue
            weights_arr = np.asarray(weights, dtype=float)
            for metric in VISIT_METRICS:
                level_metric_curves[metric].append(float(np.average(level_vals[metric], weights=weights_arr)))
        for metric in VISIT_METRICS:
            metric_curves[metric].append(np.asarray(level_metric_curves[metric], dtype=float))
    for metric, curves in metric_curves.items():
        max_len = max((len(c) for c in curves), default=0)
        if max_len <= 0:
            out[f"{metric}_visit_first5_mean"] = np.nan
            out[f"{metric}_visit_first10_cap_mean"] = np.nan
            out[f"{metric}_n_valid_visits_used_first5"] = 0.0
            out[f"{metric}_n_valid_visits_used_first10"] = 0.0
            continue
        padded = np.full((len(curves), max_len), np.nan, dtype=float)
        for idx, curve in enumerate(curves):
            if len(curve) > 0:
                padded[idx, : len(curve)] = curve
        agg_curve = np.nanmean(padded, axis=0)
        first5, n5 = _first_n_mean(agg_curve, 5)
        first10, n10 = _first_n_mean(agg_curve, 10)
        out[f"{metric}_visit_first5_mean"] = first5
        out[f"{metric}_visit_first10_cap_mean"] = first10
        out[f"{metric}_n_valid_visits_used_first5"] = float(n5)
        out[f"{metric}_n_valid_visits_used_first10"] = float(n10)
    return out


def _compute_visit_metrics(bundle_view: dict[str, Any], ma: Any, level_list: list[np.ndarray]) -> dict[str, float]:
    signal = np.asarray(bundle_view["view_signal"], dtype=float)
    df = bundle_view["selected_df_early"]
    if signal.size == 0 or len(df) == 0:
        return {}
    metric_curves: dict[str, list[np.ndarray]] = {
        "sparsity": [],
        "gini": [],
        "total_rate": [],
        "entropy_norm": [],
    }
    for level_idx in range(len(level_list)):
        spars, gini, total, entropy, _frac = compute_level_combined(
            level_idx,
            signal,
            df,
            level_list,
            ma,
            min_visits_per_cluster=5,
            min_frames_per_visit=5,
            gap_frames=10,
        )
        metric_curves["sparsity"].append(np.asarray(spars, dtype=float))
        metric_curves["gini"].append(np.asarray(gini, dtype=float))
        metric_curves["total_rate"].append(np.asarray(total, dtype=float))
        metric_curves["entropy_norm"].append(np.asarray(entropy, dtype=float))
    out: dict[str, float] = {}
    for metric, curves in metric_curves.items():
        max_len = max((len(c) for c in curves), default=0)
        if max_len <= 0:
            out[f"{metric}_visit_first5_mean"] = np.nan
            out[f"{metric}_visit_first10_cap_mean"] = np.nan
            out[f"{metric}_n_valid_visits_used_first5"] = 0.0
            out[f"{metric}_n_valid_visits_used_first10"] = 0.0
            continue
        padded = np.full((len(curves), max_len), np.nan, dtype=float)
        for i, curve in enumerate(curves):
            if len(curve) > 0:
                padded[i, : len(curve)] = curve
        agg_curve = np.nanmean(padded, axis=0)
        first5, n5 = _first_n_mean(agg_curve, 5)
        first10, n10 = _first_n_mean(agg_curve, 10)
        out[f"{metric}_visit_first5_mean"] = first5
        out[f"{metric}_visit_first10_cap_mean"] = first10
        out[f"{metric}_n_valid_visits_used_first5"] = float(n5)
        out[f"{metric}_n_valid_visits_used_first10"] = float(n10)
    return out


def _compute_behavior_summary(bundle_view: dict[str, Any], config: PopulationSparsityConfig, ma: Any) -> dict[str, float]:
    df = bundle_view["selected_df_early"]
    out: dict[str, float] = {}
    if len(df) == 0:
        return out
    bins = (df["mass_bx"].to_numpy(dtype=int) + 15 * df["mass_by"].to_numpy(dtype=int)).astype(int)
    counts = np.bincount(bins, minlength=225).astype(float)
    out["behavior_occupancy_entropy"] = float(compute_shannon_entropy(counts))
    out["behavior_bin_coverage_frac"] = float(np.mean(counts > 0))
    speed = _series_or_empty(df, ["speed", "Speed", "velocity", "vel"])
    out["behavior_speed_mean"] = float(np.nanmean(speed.to_numpy(dtype=float))) if len(speed) else np.nan
    out["behavior_speed_median"] = float(np.nanmedian(speed.to_numpy(dtype=float))) if len(speed) else np.nan

    tr = bundle_view.get("tr")
    if tr is None:
        out["endnode_coverage_frac"] = np.nan
        out["endnode_new_node_rate"] = np.nan
        out["endnode_revisit_eff"] = np.nan
        out["endnode_entropy_norm"] = np.nan
        out["endnode_gini"] = np.nan
        return out
    try:
        node_walk, node_frames = extract_explore_node_walk(tr, ma, return_frames=True)
        end_nodes, end_frames = extract_endnode_events(node_walk, node_frames=node_frames)
        if end_nodes.size == 0:
            raise ValueError("no_end_nodes")
        cutoff_frame = int(bundle_view["early_limit_frame"])
        keep = np.asarray(end_frames, dtype=int) <= cutoff_frame
        end_nodes = np.asarray(end_nodes, dtype=int)[keep]
        if end_nodes.size == 0:
            raise ValueError("no_early_end_nodes")
        seen: set[int] = set()
        new_flags = np.zeros(end_nodes.size, dtype=float)
        revisit_flags = np.zeros(end_nodes.size, dtype=float)
        for i, node in enumerate(end_nodes.tolist()):
            node_i = int(node)
            if node_i not in seen:
                new_flags[i] = 1.0
                seen.add(node_i)
            elif i > 0 and node_i != int(end_nodes[i - 1]):
                revisit_flags[i] = 1.0
        counts_end = pd.Series(end_nodes).value_counts().sort_index().to_numpy(dtype=float)
        out["endnode_coverage_frac"] = float(np.unique(end_nodes).size / 32.0)
        out["endnode_new_node_rate"] = float(np.nanmean(new_flags))
        out["endnode_revisit_eff"] = float(np.nanmean(revisit_flags))
        out["endnode_entropy_norm"] = float(compute_shannon_entropy(counts_end))
        out["endnode_gini"] = float(compute_gini_coefficient(counts_end))
    except Exception:
        out["endnode_coverage_frac"] = np.nan
        out["endnode_new_node_rate"] = np.nan
        out["endnode_revisit_eff"] = np.nan
        out["endnode_entropy_norm"] = np.nan
        out["endnode_gini"] = np.nan
    return out


def _summarize_session(bundle_view: dict[str, Any], config: PopulationSparsityConfig, ma: Any, level_list: list[np.ndarray]) -> dict[str, float | int | str]:
    out: dict[str, float | int | str] = {
        "session_id": str(bundle_view["session_id"]),
        "n_rows_used": int(len(bundle_view["selected_df_early"])),
        "n_neurons_used": int(bundle_view["view_signal"].shape[1]),
    }
    out.update(bundle_view["continuity"])
    out.update({f"reward_{k}": v for k, v in bundle_view["reward_context"].items()})
    out.update(_compute_behavior_summary(bundle_view, config, ma))
    if bundle_view.get("view_row_ids") is None:
        primary_time = _compute_window_metrics_from_cache(bundle_view, window_role=PRIMARY_WINDOW_ROLE, config=config)
        smearing_time = _compute_window_metrics_from_cache(bundle_view, window_role=SMEARING_WINDOW_ROLE, config=config)
    else:
        primary_time = _compute_window_metrics(bundle_view, config.window_sec, config.step_sec, config)
        smearing_time = _compute_window_metrics(bundle_view, config.secondary_window_sec, config.secondary_step_sec, config)
    out.update({f"primary_{k}": v for k, v in primary_time.items()})
    out.update({f"smearing_{k}": v for k, v in smearing_time.items()})
    if bundle_view.get("view_row_ids") is None:
        out.update(_compute_visit_metrics_from_cache(bundle_view, ma, level_list))
    else:
        out.update(_compute_visit_metrics(bundle_view, ma, level_list))
    return out


def _summary_cache_key(bundle_view: dict[str, Any]) -> tuple[Any, ...]:
    row_ids = bundle_view.get("view_row_ids")
    neuron_ids = bundle_view.get("view_neuron_ids")
    row_key = None if row_ids is None else row_ids.tobytes()
    neuron_key = None if neuron_ids is None else neuron_ids.tobytes()
    row_len = -1 if row_ids is None else int(row_ids.size)
    neuron_len = -1 if neuron_ids is None else int(neuron_ids.size)
    return (
        str(bundle_view["session_id"]),
        str(bundle_view.get("view_signal_source", "")),
        row_len,
        row_key,
        neuron_len,
        neuron_key,
    )


def _summarize_session_cached(
    bundle_view: dict[str, Any],
    *,
    config: PopulationSparsityConfig,
    ma: Any,
    level_list: list[np.ndarray],
    summary_cache: dict[tuple[Any, ...], dict[str, Any]],
) -> dict[str, Any]:
    cache_key = _summary_cache_key(bundle_view)
    cached = summary_cache.get(cache_key)
    if cached is not None:
        return dict(cached)
    summary = _summarize_session(bundle_view, config, ma, level_list)
    summary_cache[cache_key] = dict(summary)
    return summary


def _paired_rank_biserial(deltas: np.ndarray) -> float:
    deltas = np.asarray(deltas, dtype=float)
    deltas = deltas[np.isfinite(deltas)]
    deltas = deltas[deltas != 0]
    if deltas.size == 0:
        return np.nan
    ranks = stats.rankdata(np.abs(deltas), method="average")
    w_pos = float(np.sum(ranks[deltas > 0]))
    w_neg = float(np.sum(ranks[deltas < 0]))
    denom = w_pos + w_neg
    if denom <= 0:
        return np.nan
    return float((w_pos - w_neg) / denom)


def _bootstrap_ci_median(deltas: np.ndarray, seed: int, n_boot: int = 2000) -> tuple[float, float]:
    arr = np.asarray(deltas, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(int(seed))
    boots = np.empty(int(n_boot), dtype=float)
    for i in range(int(n_boot)):
        sample = rng.choice(arr, size=arr.size, replace=True)
        boots[i] = float(np.nanmedian(sample))
    lo, hi = np.nanpercentile(boots, [2.5, 97.5])
    return float(lo), float(hi)


def _cluster_signflip_pvalue(values: np.ndarray, clusters: np.ndarray) -> float:
    vals = np.asarray(values, dtype=float)
    cls = np.asarray(clusters)
    valid = np.isfinite(vals)
    vals = vals[valid]
    cls = cls[valid]
    if vals.size == 0:
        return np.nan
    uniq = pd.Index(cls).astype(str).unique().tolist()
    arrays = [vals[np.asarray(cls == cluster)] for cluster in uniq]
    if not arrays:
        return np.nan
    obs = float(np.nanmean(np.concatenate(arrays)))
    n_clusters = len(arrays)
    stats_perm: list[float] = []
    if n_clusters <= 16:
        for mask in range(1 << n_clusters):
            signed = []
            for idx, arr in enumerate(arrays):
                sign = -1.0 if ((mask >> idx) & 1) else 1.0
                signed.append(arr * sign)
            stats_perm.append(float(np.nanmean(np.concatenate(signed))))
    else:
        rng = np.random.default_rng(0)
        for _ in range(20000):
            signs = rng.choice(np.asarray([-1.0, 1.0], dtype=float), size=n_clusters, replace=True)
            signed = [arr * sign for arr, sign in zip(arrays, signs)]
            stats_perm.append(float(np.nanmean(np.concatenate(signed))))
    perm = np.asarray(stats_perm, dtype=float)
    return float(np.mean(np.abs(perm) >= abs(obs) - 1e-12))


def _cluster_bootstrap_ci_mean(values: np.ndarray, clusters: np.ndarray, seed: int, n_boot: int = 2000) -> tuple[float, float]:
    vals = np.asarray(values, dtype=float)
    cls = np.asarray(clusters)
    valid = np.isfinite(vals)
    vals = vals[valid]
    cls = cls[valid]
    if vals.size == 0:
        return np.nan, np.nan
    uniq = pd.Index(cls).astype(str).unique().tolist()
    if not uniq:
        return np.nan, np.nan
    cluster_map = {cluster: vals[np.asarray(cls == cluster)] for cluster in uniq}
    rng = np.random.default_rng(int(seed))
    boots = np.empty(int(n_boot), dtype=float)
    for i in range(int(n_boot)):
        sample_clusters = rng.choice(np.asarray(uniq, dtype=object), size=len(uniq), replace=True)
        sample_vals = np.concatenate([cluster_map[str(cluster)] for cluster in sample_clusters])
        boots[i] = float(np.nanmean(sample_vals))
    lo, hi = np.nanpercentile(boots, [2.5, 97.5])
    return float(lo), float(hi)


def _metric_skip_reason(summary_a: dict[str, Any], summary_b: dict[str, Any], metric: str, summary_type: str, window_role: str) -> str:
    if int(summary_a.get("continuity_warn", 0)) and int(summary_a.get("n_rows_used", 0)) == 0:
        return "continuity_failure"
    if int(summary_b.get("continuity_warn", 0)) and int(summary_b.get("n_rows_used", 0)) == 0:
        return "continuity_failure"
    if summary_type == "time_first3_window_mean":
        prefix = "primary_" if window_role == PRIMARY_WINDOW_ROLE else "smearing_"
        n_a = float(summary_a.get(f"{prefix}{metric}_n_windows_used", 0))
        n_b = float(summary_b.get(f"{prefix}{metric}_n_windows_used", 0))
        if min(n_a, n_b) < 1:
            return "insufficient_frames"
    else:
        suffix = "first5" if summary_type == "visit_first5_mean" else "first10"
        n_a = float(summary_a.get(f"{metric}_n_valid_visits_used_{suffix}", 0))
        n_b = float(summary_b.get(f"{metric}_n_valid_visits_used_{suffix}", 0))
        if min(n_a, n_b) < 1:
            return "insufficient_visits"
    return ""


def _summaries_to_contrast_rows(
    animal: str,
    control_branch: str,
    signal_source: str,
    contrast_name: str,
    session_a: str,
    session_b: str,
    summary_a: dict[str, Any],
    summary_b: dict[str, Any],
    *,
    gap_label: str,
    cohort_group: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for metric in TIME_METRICS:
        for window_role, prefix in ((PRIMARY_WINDOW_ROLE, "primary_"), (SMEARING_WINDOW_ROLE, "smearing_")):
            val_a = summary_a.get(f"{prefix}{metric}_time_first3_window_mean", np.nan)
            val_b = summary_b.get(f"{prefix}{metric}_time_first3_window_mean", np.nan)
            skip_reason = _metric_skip_reason(summary_a, summary_b, metric, "time_first3_window_mean", window_role)
            rows.append(
                {
                    "animal": animal,
                    "gap_label": gap_label,
                    "cohort_group": cohort_group,
                    "contrast_name": contrast_name,
                    "session_a": session_a,
                    "session_b": session_b,
                    "control_branch": control_branch,
                    "signal_source": signal_source,
                    "metric": metric,
                    "summary_type": "time_first3_window_mean",
                    "window_role": window_role,
                    "session_a_value": float(val_a) if pd.notna(val_a) else np.nan,
                    "session_b_value": float(val_b) if pd.notna(val_b) else np.nan,
                    "difference": float(val_b - val_a) if pd.notna(val_a) and pd.notna(val_b) else np.nan,
                    "skip_reason": skip_reason,
                }
            )
    for metric in VISIT_METRICS:
        for summary_type, key_suffix in (
            ("visit_first5_mean", "visit_first5_mean"),
            ("visit_first10_cap_mean", "visit_first10_cap_mean"),
        ):
            val_a = summary_a.get(f"{metric}_{key_suffix}", np.nan)
            val_b = summary_b.get(f"{metric}_{key_suffix}", np.nan)
            skip_reason = _metric_skip_reason(summary_a, summary_b, metric, summary_type, "")
            rows.append(
                {
                    "animal": animal,
                    "gap_label": gap_label,
                    "cohort_group": cohort_group,
                    "contrast_name": contrast_name,
                    "session_a": session_a,
                    "session_b": session_b,
                    "control_branch": control_branch,
                    "signal_source": signal_source,
                    "metric": metric,
                    "summary_type": summary_type,
                    "window_role": "",
                    "session_a_value": float(val_a) if pd.notna(val_a) else np.nan,
                    "session_b_value": float(val_b) if pd.notna(val_b) else np.nan,
                    "difference": float(val_b - val_a) if pd.notna(val_a) and pd.notna(val_b) else np.nan,
                    "skip_reason": skip_reason,
                }
            )
    return rows


def _control_branch_applicable(control_branch: str, comparison_type: str) -> bool:
    return control_branch in CONTROL_BRANCH_COMPARISON_TYPES[comparison_type]


def _resolve_branch_views(
    bundle_a: dict[str, Any],
    bundle_b: dict[str, Any],
    control_branch: str,
    signal_source: str,
    config: PopulationSparsityConfig,
    cimap_pairs: tuple[np.ndarray, np.ndarray] | None,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    rng = np.random.default_rng(int(seed))
    repeats = max(int(config.bootstrap_repeats), 1)
    notes: dict[str, Any] = {"filter_fallback_all_neurons": 0, "matching_mode": ""}
    signal_a = _signal_rows(bundle_a, signal_source)
    signal_b = _signal_rows(bundle_b, signal_source)
    n_a = int(signal_a.shape[1])
    n_b = int(signal_b.shape[1])
    base_a = _view_bundle(bundle_a, signal_source)
    base_b = _view_bundle(bundle_b, signal_source)

    if control_branch in ("all_neurons", "quality_filter_off"):
        notes["matching_mode"] = "none"
        return [base_a], [base_b], notes

    if control_branch == "legacy_notebook_filter":
        ids_a, fb_a = _compute_legacy_filter_keep_mask(bundle_a, signal_source, config)
        ids_b, fb_b = _compute_legacy_filter_keep_mask(bundle_b, signal_source, config)
        notes["filter_fallback_all_neurons"] = int(fb_a or fb_b)
        notes["matching_mode"] = "independent_filter"
        return [_view_bundle(bundle_a, signal_source, neuron_ids=ids_a)], [_view_bundle(bundle_b, signal_source, neuron_ids=ids_b)], notes

    if control_branch == "shared_rate_gate":
        rates_a = _compute_rate_per_min(_signal_rows(bundle_a, "S"), config.dt)
        rates_b = _compute_rate_per_min(_signal_rows(bundle_b, "S"), config.dt)
        thr = float(config.shared_rate_gate_events_per_min)
        if cimap_pairs is not None and cimap_pairs[0].size > 0:
            ids_a = cimap_pairs[0]
            ids_b = cimap_pairs[1]
            keep = (rates_a[ids_a] >= thr) & (rates_b[ids_b] >= thr)
            ids_a = ids_a[keep]
            ids_b = ids_b[keep]
            notes["matching_mode"] = "paired_cimap_rate_gate"
            return [_view_bundle(bundle_a, signal_source, neuron_ids=ids_a)], [_view_bundle(bundle_b, signal_source, neuron_ids=ids_b)], notes
        ids_a = np.where(rates_a >= thr)[0].astype(int)
        ids_b = np.where(rates_b >= thr)[0].astype(int)
        notes["matching_mode"] = "independent_rate_gate"
        return [_view_bundle(bundle_a, signal_source, neuron_ids=ids_a)], [_view_bundle(bundle_b, signal_source, neuron_ids=ids_b)], notes

    if control_branch == "matched_count_bootstrap":
        target = min(n_a, n_b)
        if target <= 0:
            return [], [], notes
        notes["matching_mode"] = "count_match"
        views_a = []
        views_b = []
        for _ in range(repeats):
            ids_a = np.sort(rng.choice(np.arange(n_a), size=target, replace=False))
            ids_b = np.sort(rng.choice(np.arange(n_b), size=target, replace=False))
            views_a.append(_view_bundle(bundle_a, signal_source, neuron_ids=ids_a))
            views_b.append(_view_bundle(bundle_b, signal_source, neuron_ids=ids_b))
        return views_a, views_b, notes

    if control_branch == "occupancy_matched":
        notes["matching_mode"] = "none"
        views_a = []
        views_b = []
        for _ in range(repeats):
            rows_a, rows_b = _occupancy_resample_indices(bundle_a["selected_df_early"], bundle_b["selected_df_early"], rng)
            views_a.append(_view_bundle(bundle_a, signal_source, row_ids=rows_a))
            views_b.append(_view_bundle(bundle_b, signal_source, row_ids=rows_b))
        return views_a, views_b, notes

    if control_branch == "matched_count_plus_occupancy_bootstrap":
        target = min(n_a, n_b)
        if target <= 0:
            return [], [], notes
        notes["matching_mode"] = "count_match"
        views_a = []
        views_b = []
        for _ in range(repeats):
            rows_a, rows_b = _occupancy_resample_indices(bundle_a["selected_df_early"], bundle_b["selected_df_early"], rng)
            ids_a = np.sort(rng.choice(np.arange(n_a), size=target, replace=False))
            ids_b = np.sort(rng.choice(np.arange(n_b), size=target, replace=False))
            views_a.append(_view_bundle(bundle_a, signal_source, neuron_ids=ids_a, row_ids=rows_a))
            views_b.append(_view_bundle(bundle_b, signal_source, neuron_ids=ids_b, row_ids=rows_b))
        return views_a, views_b, notes

    if control_branch == "cimap_matched_neurons":
        if cimap_pairs is None or cimap_pairs[0].size == 0:
            return [], [], notes
        notes["matching_mode"] = "cimap_pairs"
        return [_view_bundle(bundle_a, signal_source, neuron_ids=cimap_pairs[0])], [_view_bundle(bundle_b, signal_source, neuron_ids=cimap_pairs[1])], notes

    if control_branch == "cimap_matched_neurons_plus_occupancy":
        if cimap_pairs is None or cimap_pairs[0].size == 0:
            return [], [], notes
        notes["matching_mode"] = "cimap_pairs"
        views_a = []
        views_b = []
        for _ in range(repeats):
            rows_a, rows_b = _occupancy_resample_indices(bundle_a["selected_df_early"], bundle_b["selected_df_early"], rng)
            views_a.append(_view_bundle(bundle_a, signal_source, neuron_ids=cimap_pairs[0], row_ids=rows_a))
            views_b.append(_view_bundle(bundle_b, signal_source, neuron_ids=cimap_pairs[1], row_ids=rows_b))
        return views_a, views_b, notes

    raise ValueError(f"Unsupported control_branch={control_branch}")


def _comparison_type(contrast_name: str) -> str:
    if contrast_name in ("naive_day1_vs_gap_day1", "naive_day2_vs_gap_day2"):
        return "cross_condition_same_day"
    return "within_condition"


def _skip_rows(
    animal: str,
    contrast_name: str,
    session_a: str,
    session_b: str,
    control_branch: str,
    signal_source: str,
    reason: str,
    *,
    gap_label: str,
    cohort_group: str,
) -> list[dict[str, Any]]:
    rows = []
    for metric in TIME_METRICS:
        for window_role in (PRIMARY_WINDOW_ROLE, SMEARING_WINDOW_ROLE):
            rows.append(
                {
                    "animal": animal,
                    "gap_label": gap_label,
                    "cohort_group": cohort_group,
                    "contrast_name": contrast_name,
                    "session_a": session_a,
                    "session_b": session_b,
                    "control_branch": control_branch,
                    "signal_source": signal_source,
                    "metric": metric,
                    "summary_type": "time_first3_window_mean",
                    "window_role": window_role,
                    "session_a_value": np.nan,
                    "session_b_value": np.nan,
                    "difference": np.nan,
                    "skip_reason": reason,
                }
            )
    for metric in VISIT_METRICS:
        for summary_type in ("visit_first5_mean", "visit_first10_cap_mean"):
            rows.append(
                {
                    "animal": animal,
                    "gap_label": gap_label,
                    "cohort_group": cohort_group,
                    "contrast_name": contrast_name,
                    "session_a": session_a,
                    "session_b": session_b,
                    "control_branch": control_branch,
                    "signal_source": signal_source,
                    "metric": metric,
                    "summary_type": summary_type,
                    "window_role": "",
                    "session_a_value": np.nan,
                    "session_b_value": np.nan,
                    "difference": np.nan,
                    "skip_reason": reason,
                }
            )
    return rows


def _evaluate_contrast(
    animal: str,
    gap_label: str,
    cohort_group: str,
    contrast_name: str,
    bundle_a: dict[str, Any],
    bundle_b: dict[str, Any],
    control_branch: str,
    signal_source: str,
    config: PopulationSparsityConfig,
    ma: Any,
    level_list: list[np.ndarray],
    cimap_pairs: tuple[np.ndarray, np.ndarray] | None,
    seed: int,
    summary_cache: dict[tuple[Any, ...], dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    comparison_type = _comparison_type(contrast_name)
    if not _control_branch_applicable(control_branch, comparison_type):
        return _skip_rows(
            animal,
            contrast_name,
            bundle_a["session_id"],
            bundle_b["session_id"],
            control_branch,
            signal_source,
            "branch_not_applicable",
            gap_label=gap_label,
            cohort_group=cohort_group,
        ), []
    if control_branch.startswith("cimap") and (cimap_pairs is None or cimap_pairs[0].size == 0):
        return _skip_rows(
            animal,
            contrast_name,
            bundle_a["session_id"],
            bundle_b["session_id"],
            control_branch,
            signal_source,
            "missing_cimap",
            gap_label=gap_label,
            cohort_group=cohort_group,
        ), []

    views_a, views_b, notes = _resolve_branch_views(
        bundle_a=bundle_a,
        bundle_b=bundle_b,
        control_branch=control_branch,
        signal_source=signal_source,
        config=config,
        cimap_pairs=cimap_pairs,
        seed=seed,
    )
    if not views_a or not views_b:
        return _skip_rows(
            animal,
            contrast_name,
            bundle_a["session_id"],
            bundle_b["session_id"],
            control_branch,
            signal_source,
            "insufficient_neurons",
            gap_label=gap_label,
            cohort_group=cohort_group,
        ), []

    summaries_a = []
    summaries_b = []
    for view_a, view_b in zip(views_a, views_b):
        summaries_a.append(
            _summarize_session_cached(
                view_a,
                config=config,
                ma=ma,
                level_list=level_list,
                summary_cache=summary_cache,
            )
        )
        summaries_b.append(
            _summarize_session_cached(
                view_b,
                config=config,
                ma=ma,
                level_list=level_list,
                summary_cache=summary_cache,
            )
        )
    agg_a = _safe_numeric_mean(summaries_a)
    agg_b = _safe_numeric_mean(summaries_b)
    for agg in (agg_a, agg_b):
        agg["filter_fallback_all_neurons"] = int(notes.get("filter_fallback_all_neurons", 0))
        agg["matching_mode"] = str(notes.get("matching_mode", ""))
        agg["contrast_context"] = contrast_name
        agg["control_branch"] = control_branch
        agg["signal_source"] = signal_source
        agg["animal"] = animal
        agg["gap_label"] = gap_label
        agg["cohort_group"] = cohort_group
    return (
        _summaries_to_contrast_rows(
            animal=animal,
            control_branch=control_branch,
            signal_source=signal_source,
            contrast_name=contrast_name,
            session_a=bundle_a["session_id"],
            session_b=bundle_b["session_id"],
            summary_a=agg_a,
            summary_b=agg_b,
            gap_label=gap_label,
            cohort_group=cohort_group,
        ),
        [agg_a, agg_b],
    )


def _delta_rows_from_contrasts(contrast_df: pd.DataFrame) -> pd.DataFrame:
    if contrast_df.empty:
        return pd.DataFrame()
    rows = []
    group_cols = ["animal", "gap_label", "cohort_group", "metric", "summary_type", "control_branch", "signal_source", "window_role"]
    for key, sub in contrast_df.groupby(group_cols, dropna=False):
        rec = dict(zip(group_cols, key))
        diff_map = {row["contrast_name"]: row["difference"] for _, row in sub.iterrows()}
        for delta_col, contrast_name in DELTA_CONTRAST_MAP.items():
            val = diff_map.get(contrast_name, np.nan)
            rec[delta_col] = float(val) if pd.notna(val) else np.nan
        rec["raw_direction"] = "session_b_minus_session_a"
        rec["memory_aligned_direction"] = "positive_means_more_memory_like"
        rec["sign_convention"] = "memory_aligned = raw * metric_memory_sign"
        rec["metric_memory_sign"] = float(MEMORY_ALIGNMENT_SIGN.get(rec["metric"], np.nan))
        rows.append(rec)
    return pd.DataFrame(rows)


def _cohort_effect_rows(delta_df: pd.DataFrame, seed: int) -> pd.DataFrame:
    if delta_df.empty:
        return pd.DataFrame()
    rows = []
    group_cols = ["gap_label", "cohort_group", "metric", "summary_type", "control_branch", "signal_source", "window_role"]
    for key, sub in delta_df.groupby(group_cols, dropna=False):
        rec_base = dict(zip(group_cols, key))
        sign = float(MEMORY_ALIGNMENT_SIGN.get(str(rec_base["metric"]), 1.0))
        animals_total = int(sub["animal"].nunique())
        for delta_name in DELTA_CONTRAST_MAP:
            vals = pd.to_numeric(sub[delta_name], errors="coerce").to_numpy(dtype=float)
            vals = vals[np.isfinite(vals)]
            if vals.size == 0:
                rows.append({**rec_base, "delta_name": delta_name, "n_animals_total": animals_total, "n_animals_used": 0, "wilcoxon_pvalue": np.nan, "rank_biserial_r": np.nan, "median_delta": np.nan, "median_delta_memory_aligned": np.nan, "bootstrap_ci_low": np.nan, "bootstrap_ci_high": np.nan})
                continue
            try:
                _, p_val = stats.wilcoxon(vals, zero_method="wilcox", alternative="two-sided")
            except ValueError:
                p_val = np.nan
            ci_lo, ci_hi = _bootstrap_ci_median(vals, seed=seed + len(rows))
            rows.append(
                {
                    **rec_base,
                    "delta_name": delta_name,
                    "n_animals_total": animals_total,
                    "n_animals_used": int(vals.size),
                    "wilcoxon_pvalue": float(p_val) if pd.notna(p_val) else np.nan,
                    "rank_biserial_r": float(_paired_rank_biserial(vals)),
                    "median_delta": float(np.nanmedian(vals)),
                    "median_delta_memory_aligned": float(np.nanmedian(vals * sign)),
                    "bootstrap_ci_low": ci_lo,
                    "bootstrap_ci_high": ci_hi,
                }
            )
    return pd.DataFrame(rows)


def interpret_rank_biserial_r(value: float | int | None) -> str:
    if value is None or pd.isna(value):
        return "unavailable"
    value_f = float(value)
    magnitude = abs(value_f)
    if magnitude < 0.1:
        size = "negligible"
    elif magnitude < 0.3:
        size = "small"
    elif magnitude < 0.5:
        size = "medium"
    else:
        size = "large"
    if value_f > 0:
        direction = "positive"
    elif value_f < 0:
        direction = "negative"
    else:
        direction = "neutral"
    return f"{size} {direction}"


def interpret_standardized_effect(value: float | int | None) -> str:
    if value is None or pd.isna(value):
        return "unavailable"
    value_f = float(value)
    magnitude = abs(value_f)
    if magnitude < 0.2:
        size = "negligible"
    elif magnitude < 0.5:
        size = "small"
    elif magnitude < 0.8:
        size = "medium"
    else:
        size = "large"
    if value_f > 0:
        direction = "positive"
    elif value_f < 0:
        direction = "negative"
    else:
        direction = "neutral"
    return f"{size} {direction}"


def summarize_cohort_effects(delta_df: pd.DataFrame, *, seed: int = 0) -> pd.DataFrame:
    out = _cohort_effect_rows(delta_df, seed=seed)
    if out.empty:
        return out
    out["effect_size_interpretation"] = out["rank_biserial_r"].apply(interpret_rank_biserial_r)
    return out


def summarize_repeated_stage_clustered_effects(delta_df: pd.DataFrame, *, seed: int = 0) -> pd.DataFrame:
    if delta_df.empty:
        return pd.DataFrame()
    retained = delta_df.loc[delta_df["cohort_group"].astype(str) == "retained"].copy()
    if retained.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    group_cols = ["metric", "summary_type", "control_branch", "signal_source", "window_role"]
    for key, sub in retained.groupby(group_cols, dropna=False):
        rec_base = dict(zip(group_cols, key))
        sign = float(MEMORY_ALIGNMENT_SIGN.get(str(rec_base["metric"]), 1.0))
        total_animals = int(sub["animal"].nunique())
        for delta_name in DELTA_CONTRAST_MAP:
            vals = pd.to_numeric(sub[delta_name], errors="coerce").to_numpy(dtype=float)
            animals = sub["animal"].astype(str).to_numpy()
            valid = np.isfinite(vals)
            vals_valid = vals[valid]
            animals_valid = animals[valid]
            sub_valid = sub.loc[valid]
            if vals_valid.size == 0:
                rows.append(
                    {
                        **rec_base,
                        "gap_label": "ltm_repeated",
                        "cohort_group": "retained_repeated",
                        "delta_name": delta_name,
                        "n_animals_total": total_animals,
                        "n_animals_used": 0,
                        "n_rows_used": 0,
                        "cluster_signflip_pvalue": np.nan,
                        "mean_delta": np.nan,
                        "mean_delta_memory_aligned": np.nan,
                        "median_delta": np.nan,
                        "median_delta_memory_aligned": np.nan,
                        "cluster_bootstrap_ci_low": np.nan,
                        "cluster_bootstrap_ci_high": np.nan,
                        "cluster_effect_d": np.nan,
                        "cluster_effect_interpretation": "unavailable",
                        "cluster_rank_biserial_animal_mean": np.nan,
                        "animal_stage_labels": "",
                    }
                )
                continue
            ci_lo, ci_hi = _cluster_bootstrap_ci_mean(vals_valid, animals_valid, seed=seed + len(rows))
            animal_means = pd.Series(vals_valid).groupby(pd.Index(animals_valid)).mean().to_numpy(dtype=float)
            if animal_means.size > 1 and np.nanstd(animal_means, ddof=1) > 0:
                cluster_d = float(np.nanmean(animal_means) / np.nanstd(animal_means, ddof=1))
            else:
                cluster_d = np.nan
            rows.append(
                {
                    **rec_base,
                    "gap_label": "ltm_repeated",
                    "cohort_group": "retained_repeated",
                    "delta_name": delta_name,
                    "n_animals_total": total_animals,
                    "n_animals_used": int(pd.Index(animals_valid).nunique()),
                    "n_rows_used": int(vals_valid.size),
                    "cluster_signflip_pvalue": float(_cluster_signflip_pvalue(vals_valid, animals_valid)),
                    "mean_delta": float(np.nanmean(vals_valid)),
                    "mean_delta_memory_aligned": float(np.nanmean(vals_valid * sign)),
                    "median_delta": float(np.nanmedian(vals_valid)),
                    "median_delta_memory_aligned": float(np.nanmedian(vals_valid * sign)),
                    "cluster_bootstrap_ci_low": ci_lo,
                    "cluster_bootstrap_ci_high": ci_hi,
                    "cluster_effect_d": cluster_d,
                    "cluster_effect_interpretation": interpret_standardized_effect(cluster_d),
                    "cluster_rank_biserial_animal_mean": float(_paired_rank_biserial(animal_means)),
                    "animal_stage_labels": ";".join(sorted({f"{animal}|{gap}" for animal, gap in zip(sub_valid["animal"].astype(str), sub_valid["gap_label"].astype(str))})),
                }
            )
    return pd.DataFrame(rows)


def pool_retained_ltm_delta_rows(delta_df: pd.DataFrame, *, aggregate: str = "mean") -> pd.DataFrame:
    if delta_df.empty:
        return pd.DataFrame()
    retained = delta_df.loc[delta_df["cohort_group"].astype(str) == "retained"].copy()
    if retained.empty:
        return pd.DataFrame()

    reducers = {
        "mean": np.nanmean,
        "median": np.nanmedian,
    }
    if aggregate not in reducers:
        raise ValueError(f"Unsupported aggregate='{aggregate}'")
    reducer = reducers[aggregate]

    delta_cols = list(DELTA_CONTRAST_MAP.keys())
    group_cols = ["animal", "metric", "summary_type", "control_branch", "signal_source", "window_role"]
    rows: list[dict[str, Any]] = []

    def _reduce(series: pd.Series) -> tuple[float, int]:
        vals = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
        vals = vals[np.isfinite(vals)]
        if vals.size == 0:
            return np.nan, 0
        return float(reducer(vals)), int(vals.size)

    for key, sub in retained.groupby(group_cols, dropna=False):
        rec = dict(zip(group_cols, key))
        rec["gap_label"] = "ltm_pooled"
        rec["cohort_group"] = "retained_pooled"
        stage_labels = sorted({str(val) for val in sub["gap_label"].dropna().astype(str).tolist()})
        rec["ltm_stage_labels"] = ";".join(stage_labels)
        rec["n_ltm_stages_total"] = int(len(stage_labels))
        for delta_col in delta_cols:
            reduced, n_used = _reduce(sub[delta_col])
            rec[delta_col] = reduced
            rec[f"{delta_col}_n_stages_used"] = int(n_used)
        rec["raw_direction"] = "session_b_minus_session_a"
        rec["memory_aligned_direction"] = "positive_means_more_memory_like"
        rec["sign_convention"] = "memory_aligned = raw * metric_memory_sign"
        rec["metric_memory_sign"] = float(MEMORY_ALIGNMENT_SIGN.get(rec["metric"], np.nan))
        rows.append(rec)
    return pd.DataFrame(rows)


def _alignment_row(spec: QuartetSpec, loaded: dict[str, dict[str, Any]], errors: dict[str, str]) -> dict[str, Any]:
    requested_sessions = [sid for sid in (spec.naive_day1, spec.naive_day2, spec.gap_day1, spec.gap_day2) if str(sid).strip()]
    included = [sid for sid in requested_sessions if sid in loaded]
    excluded = [sid for sid in requested_sessions if sid in errors]
    report = AlignmentReport(
        session_matching_source="load_behav_neural + explicit quartet session ids",
        included_sessions=included,
        excluded_sessions=excluded,
        timebase="absolute",
        continuity_assumptions="selected_df is speed-thresholded, may be discontinuous, and is hard-cut to first 60 minutes for primary summaries",
    )
    validate_alignment(report)
    return {
        "animal": spec.animal,
        "gap_label": spec.gap_label,
        "cohort_group": spec.cohort_group,
        "session_matching_source": report.session_matching_source,
        "included_sessions": ";".join(included),
        "excluded_sessions": ";".join(excluded),
        "timebase": report.timebase,
        "continuity_assumptions": report.continuity_assumptions,
        "reward_context_note": spec.reward_context_note,
        "errors": ";".join(f"{k}:{v}" for k, v in errors.items()),
    }


def run_memory_gradient_population_sparsity(
    quartets: list[QuartetSpec],
    *,
    config: PopulationSparsityConfig | None = None,
    signal_sources: tuple[str, ...] = ("C", "S"),
    control_branches: tuple[str, ...] | None = None,
) -> dict[str, pd.DataFrame]:
    cfg = (config or PopulationSparsityConfig()).with_defaults()
    ma = NewMaze(int(cfg.maze_id))
    level_list = generate_level_list(ma.ce, grid_size=15)
    branches = tuple(control_branches or CONTROL_BRANCHES)
    session_rows: list[dict[str, Any]] = []
    contrast_rows: list[dict[str, Any]] = []
    alignment_rows: list[dict[str, Any]] = []
    summary_cache: dict[tuple[Any, ...], dict[str, Any]] = {}

    for spec_idx, spec in enumerate(quartets):
        loaded: dict[str, dict[str, Any]] = {}
        errors: dict[str, str] = {}
        requested_sessions = [sid for sid in (spec.naive_day1, spec.naive_day2, spec.gap_day1, spec.gap_day2) if str(sid).strip()]
        for session_id in requested_sessions:
            try:
                loaded[session_id] = _prepare_session_bundle(session_id, cfg, ma, level_list)
            except Exception as exc:
                errors[session_id] = str(exc)
        alignment_rows.append(_alignment_row(spec, loaded, errors))
        required_sessions = [spec.naive_day1, spec.naive_day2]
        if spec.gap_day1 and spec.gap_day2:
            required_sessions.extend([spec.gap_day1, spec.gap_day2])
        if any(session_id not in loaded for session_id in required_sessions):
            continue
        try:
            cimap_pairs = load_cimap_pairs(
                spec.cimap_path_gap,
                compose=isinstance(spec.cimap_path_gap, (list, tuple)),
            )
        except Exception:
            cimap_pairs = (np.asarray([], dtype=int), np.asarray([], dtype=int))
        contrast_defs = []
        if spec.include_naive_within:
            contrast_defs.append(("naive_day1_vs_naive_day2", spec.naive_day1, spec.naive_day2, None))
        if spec.gap_day1 and spec.gap_day2:
            contrast_defs.extend(
                [
                    ("gap_day1_vs_gap_day2", spec.gap_day1, spec.gap_day2, None),
                    ("naive_day1_vs_gap_day1", spec.naive_day1, spec.gap_day1, cimap_pairs),
                    ("naive_day2_vs_gap_day2", spec.naive_day2, spec.gap_day2, cimap_pairs),
                ]
            )
        for signal_idx, signal_source in enumerate(signal_sources):
            for contrast_idx, (contrast_name, sess_a, sess_b, maybe_pairs) in enumerate(contrast_defs):
                for branch_idx, control_branch in enumerate(branches):
                    rows, sess_rows = _evaluate_contrast(
                        animal=spec.animal,
                        gap_label=spec.gap_label,
                        cohort_group=spec.cohort_group,
                        contrast_name=contrast_name,
                        bundle_a=loaded[sess_a],
                        bundle_b=loaded[sess_b],
                        control_branch=control_branch,
                        signal_source=signal_source,
                        config=cfg,
                        ma=ma,
                        level_list=level_list,
                        cimap_pairs=maybe_pairs,
                        seed=1000 * spec_idx + 100 * signal_idx + 10 * contrast_idx + branch_idx,
                        summary_cache=summary_cache,
                    )
                    contrast_rows.extend(rows)
                    session_rows.extend(sess_rows)

    session_df = pd.DataFrame(session_rows)
    if not session_df.empty:
        session_df = session_df.drop_duplicates(
            subset=["animal", "gap_label", "cohort_group", "session_id", "contrast_context", "control_branch", "signal_source"],
            keep="last",
        )
    contrast_df = pd.DataFrame(contrast_rows)
    delta_df = _delta_rows_from_contrasts(contrast_df)
    cohort_df = summarize_cohort_effects(delta_df, seed=0)
    alignment_df = pd.DataFrame(alignment_rows)
    return {
        "quartet_session_summary": session_df,
        "quartet_contrast_summary": contrast_df,
        "quartet_delta_summary": delta_df,
        "cohort_effects": cohort_df,
        "alignment_report": alignment_df,
    }


def export_memory_gradient_results(results: dict[str, pd.DataFrame], out_dir: str | Path) -> dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, str] = {}
    for key, df in results.items():
        csv_path = out_path / f"{key}.csv"
        df.to_csv(csv_path, index=False)
        manifest[key] = str(csv_path)
    return manifest


def merge_exported_memory_gradient_results(result_dirs: list[str | Path], *, seed: int = 0) -> dict[str, pd.DataFrame]:
    required = (
        "quartet_session_summary",
        "quartet_contrast_summary",
        "quartet_delta_summary",
        "alignment_report",
    )
    frames: dict[str, list[pd.DataFrame]] = {key: [] for key in required}

    for result_dir in [Path(path) for path in result_dirs]:
        for key in required:
            csv_path = result_dir / f"{key}.csv"
            if not csv_path.exists():
                raise FileNotFoundError(f"Missing required result file: {csv_path}")
            frames[key].append(pd.read_csv(csv_path))

    def _merge(key: str, subset: list[str] | None = None) -> pd.DataFrame:
        source_frames = frames[key]
        if not source_frames:
            return pd.DataFrame()
        ordered_cols: list[str] = []
        for df in source_frames:
            for col in df.columns:
                if col not in ordered_cols:
                    ordered_cols.append(col)
        merged = pd.concat([df.reindex(columns=ordered_cols) for df in source_frames], ignore_index=True, sort=False)
        if subset:
            valid_subset = [col for col in subset if col in merged.columns]
            if valid_subset:
                merged = merged.drop_duplicates(subset=valid_subset, keep="last").reset_index(drop=True)
                return merged
        return merged.drop_duplicates().reset_index(drop=True)

    session_df = _merge(
        "quartet_session_summary",
        subset=["animal", "gap_label", "cohort_group", "session_id", "control_branch", "signal_source"],
    )
    contrast_df = _merge(
        "quartet_contrast_summary",
        subset=[
            "animal",
            "gap_label",
            "cohort_group",
            "contrast_name",
            "session_a",
            "session_b",
            "control_branch",
            "signal_source",
            "metric",
            "summary_type",
            "window_role",
        ],
    )
    delta_df = _merge(
        "quartet_delta_summary",
        subset=[
            "animal",
            "gap_label",
            "cohort_group",
            "metric",
            "summary_type",
            "control_branch",
            "signal_source",
            "window_role",
        ],
    )
    alignment_df = _merge(
        "alignment_report",
        subset=["animal", "gap_label", "cohort_group", "included_sessions", "excluded_sessions"],
    )
    cohort_df = summarize_cohort_effects(delta_df, seed=seed)
    return {
        "quartet_session_summary": session_df,
        "quartet_contrast_summary": contrast_df,
        "quartet_delta_summary": delta_df,
        "cohort_effects": cohort_df,
        "alignment_report": alignment_df,
    }


__all__ = [
    "CONTROL_BRANCHES",
    "SUMMARY_TYPES",
    "SKIP_REASONS",
    "QuartetSpec",
    "PopulationSparsityConfig",
    "default_quartet_specs",
    "default_expanded_cohort_specs",
    "load_cimap_pairs",
    "interpret_rank_biserial_r",
    "interpret_standardized_effect",
    "summarize_cohort_effects",
    "summarize_repeated_stage_clustered_effects",
    "pool_retained_ltm_delta_rows",
    "run_memory_gradient_population_sparsity",
    "export_memory_gradient_results",
    "merge_exported_memory_gradient_results",
]
