"""Ordered-loss helpers for the rapid-learning depth-code rescue."""

from __future__ import annotations

from itertools import product

import numpy as np


def normalized_absolute_depth_error(
    true_depth: np.ndarray,
    predicted_depth: np.ndarray,
    *,
    depth_min: float | None = None,
    depth_max: float | None = None,
) -> np.ndarray:
    """Return absolute depth error normalized by the supported depth span."""

    true = np.asarray(true_depth, dtype=float)
    predicted = np.asarray(predicted_depth, dtype=float)
    if true.shape != predicted.shape:
        raise ValueError("true_depth and predicted_depth must have the same shape")
    finite = np.isfinite(true) & np.isfinite(predicted)
    if not np.any(finite):
        return np.full(true.shape, np.nan, dtype=float)
    lo = float(np.nanmin(true[finite])) if depth_min is None else float(depth_min)
    hi = float(np.nanmax(true[finite])) if depth_max is None else float(depth_max)
    span = hi - lo
    if not np.isfinite(span) or span <= 0:
        raise ValueError("supported depths must span at least two ordered levels")
    result = np.full(true.shape, np.nan, dtype=float)
    result[finite] = np.abs(predicted[finite] - true[finite]) / span
    return result


def exact_sign_flip_pvalue(
    values: np.ndarray, *, alternative: str = "greater"
) -> float:
    """Return an exact animal-level sign-flip p-value for small samples."""

    sample = np.asarray(values, dtype=float)
    sample = sample[np.isfinite(sample)]
    if sample.size == 0:
        return np.nan
    observed = float(np.mean(sample))
    null = np.asarray(
        [
            np.mean(sample * np.asarray(signs, dtype=float))
            for signs in product((-1, 1), repeat=sample.size)
        ],
        dtype=float,
    )
    if alternative == "greater":
        return float(np.mean(null >= observed - np.finfo(float).eps))
    if alternative == "less":
        return float(np.mean(null <= observed + np.finfo(float).eps))
    if alternative == "two-sided":
        return float(np.mean(np.abs(null) >= abs(observed) - np.finfo(float).eps))
    raise ValueError("alternative must be greater, less, or two-sided")


def stratified_bootstrap_mean(
    values: np.ndarray,
    strata: np.ndarray,
    *,
    n_bootstrap: int,
    seed: int,
) -> tuple[float, float]:
    """Bootstrap animals within context strata and return a percentile CI."""

    sample = np.asarray(values, dtype=float)
    groups = np.asarray(strata, dtype=str)
    keep = np.isfinite(sample)
    sample = sample[keep]
    groups = groups[keep]
    if sample.size == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    draws = np.empty(int(n_bootstrap), dtype=float)
    unique = np.unique(groups)
    for index in range(draws.size):
        selected = []
        for group in unique:
            values_in_group = sample[groups == group]
            selected.extend(
                rng.choice(values_in_group, size=values_in_group.size, replace=True)
            )
        draws[index] = float(np.mean(selected))
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))
