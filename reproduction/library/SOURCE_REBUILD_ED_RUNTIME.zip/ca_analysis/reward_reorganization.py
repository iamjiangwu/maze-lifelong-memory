from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import json
import re
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import optimize, stats
from scipy.special import expit as _expit

from .behavior import default_behavior_groups_260113
from .config import FPS, N_BINS_X, N_BINS_Y, REWARD_NODE, get_behav_wd, get_neural_wd
from .decoding import evaluate_decoding_errors, pair_shuffle_null, poisson_decode_train_test
from .exploration import _extract_reward_event_frames
from .io import load_behav_neural
from .maze import HomePath, NewMaze
from .population_sparsity_controls import load_cimap_pairs
from .glm import fit_mixedlm_statsmodels
from .similarity import (
    compute_spatial_info_matched,
    compute_spatial_info_session_rategated,
    cross_session_pv_correlation,
    within_session_pv_temporal_similarity,
)
from .spatial import (
    _build_bin_to_ma_cell,
    build_session_pack,
    compute_binwise_shuffle_pmap,
    compute_rate_maps_for_neurons,
    extract_fields_from_sigmask,
    match_fields_hungarian,
)


_ANIMAL_RE = re.compile(r"^(\d+)")

HIPPOCAMPAL_REWARDED_DAY1_CONFIRMATORY = [
    "1616day1",
    "163RLday1",
    "1632Lday1",
    "418RRday1",
    "434RRday1",
    "451Rday1",
    "488Rday1",
    "489Lday1",
    "579RLday1",
    "468Lday1",
]

HIPPOCAMPAL_REWARDED_DAY1_EXPLORATORY = ["1603", "202Lday1"]
HIPPOCAMPAL_REWARDED_DAY2 = [session.replace("day1", "day2") for session in HIPPOCAMPAL_REWARDED_DAY1_CONFIRMATORY]

DRY_WATERPORT_DAY1 = ["1639RRday1", "347RLday1", "422RRday1", "1637Lday1"]
DRY_WATERPORT_DAY2 = ["1639RRday2", "347RLday2", "422RRday2", "1637Lday2"]

TRAINING_BASELINES = {
    "418": ("418RRday1", "418RRday2"),
    "434": ("434RRday1", "434RRday2"),
    "451": ("451Rday1", "451Rday2"),
    "488": ("488Rday1", "488Rday2"),
    "489": ("489Lday1", "489Lday2"),
    "579": ("579RLday1", "579RLday2"),
    "468": ("468Lday1", "468Lday2"),
    "422": ("422RRday1", "422RRday2"),
    "1616": ("1616day1", "1616day2"),
}

LTM_SESSIONS_EXPLICIT = {
    "3mo": {
        "month_value": 3.0,
        "d1": [
            {"session": "418-3day1", "animal": "418"},
            {"session": "434-3day1", "animal": "434"},
            {"session": "451-3day1", "animal": "451"},
            {"session": "488-3day1", "animal": "488"},
            {"session": "489-3day1", "animal": "489"},
            {"session": "579-3day1", "animal": "579"},
            {"session": "468-3day1", "animal": "468"},
            {"session": "422-3day1", "animal": "422"},
            {"session": "1616bday1", "animal": "1616"},
        ],
    },
    "6mo": {
        "month_value": 6.0,
        "d1": [
            {"session": "418-6day1", "animal": "418"},
            {"session": "451-6day1", "animal": "451"},
            {"session": "488-6day1", "animal": "488"},
            {"session": "489-6day1", "animal": "489"},
            {"session": "468-6day1", "animal": "468"},
            {"session": "422-6day1", "animal": "422"},
            {"session": "1616b-3day1", "animal": "1616"},
        ],
    },
    "9mo": {
        "month_value": 9.0,
        "d1": [
            {"session": "418-9day1", "animal": "418"},
            {"session": "451-9day1", "animal": "451"},
            {"session": "468-9day1", "animal": "468"},
        ],
    },
    "12mo": {
        "month_value": 12.0,
        "d1": [
            {"session": "468-12day1", "animal": "468"},
        ],
    },
}

LTM_EXCLUSIONS = {
    "434-6day1",
    "488-9day1",
    "579-6day1",
    "579-9day1",
    "418-12day1",
    "451-12day1",
}

LTM_DIRECT_CIMAPS = {
    "418-3day1": ("418", "cell_to_index_map_03.mat"),
    "434-3day1": ("434", "cell_to_index_map_03.mat"),
    "451-3day1": ("451", "cell_to_index_map_03.mat"),
    "488-3day1": ("488", "cell_to_index_map_03.mat"),
    "489-3day1": ("489", "cell_to_index_map_03.mat"),
    "579-3day1": ("579", "cell_to_index_map_03.mat"),
    "468-3day1": ("468", "cell_to_index_map_03.mat"),
    "422-3day1": ("422", "cell_to_index_map_03.mat"),
    "1616bday1": ("1616", "cell_to_index_map_01.mat"),
    "418-6day1": ("418", "cell_to_index_map_06.mat"),
    "451-6day1": ("451", "cell_to_index_map_06.mat"),
    "488-6day1": ("488", "cell_to_index_map_06.mat"),
    "489-6day1": ("489", "cell_to_index_map_06.mat"),
    "468-6day1": ("468", "cell_to_index_map_06.mat"),
    "422-6day1": ("422", "cell_to_index_map_06.mat"),
    "1616b-3day1": ("1616", "cell_to_index_map_03.mat"),
}

LTM_CHAINED_CIMAPS = {
    "418-9day1": [("418", "cell_to_index_map_06.mat"), ("418", "cell_to_index_map_69.mat")],
    "451-9day1": [("451", "cell_to_index_map_06.mat"), ("451", "cell_to_index_map_69.mat")],
    "468-9day1": [("468", "cell_to_index_map_06.mat"), ("468", "cell_to_index_map_69.mat")],
    "468-12day1": [
        ("468", "cell_to_index_map_06.mat"),
        ("468", "cell_to_index_map_69.mat"),
        ("468", "cell_to_index_map_912.mat"),
    ],
}

SMOKE_LEVEL_SESSIONS = {
    "1": ["451Rday1", "418RRday1"],
    "2": ["769day1", "838day1", "451Rday1", "418RRday1"],
    "3": ["451-3day1", "418-3day1", "468-3day1"],
    "5": ["451-3day1", "468-3day1"],
    "6": ["451-3day1", "418-3day1"],
}

CHEMOU_CONTROL_ANIMALS = {"769", "838", "837", "839", "841", "842", "862"}
OCCUPANCY_SENSITIVITY = (25, 50, 75, 100)
STABLE_NEURON_THRESHOLDS = (0.3, 0.4, 0.5)
DEFAULT_PSEUDO_REWARD_COUNT = 5
EXCLUSION_COLUMNS = ["level_label", "session_id", "related_session", "reason"]


@dataclass
class RewardReorganizationConfig:
    behav_wd: str = field(default_factory=get_behav_wd)
    neural_wd: str = field(default_factory=get_neural_wd)
    n_bins_x: int = N_BINS_X
    n_bins_y: int = N_BINS_Y
    reward_node: int = REWARD_NODE
    reward_near_threshold: float = 3.0
    window_sec: float = 180.0
    step_sec: float = 60.0
    n_sham: int = 200
    seed: int = 42
    min_occupancy: int = 25
    min_neurons: int = 5
    min_matched_neurons: int = 10
    field_shuffles: int = 100


def animal_id(session_id: str) -> str:
    match = _ANIMAL_RE.match(str(session_id))
    return match.group(1) if match else str(session_id)


def _load_session_bundle(
    session_id: str,
    *,
    config: RewardReorganizationConfig,
) -> dict[str, Any]:
    tr, selected_df, nose_interp_df, c_raw, c, s, cn = load_behav_neural(
        session_id,
        behav_wd=config.behav_wd,
        neural_wd=config.neural_wd,
    )
    if s is None:
        raise ValueError(f"Session {session_id} has no neural spike matrix S.")
    if "mass_bx" not in selected_df.columns or "mass_by" not in selected_df.columns:
        raise ValueError(f"Session {session_id} is missing precomputed mass_bx/mass_by columns.")
    pack = build_session_pack(
        selected_df,
        s,
        n_bins_x=config.n_bins_x,
        n_bins_y=config.n_bins_y,
        bin_col_x="mass_bx",
        bin_col_y="mass_by",
    )
    return {
        "session_id": session_id,
        "tr": tr,
        "selected_df": selected_df,
        "nose_interp_df": nose_interp_df,
        "c_raw": c_raw,
        "c": c,
        "s": s,
        "cn": cn,
        "pack": pack,
    }


def _record_exclusion(exclusions: list[dict[str, Any]], *, level_label: str, session_id: str, reason: str, related_session: str | None = None) -> None:
    exclusions.append(
        {
            "level_label": level_label,
            "session_id": session_id,
            "related_session": related_session,
            "reason": reason,
        }
    )


def _exclusion_frame(exclusions: list[dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(exclusions, columns=EXCLUSION_COLUMNS)


def _resolve_training_to_ltm_cimap(ltm_session_id: str) -> tuple[np.ndarray, np.ndarray]:
    from .config import get_cimap_path

    if ltm_session_id in LTM_DIRECT_CIMAPS:
        animal, filename = LTM_DIRECT_CIMAPS[ltm_session_id]
        return load_cimap_pairs(get_cimap_path(animal=animal, filename=filename))
    if ltm_session_id in LTM_CHAINED_CIMAPS:
        paths = [get_cimap_path(animal=animal, filename=filename) for animal, filename in LTM_CHAINED_CIMAPS[ltm_session_id]]
        return load_cimap_pairs(paths, compose=True)
    raise KeyError(f"No CIMap registry entry for {ltm_session_id}")


def _subset_pack(pack: dict[str, Any], row_mask: np.ndarray) -> dict[str, Any]:
    row_mask = np.asarray(row_mask, dtype=bool)
    df_sub = pack["df"].loc[row_mask].reset_index(drop=True)
    s_sub = np.asarray(pack["S"], dtype=float)[row_mask]
    return build_session_pack(
        df_sub,
        s_sub,
        n_bins_x=int(pack["n_bins_x"]),
        n_bins_y=int(pack["n_bins_y"]),
        bin_col_x="mass_bx",
        bin_col_y="mass_by",
    )


def _reference_maps_from_pack(pack: dict[str, Any], neuron_ids: np.ndarray, *, second_half_only: bool = False) -> np.ndarray:
    use_pack = pack
    if second_half_only and len(pack["df"]) >= 2:
        midpoint = int(len(pack["df"]) // 2)
        row_mask = np.zeros(len(pack["df"]), dtype=bool)
        row_mask[midpoint:] = True
        if np.sum(row_mask) >= 5:
            use_pack = _subset_pack(pack, row_mask)
    return compute_rate_maps_for_neurons(use_pack, neuron_ids=neuron_ids).T


def _selected_duration_sec(pack: dict[str, Any]) -> float:
    return float(np.asarray(pack["S"]).shape[0] / FPS)


def _distance_quartile_info(distance_flat: np.ndarray, *, n_distance_quartiles: int = 4) -> dict[str, np.ndarray]:
    distance_flat = np.asarray(distance_flat, dtype=float).ravel()
    valid = np.isfinite(distance_flat)
    if not np.any(valid):
        raise ValueError("distance_flat has no finite entries.")
    edges = np.nanquantile(distance_flat[valid], np.linspace(0.0, 1.0, n_distance_quartiles + 1))
    labels = np.full(distance_flat.shape, np.nan, dtype=float)
    for q in range(n_distance_quartiles):
        upper = edges[q + 1]
        mask = valid & (distance_flat >= edges[q]) & (
            distance_flat <= upper if q == n_distance_quartiles - 1 else distance_flat < upper
        )
        labels[mask] = float(q + 1)
    return {"edges": edges, "quartile_labels": labels}


def _window_bin_occupancy_sec(
    pivot_bounds: np.ndarray,
    bin_labels: np.ndarray,
    n_bins: int,
    *,
    dt_sec: float,
    bound_index: int = 1,
) -> np.ndarray:
    bounds = np.asarray(pivot_bounds, dtype=int)
    labels = np.asarray(bin_labels, dtype=int).ravel()
    out = np.zeros((bounds.shape[0], int(n_bins)), dtype=float)
    for pivot_idx in range(bounds.shape[0]):
        start = int(bounds[pivot_idx, bound_index, 0])
        stop = int(bounds[pivot_idx, bound_index, 1])
        if stop <= start:
            continue
        cur = labels[start:stop]
        if cur.size == 0:
            continue
        counts = np.bincount(cur, minlength=int(n_bins)).astype(float)
        out[pivot_idx, :] = counts * float(dt_sec)
    return out


def _map_vector_stats(maps: np.ndarray) -> dict[str, np.ndarray]:
    maps = np.asarray(maps, dtype=float)
    mean = np.full(maps.shape[0], np.nan, dtype=float)
    std = np.full(maps.shape[0], np.nan, dtype=float)
    nfinite = np.sum(np.isfinite(maps), axis=1).astype(int)
    for idx in range(maps.shape[0]):
        row = maps[idx]
        keep = np.isfinite(row)
        if not np.any(keep):
            continue
        mean[idx] = float(np.mean(row[keep]))
        std[idx] = float(np.std(row[keep]))
    return {"mean": mean, "std": std, "nfinite": nfinite}


def _build_temporal_audit_tables(
    *,
    evo: dict[str, Any],
    distance_flat: np.ndarray,
    bin_labels: np.ndarray,
    session_fields: dict[str, Any],
    time_column: str,
    event_sec: float | None = None,
    dt_sec: float = 1.0 / FPS,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    sim_per_bin = np.asarray(evo["sim_per_bin"], dtype=float)
    pivot_times = np.asarray(evo["pivot_times"], dtype=float)
    pivot_bounds = np.asarray(evo["pivot_bounds"], dtype=int)
    distance_flat = np.asarray(distance_flat, dtype=float).ravel()
    quartile_info = _distance_quartile_info(distance_flat)
    quartile_labels = quartile_info["quartile_labels"]
    occ_sec = _window_bin_occupancy_sec(
        pivot_bounds,
        bin_labels,
        distance_flat.size,
        dt_sec=dt_sec,
        bound_index=1,
    )
    window_vector_mean = np.asarray(evo.get("window_vector_mean"), dtype=float) if "window_vector_mean" in evo else None
    window_vector_std = np.asarray(evo.get("window_vector_std"), dtype=float) if "window_vector_std" in evo else None
    window_vector_nfinite = np.asarray(evo.get("window_vector_nfinite"), dtype=float) if "window_vector_nfinite" in evo else None
    reference_vector_mean = np.asarray(evo.get("reference_vector_mean"), dtype=float) if "reference_vector_mean" in evo else None
    reference_vector_std = np.asarray(evo.get("reference_vector_std"), dtype=float) if "reference_vector_std" in evo else None
    reference_vector_nfinite = np.asarray(evo.get("reference_vector_nfinite"), dtype=float) if "reference_vector_nfinite" in evo else None

    bin_rows: list[dict[str, Any]] = []
    window_rows: list[dict[str, Any]] = []
    for pivot_idx, pivot_sec in enumerate(pivot_times):
        time_value = float((pivot_sec - event_sec) / 60.0) if event_sec is not None else float(pivot_sec / 60.0)
        common = dict(session_fields)
        common["pivot_index"] = int(pivot_idx)
        common[time_column] = time_value

        sim_row = sim_per_bin[pivot_idx]
        finite_mask = np.isfinite(sim_row)
        q_summary: dict[int, dict[str, float]] = {}
        for q in range(1, 5):
            q_mask = quartile_labels == float(q)
            q_valid = q_mask & finite_mask
            q_summary[q] = {
                "mean_pv": float(np.nanmean(sim_row[q_mask])) if np.any(np.isfinite(sim_row[q_mask])) else np.nan,
                "nfinite": int(np.sum(q_valid)),
                "mean_occ_sec": float(np.nanmean(occ_sec[pivot_idx, q_mask])) if np.any(q_mask) else np.nan,
                "mean_window_std": float(np.nanmean(window_vector_std[pivot_idx, q_mask])) if window_vector_std is not None and np.any(np.isfinite(window_vector_std[pivot_idx, q_mask])) else np.nan,
            }
        window_rows.append(
            {
                **common,
                "n_finite_bins": int(np.sum(finite_mask)),
                "fraction_bins_finite": float(np.mean(finite_mask)) if finite_mask.size else np.nan,
                "mean_pv_similarity": float(np.nanmean(sim_row)) if np.any(finite_mask) else np.nan,
                "mean_window_vector_std": float(np.nanmean(window_vector_std[pivot_idx])) if window_vector_std is not None and np.any(np.isfinite(window_vector_std[pivot_idx])) else np.nan,
                "q1_mean_pv_similarity": q_summary[1]["mean_pv"],
                "q4_mean_pv_similarity": q_summary[4]["mean_pv"],
                "q1_nfinite_bins": q_summary[1]["nfinite"],
                "q4_nfinite_bins": q_summary[4]["nfinite"],
                "q1_mean_occ_sec": q_summary[1]["mean_occ_sec"],
                "q4_mean_occ_sec": q_summary[4]["mean_occ_sec"],
                "q1_mean_window_vector_std": q_summary[1]["mean_window_std"],
                "q4_mean_window_vector_std": q_summary[4]["mean_window_std"],
            }
        )
        for bin_id in range(distance_flat.size):
            row = {
                **common,
                "bin_id": int(bin_id),
                "reward_distance": float(distance_flat[bin_id]) if np.isfinite(distance_flat[bin_id]) else np.nan,
                "distance_quartile": int(quartile_labels[bin_id]) if np.isfinite(quartile_labels[bin_id]) else np.nan,
                "pv_similarity": float(sim_row[bin_id]) if np.isfinite(sim_row[bin_id]) else np.nan,
                "window_occ_sec": float(occ_sec[pivot_idx, bin_id]),
                "included_for_similarity": bool(np.isfinite(sim_row[bin_id])),
            }
            if window_vector_mean is not None:
                row["window_vector_mean"] = float(window_vector_mean[pivot_idx, bin_id]) if np.isfinite(window_vector_mean[pivot_idx, bin_id]) else np.nan
            if window_vector_std is not None:
                row["window_vector_std"] = float(window_vector_std[pivot_idx, bin_id]) if np.isfinite(window_vector_std[pivot_idx, bin_id]) else np.nan
            if window_vector_nfinite is not None:
                row["window_vector_nfinite"] = int(window_vector_nfinite[pivot_idx, bin_id])
            if reference_vector_mean is not None:
                row["reference_vector_mean"] = float(reference_vector_mean[bin_id]) if np.isfinite(reference_vector_mean[bin_id]) else np.nan
            if reference_vector_std is not None:
                row["reference_vector_std"] = float(reference_vector_std[bin_id]) if np.isfinite(reference_vector_std[bin_id]) else np.nan
            if reference_vector_nfinite is not None:
                row["reference_vector_nfinite"] = int(reference_vector_nfinite[bin_id])
            bin_rows.append(row)
    return pd.DataFrame(window_rows), pd.DataFrame(bin_rows)


def _build_pair_bin_audit_table(
    *,
    pair_fields: dict[str, Any],
    pvc: np.ndarray,
    pvc_z: np.ndarray,
    maps_a: np.ndarray,
    maps_b: np.ndarray,
    occupancy_a: np.ndarray,
    occupancy_b: np.ndarray,
    distance_flat: np.ndarray,
    min_occupancy: int,
) -> pd.DataFrame:
    pvc = np.asarray(pvc, dtype=float).ravel()
    pvc_z = np.asarray(pvc_z, dtype=float).ravel()
    maps_a = np.asarray(maps_a, dtype=float)
    maps_b = np.asarray(maps_b, dtype=float)
    occupancy_a = np.asarray(occupancy_a, dtype=float).ravel()
    occupancy_b = np.asarray(occupancy_b, dtype=float).ravel()
    distance_flat = np.asarray(distance_flat, dtype=float).ravel()
    if maps_a.ndim != 2 or maps_b.ndim != 2:
        raise ValueError("maps_a and maps_b must be 2D arrays.")
    n_bins_expected = distance_flat.size
    if maps_a.shape[0] != n_bins_expected and maps_a.shape[1] == n_bins_expected:
        maps_a = maps_a.T
    if maps_b.shape[0] != n_bins_expected and maps_b.shape[1] == n_bins_expected:
        maps_b = maps_b.T
    if maps_a.shape[0] != n_bins_expected or maps_b.shape[0] != n_bins_expected:
        raise ValueError(
            f"Map/bin mismatch for audit export: expected {n_bins_expected} bin rows, got {maps_a.shape} and {maps_b.shape}."
        )
    quartile_info = _distance_quartile_info(distance_flat)
    quartile_labels = quartile_info["quartile_labels"]
    stats_a = _map_vector_stats(maps_a)
    stats_b = _map_vector_stats(maps_b)
    included = (
        np.isfinite(pvc_z)
        & np.isfinite(distance_flat)
        & (occupancy_a >= float(min_occupancy))
        & (occupancy_b >= float(min_occupancy))
    )
    rows: list[dict[str, Any]] = []
    for bin_id in range(distance_flat.size):
        rows.append(
            {
                **pair_fields,
                "bin_id": int(bin_id),
                "reward_distance": float(distance_flat[bin_id]) if np.isfinite(distance_flat[bin_id]) else np.nan,
                "distance_quartile": int(quartile_labels[bin_id]) if np.isfinite(quartile_labels[bin_id]) else np.nan,
                "pv_correlation": float(pvc[bin_id]) if np.isfinite(pvc[bin_id]) else np.nan,
                "pv_correlation_z": float(pvc_z[bin_id]) if np.isfinite(pvc_z[bin_id]) else np.nan,
                "occupancy_a": float(occupancy_a[bin_id]) if np.isfinite(occupancy_a[bin_id]) else np.nan,
                "occupancy_b": float(occupancy_b[bin_id]) if np.isfinite(occupancy_b[bin_id]) else np.nan,
                "map_mean_a": float(stats_a["mean"][bin_id]) if np.isfinite(stats_a["mean"][bin_id]) else np.nan,
                "map_std_a": float(stats_a["std"][bin_id]) if np.isfinite(stats_a["std"][bin_id]) else np.nan,
                "map_nfinite_a": int(stats_a["nfinite"][bin_id]),
                "map_mean_b": float(stats_b["mean"][bin_id]) if np.isfinite(stats_b["mean"][bin_id]) else np.nan,
                "map_std_b": float(stats_b["std"][bin_id]) if np.isfinite(stats_b["std"][bin_id]) else np.nan,
                "map_nfinite_b": int(stats_b["nfinite"][bin_id]),
                "included_for_slope": bool(included[bin_id]),
            }
        )
    return pd.DataFrame(rows)


def _pivot_heatmap_matrix(frame: pd.DataFrame, value_column: str) -> tuple[np.ndarray | None, list[float], np.ndarray]:
    if frame.empty or value_column not in frame.columns:
        return None, [], np.asarray([], dtype=int)
    use = frame.loc[np.isfinite(frame["reward_distance"])].copy()
    if use.empty:
        return None, [], np.asarray([], dtype=int)
    order = use.groupby("bin_id", dropna=False)["reward_distance"].mean().sort_values().index.to_numpy(dtype=int)
    if order.size == 0:
        return None, [], np.asarray([], dtype=int)
    pivot_col = "time_rel_min" if "time_rel_min" in use.columns else "time_min"
    pivots = sorted(use["pivot_index"].dropna().unique().tolist())
    matrix = np.full((len(pivots), len(order)), np.nan, dtype=float)
    times: list[float] = []
    for row_idx, pivot_idx in enumerate(pivots):
        sub = use.loc[use["pivot_index"] == pivot_idx, ["bin_id", value_column, pivot_col]]
        lookup = sub.set_index("bin_id")[value_column].to_dict()
        matrix[row_idx, :] = [float(lookup.get(int(bin_id), np.nan)) for bin_id in order]
        times.append(float(sub[pivot_col].iloc[0]) if not sub.empty else np.nan)
    return matrix, times, order


def _plot_temporal_audit_figure(
    bin_audit: pd.DataFrame,
    window_audit: pd.DataFrame,
    session_fields: dict[str, Any],
    *,
    title: str,
) -> Any | None:
    use = bin_audit.copy()
    summary = window_audit.copy()
    for key, value in session_fields.items():
        use = use.loc[use[key] == value]
        summary = summary.loc[summary[key] == value]
    if use.empty or summary.empty:
        return None
    sim_matrix, times, order = _pivot_heatmap_matrix(use, "pv_similarity")
    occ_matrix, _, _ = _pivot_heatmap_matrix(use, "window_occ_sec")
    if sim_matrix is None or occ_matrix is None or order.size == 0:
        return None
    time_col = "time_rel_min" if "time_rel_min" in use.columns else "time_min"
    summary = summary.sort_values("pivot_index")
    fig, axes = plt.subplots(3, 1, figsize=(9, 9), sharex=False, height_ratios=[1.0, 1.0, 0.75])
    dist_sorted = use.groupby("bin_id", dropna=False)["reward_distance"].mean().reindex(order).to_numpy(dtype=float)
    extent = [float(np.nanmin(dist_sorted)), float(np.nanmax(dist_sorted)), float(np.nanmax(times)), float(np.nanmin(times))]
    im0 = axes[0].imshow(occ_matrix, aspect="auto", cmap="magma", extent=extent)
    axes[0].set_ylabel(time_col.replace("_", " "))
    axes[0].set_title(f"{title}: current-window occupancy support")
    fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)
    im1 = axes[1].imshow(sim_matrix, aspect="auto", cmap="coolwarm", extent=extent)
    axes[1].set_ylabel(time_col.replace("_", " "))
    axes[1].set_title(f"{title}: PV similarity by reward distance")
    fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)
    axes[2].plot(summary[time_col], summary["q1_mean_pv_similarity"], label="Q1 mean PV")
    axes[2].plot(summary[time_col], summary["q4_mean_pv_similarity"], label="Q4 mean PV")
    ax2 = axes[2].twinx()
    ax2.plot(summary[time_col], summary["q1_nfinite_bins"], color="tab:blue", linestyle="--", alpha=0.5, label="Q1 finite bins")
    ax2.plot(summary[time_col], summary["q4_nfinite_bins"], color="tab:orange", linestyle="--", alpha=0.5, label="Q4 finite bins")
    axes[2].set_xlabel(time_col.replace("_", " "))
    axes[2].set_ylabel("Mean PV similarity")
    ax2.set_ylabel("Finite bins")
    axes[2].set_title(f"{title}: quartile summary")
    handles1, labels1 = axes[2].get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    axes[2].legend(handles1 + handles2, labels1 + labels2, frameon=False, loc="best")
    fig.tight_layout()
    return fig


def _plot_pair_audit_figure(frame: pd.DataFrame, pair_fields: dict[str, Any], *, title: str) -> Any | None:
    use = frame.copy()
    for key, value in pair_fields.items():
        use = use.loc[use[key] == value]
    if use.empty:
        return None
    fig, axes = plt.subplots(3, 1, figsize=(8, 9), sharex=True)
    included = use["included_for_slope"].to_numpy(dtype=bool)
    x = use["reward_distance"].to_numpy(dtype=float)
    axes[0].scatter(x[~included], use.loc[~included, "map_std_a"], s=12, color="0.75", label="A excluded")
    axes[0].scatter(x[included], use.loc[included, "map_std_a"], s=18, color="tab:blue", label="A included")
    axes[0].scatter(x[~included], use.loc[~included, "map_std_b"], s=12, color="0.85", marker="x")
    axes[0].scatter(x[included], use.loc[included, "map_std_b"], s=18, color="tab:orange", marker="x", label="B included")
    axes[0].set_ylabel("Map vector std")
    axes[0].set_title(f"{title}: map spread before PV")
    axes[0].legend(frameon=False, loc="best")
    axes[1].scatter(x[~included], use.loc[~included, "occupancy_a"], s=12, color="0.75", label="A excluded")
    axes[1].scatter(x[included], use.loc[included, "occupancy_a"], s=18, color="tab:blue", label="A included")
    axes[1].scatter(x[~included], use.loc[~included, "occupancy_b"], s=12, color="0.85", marker="x")
    axes[1].scatter(x[included], use.loc[included, "occupancy_b"], s=18, color="tab:orange", marker="x", label="B included")
    axes[1].set_ylabel("Occupancy (frames)")
    axes[1].set_title(f"{title}: occupancy support")
    axes[2].scatter(x[~included], use.loc[~included, "pv_correlation_z"], s=12, color="0.75", label="Excluded")
    axes[2].scatter(x[included], use.loc[included, "pv_correlation_z"], s=18, color="tab:red", label="Included")
    axes[2].set_xlabel("Reward distance")
    axes[2].set_ylabel("PV correlation (Fisher z)")
    axes[2].set_title(f"{title}: per-bin PV used for slope")
    axes[2].legend(frameon=False, loc="best")
    fig.tight_layout()
    return fig


def _bin_reward_distance(
    maze: Any | None = None,
    *,
    reward_node: int = REWARD_NODE,
    n_bins_x: int = N_BINS_X,
    n_bins_y: int = N_BINS_Y,
) -> np.ndarray:
    ma = maze if maze is not None else NewMaze(6)
    mapping = _build_bin_to_ma_cell(n_bins_x, n_bins_y, ma)
    out = np.full(mapping.shape, np.nan, dtype=float)
    valid = mapping >= 0
    out[valid] = np.asarray(ma.di, dtype=float)[mapping[valid], int(reward_node)]
    return out


def _bin_tree_depth(
    maze: Any | None = None,
    *,
    n_bins_x: int = N_BINS_X,
    n_bins_y: int = N_BINS_Y,
) -> np.ndarray:
    ma = maze if maze is not None else NewMaze(6)
    mapping = _build_bin_to_ma_cell(n_bins_x, n_bins_y, ma)
    out = np.full(mapping.shape, np.nan, dtype=float)
    valid = mapping >= 0
    for cell in np.unique(mapping[valid]):
        out[mapping == int(cell)] = float(len(HomePath(int(cell), ma)) - 1)
    return out


def _ols_fit(y: np.ndarray, x_cols: list[np.ndarray], names: list[str]) -> dict[str, Any]:
    y = np.asarray(y, dtype=float)
    X = [np.ones_like(y)]
    X.extend(np.asarray(col, dtype=float) for col in x_cols)
    X = np.column_stack(X)
    coef, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    fitted = X @ coef
    resid = y - fitted
    dof = max(0, X.shape[0] - X.shape[1])
    ss_res = float(np.sum(resid ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r_squared = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan
    out = {"intercept": float(coef[0]), "r_squared": r_squared}
    if dof > 0:
        sigma2 = ss_res / dof
        cov = sigma2 * np.linalg.pinv(X.T @ X)
        se = np.sqrt(np.clip(np.diag(cov), 0.0, np.inf))
        t_vals = np.divide(coef, se, out=np.full_like(coef, np.nan), where=se > 0)
        p_vals = 2.0 * stats.t.sf(np.abs(t_vals), df=dof)
    else:
        se = np.full_like(coef, np.nan)
        p_vals = np.full_like(coef, np.nan)
    for idx, name in enumerate(names, start=1):
        out[f"{name}_coef"] = float(coef[idx])
        out[f"{name}_se"] = float(se[idx]) if idx < len(se) else np.nan
        out[f"{name}_p_value"] = float(p_vals[idx]) if idx < len(p_vals) else np.nan
    return out


def _spatial_permutation_pvalue(
    y: np.ndarray,
    x_cols: list[np.ndarray],
    *,
    target_index: int = 0,
    n_permutations: int = 200,
    seed: int = 0,
    names: list[str] | None = None,
) -> dict[str, Any]:
    y = np.asarray(y, dtype=float).ravel()
    cols = [np.asarray(col, dtype=float).ravel() for col in x_cols]
    keep = np.isfinite(y)
    for col in cols:
        keep &= np.isfinite(col)
    if np.sum(keep) < 3:
        return {
            "observed_coef": np.nan,
            "permutation_p_value": np.nan,
            "permutation_null": np.asarray([], dtype=float),
        }
    cols = [col[keep] for col in cols]
    y = y[keep]
    names = names or [f"x{i}" for i in range(len(cols))]
    obs_fit = _ols_fit(y, cols, names)
    observed = float(obs_fit[f"{names[target_index]}_coef"])
    rng = np.random.default_rng(int(seed))
    null = np.full(int(n_permutations), np.nan, dtype=float)
    for idx in range(int(n_permutations)):
        perm_cols = list(cols)
        perm_cols[target_index] = rng.permutation(cols[target_index])
        fit = _ols_fit(y, perm_cols, names)
        null[idx] = float(fit[f"{names[target_index]}_coef"])
    p_value = float(np.mean(np.abs(null) >= abs(observed))) if null.size else np.nan
    return {
        "observed_coef": observed,
        "permutation_p_value": p_value,
        "permutation_null": null,
    }


def _compute_vif_matrix(x_cols: list[np.ndarray], names: list[str]) -> dict[str, float]:
    out: dict[str, float] = {}
    if len(x_cols) <= 1:
        return {name: 1.0 for name in names}
    X = [np.asarray(col, dtype=float).ravel() for col in x_cols]
    keep = np.ones_like(X[0], dtype=bool)
    for col in X:
        keep &= np.isfinite(col)
    if np.sum(keep) < 3:
        return {name: np.nan for name in names}
    X = [col[keep] for col in X]
    for idx, name in enumerate(names):
        y = X[idx]
        others = [X[j] for j in range(len(X)) if j != idx]
        if not others:
            out[name] = 1.0
            continue
        fit = _ols_fit(y, others, [names[j] for j in range(len(names)) if j != idx])
        r_squared = float(fit.get("r_squared", np.nan))
        out[name] = float(1.0 / max(1.0e-9, 1.0 - r_squared)) if np.isfinite(r_squared) else np.nan
    return out


def _fit_mixedlm_linear(y: np.ndarray, x: np.ndarray, groups: np.ndarray) -> dict[str, Any]:
    y = np.asarray(y, dtype=float).ravel()
    x = np.asarray(x, dtype=float).ravel()
    g = np.asarray(groups)
    keep = np.isfinite(y) & np.isfinite(x)
    if np.sum(keep) < 3 or len(np.unique(g[keep])) < 2 or len(np.unique(x[keep])) < 2:
        return {
            "backend": "insufficient_data",
            "coef": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "converged": False,
            "predicted": np.full(np.sum(keep), np.nan, dtype=float),
        }
    try:
        fit_out = fit_mixedlm_statsmodels(x[keep, None], y[keep], g[keep])
        fit = fit_out["fit"]
        exog_names = list(getattr(fit.model, "exog_names", ["const", "x"]))
        coef = np.nan
        p_value = np.nan
        if len(exog_names) >= 2:
            params = getattr(fit, "params", np.asarray([]))
            if hasattr(params, "index") and exog_names[1] in params.index:
                coef = float(params[exog_names[1]])
            else:
                params_arr = np.asarray(params, dtype=float).ravel()
                if params_arr.size >= 2:
                    coef = float(params_arr[1])
            pvals = getattr(fit, "pvalues", None)
            if pvals is not None:
                if hasattr(pvals, "index") and exog_names[1] in pvals.index:
                    p_value = float(pvals[exog_names[1]])
                else:
                    pvals_arr = np.asarray(pvals, dtype=float).ravel()
                    if pvals_arr.size >= 2:
                        p_value = float(pvals_arr[1])
        return {
            "backend": fit_out["backend"],
            "coef": coef,
            "p_value": p_value,
            "aic": float(fit_out.get("aic", np.nan)),
            "converged": bool(fit_out.get("converged", False)),
            "predicted": np.asarray(fit_out.get("prediction", np.full(np.sum(keep), np.nan)), dtype=float),
            "mask": keep,
        }
    except Exception:
        fit = stats.linregress(x[keep], y[keep])
        predicted = fit.intercept + fit.slope * x[keep]
        return {
            "backend": "ols_fallback",
            "coef": float(fit.slope),
            "p_value": float(fit.pvalue),
            "aic": np.nan,
            "converged": False,
            "predicted": np.asarray(predicted, dtype=float),
            "mask": keep,
        }


_NAN_GEE = {"coef": np.nan, "p_value": np.nan, "odds_ratio": np.nan}


def _fit_gee_binomial(y: np.ndarray, x: np.ndarray, groups: np.ndarray) -> dict[str, Any]:
    y = np.asarray(y, dtype=float).ravel()
    x = np.asarray(x, dtype=float).ravel()
    g = np.asarray(groups)
    keep = np.isfinite(y) & np.isfinite(x)
    if np.sum(keep) < 3 or len(np.unique(g[keep])) < 2 or len(np.unique(y[keep])) < 2 or len(np.unique(x[keep])) < 2:
        return dict(_NAN_GEE)
    try:
        import statsmodels.api as sm
        from statsmodels.genmod.generalized_estimating_equations import GEE
        from statsmodels.genmod.families import Binomial

        X = sm.add_constant(x[keep], has_constant="add")
        fit = GEE(y[keep], X, groups=g[keep], family=Binomial()).fit()
        coef = float(fit.params[1]) if len(fit.params) > 1 else np.nan
        p_value = float(fit.pvalues[1]) if len(fit.pvalues) > 1 else np.nan
        return {
            "coef": coef,
            "p_value": p_value,
            "odds_ratio": float(np.exp(coef)) if np.isfinite(coef) else np.nan,
        }
    except ModuleNotFoundError:
        pass
    except Exception:
        return dict(_NAN_GEE)

    # Fallback: unclustered logistic MLE keeps the summary available in base CI
    # even when statsmodels is not installed.
    x_keep = x[keep]
    y_keep = y[keep]
    X = np.column_stack([np.ones_like(x_keep), x_keep])
    ridge = 1.0e-8

    def _objective(beta: np.ndarray) -> tuple[float, np.ndarray]:
        beta = np.asarray(beta, dtype=float)
        eta = X @ beta
        p = np.clip(_expit(eta), 1.0e-9, 1.0 - 1.0e-9)
        nll = -float(np.sum(y_keep * np.log(p) + (1.0 - y_keep) * np.log(1.0 - p)))
        grad = X.T @ (p - y_keep)
        nll += ridge * float(np.sum(beta[1:] ** 2))
        grad[1:] += 2.0 * ridge * beta[1:]
        return nll, np.asarray(grad, dtype=float)

    try:
        result = optimize.minimize(
            _objective,
            x0=np.zeros(X.shape[1], dtype=float),
            jac=True,
            method="BFGS",
        )
    except Exception:
        return dict(_NAN_GEE)
    if not result.success:
        return dict(_NAN_GEE)

    beta = np.asarray(result.x, dtype=float)
    eta = X @ beta
    p = np.clip(_expit(eta), 1.0e-9, 1.0 - 1.0e-9)
    w = p * (1.0 - p)
    hessian = X.T @ (X * w[:, None])
    hessian[1:, 1:] += 2.0 * ridge * np.eye(X.shape[1] - 1)
    try:
        cov = np.linalg.pinv(hessian)
        se = float(np.sqrt(max(cov[1, 1], 0.0))) if cov.shape[0] > 1 else np.nan
    except Exception:
        se = np.nan
    coef = float(beta[1]) if beta.size > 1 else np.nan
    if np.isfinite(coef) and np.isfinite(se) and se > 0:
        z_score = coef / se
        p_value = float(2.0 * stats.norm.sf(abs(z_score)))
    else:
        p_value = np.nan
    return {
        "coef": coef,
        "p_value": p_value,
        "odds_ratio": float(np.exp(coef)) if np.isfinite(coef) else np.nan,
    }


def _leaf_nodes(maze: Any) -> np.ndarray:
    depths = np.asarray([len(HomePath(cell_id, maze)) - 1 for cell_id in range(len(maze.xc))], dtype=int)
    return np.where(depths == int(np.nanmax(depths)))[0]


def _select_pseudo_reward_nodes(maze: Any, *, reward_node: int, seed: int, n_nodes: int = DEFAULT_PSEUDO_REWARD_COUNT) -> np.ndarray:
    leaves = _leaf_nodes(maze)
    candidates = leaves[leaves != int(reward_node)]
    if candidates.size <= int(n_nodes):
        return candidates.astype(int)
    rng = np.random.default_rng(int(seed))
    return np.sort(rng.choice(candidates, size=int(n_nodes), replace=False).astype(int))


def _reward_distance_flat_for_node(maze: Any, reward_node: int, *, n_bins_x: int, n_bins_y: int) -> np.ndarray:
    return _bin_reward_distance(maze, reward_node=int(reward_node), n_bins_x=n_bins_x, n_bins_y=n_bins_y).ravel()


def _compute_cooks_distance(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    keep = np.isfinite(x) & np.isfinite(y)
    if np.sum(keep) < 3:
        return np.full_like(y, np.nan, dtype=float)
    x = x[keep]
    y = y[keep]
    X = np.column_stack([np.ones_like(x), x])
    beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    fitted = X @ beta
    resid = y - fitted
    hat = X @ np.linalg.pinv(X.T @ X) @ X.T
    leverage = np.clip(np.diag(hat), 0.0, 0.999999)
    mse = np.sum(resid ** 2) / max(1, X.shape[0] - X.shape[1])
    cooks = ((resid ** 2) / (X.shape[1] * max(mse, 1.0e-12))) * (leverage / np.clip((1.0 - leverage) ** 2, 1.0e-12, np.inf))
    out = np.full(keep.shape, np.nan, dtype=float)
    out[np.where(keep)[0]] = cooks
    return out


def _cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    a = a[np.isfinite(a)]
    b = b[np.isfinite(b)]
    if a.size < 2 or b.size < 2:
        return np.nan
    pooled = np.sqrt(((a.size - 1) * np.var(a, ddof=1) + (b.size - 1) * np.var(b, ddof=1)) / max(1, a.size + b.size - 2))
    if pooled <= 0:
        return np.nan
    return float((np.mean(a) - np.mean(b)) / pooled)


def _safe_vector_correlation(a: np.ndarray, b: np.ndarray, *, min_points: int = 3) -> float:
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    keep = np.isfinite(a) & np.isfinite(b)
    if np.sum(keep) < int(min_points):
        return np.nan
    a = a[keep]
    b = b[keep]
    if np.nanstd(a) <= 1.0e-12 or np.nanstd(b) <= 1.0e-12:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def _safe_bin_curve_mean(values: np.ndarray, bins: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    bins = np.asarray(bins, dtype=int).ravel()
    curve = np.full(values.shape[0], np.nan, dtype=float)
    if bins.size == 0:
        return curve
    for time_idx in range(values.shape[0]):
        cur = np.asarray(values[time_idx, bins], dtype=float)
        keep = np.isfinite(cur)
        if np.any(keep):
            curve[time_idx] = float(np.mean(cur[keep]))
    return curve


def _temporal_support_summary(window_audit: pd.DataFrame, *, entity_col: str) -> pd.DataFrame:
    if window_audit.empty:
        return pd.DataFrame()
    def _safe_median(series: pd.Series) -> float:
        values = series.to_numpy(dtype=float)
        values = values[np.isfinite(values)]
        return float(np.median(values)) if values.size else np.nan
    rows: list[dict[str, Any]] = []
    for entity_id, grp in window_audit.groupby(entity_col, dropna=False):
        rows.append(
            {
                entity_col: entity_id,
                "n_windows": int(len(grp)),
                "median_fraction_bins_finite": _safe_median(grp["fraction_bins_finite"]),
                "median_q1_nfinite_bins": _safe_median(grp["q1_nfinite_bins"]),
                "median_q4_nfinite_bins": _safe_median(grp["q4_nfinite_bins"]),
                "median_q1_mean_occ_sec": _safe_median(grp["q1_mean_occ_sec"]),
                "median_q4_mean_occ_sec": _safe_median(grp["q4_mean_occ_sec"]),
                "median_q1_mean_window_vector_std": _safe_median(grp["q1_mean_window_vector_std"]),
                "median_q4_mean_window_vector_std": _safe_median(grp["q4_mean_window_vector_std"]),
                "support_warning_sparse_q4": bool(_safe_median(grp["q4_nfinite_bins"]) < 1.0),
                "support_warning_sparse_all_bins": bool(_safe_median(grp["fraction_bins_finite"]) < 0.05),
            }
        )
    return pd.DataFrame(rows)


def _save_figure(fig: Any, base_path: Path) -> list[Path]:
    written = []
    for suffix in (".png", ".pdf"):
        path = base_path.with_suffix(suffix)
        fig.savefig(path, dpi=200, bbox_inches="tight")
        written.append(path)
    plt.close(fig)
    return written


def _safe_token(value: Any) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(value)).strip("_") or "item"


def estimate_convergence_rate(
    pv_sim: np.ndarray,
    pivot_times: np.ndarray,
    event_sec: float,
    distance_labels: np.ndarray,
    *,
    n_distance_quartiles: int = 4,
) -> dict[str, Any]:
    pv_sim = np.asarray(pv_sim, dtype=float)
    pivot_times = np.asarray(pivot_times, dtype=float)
    distance_labels = np.asarray(distance_labels, dtype=float)
    valid = np.isfinite(distance_labels)
    if not np.any(valid):
        raise ValueError("distance_labels has no finite bins.")
    edges = np.nanquantile(distance_labels[valid], np.linspace(0.0, 1.0, n_distance_quartiles + 1))
    mean_curves = np.full((n_distance_quartiles, pv_sim.shape[0]), np.nan, dtype=float)
    pre_slopes = np.full(n_distance_quartiles, np.nan, dtype=float)
    post_slopes = np.full(n_distance_quartiles, np.nan, dtype=float)
    pre_r2 = np.full(n_distance_quartiles, np.nan, dtype=float)
    post_r2 = np.full(n_distance_quartiles, np.nan, dtype=float)
    for q in range(n_distance_quartiles):
        upper = edges[q + 1]
        mask = valid & (distance_labels >= edges[q]) & (distance_labels <= upper if q == n_distance_quartiles - 1 else distance_labels < upper)
        q_bins = np.where(mask)[0]
        if q_bins.size == 0:
            continue
        curve = np.full(pv_sim.shape[0], np.nan, dtype=float)
        for time_idx in range(pv_sim.shape[0]):
            vals = np.asarray(pv_sim[time_idx, q_bins], dtype=float)
            keep = np.isfinite(vals)
            if np.any(keep):
                curve[time_idx] = float(np.mean(vals[keep]))
        mean_curves[q] = curve
        pre_mask = pivot_times < float(event_sec)
        post_mask = pivot_times >= float(event_sec)
        valid_pre = pre_mask & np.isfinite(curve) & np.isfinite(pivot_times)
        valid_post = post_mask & np.isfinite(curve) & np.isfinite(pivot_times)
        if np.sum(valid_pre) >= 3:
            fit = stats.linregress(pivot_times[valid_pre], curve[valid_pre])
            pre_slopes[q] = float(fit.slope)
            pre_r2[q] = float(fit.rvalue ** 2)
        if np.sum(valid_post) >= 3:
            fit = stats.linregress(pivot_times[valid_post], curve[valid_post])
            post_slopes[q] = float(fit.slope)
            post_r2[q] = float(fit.rvalue ** 2)
    return {
        "pre_slopes": pre_slopes,
        "post_slopes": post_slopes,
        "pre_r2": pre_r2,
        "post_r2": post_r2,
        "acceleration": post_slopes - pre_slopes,
        "distance_quartile_edges": edges,
        "mean_pv_sim_curves": mean_curves,
    }


def compute_distance_graded_similarity(
    pv_similarity_per_bin: np.ndarray,
    distance_per_bin: np.ndarray,
    occupancy_s1: np.ndarray,
    occupancy_s2: np.ndarray,
    *,
    min_occupancy: int = 25,
    tree_depth_per_bin: np.ndarray | None = None,
    n_permutations: int = 200,
    seed: int = 0,
) -> dict[str, Any]:
    pv_similarity_per_bin = np.asarray(pv_similarity_per_bin, dtype=float).ravel()
    distance_per_bin = np.asarray(distance_per_bin, dtype=float).ravel()
    occupancy_s1 = np.asarray(occupancy_s1, dtype=float).ravel()
    occupancy_s2 = np.asarray(occupancy_s2, dtype=float).ravel()
    keep = (
        np.isfinite(pv_similarity_per_bin)
        & np.isfinite(distance_per_bin)
        & (occupancy_s1 >= float(min_occupancy))
        & (occupancy_s2 >= float(min_occupancy))
    )
    out = {
        "slope": np.nan,
        "intercept": np.nan,
        "p_value": np.nan,
        "r_squared": np.nan,
        "partial_slope": np.nan,
        "partial_p_value": np.nan,
        "partial_r_squared": np.nan,
        "permutation_p_value": np.nan,
        "partial_permutation_p_value": np.nan,
        "distance_vif": np.nan,
        "n_bins_included": int(np.sum(keep)),
        "n_bins_excluded": int(np.sum(~keep)),
    }
    if np.sum(keep) < 3:
        return out
    y = pv_similarity_per_bin[keep]
    x = distance_per_bin[keep]
    fit = stats.linregress(x, y)
    out["slope"] = float(fit.slope)
    out["intercept"] = float(fit.intercept)
    out["p_value"] = float(fit.pvalue)
    out["r_squared"] = float(fit.rvalue ** 2)
    x_cols = [
        x,
        np.log(np.clip(occupancy_s1[keep], 1.0, np.inf)),
        np.log(np.clip(occupancy_s2[keep], 1.0, np.inf)),
    ]
    names = ["distance", "log_occ_s1", "log_occ_s2"]
    if tree_depth_per_bin is not None:
        x_cols.append(np.asarray(tree_depth_per_bin, dtype=float).ravel()[keep])
        names.append("tree_depth")
    partial = _ols_fit(y, x_cols, names)
    out["partial_slope"] = float(partial["distance_coef"])
    out["partial_p_value"] = float(partial["distance_p_value"])
    out["partial_r_squared"] = float(partial["r_squared"])
    vif = _compute_vif_matrix(x_cols, names)
    out["distance_vif"] = float(vif.get("distance", np.nan))
    raw_perm = _spatial_permutation_pvalue(
        y,
        [x],
        target_index=0,
        n_permutations=n_permutations,
        seed=seed,
        names=["distance"],
    )
    partial_perm = _spatial_permutation_pvalue(
        y,
        x_cols,
        target_index=0,
        n_permutations=n_permutations,
        seed=seed + 1,
        names=names,
    )
    out["permutation_p_value"] = float(raw_perm["permutation_p_value"])
    out["partial_permutation_p_value"] = float(partial_perm["permutation_p_value"])
    return out


def run_sham_null(
    pv_sim: np.ndarray,
    pivot_times: np.ndarray,
    distance_labels: np.ndarray,
    *,
    event_sec: float,
    total_session_sec: float,
    n_sham: int,
    seed: int,
    margin_sec: float,
) -> dict[str, Any]:
    rng = np.random.default_rng(int(seed))
    low = float(margin_sec)
    high = max(low, float(total_session_sec) - float(margin_sec))
    sham_times = rng.uniform(low, high, size=int(n_sham)) if high > low else np.full(int(n_sham), low, dtype=float)
    sham_acc = []
    for sham_sec in sham_times:
        sham = estimate_convergence_rate(
            pv_sim,
            pivot_times,
            float(sham_sec),
            distance_labels,
        )
        sham_acc.append(sham["acceleration"])
    sham_acc = np.asarray(sham_acc, dtype=float)
    observed = estimate_convergence_rate(
        pv_sim,
        pivot_times,
        float(event_sec),
        distance_labels,
    )
    p_values = np.nanmean(sham_acc >= observed["acceleration"][None, :], axis=0) if sham_acc.size else np.full(4, np.nan)
    return {
        "observed": observed,
        "sham_times": sham_times,
        "sham_accelerations": sham_acc,
        "p_values": p_values,
    }


def _path_position_for_cell(cell_id: int, maze: Any | None = None, *, reward_node: int = REWARD_NODE) -> float:
    ma = maze if maze is not None else NewMaze(6)
    path = list(reversed(HomePath(int(reward_node), ma)))
    if int(cell_id) not in path:
        return np.nan
    if len(path) <= 1:
        return 0.0
    return float(path.index(int(cell_id)) / (len(path) - 1))


def _reward_ensemble_overlap(
    maps_train: np.ndarray,
    maps_ltm: np.ndarray,
    distance_flat: np.ndarray,
    *,
    near_threshold: float,
) -> dict[str, float]:
    maps_train = np.asarray(maps_train, dtype=float)
    maps_ltm = np.asarray(maps_ltm, dtype=float)
    dist = np.asarray(distance_flat, dtype=float).ravel()
    near_bins = np.where(np.isfinite(dist) & (dist <= float(near_threshold)))[0]
    far_bins = np.where(np.isfinite(dist) & (dist > float(near_threshold)))[0]

    def _active_set(maps: np.ndarray, bins: np.ndarray) -> set[int]:
        if bins.size == 0:
            return set()
        rates = np.nanmean(maps[:, bins], axis=1)
        return set(np.where(np.isfinite(rates) & (rates > 0))[0].tolist())

    def _jaccard(a: set[int], b: set[int]) -> float:
        if not a and not b:
            return np.nan
        return float(len(a & b) / len(a | b))

    train_near = _active_set(maps_train, near_bins)
    ltm_near = _active_set(maps_ltm, near_bins)
    train_far = _active_set(maps_train, far_bins)
    ltm_far = _active_set(maps_ltm, far_bins)
    return {
        "jaccard_near": _jaccard(train_near, ltm_near),
        "jaccard_far": _jaccard(train_far, ltm_far),
        "jaccard_delta_near_minus_far": _jaccard(train_near, ltm_near) - _jaccard(train_far, ltm_far),
    }


def _select_pairs_for_level(level: str, *, smoke: bool) -> list[tuple[str, str, str]]:
    groups = default_behavior_groups_260113()
    if level == "2":
        no_water = list(zip(groups["AllUnrewardedDay1"], groups["AllUnrewardedDay2"]))
        dry = list(zip(DRY_WATERPORT_DAY1, DRY_WATERPORT_DAY2))
        rewarded = list(zip(HIPPOCAMPAL_REWARDED_DAY1_CONFIRMATORY, HIPPOCAMPAL_REWARDED_DAY2))
        pairs = [(a, b, "unrewarded_no_water") for a, b in no_water]
        pairs += [(a, b, "unrewarded_dry_waterport") for a, b in dry]
        pairs += [(a, b, "rewarded") for a, b in rewarded]
        if smoke:
            smoke_set = {"769day1", "838day1", "451Rday1", "418RRday1"}
            pairs = [item for item in pairs if item[0] in smoke_set]
        return pairs
    raise ValueError(f"No pair selector for level {level}")


def run_level1(config: RewardReorganizationConfig, *, smoke: bool = False) -> dict[str, pd.DataFrame]:
    ma = NewMaze(6)
    distance_flat = _bin_reward_distance(ma, reward_node=config.reward_node).ravel()
    sessions = (
        HIPPOCAMPAL_REWARDED_DAY1_CONFIRMATORY + HIPPOCAMPAL_REWARDED_DAY1_EXPLORATORY
        if not smoke
        else SMOKE_LEVEL_SESSIONS["1"]
    )
    per_session_rows: list[dict[str, Any]] = []
    curve_rows: list[dict[str, Any]] = []
    drift_rows: list[dict[str, Any]] = []
    reference_rows: list[dict[str, Any]] = []
    window_audit_frames: list[pd.DataFrame] = []
    bin_audit_frames: list[pd.DataFrame] = []
    exclusion_rows: list[dict[str, Any]] = []
    for session_id in sessions:
        try:
            bundle = _load_session_bundle(session_id, config=config)
        except Exception as exc:
            _record_exclusion(exclusion_rows, level_label="L1", session_id=session_id, reason=str(exc))
            continue
        pack = bundle["pack"]
        reward_frames = _extract_reward_event_frames(bundle["tr"])
        if reward_frames.size == 0:
            _record_exclusion(exclusion_rows, level_label="L1", session_id=session_id, reason="No reward events found.")
            continue
        first_reward_frame = float(reward_frames[0])
        pre_reward_selected_sec = float(np.sum(pack["df"]["frame"].to_numpy(dtype=float) < first_reward_frame) / FPS)
        if pre_reward_selected_sec < 180.0:
            _record_exclusion(exclusion_rows, level_label="L1", session_id=session_id, reason="Insufficient pre-reward exploration.")
            continue
        analysis_group = "confirmatory"
        reference_mode = "day2_full"
        second_half_reference_mode = "day2_second_half"
        try:
            if session_id not in HIPPOCAMPAL_REWARDED_DAY1_CONFIRMATORY:
                raise FileNotFoundError("No independent Day 2 reference session listed.")
            day2_bundle = _load_session_bundle(session_id.replace("day1", "day2"), config=config)
            day2_pack = day2_bundle["pack"]
            n_shared = min(pack["S"].shape[1], day2_pack["S"].shape[1])
            neuron_ids = np.arange(n_shared, dtype=int)
            reference_maps = _reference_maps_from_pack(day2_pack, neuron_ids, second_half_only=False)
            reference_maps_second_half = _reference_maps_from_pack(day2_pack, neuron_ids, second_half_only=True)
        except Exception:
            analysis_group = "exploratory"
            reference_mode = "split_half_within_session"
            second_half_reference_mode = "split_half_within_session"
            n_shared = int(pack["S"].shape[1])
            neuron_ids = np.arange(n_shared, dtype=int)
            reference_maps = _reference_maps_from_pack(pack, neuron_ids, second_half_only=True)
            reference_maps_second_half = reference_maps
        evo = within_session_pv_temporal_similarity(
            spike_counts=pack["S"],
            raw_counts=bundle["c_raw"],
            selected_df=pack["df"],
            positions=pack["df"][["mass_bx", "mass_by"]].to_numpy(),
            neuron_ids=neuron_ids,
            win_len_sec=config.window_sec,
            pivot_step_sec=config.step_sec,
            pivot_time_axis="selected",
            spatial_labels=pack["bins"],
            reference_maps=reference_maps,
            fisher_z=True,
            min_neurons=config.min_neurons,
            return_vector_stats=True,
        )
        evo_second_half_ref = within_session_pv_temporal_similarity(
            spike_counts=pack["S"],
            raw_counts=bundle["c_raw"],
            selected_df=pack["df"],
            positions=pack["df"][["mass_bx", "mass_by"]].to_numpy(),
            neuron_ids=neuron_ids,
            win_len_sec=config.window_sec,
            pivot_step_sec=config.step_sec,
            pivot_time_axis="selected",
            spatial_labels=pack["bins"],
            reference_maps=reference_maps_second_half,
            fisher_z=True,
            min_neurons=config.min_neurons,
            return_vector_stats=True,
        )
        convergence = estimate_convergence_rate(
            evo["sim_per_bin"],
            evo["pivot_times"],
            event_sec=pre_reward_selected_sec,
            distance_labels=distance_flat,
        )
        convergence_second_half_ref = estimate_convergence_rate(
            evo_second_half_ref["sim_per_bin"],
            evo_second_half_ref["pivot_times"],
            event_sec=pre_reward_selected_sec,
            distance_labels=distance_flat,
        )
        sham = run_sham_null(
            evo["sim_per_bin"],
            evo["pivot_times"],
            distance_flat,
            event_sec=pre_reward_selected_sec,
            total_session_sec=_selected_duration_sec(pack),
            n_sham=config.n_sham,
            seed=config.seed,
            margin_sec=config.window_sec / 2.0,
        )
        reward_bins = np.where(np.isfinite(distance_flat) & (distance_flat <= config.reward_near_threshold))[0]
        frame_vals = pack["df"]["frame"].to_numpy(dtype=float)
        pre_mask = frame_vals < first_reward_frame
        post_mask = ~pre_mask
        pre_frac = float(np.mean(np.isin(pack["bins"][pre_mask], reward_bins))) if np.any(pre_mask) else np.nan
        post_frac = float(np.mean(np.isin(pack["bins"][post_mask], reward_bins))) if np.any(post_mask) else np.nan
        row = {
            "session_id": session_id,
            "animal_id": animal_id(session_id),
            "n_neurons": int(pack["S"].shape[1]),
            "n_shared_neurons": int(n_shared),
            "first_reward_frame": first_reward_frame,
            "first_reward_sec": first_reward_frame / FPS,
            "first_reward_selected_sec": pre_reward_selected_sec,
            "pre_reward_exploration_sec": pre_reward_selected_sec,
            "n_reward_visits": int(reward_frames.size),
            "pre_occ_frac_near_94": pre_frac,
            "post_occ_frac_near_94": post_frac,
            "analysis_group": analysis_group,
            "reference_mode": reference_mode,
            "temporal_timebase": "selected",
        }
        for idx in range(4):
            row[f"pre_slope_q{idx + 1}"] = float(convergence["pre_slopes"][idx])
            row[f"post_slope_q{idx + 1}"] = float(convergence["post_slopes"][idx])
            row[f"acceleration_q{idx + 1}"] = float(convergence["acceleration"][idx])
            row[f"sham_p_q{idx + 1}"] = float(sham["p_values"][idx])
        delta_acc = float(convergence["acceleration"][0] - convergence["acceleration"][3])
        row["delta_acceleration_q1_q4"] = delta_acc
        sham_delta = np.asarray(sham["sham_accelerations"], dtype=float)[:, 0] - np.asarray(sham["sham_accelerations"], dtype=float)[:, 3]
        sham_delta = sham_delta[np.isfinite(sham_delta)]
        if np.isfinite(delta_acc) and sham_delta.size:
            row["delta_acceleration_p"] = float((np.sum(np.abs(sham_delta) >= abs(delta_acc)) + 1.0) / (sham_delta.size + 1.0))
        else:
            row["delta_acceleration_p"] = np.nan
        per_session_rows.append(row)
        rel_minutes = (evo["pivot_times"] - pre_reward_selected_sec) / 60.0
        for q in range(4):
            curve = convergence["mean_pv_sim_curves"][q]
            for t_min, value in zip(rel_minutes, curve):
                curve_rows.append(
                    {
                        "session_id": session_id,
                        "animal_id": animal_id(session_id),
                        "distance_quartile": q + 1,
                        "time_rel_min": float(t_min),
                        "pv_similarity": float(value) if np.isfinite(value) else np.nan,
                    }
                )
        for idx in range(4):
            reference_rows.append(
                {
                    "session_id": session_id,
                    "animal_id": animal_id(session_id),
                    "reference_mode_primary": reference_mode,
                    "reference_mode_sensitivity": second_half_reference_mode,
                    "temporal_timebase": "selected",
                    "distance_quartile": idx + 1,
                    "primary_acceleration": float(convergence["acceleration"][idx]),
                    "sensitivity_acceleration": float(convergence_second_half_ref["acceleration"][idx]),
                    "acceleration_delta": float(convergence_second_half_ref["acceleration"][idx] - convergence["acceleration"][idx]),
                }
            )
        session_fields = {
            "session_id": session_id,
            "animal_id": animal_id(session_id),
            "temporal_timebase": "selected",
            "reference_mode": reference_mode,
        }
        window_audit_df, bin_audit_df = _build_temporal_audit_tables(
            evo=evo,
            distance_flat=distance_flat,
            bin_labels=pack["bins"],
            session_fields=session_fields,
            time_column="time_rel_min",
            event_sec=pre_reward_selected_sec,
        )
        window_audit_frames.append(window_audit_df)
        bin_audit_frames.append(bin_audit_df)
        if analysis_group == "confirmatory":
            midpoint_sec = _selected_duration_sec(day2_pack) / 2.0
            evo_d2 = within_session_pv_temporal_similarity(
                spike_counts=day2_pack["S"],
                raw_counts=day2_bundle["c_raw"],
                selected_df=day2_pack["df"],
                positions=day2_pack["df"][["mass_bx", "mass_by"]].to_numpy(),
                neuron_ids=neuron_ids,
                win_len_sec=config.window_sec,
                pivot_step_sec=config.step_sec,
                pivot_time_axis="selected",
                spatial_labels=day2_pack["bins"],
                reference_maps=reference_maps_second_half,
                fisher_z=True,
                min_neurons=config.min_neurons,
            )
            convergence_d2 = estimate_convergence_rate(
                evo_d2["sim_per_bin"],
                evo_d2["pivot_times"],
                event_sec=midpoint_sec,
                distance_labels=distance_flat,
            )
            drift_rows.append(
                {
                    "session_id": session_id,
                    "animal_id": animal_id(session_id),
                    "day2_session_id": session_id.replace("day1", "day2"),
                    "sham_midpoint_sec": midpoint_sec,
                    "temporal_timebase": "selected",
                    "delta_acceleration_q1_q4_day2": float(convergence_d2["acceleration"][0] - convergence_d2["acceleration"][3]),
                    "delta_acceleration_q1_q4_day1": float(convergence["acceleration"][0] - convergence["acceleration"][3]),
                }
            )
    per_session_df = pd.DataFrame(per_session_rows)
    confirmatory_df = per_session_df.loc[per_session_df["analysis_group"] == "confirmatory"].copy() if "analysis_group" in per_session_df.columns else pd.DataFrame()
    window_audit_all = pd.concat(window_audit_frames, ignore_index=True) if window_audit_frames else pd.DataFrame()
    return {
        "reward_reorg_L1_per_session": per_session_df,
        "reward_reorg_L1_group_curves": pd.DataFrame(curve_rows),
        "reward_reorg_L1_group_summary": _level1_group_summary(confirmatory_df),
        "reward_reorg_L1_reference_sensitivity": pd.DataFrame(reference_rows),
        "reward_reorg_L1_drift_control": pd.DataFrame(drift_rows),
        "reward_reorg_L1_window_audit": window_audit_all,
        "reward_reorg_L1_support_summary": _temporal_support_summary(window_audit_all, entity_col="session_id"),
        "reward_reorg_L1_bin_audit": pd.concat(bin_audit_frames, ignore_index=True) if bin_audit_frames else pd.DataFrame(),
        "reward_reorg_L1_exclusions": _exclusion_frame(exclusion_rows),
    }


def run_level2(config: RewardReorganizationConfig, *, smoke: bool = False) -> dict[str, pd.DataFrame]:
    ma = NewMaze(6)
    distance_flat = _bin_reward_distance(ma, reward_node=config.reward_node).ravel()
    tree_depth_flat = _bin_tree_depth(ma).ravel()
    pseudo_nodes = _select_pseudo_reward_nodes(ma, reward_node=config.reward_node, seed=config.seed)
    pairs = _select_pairs_for_level("2", smoke=smoke)
    pair_rows: list[dict[str, Any]] = []
    sensitivity_frames: list[pd.DataFrame] = []
    pseudo_rows: list[dict[str, Any]] = []
    baseline_rows: list[dict[str, Any]] = []
    bin_audit_frames: list[pd.DataFrame] = []
    exclusion_rows: list[dict[str, Any]] = []
    for s1_id, s2_id, cohort in pairs:
        try:
            b1 = _load_session_bundle(s1_id, config=config)
            b2 = _load_session_bundle(s2_id, config=config)
        except Exception as exc:
            _record_exclusion(exclusion_rows, level_label="L2", session_id=s1_id, related_session=s2_id, reason=str(exc))
            continue
        n_shared = min(b1["pack"]["S"].shape[1], b2["pack"]["S"].shape[1])
        neuron_ids = np.arange(n_shared, dtype=int)
        pv = cross_session_pv_correlation(
            b1["pack"]["S"],
            b1["c_raw"],
            b1["pack"]["df"],
            b1["pack"]["df"][["mass_bx", "mass_by"]].to_numpy(),
            b2["pack"]["S"],
            b2["c_raw"],
            b2["pack"]["df"],
            b2["pack"]["df"][["mass_bx", "mass_by"]].to_numpy(),
            cimap=None,
            train_ids=neuron_ids,
            test_ids=neuron_ids,
            time_window=0,
            min_neurons=config.min_neurons,
            spatial_labels_train=b1["pack"]["bins"],
            spatial_labels_test=b2["pack"]["bins"],
        )
        pvc = np.asarray(pv["pvc"], dtype=float)
        pvc_z = np.where(np.isfinite(pvc), np.arctanh(np.clip(pvc, -0.9999, 0.9999)), np.nan)
        dgs = compute_distance_graded_similarity(
            pvc_z,
            distance_flat,
            b1["pack"]["occ_counts"],
            b2["pack"]["occ_counts"],
            min_occupancy=config.min_occupancy,
            tree_depth_per_bin=tree_depth_flat,
            seed=config.seed,
        )
        animal = animal_id(s1_id)
        waterport_present = cohort == "unrewarded_dry_waterport"
        chemo_control = animal in CHEMOU_CONTROL_ANIMALS
        pair_rows.append(
            {
                "session_day1": s1_id,
                "session_day2": s2_id,
                "animal_id": animal,
                "cohort_group": cohort,
                "waterport_present": bool(waterport_present),
                "chemo_control": bool(chemo_control),
                "n_shared_neurons": int(n_shared),
                "pv_mean_z": float(np.nanmean(pvc_z)),
                **dgs,
            }
        )
        sensitivity_frames.append(
            _occupancy_sensitivity_table(
                level_label="L2",
                key_fields={"animal_id": animal, "session_day1": s1_id, "session_day2": s2_id, "cohort_group": cohort},
                pv_similarity_per_bin=pvc_z,
                distance_per_bin=distance_flat,
                occupancy_s1=b1["pack"]["occ_counts"],
                occupancy_s2=b2["pack"]["occ_counts"],
                tree_depth_per_bin=tree_depth_flat,
                seed=config.seed,
            )
        )
        baseline_rows.append(
            {
                "animal_id": animal,
                "session_day1": s1_id,
                "cohort_group": cohort,
                **_baseline_metrics(b1),
            }
        )
        bin_audit_frames.append(
            _build_pair_bin_audit_table(
                pair_fields={
                    "animal_id": animal,
                    "session_day1": s1_id,
                    "session_day2": s2_id,
                    "cohort_group": cohort,
                },
                pvc=pvc,
                pvc_z=pvc_z,
                maps_a=pv["maps_tr"],
                maps_b=pv["maps_te"],
                occupancy_a=b1["pack"]["occ_counts"],
                occupancy_b=b2["pack"]["occ_counts"],
                distance_flat=distance_flat,
                min_occupancy=config.min_occupancy,
            )
        )
        reward_node_slopes = []
        real_fit = compute_distance_graded_similarity(
            pvc_z,
            distance_flat,
            b1["pack"]["occ_counts"],
            b2["pack"]["occ_counts"],
            min_occupancy=config.min_occupancy,
            tree_depth_per_bin=tree_depth_flat,
            seed=config.seed,
        )
        reward_node_slopes.append((int(config.reward_node), float(real_fit["partial_slope"]), True))
        for pseudo_node in pseudo_nodes:
            pseudo_distance = _reward_distance_flat_for_node(ma, int(pseudo_node), n_bins_x=config.n_bins_x, n_bins_y=config.n_bins_y)
            pseudo_fit = compute_distance_graded_similarity(
                pvc_z,
                pseudo_distance,
                b1["pack"]["occ_counts"],
                b2["pack"]["occ_counts"],
                min_occupancy=config.min_occupancy,
                tree_depth_per_bin=tree_depth_flat,
                seed=config.seed + int(pseudo_node),
            )
            reward_node_slopes.append((int(pseudo_node), float(pseudo_fit["partial_slope"]), False))
        valid_slopes = np.asarray([item[1] for item in reward_node_slopes], dtype=float)
        real_slope = float(reward_node_slopes[0][1])
        rank = np.nan
        rank_p = np.nan
        if np.any(np.isfinite(valid_slopes)):
            rank = 1.0 + float(np.sum(valid_slopes[1:] <= real_slope))
            rank_p = rank / float(len(valid_slopes))
        for reward_node, slope_value, is_real in reward_node_slopes:
            pseudo_rows.append(
                {
                    "animal_id": animal,
                    "session_day1": s1_id,
                    "session_day2": s2_id,
                    "cohort_group": cohort,
                    "reward_node": int(reward_node),
                    "is_real_reward": bool(is_real),
                    "partial_slope": float(slope_value),
                    "real_reward_rank": rank,
                    "real_reward_rank_p_value": rank_p,
                }
            )
    per_pair = pd.DataFrame(pair_rows)
    summary_rows: list[dict[str, Any]] = []
    for group_name, grp in per_pair.groupby("cohort_group"):
        summary_rows.append(
            {
                "cohort_group": group_name,
                "n_pairs": int(len(grp)),
                "mean_slope": float(np.nanmean(grp["slope"])),
                "median_slope": float(np.nanmedian(grp["slope"])),
                "mean_partial_slope": float(np.nanmean(grp["partial_slope"])),
                "mean_partial_permutation_p": float(np.nanmean(grp["partial_permutation_p_value"])),
            }
        )
    rewarded = per_pair.loc[per_pair["cohort_group"] == "rewarded", "partial_slope"].to_numpy(dtype=float)
    no_water = per_pair.loc[per_pair["cohort_group"] == "unrewarded_no_water", "partial_slope"].to_numpy(dtype=float)
    if rewarded.size and no_water.size:
        summary_rows.append(
            {
                "cohort_group": "rewarded_vs_unrewarded_no_water",
                "n_pairs": int(rewarded.size + no_water.size),
                "mean_slope": _cohens_d(rewarded, no_water),
                "median_slope": float(np.nanmedian(rewarded) - np.nanmedian(no_water)),
                "mean_partial_slope": float(np.nanmean(rewarded) - np.nanmean(no_water)),
                "mean_partial_permutation_p": float(stats.ttest_ind(rewarded, no_water, equal_var=False, nan_policy="omit").pvalue),
            }
        )
    pseudo_df = pd.DataFrame(pseudo_rows)
    if not pseudo_df.empty:
        rank_p = pseudo_df.loc[pseudo_df["is_real_reward"], "real_reward_rank_p_value"].to_numpy(dtype=float)
        rank_p = rank_p[np.isfinite(rank_p)]
        if rank_p.size:
            fisher_stat, fisher_p = stats.combine_pvalues(rank_p, method="fisher")
            pseudo_df["pooled_fisher_stat"] = fisher_stat
            pseudo_df["pooled_fisher_p_value"] = fisher_p
    baseline_df = pd.DataFrame(baseline_rows)
    baseline_summary_rows: list[dict[str, Any]] = []
    for metric in ["n_neurons", "active_fraction_mean", "occupancy_coverage", "recording_duration_sec"]:
        for group_name, grp in baseline_df.groupby("cohort_group"):
            baseline_summary_rows.append(
                {
                    "metric": metric,
                    "cohort_group": group_name,
                    "mean_value": float(np.nanmean(grp[metric])),
                    "median_value": float(np.nanmedian(grp[metric])),
                    "n_animals": int(len(grp)),
                }
            )
    return {
        "reward_reorg_L2_per_pair": per_pair,
        "reward_reorg_L2_group_comparison": pd.DataFrame(summary_rows),
        "reward_reorg_L2_pseudo_reward_null": pseudo_df,
        "reward_reorg_L2_min_occupancy_sensitivity": pd.concat(sensitivity_frames, ignore_index=True) if sensitivity_frames else pd.DataFrame(),
        "reward_reorg_L2_baseline_equivalence": pd.DataFrame(baseline_summary_rows),
        "reward_reorg_L2_bin_audit": pd.concat(bin_audit_frames, ignore_index=True) if bin_audit_frames else pd.DataFrame(),
        "reward_reorg_L2_exclusions": _exclusion_frame(exclusion_rows),
    }


def run_level3(config: RewardReorganizationConfig, *, smoke: bool = False) -> dict[str, pd.DataFrame]:
    ma = NewMaze(6)
    distance_flat = _bin_reward_distance(ma, reward_node=config.reward_node).ravel()
    tree_depth_flat = _bin_tree_depth(ma).ravel()
    rows: list[dict[str, Any]] = []
    sensitivity_frames: list[pd.DataFrame] = []
    bin_audit_frames: list[pd.DataFrame] = []
    exclusion_rows: list[dict[str, Any]] = []
    interval_keys = ["3mo"] if smoke else list(LTM_SESSIONS_EXPLICIT.keys())
    for interval in interval_keys:
        registry = LTM_SESSIONS_EXPLICIT[interval]
        for entry in registry["d1"]:
            session_id = entry["session"]
            if session_id in LTM_EXCLUSIONS:
                _record_exclusion(exclusion_rows, level_label="L3", session_id=session_id, reason="Session in explicit LTM exclusion list.")
                continue
            animal = entry["animal"]
            train_day1, train_day2 = TRAINING_BASELINES[animal]
            try:
                ltm_bundle = _load_session_bundle(session_id, config=config)
                train_ids, ltm_ids = _resolve_training_to_ltm_cimap(session_id)
            except Exception as exc:
                _record_exclusion(exclusion_rows, level_label="L3", session_id=session_id, reason=str(exc))
                continue
            if len(train_ids) < config.min_matched_neurons:
                _record_exclusion(exclusion_rows, level_label="L3", session_id=session_id, reason="Matched neuron count below threshold.")
                continue
            for baseline_type, training_session in [("day1_secondary", train_day1), ("day2_primary", train_day2)]:
                try:
                    train_bundle = _load_session_bundle(training_session, config=config)
                except Exception as exc:
                    _record_exclusion(exclusion_rows, level_label="L3", session_id=training_session, related_session=session_id, reason=str(exc))
                    continue
                maps_train = compute_rate_maps_for_neurons(train_bundle["pack"], neuron_ids=train_ids).T
                maps_ltm = compute_rate_maps_for_neurons(ltm_bundle["pack"], neuron_ids=ltm_ids).T
                pvc = np.full(train_bundle["pack"]["K"], np.nan, dtype=float)
                for b in range(train_bundle["pack"]["K"]):
                    a = maps_train[:, b]
                    c = maps_ltm[:, b]
                    pvc[b] = _safe_vector_correlation(a, c, min_points=config.min_neurons)
                pvc_z = np.where(np.isfinite(pvc), np.arctanh(np.clip(pvc, -0.9999, 0.9999)), np.nan)
                dgs = compute_distance_graded_similarity(
                    pvc_z,
                    distance_flat,
                    train_bundle["pack"]["occ_counts"],
                    ltm_bundle["pack"]["occ_counts"],
                    min_occupancy=config.min_occupancy,
                    tree_depth_per_bin=tree_depth_flat,
                    seed=config.seed,
                )
                q_edges = np.nanquantile(distance_flat[np.isfinite(distance_flat)], np.linspace(0.0, 1.0, 5))
                q1 = np.where(np.isfinite(distance_flat) & (distance_flat >= q_edges[0]) & (distance_flat < q_edges[1]))[0]
                q4 = np.where(np.isfinite(distance_flat) & (distance_flat >= q_edges[3]) & (distance_flat <= q_edges[4]))[0]
                mean_q1 = float(np.nanmean(pvc_z[q1])) if q1.size else np.nan
                mean_q4 = float(np.nanmean(pvc_z[q4])) if q4.size else np.nan
                rows.append(
                    {
                        "interval_label": interval,
                        "interval_month": float(registry["month_value"]),
                        "animal_id": animal,
                        "training_session": training_session,
                        "baseline_type": baseline_type,
                        "training_paradigm": "latent" if animal == "422" else "rewarded",
                        "experience_mapped": bool(animal == "1616"),
                        "ltm_day1": session_id,
                        "n_matched_neurons": int(len(train_ids)),
                        "mean_pv_z_q1": mean_q1,
                        "mean_pv_z_q4": mean_q4,
                        "delta_pv_z_q1_q4": float(mean_q1 - mean_q4) if np.isfinite(mean_q1) and np.isfinite(mean_q4) else np.nan,
                        **dgs,
                    }
                )
                sensitivity_frames.append(
                    _occupancy_sensitivity_table(
                        level_label="L3",
                        key_fields={
                            "animal_id": animal,
                            "training_session": training_session,
                            "baseline_type": baseline_type,
                            "ltm_day1": session_id,
                            "interval_label": interval,
                        },
                        pv_similarity_per_bin=pvc_z,
                        distance_per_bin=distance_flat,
                        occupancy_s1=train_bundle["pack"]["occ_counts"],
                        occupancy_s2=ltm_bundle["pack"]["occ_counts"],
                        tree_depth_per_bin=tree_depth_flat,
                        seed=config.seed,
                    )
                )
                bin_audit_frames.append(
                    _build_pair_bin_audit_table(
                        pair_fields={
                            "animal_id": animal,
                            "training_session": training_session,
                            "baseline_type": baseline_type,
                            "ltm_day1": session_id,
                            "interval_label": interval,
                            "interval_month": float(registry["month_value"]),
                        },
                        pvc=pvc,
                        pvc_z=pvc_z,
                        maps_a=maps_train,
                        maps_b=maps_ltm,
                        occupancy_a=train_bundle["pack"]["occ_counts"],
                        occupancy_b=ltm_bundle["pack"]["occ_counts"],
                        distance_flat=distance_flat,
                        min_occupancy=config.min_occupancy,
                    )
                )
    return {
        "reward_reorg_L3_per_pair": pd.DataFrame(rows),
        "reward_reorg_L3_min_occupancy_sensitivity": pd.concat(sensitivity_frames, ignore_index=True) if sensitivity_frames else pd.DataFrame(),
        "reward_reorg_L3_bin_audit": pd.concat(bin_audit_frames, ignore_index=True) if bin_audit_frames else pd.DataFrame(),
        "reward_reorg_L3_exclusions": _exclusion_frame(exclusion_rows),
    }


def run_level4(level3_df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    if level3_df.empty:
        return {"reward_reorg_L4_dose_response": pd.DataFrame()}
    df = level3_df.copy()
    if "baseline_type" in df.columns:
        df = df.loc[df["baseline_type"] == "day2_primary"].copy()
    if df.empty:
        return {"reward_reorg_L4_dose_response": pd.DataFrame()}
    dose_fit = _fit_mixedlm_linear(
        df["partial_slope"].to_numpy(dtype=float),
        df["interval_month"].to_numpy(dtype=float),
        df["animal_id"].to_numpy(),
    )
    cooks = _compute_cooks_distance(df["interval_month"].to_numpy(dtype=float), df["partial_slope"].to_numpy(dtype=float))
    df["cooks_distance"] = cooks
    leave_one_out = []
    for animal in sorted(df["animal_id"].unique()):
        sub = df.loc[df["animal_id"] != animal]
        if len(sub) < 3:
            continue
        loo = _fit_mixedlm_linear(
            sub["partial_slope"].to_numpy(dtype=float),
            sub["interval_month"].to_numpy(dtype=float),
            sub["animal_id"].to_numpy(),
        )
        leave_one_out.append(
            {
                "analysis": "leave_one_out",
                "leave_out_animal": animal,
                "interval_month_coef": float(loo["coef"]),
                "interval_month_p_value": float(loo["p_value"]),
            }
        )
    without_468 = df.loc[df["animal_id"] != "468"]
    fit_without_468 = _fit_mixedlm_linear(
        without_468["partial_slope"].to_numpy(dtype=float),
        without_468["interval_month"].to_numpy(dtype=float),
        without_468["animal_id"].to_numpy(),
    ) if not without_468.empty else {"coef": np.nan, "p_value": np.nan}
    summary = pd.DataFrame(
        [
            {
                "analysis": "pooled_mixedlm",
                "n_pairs": int(len(df)),
                "n_animals": int(df["animal_id"].nunique()),
                "interval_month_coef": float(dose_fit["coef"]),
                "interval_month_p_value": float(dose_fit["p_value"]),
                "aic": float(dose_fit["aic"]),
                "converged": bool(dose_fit["converged"]),
                "with_without_468_coef_delta": float(dose_fit["coef"] - fit_without_468["coef"]) if np.isfinite(dose_fit["coef"]) and np.isfinite(fit_without_468["coef"]) else np.nan,
                "cooks_distance_468": float(np.nanmax(df.loc[df["animal_id"] == "468", "cooks_distance"])) if np.any(df["animal_id"] == "468") else np.nan,
            }
        ]
    )
    if leave_one_out:
        summary = pd.concat([summary, pd.DataFrame(leave_one_out)], ignore_index=True, sort=False)
    per_pair = df[[
        "animal_id",
        "interval_month",
        "partial_slope",
        "training_paradigm",
        "experience_mapped",
        "cooks_distance",
    ]].copy()
    per_pair["mixed_effects_predicted_slope"] = np.nan
    predicted = np.asarray(dose_fit.get("predicted", np.full(len(df), np.nan)), dtype=float)
    if predicted.size == len(df):
        per_pair["mixed_effects_predicted_slope"] = predicted
    per_pair = per_pair.rename(columns={"cooks_distance": "cooks_distance_468"})
    summary = pd.concat([summary, per_pair], ignore_index=True, sort=False)
    return {"reward_reorg_L4_dose_response": summary}


def _compute_field_stability(
    pack_train: dict[str, Any],
    pack_ltm: dict[str, Any],
    train_ids: np.ndarray,
    ltm_ids: np.ndarray,
    *,
    distance_flat: np.ndarray,
    n_shuffles: int,
    seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for idx, (train_id, ltm_id) in enumerate(zip(train_ids, ltm_ids)):
        train_field = compute_binwise_shuffle_pmap(pack_train, int(train_id), n_shuffles=n_shuffles, rng=np.random.default_rng(seed + idx))
        ltm_field = compute_binwise_shuffle_pmap(pack_ltm, int(ltm_id), n_shuffles=n_shuffles, rng=np.random.default_rng(seed + 1000 + idx))
        train_fields = extract_fields_from_sigmask(
            train_field["obs_map"],
            train_field["sig_mask"],
            pack_train["occ_counts"],
            pack_train["bin_level"],
            pack_train["n_bins_x"],
            pack_train["n_bins_y"],
        )
        ltm_fields = extract_fields_from_sigmask(
            ltm_field["obs_map"],
            ltm_field["sig_mask"],
            pack_ltm["occ_counts"],
            pack_ltm["bin_level"],
            pack_ltm["n_bins_x"],
            pack_ltm["n_bins_y"],
        )
        matches = match_fields_hungarian(
            train_fields,
            ltm_fields,
            obs_map_a=train_field["obs_map"],
            obs_map_b=ltm_field["obs_map"],
            n_bins_x=pack_train["n_bins_x"],
            n_bins_y=pack_train["n_bins_y"],
        )
        if matches.empty:
            rows.append(
                {
                    "train_id": int(train_id),
                    "ltm_id": int(ltm_id),
                    "field_match_score": np.nan,
                    "field_centroid_dist": np.nan,
                    "field_jaccard": np.nan,
                    "stable_field": 0,
                    "reward_distance": np.nan,
                }
            )
            continue
        best = matches.iloc[0]
        centroid_x = best.get("centroid_x_s1", np.nan)
        centroid_y = best.get("centroid_y_s1", np.nan)
        if np.isfinite(centroid_x) and np.isfinite(centroid_y):
            peak_bin = int(round(float(centroid_x))) + int(round(float(centroid_y))) * int(pack_train["n_bins_x"])
            reward_distance = float(distance_flat[peak_bin]) if 0 <= peak_bin < distance_flat.size else np.nan
        else:
            reward_distance = np.nan
        rows.append(
            {
                "train_id": int(train_id),
                "ltm_id": int(ltm_id),
                "field_match_score": float(best["score"]),
                "field_centroid_dist": float(best["centroid_dist"]),
                "field_jaccard": float(best["jaccard"]),
                "stable_field": int(bool(best["retained"])),
                "reward_distance": reward_distance,
            }
        )
    return pd.DataFrame(rows)


def _stable_neuron_table(
    train_pack: dict[str, Any],
    ltm_pack: dict[str, Any],
    train_ids: np.ndarray,
    ltm_ids: np.ndarray,
    *,
    distance_flat: np.ndarray,
    maze: Any,
) -> pd.DataFrame:
    map_train = compute_rate_maps_for_neurons(train_pack, neuron_ids=train_ids)
    map_ltm = compute_rate_maps_for_neurons(ltm_pack, neuron_ids=ltm_ids)
    cell_grid = _build_bin_to_ma_cell(train_pack["n_bins_x"], train_pack["n_bins_y"], maze).ravel()
    rows: list[dict[str, Any]] = []
    for idx, (train_id, ltm_id) in enumerate(zip(train_ids, ltm_ids)):
        a = np.asarray(map_train[:, idx], dtype=float)
        b = np.asarray(map_ltm[:, idx], dtype=float)
        corr = _safe_vector_correlation(a, b, min_points=3)
        peak_bin = int(np.nanargmax(a)) if np.any(np.isfinite(a)) else -1
        cell_id = int(cell_grid[peak_bin]) if 0 <= peak_bin < cell_grid.size else -1
        rows.append(
            {
                "train_id": int(train_id),
                "ltm_id": int(ltm_id),
                "place_map_corr": corr,
                "stable_neuron": int(np.isfinite(corr) and corr > 0.4),
                "peak_bin": peak_bin,
                "reward_distance": float(distance_flat[peak_bin]) if 0 <= peak_bin < distance_flat.size else np.nan,
                "path_position": _path_position_for_cell(cell_id, maze),
            }
        )
    return pd.DataFrame(rows)


def _metric_slope(values: np.ndarray, distance: np.ndarray, *, min_points: int = 3) -> tuple[float, float]:
    values = np.asarray(values, dtype=float).ravel()
    distance = np.asarray(distance, dtype=float).ravel()
    keep = np.isfinite(values) & np.isfinite(distance)
    if np.sum(keep) < int(min_points):
        return np.nan, np.nan
    fit = stats.linregress(distance[keep], values[keep])
    return float(fit.slope), float(fit.pvalue)


def _path_enrichment_summary(
    stable_df: pd.DataFrame,
    *,
    near_threshold: float,
    n_sham: int,
    seed: int,
) -> pd.DataFrame:
    if stable_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    group_cols = ["interval_label", "animal_id", "ltm_day1"]
    for threshold in STABLE_NEURON_THRESHOLDS:
        threshold_rows = []
        work_all = stable_df.loc[np.isfinite(stable_df["reward_distance"]) & np.isfinite(stable_df["place_map_corr"])].copy()
        work_all["stable_binary"] = (work_all["place_map_corr"].to_numpy(dtype=float) > float(threshold)).astype(float)
        gee = _fit_gee_binomial(
            work_all["stable_binary"].to_numpy(dtype=float),
            work_all["path_position"].to_numpy(dtype=float),
            work_all["ltm_day1"].to_numpy(),
        ) if not work_all.empty else {"coef": np.nan, "p_value": np.nan, "odds_ratio": np.nan}
        for group_index, (group_key, group) in enumerate(work_all.groupby(group_cols, dropna=False)):
            work = group.copy()
            if work.empty:
                continue
            near_mask = work["reward_distance"].to_numpy(dtype=float) <= float(near_threshold)
            far_mask = ~near_mask
            near_total = int(np.sum(near_mask))
            far_total = int(np.sum(far_mask))
            near_stable = int(work.loc[near_mask, "stable_binary"].sum()) if near_total else 0
            far_stable = int(work.loc[far_mask, "stable_binary"].sum()) if far_total else 0
            near_rate = near_stable / near_total if near_total else np.nan
            far_rate = far_stable / far_total if far_total else np.nan
            table = np.asarray(
                [
                    [near_stable, max(0, near_total - near_stable)],
                    [far_stable, max(0, far_total - far_stable)],
                ],
                dtype=int,
            )
            fisher_p = np.nan
            odds_ratio = np.nan
            if near_total and far_total:
                odds_ratio, fisher_p = stats.fisher_exact(table)
            rng = np.random.default_rng(int(seed) + int(group_index) + int(threshold * 100))
            observed_delta = near_rate - far_rate if np.isfinite(near_rate) and np.isfinite(far_rate) else np.nan
            perm = np.full(int(n_sham), np.nan, dtype=float)
            if near_total and far_total and int(n_sham) > 0 and np.isfinite(observed_delta):
                stable = work["stable_binary"].to_numpy(dtype=float)
                for idx in range(int(n_sham)):
                    shuffled = rng.permutation(stable)
                    perm[idx] = float(np.nanmean(shuffled[near_mask]) - np.nanmean(shuffled[far_mask]))
            perm_p = float(np.nanmean(np.abs(perm) >= abs(observed_delta))) if np.any(np.isfinite(perm)) else np.nan
            interval_label, animal_id_value, ltm_day1 = group_key
            threshold_rows.append(
                {
                    "analysis": "per_pair",
                    "stability_threshold": float(threshold),
                    "interval_label": interval_label,
                    "animal_id": animal_id_value,
                    "ltm_day1": ltm_day1,
                    "near_total": near_total,
                    "far_total": far_total,
                    "near_stable": near_stable,
                    "far_stable": far_stable,
                    "stable_rate_near": near_rate,
                    "stable_rate_far": far_rate,
                    "stable_rate_delta_near_minus_far": observed_delta,
                    "odds_ratio": float(odds_ratio) if np.isfinite(odds_ratio) else np.nan,
                    "fisher_p_value": float(fisher_p) if np.isfinite(fisher_p) else np.nan,
                    "permutation_p_value": perm_p,
                    "gee_coef": np.nan,
                    "gee_p_value": np.nan,
                    "gee_odds_ratio": np.nan,
                }
            )
        rows.extend(threshold_rows)
        rows.append(
            {
                "analysis": "pooled_gee",
                "stability_threshold": float(threshold),
                "interval_label": "all",
                "animal_id": "all",
                "ltm_day1": "all",
                "near_total": np.nan,
                "far_total": np.nan,
                "near_stable": np.nan,
                "far_stable": np.nan,
                "stable_rate_near": np.nan,
                "stable_rate_far": np.nan,
                "stable_rate_delta_near_minus_far": np.nan,
                "odds_ratio": np.nan,
                "fisher_p_value": np.nan,
                "permutation_p_value": np.nan,
                "gee_coef": float(gee["coef"]),
                "gee_p_value": float(gee["p_value"]),
                "gee_odds_ratio": float(gee["odds_ratio"]),
            }
        )
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows)


def _multimetric_correlation_table(multimetric_df: pd.DataFrame) -> pd.DataFrame:
    if multimetric_df.empty:
        return pd.DataFrame()
    metric_cols = [col for col in multimetric_df.columns if col.startswith("slope_")]
    rows: list[dict[str, Any]] = []
    for idx, metric_1 in enumerate(metric_cols):
        for metric_2 in metric_cols[idx + 1:]:
            a = multimetric_df[metric_1].to_numpy(dtype=float)
            b = multimetric_df[metric_2].to_numpy(dtype=float)
            keep = np.isfinite(a) & np.isfinite(b)
            if np.sum(keep) < 3:
                pearson_r = np.nan
                p_value = np.nan
            else:
                pearson_r, p_value = stats.pearsonr(a[keep], b[keep])
            rows.append(
                {
                    "metric_1": metric_1,
                    "metric_2": metric_2,
                    "pearson_r": float(pearson_r) if np.isfinite(pearson_r) else np.nan,
                    "p_value": float(p_value) if np.isfinite(p_value) else np.nan,
                    "n_pairs": int(np.sum(keep)),
                }
            )
    return pd.DataFrame(rows)


def _multimetric_integration_summary(multimetric_df: pd.DataFrame) -> pd.DataFrame:
    if multimetric_df.empty:
        return pd.DataFrame()
    z_cols = [col for col in multimetric_df.columns if col.startswith("z_slope_")]
    if not z_cols:
        return pd.DataFrame()
    values = multimetric_df[z_cols].to_numpy(dtype=float)
    if values.size == 0:
        return pd.DataFrame()
    multimetric_df = multimetric_df.copy()
    multimetric_df["gradient_strength_mean_z"] = np.nanmean(values, axis=1)
    mixed = _fit_mixedlm_linear(
        multimetric_df["gradient_strength_mean_z"].to_numpy(dtype=float),
        np.arange(len(multimetric_df), dtype=float),
        multimetric_df["animal_id"].to_numpy(),
    )
    corr = np.corrcoef(np.nan_to_num(values, nan=0.0), rowvar=False)
    corr = np.nan_to_num(corr, nan=0.0, posinf=0.0, neginf=0.0)
    eigvals = np.asarray([], dtype=float)
    if corr.size:
        try:
            eigvals = np.linalg.eigvalsh(corr)
        except np.linalg.LinAlgError:
            eigvals = np.asarray([], dtype=float)
    meff = float(np.sum(np.clip(eigvals, 0.0, 1.0))) if eigvals.size else np.nan
    return pd.DataFrame(
        [
            {
                "n_pairs": int(len(multimetric_df)),
                "n_metrics": int(len(z_cols)),
                "meff_eigendecomposition": meff,
                "mean_gradient_strength": float(np.nanmean(multimetric_df["gradient_strength_mean_z"])),
                "mixedlm_coef": float(mixed["coef"]),
                "mixedlm_p_value": float(mixed["p_value"]),
            }
        ]
    )


def _half_max_time(curve_df: pd.DataFrame, *, time_col: str, value_col: str, group_cols: list[str]) -> pd.DataFrame:
    if curve_df.empty:
        return pd.DataFrame()
    rows = []
    for group_key, group in curve_df.groupby(group_cols, dropna=False):
        work = group.sort_values(time_col)
        values = work[value_col].to_numpy(dtype=float)
        times = work[time_col].to_numpy(dtype=float)
        if not np.any(np.isfinite(values)):
            continue
        finite = values[np.isfinite(values)]
        target = float(np.nanmin(finite) + 0.5 * (np.nanmax(finite) - np.nanmin(finite)))
        reach = np.where(np.isfinite(values) & (values >= target))[0]
        hit_time = float(times[reach[0]]) if reach.size else np.nan
        row = {col: value for col, value in zip(group_cols, group_key if isinstance(group_key, tuple) else (group_key,))}
        row["half_max_time"] = hit_time
        row["target_value"] = target
        rows.append(row)
    return pd.DataFrame(rows)


def _compare_l1_l5_convergence(l1_curves: pd.DataFrame, l5_curves: pd.DataFrame) -> pd.DataFrame:
    if l1_curves.empty or l5_curves.empty:
        return pd.DataFrame()
    l1_half = _half_max_time(
        l1_curves,
        time_col="time_rel_min",
        value_col="pv_similarity",
        group_cols=["session_id", "animal_id", "distance_quartile"],
    )
    l1_half["analysis_level"] = "L1"
    l5_half = _half_max_time(
        l5_curves,
        time_col="time_min",
        value_col="pv_similarity",
        group_cols=["ltm_day1", "animal_id", "distance_quartile"],
    )
    l5_half = l5_half.rename(columns={"ltm_day1": "session_id"})
    l5_half["analysis_level"] = "L5"
    both = pd.concat([l1_half, l5_half], ignore_index=True, sort=False)
    summary = both.groupby(["analysis_level", "distance_quartile"], dropna=False)["half_max_time"].agg(["mean", "median", "count"]).reset_index()
    return summary.rename(columns={"count": "n_sessions", "mean": "mean_half_max_time", "median": "median_half_max_time"})


def _occupancy_sensitivity_table(
    *,
    level_label: str,
    key_fields: dict[str, Any],
    pv_similarity_per_bin: np.ndarray,
    distance_per_bin: np.ndarray,
    occupancy_s1: np.ndarray,
    occupancy_s2: np.ndarray,
    tree_depth_per_bin: np.ndarray | None,
    seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for idx, threshold in enumerate(OCCUPANCY_SENSITIVITY):
        fit = compute_distance_graded_similarity(
            pv_similarity_per_bin,
            distance_per_bin,
            occupancy_s1,
            occupancy_s2,
            min_occupancy=int(threshold),
            tree_depth_per_bin=tree_depth_per_bin,
            seed=int(seed) + idx * 17,
        )
        rows.append(
            {
                "level_label": level_label,
                "min_occupancy": int(threshold),
                **key_fields,
                "slope": float(fit["slope"]),
                "partial_slope": float(fit["partial_slope"]),
                "permutation_p_value": float(fit["permutation_p_value"]),
                "partial_permutation_p_value": float(fit["partial_permutation_p_value"]),
                "n_bins_included": int(fit["n_bins_included"]),
            }
        )
    return pd.DataFrame(rows)


def _baseline_metrics(bundle: dict[str, Any]) -> dict[str, Any]:
    pack = bundle["pack"]
    finite_spikes = np.asarray(pack["S"], dtype=float)
    active_fraction = float(np.mean(np.nanmean(finite_spikes > 0, axis=0))) if finite_spikes.size else np.nan
    occupancy_coverage = float(np.mean(np.asarray(pack["occ_counts"], dtype=float) > 0)) if pack["occ_counts"].size else np.nan
    return {
        "n_neurons": int(finite_spikes.shape[1]) if finite_spikes.ndim == 2 else 0,
        "active_fraction_mean": active_fraction,
        "occupancy_coverage": occupancy_coverage,
        "recording_duration_sec": float(pack["df"]["frame"].iloc[-1] / FPS) if len(pack["df"]) else np.nan,
    }


def _level1_group_summary(per_session_df: pd.DataFrame) -> pd.DataFrame:
    if per_session_df.empty:
        return pd.DataFrame()
    long_rows: list[dict[str, Any]] = []
    for _, row in per_session_df.iterrows():
        for quartile in range(1, 5):
            long_rows.append(
                {
                    "animal_id": row["animal_id"],
                    "session_id": row["session_id"],
                    "distance_quartile": quartile,
                    "acceleration": row[f"acceleration_q{quartile}"],
                }
            )
    long_df = pd.DataFrame(long_rows)
    mix = _fit_mixedlm_linear(
        long_df["acceleration"].to_numpy(dtype=float),
        long_df["distance_quartile"].to_numpy(dtype=float),
        long_df["animal_id"].to_numpy(),
    )
    delta = per_session_df["acceleration_q1"].to_numpy(dtype=float) - per_session_df["acceleration_q4"].to_numpy(dtype=float)
    delta = delta[np.isfinite(delta)]
    if delta.size >= 2:
        delta_test = stats.ttest_1samp(delta, 0.0, nan_policy="omit")
        delta_mean = float(np.nanmean(delta))
        delta_p = float(delta_test.pvalue)
    else:
        delta_mean = np.nan
        delta_p = np.nan
    return pd.DataFrame(
        [
            {
                "analysis": "mixedlm_distance_quartile",
                "coef": float(mix["coef"]),
                "p_value": float(mix["p_value"]),
                "aic": float(mix["aic"]),
                "converged": bool(mix["converged"]),
                "n_sessions": int(per_session_df["session_id"].nunique()),
                "n_animals": int(per_session_df["animal_id"].nunique()),
            },
            {
                "analysis": "delta_acceleration_q1_minus_q4",
                "coef": delta_mean,
                "p_value": delta_p,
                "aic": np.nan,
                "converged": True,
                "n_sessions": int(per_session_df["session_id"].nunique()),
                "n_animals": int(per_session_df["animal_id"].nunique()),
            },
        ]
    )


def run_level5(config: RewardReorganizationConfig, *, smoke: bool = False) -> dict[str, pd.DataFrame]:
    ma = NewMaze(6)
    distance_flat = _bin_reward_distance(ma, reward_node=config.reward_node).ravel()
    rows: list[dict[str, Any]] = []
    window_audit_frames: list[pd.DataFrame] = []
    bin_audit_frames: list[pd.DataFrame] = []
    exclusion_rows: list[dict[str, Any]] = []
    interval_keys = ["3mo"] if smoke else list(LTM_SESSIONS_EXPLICIT.keys())
    for interval in interval_keys:
        registry = LTM_SESSIONS_EXPLICIT[interval]
        for entry in registry["d1"]:
            session_id = entry["session"]
            if session_id in LTM_EXCLUSIONS:
                _record_exclusion(exclusion_rows, level_label="L5", session_id=session_id, reason="Session in explicit LTM exclusion list.")
                continue
            animal = entry["animal"]
            train_day2 = TRAINING_BASELINES[animal][1]
            try:
                train_bundle = _load_session_bundle(train_day2, config=config)
                ltm_bundle = _load_session_bundle(session_id, config=config)
                train_ids, ltm_ids = _resolve_training_to_ltm_cimap(session_id)
            except Exception as exc:
                _record_exclusion(exclusion_rows, level_label="L5", session_id=session_id, related_session=train_day2, reason=str(exc))
                continue
            if len(train_ids) < config.min_matched_neurons:
                _record_exclusion(exclusion_rows, level_label="L5", session_id=session_id, related_session=train_day2, reason="Matched neuron count below threshold.")
                continue
            reference_maps = compute_rate_maps_for_neurons(train_bundle["pack"], neuron_ids=train_ids).T
            evo = within_session_pv_temporal_similarity(
                spike_counts=ltm_bundle["pack"]["S"],
                raw_counts=ltm_bundle["c_raw"],
                selected_df=ltm_bundle["pack"]["df"],
                positions=ltm_bundle["pack"]["df"][["mass_bx", "mass_by"]].to_numpy(),
                neuron_ids=ltm_ids,
                win_len_sec=config.window_sec,
                pivot_step_sec=config.step_sec,
                pivot_time_axis="selected",
                spatial_labels=ltm_bundle["pack"]["bins"],
                reference_maps=reference_maps,
                fisher_z=True,
                min_neurons=config.min_neurons,
                return_vector_stats=True,
            )
            session_fields = {
                "interval_label": interval,
                "animal_id": animal,
                "ltm_day1": session_id,
                "training_day2": train_day2,
                "temporal_timebase": "selected",
            }
            window_audit_df, bin_audit_df = _build_temporal_audit_tables(
                evo=evo,
                distance_flat=distance_flat,
                bin_labels=ltm_bundle["pack"]["bins"],
                session_fields=session_fields,
                time_column="time_min",
                event_sec=None,
            )
            window_audit_frames.append(window_audit_df)
            bin_audit_frames.append(bin_audit_df)
            edges = np.nanquantile(distance_flat[np.isfinite(distance_flat)], np.linspace(0.0, 1.0, 5))
            for q in range(4):
                upper = edges[q + 1]
                bins = np.where(np.isfinite(distance_flat) & (distance_flat >= edges[q]) & (distance_flat <= upper if q == 3 else distance_flat < upper))[0]
                curve = _safe_bin_curve_mean(evo["sim_per_bin"], bins)
                for t_min, value in zip(evo["pivot_times"] / 60.0, curve):
                    rows.append(
                        {
                            "interval_label": interval,
                            "animal_id": animal,
                            "ltm_day1": session_id,
                            "distance_quartile": q + 1,
                            "time_min": float(t_min),
                            "pv_similarity": float(value) if np.isfinite(value) else np.nan,
                            "temporal_timebase": "selected",
                        }
                    )
    window_audit_all = pd.concat(window_audit_frames, ignore_index=True) if window_audit_frames else pd.DataFrame()
    return {
        "reward_reorg_L5_reinstatement_curves": pd.DataFrame(rows),
        "reward_reorg_L5_window_audit": window_audit_all,
        "reward_reorg_L5_support_summary": _temporal_support_summary(window_audit_all, entity_col="ltm_day1"),
        "reward_reorg_L5_bin_audit": pd.concat(bin_audit_frames, ignore_index=True) if bin_audit_frames else pd.DataFrame(),
        "reward_reorg_L5_exclusions": _exclusion_frame(exclusion_rows),
    }


def run_level6(config: RewardReorganizationConfig, *, smoke: bool = False) -> dict[str, pd.DataFrame]:
    ma = NewMaze(6)
    distance_flat = _bin_reward_distance(ma, reward_node=config.reward_node).ravel()
    decoding_rows: list[dict[str, Any]] = []
    confusion_rows: list[dict[str, Any]] = []
    field_rows: list[pd.DataFrame] = []
    overlap_rows: list[dict[str, Any]] = []
    si_rows: list[dict[str, Any]] = []
    stable_rows: list[pd.DataFrame] = []
    multimetric_rows: list[dict[str, Any]] = []
    exclusion_rows: list[dict[str, Any]] = []
    interval_keys = ["3mo"] if smoke else list(LTM_SESSIONS_EXPLICIT.keys())
    for interval in interval_keys:
        for entry in LTM_SESSIONS_EXPLICIT[interval]["d1"]:
            session_id = entry["session"]
            if session_id in LTM_EXCLUSIONS:
                _record_exclusion(exclusion_rows, level_label="L6", session_id=session_id, reason="Session in explicit LTM exclusion list.")
                continue
            animal = entry["animal"]
            train_day2 = TRAINING_BASELINES[animal][1]
            try:
                train_bundle = _load_session_bundle(train_day2, config=config)
                ltm_bundle = _load_session_bundle(session_id, config=config)
                train_ids, ltm_ids = _resolve_training_to_ltm_cimap(session_id)
            except Exception as exc:
                _record_exclusion(exclusion_rows, level_label="L6", session_id=session_id, related_session=train_day2, reason=str(exc))
                continue
            if len(train_ids) < config.min_matched_neurons:
                _record_exclusion(exclusion_rows, level_label="L6", session_id=session_id, related_session=train_day2, reason="Matched neuron count below threshold.")
                continue
            counts_train = train_bundle["pack"]["S"][:, train_ids]
            counts_ltm = ltm_bundle["pack"]["S"][:, ltm_ids]
            labels_train = train_bundle["pack"]["bins"]
            labels_ltm = ltm_bundle["pack"]["bins"]
            decode = poisson_decode_train_test(counts_train, labels_train, counts_ltm, n_bins=train_bundle["pack"]["K"], dt=1.0 / FPS)
            err = evaluate_decoding_errors(
                decode["pred"],
                labels_ltm,
                n_bins_x=config.n_bins_x,
                n_bins_y=config.n_bins_y,
                distance_flat=distance_flat,
                near_threshold=config.reward_near_threshold,
                return_confusion=True,
            )
            decoding_rows.append(
                {
                    "interval_label": interval,
                    "animal_id": animal,
                    "ltm_day1": session_id,
                    "n_matched_neurons": int(len(train_ids)),
                    "mean_euclidean_error": float(err["mean_euclidean_error"]),
                    "mean_confusion_diag_fraction": float(err["mean_confusion_diag_fraction"]),
                    "near_reward_mean_error": float(err.get("near_reward_mean_error", np.nan)),
                    "far_reward_mean_error": float(err.get("far_reward_mean_error", np.nan)),
                    "attraction_index": float(err.get("attraction_index", np.nan)),
                    "shuffle_null_median_accuracy": float(np.nanmedian(pair_shuffle_null(counts_train, labels_train, counts_ltm, labels_ltm, n_bins=train_bundle["pack"]["K"], n_repeats=50, random_state=config.seed))),
                }
            )
            maps_train = compute_rate_maps_for_neurons(train_bundle["pack"], neuron_ids=train_ids).T
            maps_ltm = compute_rate_maps_for_neurons(ltm_bundle["pack"], neuron_ids=ltm_ids).T
            pvc = np.full(train_bundle["pack"]["K"], np.nan, dtype=float)
            for b in range(train_bundle["pack"]["K"]):
                v_train = maps_train[:, b]
                v_ltm = maps_ltm[:, b]
                pvc[b] = _safe_vector_correlation(v_train, v_ltm, min_points=config.min_neurons)
            pvc_z = np.where(np.isfinite(pvc), np.arctanh(np.clip(pvc, -0.9999, 0.9999)), np.nan)
            pvc_grad = compute_distance_graded_similarity(
                pvc_z,
                distance_flat,
                train_bundle["pack"]["occ_counts"],
                ltm_bundle["pack"]["occ_counts"],
                min_occupancy=config.min_occupancy,
            )
            overlap = _reward_ensemble_overlap(maps_train, maps_ltm, distance_flat, near_threshold=config.reward_near_threshold)
            overlap.update({"interval_label": interval, "animal_id": animal, "ltm_day1": session_id})
            overlap_rows.append(overlap)
            confusion_rows.append(
                {
                    "interval_label": interval,
                    "animal_id": animal,
                    "ltm_day1": session_id,
                    "mean_confusion_diag_fraction": float(err.get("mean_confusion_diag_fraction", np.nan)),
                    "near_reward_mean_diag_fraction": float(err.get("near_reward_mean_diag_fraction", np.nan)),
                    "far_reward_mean_diag_fraction": float(err.get("far_reward_mean_diag_fraction", np.nan)),
                    "mean_distance_error": float(err.get("mean_distance_error", np.nan)),
                    "near_reward_mean_distance_error": float(err.get("near_reward_mean_distance_error", np.nan)),
                    "far_reward_mean_distance_error": float(err.get("far_reward_mean_distance_error", np.nan)),
                    "attraction_index": float(err.get("attraction_index", np.nan)),
                }
            )
            train_si = compute_spatial_info_session_rategated(
                train_bundle["pack"]["S"],
                train_bundle["c_raw"],
                train_bundle["pack"]["df"],
                train_bundle["pack"]["df"][["mass_bx", "mass_by"]].to_numpy(),
                neuron_ids=train_ids,
            )
            ltm_si = compute_spatial_info_session_rategated(
                ltm_bundle["pack"]["S"],
                ltm_bundle["c_raw"],
                ltm_bundle["pack"]["df"],
                ltm_bundle["pack"]["df"][["mass_bx", "mass_by"]].to_numpy(),
                neuron_ids=ltm_ids,
            )
            si_match = compute_spatial_info_matched(train_si, ltm_si, control="intersection_native")
            for idx, (train_id, ltm_id) in enumerate(zip(train_ids, ltm_ids)):
                peak_bin = int(np.nanargmax(maps_train[idx])) if np.any(np.isfinite(maps_train[idx])) else -1
                si_rows.append(
                    {
                        "interval_label": interval,
                        "animal_id": animal,
                        "ltm_day1": session_id,
                        "train_id": int(train_id),
                        "ltm_id": int(ltm_id),
                        "si_train": float(si_match["SI_matched_s1"][idx]) if idx < len(si_match["SI_matched_s1"]) else np.nan,
                        "si_ltm": float(si_match["SI_matched_s2"][idx]) if idx < len(si_match["SI_matched_s2"]) else np.nan,
                        "si_ratio_ltm_over_train": float(si_match["SI_matched_s2"][idx] / si_match["SI_matched_s1"][idx]) if idx < len(si_match["SI_matched_s1"]) and idx < len(si_match["SI_matched_s2"]) and np.isfinite(si_match["SI_matched_s1"][idx]) and si_match["SI_matched_s1"][idx] != 0 else np.nan,
                        "reward_distance": float(distance_flat[peak_bin]) if 0 <= peak_bin < distance_flat.size else np.nan,
                    }
                )
            field_df = _compute_field_stability(
                train_bundle["pack"],
                ltm_bundle["pack"],
                train_ids,
                ltm_ids,
                distance_flat=distance_flat,
                n_shuffles=config.field_shuffles,
                seed=config.seed,
            )
            field_df["interval_label"] = interval
            field_df["animal_id"] = animal
            field_df["ltm_day1"] = session_id
            field_rows.append(field_df)
            stable_df = _stable_neuron_table(
                train_bundle["pack"],
                ltm_bundle["pack"],
                train_ids,
                ltm_ids,
                distance_flat=distance_flat,
                maze=ma,
            )
            stable_df["interval_label"] = interval
            stable_df["animal_id"] = animal
            stable_df["ltm_day1"] = session_id
            stable_rows.append(stable_df)
            slope_decoding_error, _ = _metric_slope(err["error_heatmap"], distance_flat, min_points=3)
            slope_confusion_diagonal, _ = _metric_slope(
                err.get("confusion_diag_fraction", np.asarray([], dtype=float)),
                distance_flat,
                min_points=3,
            )
            slope_field_survival, _ = _metric_slope(
                field_df["stable_field"].to_numpy(dtype=float),
                field_df["reward_distance"].to_numpy(dtype=float),
                min_points=3,
            )
            slope_si_ratio, _ = _metric_slope(
                [
                    row["si_ratio_ltm_over_train"]
                    for row in si_rows[-len(train_ids):]
                ],
                [
                    row["reward_distance"]
                    for row in si_rows[-len(train_ids):]
                ],
                min_points=3,
            )
            slope_stable_enrichment, _ = _metric_slope(
                stable_df["stable_neuron"].to_numpy(dtype=float),
                stable_df["reward_distance"].to_numpy(dtype=float),
                min_points=3,
            )
            multimetric_rows.append(
                {
                    "interval_label": interval,
                    "animal_id": animal,
                    "ltm_day1": session_id,
                    "slope_pv": float(pvc_grad["partial_slope"]),
                    "slope_decoding_error": float(slope_decoding_error),
                    "slope_field_survival": float(slope_field_survival),
                    "slope_ensemble_overlap": float(overlap["jaccard_delta_near_minus_far"]),
                    "slope_si_ratio": float(slope_si_ratio),
                    "slope_confusion_diagonal": float(slope_confusion_diagonal),
                    "slope_stable_enrichment": float(slope_stable_enrichment),
                }
            )
    multimetric_df = pd.DataFrame(multimetric_rows)
    slope_cols = [col for col in multimetric_df.columns if col.startswith("slope_")]
    for col in slope_cols:
        values = multimetric_df[col].to_numpy(dtype=float)
        mean = float(np.nanmean(values)) if np.any(np.isfinite(values)) else np.nan
        std = float(np.nanstd(values)) if np.any(np.isfinite(values)) else np.nan
        if np.isfinite(std) and std > 0:
            multimetric_df[f"z_{col}"] = (values - mean) / std
        else:
            multimetric_df[f"z_{col}"] = np.nan
    stable_table = pd.concat(stable_rows, ignore_index=True) if stable_rows else pd.DataFrame()
    path_enrichment = _path_enrichment_summary(
        stable_table,
        near_threshold=config.reward_near_threshold,
        n_sham=config.n_sham,
        seed=config.seed,
    )
    integration_summary = _multimetric_integration_summary(multimetric_df)
    return {
        "reward_reorg_L6_decoding_per_pair": pd.DataFrame(decoding_rows),
        "reward_reorg_L6_confusion_matrix_summary": pd.DataFrame(confusion_rows),
        "reward_reorg_L6_field_stability": pd.concat(field_rows, ignore_index=True) if field_rows else pd.DataFrame(),
        "reward_reorg_L6_ensemble_overlap": pd.DataFrame(overlap_rows),
        "reward_reorg_L6_si_preservation": pd.DataFrame(si_rows),
        "reward_reorg_L6_path_stable_neurons": stable_table,
        "reward_reorg_L6_path_enrichment_summary": path_enrichment,
        "reward_reorg_L6_multimetric_slopes": multimetric_df,
        "reward_reorg_L6_multimetric_correlation": _multimetric_correlation_table(multimetric_df),
        "reward_reorg_L6_multimetric_integration_summary": integration_summary,
        "reward_reorg_L6_exclusions": _exclusion_frame(exclusion_rows),
    }


def run_reward_reorganization(
    *,
    level: str = "all",
    smoke: bool = False,
    config: RewardReorganizationConfig | None = None,
) -> dict[str, Any]:
    cfg = config or RewardReorganizationConfig()
    outputs: dict[str, Any] = {}
    levels = ["1", "2", "3", "4", "5", "6"] if level == "all" else [str(level)]
    level3_df = pd.DataFrame()
    if "1" in levels:
        outputs.update(run_level1(cfg, smoke=smoke))
    if "2" in levels:
        outputs.update(run_level2(cfg, smoke=smoke))
    if "3" in levels or "4" in levels:
        level3 = run_level3(cfg, smoke=smoke)
        outputs.update(level3)
        level3_df = level3["reward_reorg_L3_per_pair"]
    if "4" in levels:
        outputs.update(run_level4(level3_df))
    if "5" in levels:
        outputs.update(run_level5(cfg, smoke=smoke))
    if "6" in levels:
        outputs.update(run_level6(cfg, smoke=smoke))
    if "reward_reorg_L1_group_curves" in outputs and "reward_reorg_L5_reinstatement_curves" in outputs:
        outputs["reward_reorg_L5_vs_L1_convergence"] = _compare_l1_l5_convergence(
            outputs["reward_reorg_L1_group_curves"],
            outputs["reward_reorg_L5_reinstatement_curves"],
        )
    outputs["reward_reorg_config"] = {
        "plan_version": "v2",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "config": asdict(cfg),
        "level": level,
        "smoke": bool(smoke),
        "min_occupancy_sensitivity_sweep": list(OCCUPANCY_SENSITIVITY),
        "stable_neuron_threshold_sensitivity": list(STABLE_NEURON_THRESHOLDS),
        "timebase_used": "selected_df/frame with pack['S'] for selected-frame-aligned analyses",
        "continuity_assumptions": "selected_df may be discontinuous in absolute frame time; cross-session analyses use session-local occupancy counts and explicit frame alignment from session packs.",
    }
    return outputs


def _export_reward_reorganization_figures(results: dict[str, Any], out_dir: str | Path) -> list[Path]:
    out_root = Path(out_dir)
    out_root.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    l1_curves = results.get("reward_reorg_L1_group_curves")
    if isinstance(l1_curves, pd.DataFrame) and not l1_curves.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        grouped = l1_curves.groupby("distance_quartile", dropna=False)
        for quartile, grp in grouped:
            mean_curve = grp.groupby("time_rel_min", dropna=False)["pv_similarity"].mean().reset_index()
            ax.plot(mean_curve["time_rel_min"], mean_curve["pv_similarity"], label=f"Q{quartile}")
        ax.set_xlabel("Time Relative To Reward (min)")
        ax.set_ylabel("PV Similarity (Fisher z)")
        ax.set_title("L1 Reward-Aligned Convergence")
        ax.legend(frameon=False)
        written.extend(_save_figure(fig, out_root / "reward_reorg_L1_group_curves"))
    l1_bin_audit = results.get("reward_reorg_L1_bin_audit")
    l1_window_audit = results.get("reward_reorg_L1_window_audit")
    if (
        isinstance(l1_bin_audit, pd.DataFrame)
        and not l1_bin_audit.empty
        and isinstance(l1_window_audit, pd.DataFrame)
        and not l1_window_audit.empty
    ):
        audit_dir = out_root / "audit" / "L1"
        audit_dir.mkdir(parents=True, exist_ok=True)
        sessions = (
            l1_window_audit[["session_id", "animal_id", "reference_mode"]]
            .drop_duplicates()
            .to_dict("records")
        )
        for session_fields in sessions:
            fig = _plot_temporal_audit_figure(
                l1_bin_audit,
                l1_window_audit,
                session_fields,
                title=f"L1 {session_fields['session_id']}",
            )
            if fig is None:
                continue
            written.extend(
                _save_figure(
                    fig,
                    audit_dir / f"{_safe_token(session_fields['session_id'])}_conversion_audit",
                )
            )

    l2_pairs = results.get("reward_reorg_L2_per_pair")
    if isinstance(l2_pairs, pd.DataFrame) and not l2_pairs.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        order = list(dict.fromkeys(l2_pairs["cohort_group"].tolist()))
        data = [l2_pairs.loc[l2_pairs["cohort_group"] == name, "partial_slope"].to_numpy(dtype=float) for name in order]
        ax.boxplot(data, labels=order, patch_artist=True)
        ax.set_ylabel("Partial Slope")
        ax.set_title("L2 Cohort Comparison")
        ax.tick_params(axis="x", rotation=20)
        written.extend(_save_figure(fig, out_root / "reward_reorg_L2_group_comparison"))
    l2_bin_audit = results.get("reward_reorg_L2_bin_audit")
    if isinstance(l2_bin_audit, pd.DataFrame) and not l2_bin_audit.empty:
        audit_dir = out_root / "audit" / "L2"
        audit_dir.mkdir(parents=True, exist_ok=True)
        pairs = l2_bin_audit[["session_day1", "session_day2", "cohort_group"]].drop_duplicates().to_dict("records")
        for pair_fields in pairs:
            fig = _plot_pair_audit_figure(
                l2_bin_audit,
                pair_fields,
                title=f"L2 {pair_fields['session_day1']} vs {pair_fields['session_day2']}",
            )
            if fig is None:
                continue
            written.extend(
                _save_figure(
                    fig,
                    audit_dir / f"{_safe_token(pair_fields['session_day1'])}__{_safe_token(pair_fields['session_day2'])}_conversion_audit",
                )
            )

    l3_pairs = results.get("reward_reorg_L3_per_pair")
    if isinstance(l3_pairs, pd.DataFrame) and not l3_pairs.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        primary = l3_pairs.loc[l3_pairs.get("baseline_type", "day2_primary") == "day2_primary"].copy() if "baseline_type" in l3_pairs.columns else l3_pairs
        for animal, grp in primary.groupby("animal_id", dropna=False):
            ax.plot(grp["interval_month"], grp["partial_slope"], marker="o", label=str(animal))
        ax.set_xlabel("Interval (months)")
        ax.set_ylabel("Partial Slope")
        ax.set_title("L3 Reward Gradient Across Retention Intervals")
        written.extend(_save_figure(fig, out_root / "reward_reorg_L3_intervals"))
    l3_bin_audit = results.get("reward_reorg_L3_bin_audit")
    if isinstance(l3_bin_audit, pd.DataFrame) and not l3_bin_audit.empty:
        audit_dir = out_root / "audit" / "L3"
        audit_dir.mkdir(parents=True, exist_ok=True)
        pairs = l3_bin_audit[["training_session", "ltm_day1", "baseline_type"]].drop_duplicates().to_dict("records")
        for pair_fields in pairs:
            fig = _plot_pair_audit_figure(
                l3_bin_audit,
                pair_fields,
                title=f"L3 {pair_fields['training_session']} vs {pair_fields['ltm_day1']}",
            )
            if fig is None:
                continue
            written.extend(
                _save_figure(
                    fig,
                    audit_dir / f"{_safe_token(pair_fields['training_session'])}__{_safe_token(pair_fields['ltm_day1'])}__{_safe_token(pair_fields['baseline_type'])}_conversion_audit",
                )
            )

    l4_df = results.get("reward_reorg_L4_dose_response")
    if isinstance(l4_df, pd.DataFrame) and not l4_df.empty:
        per_pair = l4_df.loc[l4_df["analysis"].isna()] if "analysis" in l4_df.columns else pd.DataFrame()
        if not per_pair.empty:
            fig, ax = plt.subplots(figsize=(7, 4))
            for animal, grp in per_pair.groupby("animal_id", dropna=False):
                ax.plot(grp["interval_month"], grp["partial_slope"], marker="o", label=str(animal))
            ax.set_xlabel("Interval (months)")
            ax.set_ylabel("Partial Slope")
            ax.set_title("L4 Dose Response")
            written.extend(_save_figure(fig, out_root / "reward_reorg_L4_dose_response"))

    l5_curves = results.get("reward_reorg_L5_reinstatement_curves")
    if isinstance(l5_curves, pd.DataFrame) and not l5_curves.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        for quartile, grp in l5_curves.groupby("distance_quartile", dropna=False):
            mean_curve = grp.groupby("time_min", dropna=False)["pv_similarity"].mean().reset_index()
            ax.plot(mean_curve["time_min"], mean_curve["pv_similarity"], label=f"Q{quartile}")
        ax.set_xlabel("Time (min)")
        ax.set_ylabel("PV Similarity")
        ax.set_title("L5 LTM Reinstatement Curves")
        ax.legend(frameon=False)
        written.extend(_save_figure(fig, out_root / "reward_reorg_L5_reinstatement"))
    l5_bin_audit = results.get("reward_reorg_L5_bin_audit")
    l5_window_audit = results.get("reward_reorg_L5_window_audit")
    if (
        isinstance(l5_bin_audit, pd.DataFrame)
        and not l5_bin_audit.empty
        and isinstance(l5_window_audit, pd.DataFrame)
        and not l5_window_audit.empty
    ):
        audit_dir = out_root / "audit" / "L5"
        audit_dir.mkdir(parents=True, exist_ok=True)
        sessions = l5_window_audit[["ltm_day1", "animal_id", "interval_label"]].drop_duplicates().to_dict("records")
        for session_fields in sessions:
            fig = _plot_temporal_audit_figure(
                l5_bin_audit,
                l5_window_audit,
                session_fields,
                title=f"L5 {session_fields['ltm_day1']}",
            )
            if fig is None:
                continue
            written.extend(
                _save_figure(
                    fig,
                    audit_dir / f"{_safe_token(session_fields['ltm_day1'])}_conversion_audit",
                )
            )

    l6_corr = results.get("reward_reorg_L6_multimetric_correlation")
    if isinstance(l6_corr, pd.DataFrame) and not l6_corr.empty:
        metrics = sorted(set(l6_corr["metric_1"]).union(set(l6_corr["metric_2"])))
        mat = pd.DataFrame(np.nan, index=metrics, columns=metrics)
        for _, row in l6_corr.iterrows():
            mat.loc[row["metric_1"], row["metric_2"]] = row["pearson_r"]
            mat.loc[row["metric_2"], row["metric_1"]] = row["pearson_r"]
        np.fill_diagonal(mat.values, 1.0)
        fig, ax = plt.subplots(figsize=(7, 6))
        im = ax.imshow(mat.to_numpy(dtype=float), vmin=-1, vmax=1, cmap="coolwarm")
        ax.set_xticks(range(len(metrics)))
        ax.set_xticklabels(metrics, rotation=45, ha="right")
        ax.set_yticks(range(len(metrics)))
        ax.set_yticklabels(metrics)
        ax.set_title("L6 Inter-Metric Correlation")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        written.extend(_save_figure(fig, out_root / "reward_reorg_L6_metric_correlation"))

    integration = results.get("reward_reorg_L5_vs_L1_convergence")
    if isinstance(integration, pd.DataFrame) and not integration.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        for level_name, grp in integration.groupby("analysis_level", dropna=False):
            ax.plot(grp["distance_quartile"], grp["median_half_max_time"], marker="o", label=str(level_name))
        ax.set_xlabel("Distance Quartile")
        ax.set_ylabel("Median Half-Max Time")
        ax.set_title("L1 vs L5 Convergence Speed")
        ax.legend(frameon=False)
        written.extend(_save_figure(fig, out_root / "reward_reorg_integration_convergence"))

    return written


def export_reward_reorganization_results(results: dict[str, Any], out_dir: str | Path) -> list[Path]:
    out_root = Path(out_dir)
    out_root.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for key, value in results.items():
        if isinstance(value, pd.DataFrame):
            path = out_root / f"{key}.csv"
            value.to_csv(path, index=False)
            written.append(path)
        elif key == "reward_reorg_config":
            path = out_root / "reward_reorg_config.json"
            path.write_text(json.dumps(value, indent=2), encoding="utf-8")
            written.append(path)
    written.extend(_export_reward_reorganization_figures(results, out_root))
    return written
