from __future__ import annotations


def pick_global(*names, scope=None):
    """Return the first non-None global value from candidate names."""
    g = globals() if scope is None else scope
    for name in names:
        if name in g and g[name] is not None:
            return g[name]
    return None
