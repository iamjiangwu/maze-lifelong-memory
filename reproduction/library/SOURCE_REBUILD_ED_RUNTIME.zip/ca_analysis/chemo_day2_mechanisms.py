from __future__ import annotations

import json
import math
import os
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Callable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .behavior_models import fit_four_bias_model
from .chemo_day2_compare import (
    ComparisonConfig,
    _event_time_lookup,
    _frames_to_maze_seconds,
    _load_optional_csv,
    _mode_clip_intervals,
    _mode_fraction_between,
    build_cumulative_curve_table,
    default_comparison_config,
    run_full_analysis,
)
from .exploration import compute_scalar_efficiency_metrics, extract_explore_endnode_sequence
from .trajectory import LoadTraj

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


BASE_METRICS = [
    "long_path_reward_rate",
    "reward_per_long_path",
    "control_path_rate",
    "mode_drink_frac",
    "mode_explore_frac",
    "outer_inner_preference",
    "entropy_norm",
    "bias_in_left",
    "bias_in_right",
    "bias_out_left",
    "bias_out_right",
    "speed_mean",
    "run_fraction_gt2",
]

EXTRA_METRICS = [
    "reward_latency_from_longpath_med",
    "terminal_repeat_rate",
    "backtrack_rate",
    "depth_progress_rate",
]

TIER2_INTERACTIONS = [
    ("mode_drink_frac", "reward_per_long_path"),
    ("entropy_norm", "long_path_reward_rate"),
    ("backtrack_rate", "speed_mean"),
]


@dataclass(frozen=True)
class MechanismConfig:
    reward_node: int = 94
    long_path_min: int = 7
    dt_sec: int = 10
    window_sec: int = 300
    consecutive_outside: int = 3
    n_boot: int = 2000
    n_perm: int = 2000
    seed: int = 0
    strict_q: float = 0.05
    strict_cliff: float = 0.47
    strict_gap_reduction: float = 0.30
    strict_stability_frac: float = 0.80
    max_workers: int = 8
    memory_budget_gb: float = 80.0

    def __post_init__(self) -> None:
        if int(self.reward_node) != 94:
            raise ValueError("Primary reward location must be node 94.")


def _safe_numeric(x: Any) -> np.ndarray:
    arr = np.asarray(x, dtype=float).ravel()
    return arr[np.isfinite(arr)]


def _memory_gb() -> float:
    if psutil is None:
        return float("nan")
    try:
        p = psutil.Process(os.getpid())
        return float(p.memory_info().rss / (1024**3))
    except Exception:
        return float("nan")


def _cliffs_delta(x: np.ndarray, y: np.ndarray) -> float:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan
    gt = 0
    lt = 0
    for v in a:
        gt += int(np.sum(v > b))
        lt += int(np.sum(v < b))
    return float((gt - lt) / (a.size * b.size))


def _perm_pvalue(x: np.ndarray, y: np.ndarray, *, n_perm: int, seed: int) -> tuple[float, float]:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan, np.nan
    obs = float(np.nanmedian(a) - np.nanmedian(b))
    pool = np.concatenate([a, b])
    n_a = a.size
    rng = np.random.default_rng(int(seed))
    n_iter = int(max(200, n_perm))
    more_extreme = 0
    for _ in range(n_iter):
        perm = rng.permutation(pool)
        d = float(np.nanmedian(perm[:n_a]) - np.nanmedian(perm[n_a:]))
        if abs(d) >= abs(obs):
            more_extreme += 1
    p = float((more_extreme + 1) / (n_iter + 1))
    return obs, p


def _bootstrap_diff_ci(x: np.ndarray, y: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    a = _safe_numeric(x)
    b = _safe_numeric(y)
    if a.size == 0 or b.size == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(int(seed))
    n_iter = int(max(300, n_boot))
    diffs = np.zeros(n_iter, dtype=float)
    for i in range(n_iter):
        xa = rng.choice(a, size=a.size, replace=True)
        xb = rng.choice(b, size=b.size, replace=True)
        diffs[i] = float(np.nanmedian(xa) - np.nanmedian(xb))
    return float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))


def bh_fdr(p_values: np.ndarray | pd.Series) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    out = np.full(p.shape, np.nan, dtype=float)
    ok = np.isfinite(p)
    if not np.any(ok):
        return out
    pv = p[ok]
    m = pv.size
    order = np.argsort(pv)
    ranked = pv[order]
    q = ranked * m / np.arange(1, m + 1, dtype=float)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0.0, 1.0)
    out_ok = np.empty_like(pv)
    out_ok[order] = q
    out[ok] = out_ok
    return out


def _bootstrap_cumulative_gap_from_session(
    curve_session: pd.DataFrame,
    *,
    event_type: str,
    group_a: str,
    group_b: str,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    req = {"group", "session", "event_type", "maze_seconds", "cum_count"}
    if curve_session.empty or not req.issubset(set(curve_session.columns)):
        return pd.DataFrame(
            columns=[
                "event_type",
                "maze_seconds",
                "mean_cum_a",
                "mean_cum_b",
                "gap_mean",
                "gap_ci_low",
                "gap_ci_high",
                "n_a",
                "n_b",
            ]
        )
    sub = curve_session.loc[curve_session["event_type"] == str(event_type)].copy()
    if sub.empty:
        return pd.DataFrame(
            columns=[
                "event_type",
                "maze_seconds",
                "mean_cum_a",
                "mean_cum_b",
                "gap_mean",
                "gap_ci_low",
                "gap_ci_high",
                "n_a",
                "n_b",
            ]
        )

    rng = np.random.default_rng(int(seed))
    rows: list[dict[str, Any]] = []
    for t, block in sub.groupby("maze_seconds", sort=True):
        a = _safe_numeric(block.loc[block["group"].astype(str) == str(group_a), "cum_count"].to_numpy())
        b = _safe_numeric(block.loc[block["group"].astype(str) == str(group_b), "cum_count"].to_numpy())
        if a.size == 0 or b.size == 0:
            continue
        n_iter = int(max(300, n_boot))
        boot = np.zeros(n_iter, dtype=float)
        for i in range(n_iter):
            ma = float(rng.choice(a, size=a.size, replace=True).mean())
            mb = float(rng.choice(b, size=b.size, replace=True).mean())
            boot[i] = mb - ma
        rows.append(
            {
                "event_type": str(event_type),
                "maze_seconds": float(t),
                "mean_cum_a": float(np.mean(a)),
                "mean_cum_b": float(np.mean(b)),
                "gap_mean": float(np.mean(boot)),
                "gap_ci_low": float(np.quantile(boot, 0.025)),
                "gap_ci_high": float(np.quantile(boot, 0.975)),
                "n_a": int(a.size),
                "n_b": int(b.size),
            }
        )
    return pd.DataFrame(rows).sort_values("maze_seconds").reset_index(drop=True)


def estimate_breakpoint_gap_ci_dt10(
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    compare_config: ComparisonConfig,
    mech_config: MechanismConfig,
) -> dict[str, Any]:
    curve_group_dt10, curve_session_dt10 = build_cumulative_curve_table(
        event_table,
        session_qc,
        compare_config,
        n_boot=int(mech_config.n_boot),
        seed=int(mech_config.seed),
        time_step_sec=float(mech_config.dt_sec),
    )
    gap_reward = _bootstrap_cumulative_gap_from_session(
        curve_session_dt10,
        event_type="reward",
        group_a=compare_config.group_a_name,
        group_b=compare_config.group_b_name,
        n_boot=int(mech_config.n_boot),
        seed=int(mech_config.seed),
    )
    gap_long = _bootstrap_cumulative_gap_from_session(
        curve_session_dt10,
        event_type="long_path_reward",
        group_a=compare_config.group_a_name,
        group_b=compare_config.group_b_name,
        n_boot=int(mech_config.n_boot),
        seed=int(mech_config.seed) + 17,
    )

    g = gap_reward.copy()
    if g.empty:
        return {
            "t_break": 3000.0,
            "found": False,
            "fallback_used": True,
            "fallback_reason": "no gap rows",
            "gap_reward_dt10": gap_reward,
            "gap_long_dt10": gap_long,
            "curve_group_dt10": curve_group_dt10,
            "curve_session_dt10": curve_session_dt10,
            "equivalence_reward_early": False,
            "equivalence_long_early": False,
        }

    g["window_index"] = np.floor(pd.to_numeric(g["maze_seconds"], errors="coerce") / float(mech_config.window_sec)).astype(int)
    decision = g.groupby("window_index", as_index=False).agg(
        maze_seconds=("maze_seconds", "min"),
        gap_ci_low=("gap_ci_low", "median"),
        gap_ci_high=("gap_ci_high", "median"),
    )
    decision = decision.sort_values("maze_seconds").reset_index(drop=True)
    outside = (decision["gap_ci_low"] > 0.0) | (decision["gap_ci_high"] < 0.0)
    outside_arr = outside.to_numpy(dtype=bool)

    k = int(max(1, mech_config.consecutive_outside))
    idx = -1
    for i in range(0, len(outside_arr) - k + 1):
        if bool(np.all(outside_arr[i : i + k])):
            idx = i
            break

    if idx >= 0:
        t_break = float(decision.iloc[idx]["maze_seconds"])
        found = True
        fallback = False
        reason = ""
    else:
        t_break = 3000.0
        found = False
        fallback = True
        reason = "no sustained CI departure"

    eq_rew = g.loc[g["maze_seconds"] < float(t_break)].copy()
    if not eq_rew.empty:
        eq_rew["window_index"] = np.floor(pd.to_numeric(eq_rew["maze_seconds"], errors="coerce") / float(mech_config.window_sec)).astype(int)
        eq_rew = eq_rew.groupby("window_index", as_index=False).agg(
            gap_ci_low=("gap_ci_low", "median"),
            gap_ci_high=("gap_ci_high", "median"),
        )
    eq_rew_ok = bool(((eq_rew["gap_ci_low"] <= 0.0) & (eq_rew["gap_ci_high"] >= 0.0)).all()) if not eq_rew.empty else False

    gl = gap_long.copy()
    eq_long = gl.loc[gl["maze_seconds"] < float(t_break)].copy() if not gl.empty else pd.DataFrame()
    if not eq_long.empty:
        eq_long["window_index"] = np.floor(pd.to_numeric(eq_long["maze_seconds"], errors="coerce") / float(mech_config.window_sec)).astype(int)
        eq_long = eq_long.groupby("window_index", as_index=False).agg(
            gap_ci_low=("gap_ci_low", "median"),
            gap_ci_high=("gap_ci_high", "median"),
        )
    eq_long_ok = bool(((eq_long["gap_ci_low"] <= 0.0) & (eq_long["gap_ci_high"] >= 0.0)).all()) if not eq_long.empty else False

    return {
        "t_break": float(t_break),
        "found": bool(found),
        "fallback_used": bool(fallback),
        "fallback_reason": str(reason),
        "gap_reward_dt10": gap_reward,
        "gap_long_dt10": gap_long,
        "curve_group_dt10": curve_group_dt10,
        "curve_session_dt10": curve_session_dt10,
        "equivalence_reward_early": bool(eq_rew_ok),
        "equivalence_long_early": bool(eq_long_ok),
    }


def _safe_rate(count: int, width: float) -> float:
    w = float(width)
    if not np.isfinite(w) or w <= 0:
        return np.nan
    return float(count / w)


def _ratio_or_nan(a: float, b: float) -> float:
    a = float(a)
    b = float(b)
    if not np.isfinite(a) or not np.isfinite(b) or b <= 0:
        return np.nan
    return float(a / b)


def _sequence_bias_metrics(seq: np.ndarray, ma: Any) -> dict[str, float]:
    keys = ("bias_in_left", "bias_in_right", "bias_out_left", "bias_out_right")
    if len(seq) < 5:
        return {k: np.nan for k in keys}
    try:
        model = fit_four_bias_model(np.asarray(seq, dtype=int), ma)
        p = np.asarray(model.probs, dtype=float).ravel()
        if p.size < 4:
            return {k: np.nan for k in keys}
        return {
            "bias_in_left": float(p[0]),
            "bias_in_right": float(p[1]),
            "bias_out_left": float(p[2]),
            "bias_out_right": float(p[3]),
        }
    except Exception:
        return {k: np.nan for k in keys}


def _terminal_repeat_rate(seq: np.ndarray) -> float:
    s = np.asarray(seq, dtype=int).ravel()
    if s.size < 2:
        return np.nan
    return float(np.mean(s[1:] == s[:-1]))


def _backtrack_rate(seq: np.ndarray) -> float:
    s = np.asarray(seq, dtype=int).ravel()
    if s.size < 3:
        return np.nan
    return float(np.mean(s[2:] == s[:-2]))


def _depth_progress_rate(seq: np.ndarray, ma: Any) -> float:
    s = np.asarray(seq, dtype=int).ravel()
    if s.size < 2:
        return np.nan
    try:
        depth = np.asarray([ma.di[0, int(v)] for v in s], dtype=float)
    except Exception:
        return np.nan
    d = np.diff(depth)
    if d.size == 0:
        return np.nan
    return float(np.mean(d > 0.0))


def _reward_latency_from_longpath(reward_t: np.ndarray, long_t: np.ndarray, *, lo: float, hi: float, max_wait: float = 300.0) -> float:
    r = np.sort(_safe_numeric(reward_t))
    l = _safe_numeric(long_t)
    l = l[(l >= float(lo)) & (l < float(hi))]
    if l.size == 0 or r.size == 0:
        return np.nan
    out: list[float] = []
    for t in l:
        idx = int(np.searchsorted(r, t, side="left"))
        if idx >= r.size:
            continue
        lag = float(r[idx] - t)
        if 0.0 <= lag <= float(max_wait):
            out.append(lag)
    if not out:
        return np.nan
    return float(np.nanmedian(np.asarray(out, dtype=float)))


def _window_edges(duration: float, window_sec: float) -> np.ndarray:
    dur = float(duration)
    if not np.isfinite(dur) or dur <= 0:
        return np.asarray([0.0, float(window_sec)], dtype=float)
    n = int(max(1, math.ceil(dur / float(window_sec))))
    edges = np.arange(n + 1, dtype=float) * float(window_sec)
    edges[-1] = max(edges[-1], dur)
    return edges


def build_windowed_behavior_table(
    config: MechanismConfig,
    compare_config: ComparisonConfig,
    ma: Any,
    event_table: pd.DataFrame,
    session_qc: pd.DataFrame,
    *,
    working_dir: str | Path,
    t_break: float,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> pd.DataFrame:
    working_dir = Path(working_dir)
    selected_dir = working_dir / "selected_data"
    keep = session_qc.loc[session_qc["load_ok"] == True].copy()  # noqa: E712
    rows: list[dict[str, Any]] = []

    for _, q in keep.iterrows():
        session = str(q["session"])
        group = str(q["group"])
        duration = float(q["maze_duration_sec"])
        tf = load_traj_fn(f"{session}-tf")

        reward_t = _event_time_lookup(event_table, session, "reward")
        long_t = _event_time_lookup(event_table, session, "long_path_reward")
        ctrl_t = _event_time_lookup(event_table, session, "control_path")

        nodes, node_frames = extract_explore_endnode_sequence(tf, ma, return_frames=True)
        node_times = _frames_to_maze_seconds(np.asarray(node_frames, dtype=float), tf, fps=float(compare_config.fps))
        nodes = np.asarray(nodes, dtype=int)
        if nodes.size and node_times.size:
            ok_nodes = np.isfinite(node_times)
            nodes = nodes[ok_nodes]
            node_times = node_times[ok_nodes]

        intervals = _mode_clip_intervals(tf, ma)

        nose_df = _load_optional_csv(selected_dir / f"{session}_nose_interp_data.csv")
        if not nose_df.empty and {"frame", "speed"}.issubset(set(nose_df.columns)):
            speed_frames = pd.to_numeric(nose_df["frame"], errors="coerce").to_numpy(dtype=float)
            speed_vals = pd.to_numeric(nose_df["speed"], errors="coerce").to_numpy(dtype=float)
            speed_times = _frames_to_maze_seconds(speed_frames, tf, fps=float(compare_config.fps))
            ok_sp = np.isfinite(speed_times) & np.isfinite(speed_vals)
            speed_times = speed_times[ok_sp]
            speed_vals = speed_vals[ok_sp]
        else:
            speed_times = np.asarray([], dtype=float)
            speed_vals = np.asarray([], dtype=float)

        edges = _window_edges(duration, float(config.window_sec))
        for wi in range(len(edges) - 1):
            lo = float(edges[wi])
            hi = float(edges[wi + 1])
            width = max(hi - lo, 1e-9)

            reward_n = int(np.sum((reward_t >= lo) & (reward_t < hi)))
            long_n = int(np.sum((long_t >= lo) & (long_t < hi)))
            ctrl_n = int(np.sum((ctrl_t >= lo) & (ctrl_t < hi)))

            leave, drink, explore = _mode_fraction_between(intervals, lo, hi)

            if nodes.size:
                m = (node_times >= lo) & (node_times < hi)
                seq = nodes[m]
            else:
                seq = np.asarray([], dtype=int)
            seq_scalar = compute_scalar_efficiency_metrics(seq) if seq.size >= 5 else {}
            bias = _sequence_bias_metrics(seq, ma)

            outer_pref = float(seq_scalar.get("outer_inner_preference_mean", np.nan))
            entropy = float(seq_scalar.get("entropy_norm_mean", np.nan))
            terminal_rep = _terminal_repeat_rate(seq)
            backtrack = _backtrack_rate(seq)
            depth_prog = _depth_progress_rate(seq, ma)

            sp = (speed_times >= lo) & (speed_times < hi)
            speed_mean = float(np.nanmean(speed_vals[sp])) if np.any(sp) else np.nan
            run_frac = float(np.mean(speed_vals[sp] > 2.0)) if np.any(sp) else np.nan

            rows.append(
                {
                    "session": session,
                    "group": group,
                    "window_index": int(wi),
                    "time_start": lo,
                    "time_end": hi,
                    "time_mid": float((lo + hi) * 0.5),
                    "phase": "pre" if float((lo + hi) * 0.5) < float(t_break) else "post",
                    "reward_rate": _safe_rate(reward_n, width),
                    "long_path_reward_rate": _safe_rate(long_n, width),
                    "reward_per_long_path": _ratio_or_nan(reward_n, long_n),
                    "control_path_rate": _safe_rate(ctrl_n, width),
                    "mode_leave_frac": leave,
                    "mode_drink_frac": drink,
                    "mode_explore_frac": explore,
                    "outer_inner_preference": outer_pref,
                    "entropy_norm": entropy,
                    "bias_in_left": bias["bias_in_left"],
                    "bias_in_right": bias["bias_in_right"],
                    "bias_out_left": bias["bias_out_left"],
                    "bias_out_right": bias["bias_out_right"],
                    "speed_mean": speed_mean,
                    "run_fraction_gt2": run_frac,
                    "reward_latency_from_longpath_med": _reward_latency_from_longpath(reward_t, long_t, lo=lo, hi=hi),
                    "terminal_repeat_rate": terminal_rep,
                    "backtrack_rate": backtrack,
                    "depth_progress_rate": depth_prog,
                }
            )

    return pd.DataFrame(rows)


def build_session_prepost_table(
    windowed_df: pd.DataFrame,
    *,
    t_break: float,
    group_a: str,
    group_b: str,
    metrics: list[str],
) -> pd.DataFrame:
    req = {"session", "group", "time_mid"}
    if windowed_df.empty or not req.issubset(set(windowed_df.columns)):
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for (session, group), sub in windowed_df.groupby(["session", "group"], sort=False):
        row: dict[str, Any] = {"session": str(session), "group": str(group)}
        for m in metrics + ["reward_rate"]:
            if m not in sub.columns:
                row[f"{m}_pre"] = np.nan
                row[f"{m}_post"] = np.nan
                continue
            x = pd.to_numeric(sub[m], errors="coerce")
            pre = x[sub["time_mid"] < float(t_break)]
            post = x[sub["time_mid"] >= float(t_break)]
            row[f"{m}_pre"] = float(np.nanmean(pre)) if np.any(np.isfinite(pre.to_numpy(dtype=float))) else np.nan
            row[f"{m}_post"] = float(np.nanmean(post)) if np.any(np.isfinite(post.to_numpy(dtype=float))) else np.nan
        rows.append(row)
    out = pd.DataFrame(rows)
    out = out.loc[out["group"].astype(str).isin([str(group_a), str(group_b)])].reset_index(drop=True)
    return out


def _group_gap_reduction(y_reward_post: pd.Series, x_metric_post: pd.Series, group_is_a: pd.Series) -> float:
    y = pd.to_numeric(y_reward_post, errors="coerce").to_numpy(dtype=float)
    x = pd.to_numeric(x_metric_post, errors="coerce").to_numpy(dtype=float)
    g = pd.to_numeric(group_is_a, errors="coerce").to_numpy(dtype=float)
    ok = np.isfinite(y) & np.isfinite(x) & np.isfinite(g)
    y = y[ok]
    x = x[ok]
    g = g[ok]
    if y.size < 6 or np.unique(g).size < 2:
        return np.nan
    xz = (x - np.nanmean(x)) / (np.nanstd(x) + 1e-9)
    X0 = np.column_stack([np.ones(y.size), g])
    X1 = np.column_stack([np.ones(y.size), g, xz])
    try:
        b0, *_ = np.linalg.lstsq(X0, y, rcond=None)
        b1, *_ = np.linalg.lstsq(X1, y, rcond=None)
    except Exception:
        return np.nan
    beta0 = float(b0[1]) if len(b0) > 1 else np.nan
    beta1 = float(b1[1]) if len(b1) > 1 else np.nan
    if not np.isfinite(beta0) or abs(beta0) < 1e-9 or not np.isfinite(beta1):
        return np.nan
    return float((abs(beta0) - abs(beta1)) / abs(beta0))


def rank_strategies_strict(
    session_prepost: pd.DataFrame,
    *,
    group_a: str,
    group_b: str,
    metrics: list[str],
    n_perm: int,
    n_boot: int,
    seed: int,
    strict_q: float,
    strict_cliff: float,
    strict_gap_reduction: float,
) -> pd.DataFrame:
    if session_prepost.empty:
        return pd.DataFrame()

    base = session_prepost.copy()
    reward_post = pd.to_numeric(base.get("reward_rate_post", np.nan), errors="coerce")
    gflag = (base["group"].astype(str) == str(group_a)).astype(float)

    rows: list[dict[str, Any]] = []
    for i, m in enumerate(metrics):
        pre = f"{m}_pre"
        post = f"{m}_post"
        if pre not in base.columns or post not in base.columns:
            continue
        dd = base[["session", "group", pre, post]].copy()
        dd["delta"] = pd.to_numeric(dd[post], errors="coerce") - pd.to_numeric(dd[pre], errors="coerce")
        a = _safe_numeric(dd.loc[dd["group"].astype(str) == str(group_a), "delta"].to_numpy())
        b = _safe_numeric(dd.loc[dd["group"].astype(str) == str(group_b), "delta"].to_numpy())
        obs, p = _perm_pvalue(a, b, n_perm=int(n_perm), seed=int(seed) + 1000 * i + 1)
        ci_lo, ci_hi = _bootstrap_diff_ci(a, b, n_boot=int(n_boot), seed=int(seed) + 1000 * i + 2)
        cliff = _cliffs_delta(a, b)
        pooled = float(np.nanstd(np.r_[a, b], ddof=1)) if (a.size + b.size) > 2 else np.nan
        effect_std = float(obs / pooled) if np.isfinite(obs) and np.isfinite(pooled) and pooled > 0 else np.nan
        gap_red = _group_gap_reduction(reward_post, pd.to_numeric(base.get(post, np.nan), errors="coerce"), gflag)
        rows.append(
            {
                "metric": m,
                "n_a": int(a.size),
                "n_b": int(b.size),
                "delta_median_a": float(np.nanmedian(a)) if a.size else np.nan,
                "delta_median_b": float(np.nanmedian(b)) if b.size else np.nan,
                "delta_of_deltas": float(obs),
                "perm_p": float(p),
                "ci_low": float(ci_lo),
                "ci_high": float(ci_hi),
                "cliffs_delta": float(cliff),
                "effect_std": float(effect_std),
                "gap_reduction_reward_rate": float(gap_red),
            }
        )

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["q_value"] = bh_fdr(pd.to_numeric(out["perm_p"], errors="coerce"))
    out["strict_pass"] = (
        (pd.to_numeric(out["q_value"], errors="coerce") < float(strict_q))
        & (np.abs(pd.to_numeric(out["cliffs_delta"], errors="coerce")) >= float(strict_cliff))
        & (pd.to_numeric(out["gap_reduction_reward_rate"], errors="coerce") >= float(strict_gap_reduction))
    )
    out["rank_score"] = np.abs(pd.to_numeric(out["effect_std"], errors="coerce")).fillna(0.0) + np.maximum(
        0.0, pd.to_numeric(out["gap_reduction_reward_rate"], errors="coerce").fillna(0.0)
    )
    out = out.sort_values("rank_score", ascending=False).reset_index(drop=True)
    out["rank"] = np.arange(1, len(out) + 1, dtype=int)
    return out


def _fit_ols(y: np.ndarray, X: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    yhat = X @ beta
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else np.nan
    return beta, yhat, r2


def fit_nested_reward_models(
    session_prepost: pd.DataFrame,
    *,
    group_a: str,
    block_definitions: list[tuple[str, list[str]]],
) -> pd.DataFrame:
    if session_prepost.empty:
        return pd.DataFrame()

    base = session_prepost.copy()
    rows: list[dict[str, Any]] = []

    def fit_with_predictors(model_name: str, predictors: list[str]) -> dict[str, Any]:
        cols = ["reward_rate_post", "group"] + [f"{m}_post" for m in predictors]
        cols = [c for c in cols if c in base.columns]
        d = base[cols].copy()
        d["reward_rate_post"] = pd.to_numeric(d["reward_rate_post"], errors="coerce")
        d["group"] = (base["group"].astype(str) == str(group_a)).astype(float)
        d = d.loc[np.isfinite(d["reward_rate_post"].to_numpy(dtype=float))].copy()
        if d.empty:
            return {
                "model": model_name,
                "n": 0,
                "predictors": json.dumps(predictors),
                "group_beta": np.nan,
                "r2": np.nan,
            }

        yv = pd.to_numeric(d["reward_rate_post"], errors="coerce").to_numpy(dtype=float)
        gv = pd.to_numeric(d["group"], errors="coerce").to_numpy(dtype=float)

        X_cols = [np.ones(len(d), dtype=float), gv]
        for m in predictors:
            c = f"{m}_post"
            if c not in d.columns:
                continue
            xv = pd.to_numeric(d[c], errors="coerce").to_numpy(dtype=float, copy=True)
            med = float(np.nanmedian(xv)) if np.any(np.isfinite(xv)) else 0.0
            xv[~np.isfinite(xv)] = med
            xv = (xv - np.nanmean(xv)) / (np.nanstd(xv) + 1e-9)
            X_cols.append(xv)
        X = np.column_stack(X_cols)
        beta, _, r2 = _fit_ols(yv, X)
        group_beta = float(beta[1]) if beta.size > 1 else np.nan
        return {
            "model": model_name,
            "n": int(len(d)),
            "predictors": json.dumps(predictors),
            "group_beta": float(group_beta),
            "r2": float(r2),
        }

    current: list[str] = []
    rows.append(fit_with_predictors("M0_group_only", current))
    for name, block in block_definitions:
        current = [*current, *block]
        rows.append(fit_with_predictors(name, current))

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    b0 = float(pd.to_numeric(out.loc[out["model"] == "M0_group_only", "group_beta"], errors="coerce").iloc[0])
    if np.isfinite(b0) and abs(b0) > 1e-12:
        out["group_coef_reduction_vs_M0"] = (
            abs(b0) - np.abs(pd.to_numeric(out["group_beta"], errors="coerce"))
        ) / abs(b0)
    else:
        out["group_coef_reduction_vs_M0"] = np.nan
    return out


def _augment_tier2_interactions(session_prepost: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    df = session_prepost.copy()
    added: list[str] = []
    for a, b in TIER2_INTERACTIONS:
        pre_a = f"{a}_pre"
        pre_b = f"{b}_pre"
        post_a = f"{a}_post"
        post_b = f"{b}_post"
        if pre_a not in df.columns or pre_b not in df.columns or post_a not in df.columns or post_b not in df.columns:
            continue
        name = f"{a}__x__{b}"
        df[f"{name}_pre"] = pd.to_numeric(df[pre_a], errors="coerce") * pd.to_numeric(df[pre_b], errors="coerce")
        df[f"{name}_post"] = pd.to_numeric(df[post_a], errors="coerce") * pd.to_numeric(df[post_b], errors="coerce")
        added.append(name)
    return df, added


def evaluate_stability(
    windowed_df: pd.DataFrame,
    *,
    t_break: float,
    group_a: str,
    group_b: str,
    metrics: list[str],
    config: MechanismConfig,
    include_tier2: bool,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    run_rows: list[dict[str, Any]] = []
    shifts = [-300.0, 0.0, 300.0]
    seeds = [0, 1, 2, 3, 4]
    for shift in shifts:
        tb = max(float(config.window_sec), float(t_break) + float(shift))
        for sd in seeds:
            prepost = build_session_prepost_table(
                windowed_df,
                t_break=tb,
                group_a=group_a,
                group_b=group_b,
                metrics=metrics,
            )
            use_metrics = list(metrics)
            if include_tier2:
                prepost, added = _augment_tier2_interactions(prepost)
                use_metrics = [*use_metrics, *added]
            stats = rank_strategies_strict(
                prepost,
                group_a=group_a,
                group_b=group_b,
                metrics=use_metrics,
                n_perm=int(config.n_perm),
                n_boot=int(config.n_boot),
                seed=int(sd + 1000 * (shift + 500.0)),
                strict_q=float(config.strict_q),
                strict_cliff=float(config.strict_cliff),
                strict_gap_reduction=float(config.strict_gap_reduction),
            )
            if stats.empty:
                continue
            for _, r in stats.iterrows():
                run_rows.append(
                    {
                        "metric": str(r["metric"]),
                        "seed": int(sd),
                        "break_shift_sec": float(shift),
                        "strict_pass": bool(r["strict_pass"]),
                        "run_id": f"seed{sd}_shift{int(shift)}",
                    }
                )
    runs = pd.DataFrame(run_rows)
    if runs.empty:
        return pd.DataFrame(columns=["metric", "stability_fraction"]), runs
    stab = runs.groupby("metric", as_index=False)["strict_pass"].mean().rename(columns={"strict_pass": "stability_fraction"})
    return stab, runs


def compute_lead_lag_table(
    windowed_df: pd.DataFrame,
    *,
    group_a: str,
    group_b: str,
    metrics: list[str],
    t_break: float,
    n_perm: int,
    seed: int,
) -> pd.DataFrame:
    _ = group_b
    rows: list[dict[str, Any]] = []
    sub = windowed_df.loc[windowed_df["time_mid"] >= float(t_break)].copy()
    if sub.empty:
        return pd.DataFrame()

    for i, m in enumerate(metrics):
        pairs: list[tuple[float, float, float]] = []
        for (session, group), ss in sub.groupby(["session", "group"], sort=False):
            s2 = ss.sort_values("time_start")
            if len(s2) < 2 or m not in s2.columns:
                continue
            x = pd.to_numeric(s2[m], errors="coerce").to_numpy(dtype=float)
            r = pd.to_numeric(s2["reward_rate"], errors="coerce").to_numpy(dtype=float)
            for j in range(len(x) - 1):
                xx = float(x[j])
                yy = float(r[j + 1] - r[j])
                if np.isfinite(xx) and np.isfinite(yy):
                    g = 1.0 if str(group) == str(group_a) else 0.0
                    pairs.append((xx, yy, g))
        if len(pairs) < 8:
            continue
        arr = np.asarray(pairs, dtype=float)
        x = arr[:, 0]
        y = arr[:, 1]
        g = arr[:, 2]
        xz = (x - np.mean(x)) / (np.std(x) + 1e-9)
        X = np.column_stack([np.ones(x.size), g, xz, g * xz])
        try:
            beta, *_ = np.linalg.lstsq(X, y, rcond=None)
            inter = float(beta[3])
        except Exception:
            inter = np.nan

        rng = np.random.default_rng(int(seed) + 1000 * i + 7)
        n_iter = int(max(300, n_perm))
        perms = np.zeros(n_iter, dtype=float)
        for k in range(n_iter):
            gp = rng.permutation(g)
            Xp = np.column_stack([np.ones(x.size), gp, xz, gp * xz])
            try:
                bp, *_ = np.linalg.lstsq(Xp, y, rcond=None)
                perms[k] = float(bp[3])
            except Exception:
                perms[k] = 0.0
        p = float((1 + np.sum(np.abs(perms) >= abs(inter))) / (n_iter + 1)) if np.isfinite(inter) else np.nan
        rows.append(
            {
                "metric": m,
                "interaction_beta": inter,
                "perm_p": p,
                "n_pairs": int(x.size),
            }
        )
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["q_value"] = bh_fdr(pd.to_numeric(out["perm_p"], errors="coerce"))
    return out.sort_values(["q_value", "perm_p", "metric"]).reset_index(drop=True)


def _plot_gap(gap_df: pd.DataFrame, t_break: float, out_path: Path, title: str) -> str:
    fig, ax = plt.subplots(figsize=(8.8, 4.7))
    if gap_df is None or gap_df.empty:
        ax.text(0.5, 0.5, "No gap data", transform=ax.transAxes, ha="center", va="center")
        ax.set_axis_off()
    else:
        s = gap_df.sort_values("maze_seconds")
        x = pd.to_numeric(s["maze_seconds"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(s["gap_mean"], errors="coerce").to_numpy(dtype=float)
        lo = pd.to_numeric(s["gap_ci_low"], errors="coerce").to_numpy(dtype=float)
        hi = pd.to_numeric(s["gap_ci_high"], errors="coerce").to_numpy(dtype=float)
        ax.plot(x, y, color="#1565c0", lw=2.1)
        ax.fill_between(x, lo, hi, color="#1565c0", alpha=0.18, linewidth=0)
        ax.axhline(0.0, color="#444444", ls=":", lw=1.0)
        if np.isfinite(t_break):
            ax.axvline(float(t_break), color="#222222", ls="--", lw=1.2)
        ax.set_xlabel("Maze time (s)")
        ax.set_ylabel("Control - chemo cumulative gap")
        ax.grid(alpha=0.25)
        ax.set_title(title)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_strategy_timecourses(windowed_df: pd.DataFrame, rank_df: pd.DataFrame, out_path: Path) -> str:
    fig, axes = plt.subplots(2, 2, figsize=(13.2, 8.2), sharex=True)
    axes = axes.ravel()
    if rank_df is None or rank_df.empty or windowed_df.empty:
        for ax in axes:
            ax.text(0.5, 0.5, "No strategy data", transform=ax.transAxes, ha="center", va="center")
            ax.set_axis_off()
    else:
        top_metrics = rank_df["metric"].astype(str).head(4).tolist()
        for ax, m in zip(axes, top_metrics):
            if m not in windowed_df.columns:
                ax.text(0.5, 0.5, f"Missing {m}", transform=ax.transAxes, ha="center", va="center")
                continue
            sub = windowed_df[["group", "time_start", m]].copy()
            ag = sub.groupby(["group", "time_start"], as_index=False)[m].mean()
            for group, ss in ag.groupby("group"):
                s2 = ss.sort_values("time_start")
                x = pd.to_numeric(s2["time_start"], errors="coerce").to_numpy(dtype=float)
                y = pd.to_numeric(s2[m], errors="coerce").to_numpy(dtype=float)
                c = "#c0392b" if "Chemo" in str(group) else "#1f77b4"
                ax.plot(x, y, lw=2.0, color=c, label=str(group))
            ax.set_title(m)
            ax.grid(alpha=0.25)
        for ax in axes:
            ax.set_xlabel("Window start (s)")
        handles, labels = axes[0].get_legend_handles_labels()
        if handles:
            axes[0].legend(frameon=False, fontsize=8)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_conversion_latency(windowed_df: pd.DataFrame, out_path: Path) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(12.6, 4.6), sharex=True)
    metrics = ["reward_per_long_path", "reward_latency_from_longpath_med"]
    for ax, m in zip(axes, metrics):
        if windowed_df.empty or m not in windowed_df.columns:
            ax.text(0.5, 0.5, "No data", transform=ax.transAxes, ha="center", va="center")
            ax.set_axis_off()
            continue
        ag = windowed_df.groupby(["group", "time_start"], as_index=False)[m].mean()
        for group, ss in ag.groupby("group"):
            s2 = ss.sort_values("time_start")
            x = pd.to_numeric(s2["time_start"], errors="coerce").to_numpy(dtype=float)
            y = pd.to_numeric(s2[m], errors="coerce").to_numpy(dtype=float)
            c = "#c0392b" if "Chemo" in str(group) else "#1f77b4"
            ax.plot(x, y, color=c, lw=2.0, label=str(group))
        ax.set_title(m)
        ax.grid(alpha=0.25)
        ax.set_xlabel("Window start (s)")
    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        axes[0].legend(frameon=False, fontsize=8)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_nested_models(nested_df: pd.DataFrame, out_path: Path) -> str:
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    if nested_df.empty:
        ax.text(0.5, 0.5, "No nested-model results", transform=ax.transAxes, ha="center", va="center")
        ax.set_axis_off()
    else:
        s = nested_df.copy()
        x = np.arange(len(s), dtype=float)
        y = pd.to_numeric(s["group_coef_reduction_vs_M0"], errors="coerce").to_numpy(dtype=float)
        ax.bar(x, y, color="#2e7d32", alpha=0.85)
        ax.set_xticks(x, s["model"].astype(str).tolist(), rotation=25, ha="right")
        ax.set_ylabel("Group-coef reduction vs M0")
        ax.set_ylim(min(-0.05, np.nanmin(y) - 0.05), max(1.0, np.nanmax(y) + 0.05))
        ax.grid(alpha=0.25, axis="y")
        ax.set_title("Nested reward models")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_strategy_forest(rank_df: pd.DataFrame, out_path: Path) -> str:
    fig, ax = plt.subplots(figsize=(9.2, 6.0))
    if rank_df.empty:
        ax.text(0.5, 0.5, "No mechanism ranking", transform=ax.transAxes, ha="center", va="center")
        ax.set_axis_off()
    else:
        s = rank_df.sort_values("rank_score", ascending=True).reset_index(drop=True)
        y = np.arange(len(s), dtype=float)
        x = pd.to_numeric(s["cliffs_delta"], errors="coerce").to_numpy(dtype=float)
        lo = pd.to_numeric(s["ci_low"], errors="coerce").to_numpy(dtype=float)
        hi = pd.to_numeric(s["ci_high"], errors="coerce").to_numpy(dtype=float)
        c = np.where(s["stable_strict_pass"].astype(bool), "#2e7d32", "#546e7a")
        ax.hlines(y, lo, hi, color="#90a4ae", lw=1.5)
        ax.scatter(x, y, c=c, s=46)
        labels = [f"{m} | q={q:.3g}" for m, q in zip(s["metric"], pd.to_numeric(s["q_value"], errors="coerce"))]
        ax.set_yticks(y, labels)
        ax.axvline(0.0, color="#444444", ls=":", lw=1.0)
        ax.set_xlabel("Delta-of-deltas (median) with CI")
        ax.set_title("Strategy effects and significance")
        ax.grid(alpha=0.2, axis="x")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_stability_matrix(stability_runs: pd.DataFrame, out_path: Path) -> str:
    fig, ax = plt.subplots(figsize=(10.0, 5.4))
    if stability_runs.empty:
        ax.text(0.5, 0.5, "No stability runs", transform=ax.transAxes, ha="center", va="center")
        ax.set_axis_off()
    else:
        piv = stability_runs.pivot_table(index="metric", columns="run_id", values="strict_pass", aggfunc="mean")
        arr = piv.to_numpy(dtype=float)
        im = ax.imshow(arr, aspect="auto", cmap="viridis", vmin=0.0, vmax=1.0)
        ax.set_yticks(np.arange(piv.shape[0]), piv.index.astype(str).tolist())
        ax.set_xticks(np.arange(piv.shape[1]), piv.columns.astype(str).tolist(), rotation=55, ha="right")
        ax.set_title("Strict-pass stability across seed x breakpoint shift")
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label("strict pass")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def _plot_leadlag(leadlag_df: pd.DataFrame, out_path: Path) -> str:
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    if leadlag_df.empty:
        ax.text(0.5, 0.5, "No lead-lag results", transform=ax.transAxes, ha="center", va="center")
        ax.set_axis_off()
    else:
        s = leadlag_df.head(10).copy()
        x = np.arange(len(s), dtype=float)
        y = pd.to_numeric(s["interaction_beta"], errors="coerce").to_numpy(dtype=float)
        colors = ["#2e7d32" if q < 0.05 else "#607d8b" for q in pd.to_numeric(s["q_value"], errors="coerce")]
        ax.bar(x, y, color=colors)
        ax.set_xticks(x, s["metric"].astype(str).tolist(), rotation=30, ha="right")
        ax.axhline(0.0, color="#444444", ls=":", lw=1.0)
        ax.set_ylabel("Group x metric interaction beta")
        ax.set_title("Lead-lag strategy to reward-gain coupling")
        ax.grid(alpha=0.25, axis="y")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return str(out_path)


def run_strict_attribution(
    config: MechanismConfig,
    *,
    working_dir: str | Path,
    ma: Any,
    regen_selected_data: bool = False,
    load_traj_fn: Callable[[str], Any] = LoadTraj,
) -> dict[str, Any]:
    mem_log: list[dict[str, Any]] = []

    def mark(stage: str) -> None:
        mem_log.append({"stage": stage, "memory_gb": _memory_gb(), "timestamp": float(time.time())})

    mark("start")
    base_cfg0 = default_comparison_config()
    base_cfg = replace(
        base_cfg0,
        reward_node=int(config.reward_node),
        long_path_min=int(config.long_path_min),
        time_bin_sec=int(config.window_sec),
        consecutive_bins=int(config.consecutive_outside),
    )

    base = run_full_analysis(
        base_cfg,
        working_dir=Path(working_dir),
        ma=ma,
        regen_selected_data=bool(regen_selected_data),
        load_traj_fn=load_traj_fn,
        n_boot=int(config.n_boot),
        n_perm=int(config.n_perm),
        seed=int(config.seed),
    )
    mark("base_analysis")

    bp = estimate_breakpoint_gap_ci_dt10(base["event_table"], base["session_qc"], base_cfg, config)
    t_break = float(bp["t_break"])
    mark("breakpoint_dt10")

    windowed = build_windowed_behavior_table(
        config,
        base_cfg,
        ma,
        base["event_table"],
        base["session_qc"],
        working_dir=Path(working_dir),
        t_break=t_break,
        load_traj_fn=load_traj_fn,
    )
    mark("windowed_metrics")

    metrics = [*BASE_METRICS, *EXTRA_METRICS]
    prepost = build_session_prepost_table(
        windowed,
        t_break=t_break,
        group_a=base_cfg.group_a_name,
        group_b=base_cfg.group_b_name,
        metrics=metrics,
    )

    rank = rank_strategies_strict(
        prepost,
        group_a=base_cfg.group_a_name,
        group_b=base_cfg.group_b_name,
        metrics=metrics,
        n_perm=int(config.n_perm),
        n_boot=int(config.n_boot),
        seed=int(config.seed),
        strict_q=float(config.strict_q),
        strict_cliff=float(config.strict_cliff),
        strict_gap_reduction=float(config.strict_gap_reduction),
    )

    blocks = [
        ("M1_opportunity", ["long_path_reward_rate", "control_path_rate", "depth_progress_rate"]),
        ("M2_conversion", ["reward_per_long_path", "reward_latency_from_longpath_med"]),
        ("M3_state", ["mode_drink_frac", "mode_explore_frac"]),
        (
            "M4_policy",
            ["outer_inner_preference", "entropy_norm", "bias_in_left", "bias_in_right", "bias_out_left", "bias_out_right"],
        ),
        ("M5_locomotion", ["speed_mean", "run_fraction_gt2", "backtrack_rate", "terminal_repeat_rate"]),
    ]
    nested = fit_nested_reward_models(prepost, group_a=base_cfg.group_a_name, block_definitions=blocks)
    mark("tier1_rank")

    stab_summary, stab_runs = evaluate_stability(
        windowed,
        t_break=t_break,
        group_a=base_cfg.group_a_name,
        group_b=base_cfg.group_b_name,
        metrics=metrics,
        config=config,
        include_tier2=False,
    )
    if not rank.empty and not stab_summary.empty:
        rank = rank.merge(stab_summary, on="metric", how="left")
    rank["stability_fraction"] = pd.to_numeric(rank.get("stability_fraction", np.nan), errors="coerce")
    rank["stable_strict_pass"] = rank["strict_pass"].astype(bool) & (
        rank["stability_fraction"] >= float(config.strict_stability_frac)
    )
    mark("tier1_stability")

    tier_used = "tier1"
    rank_tier1 = rank.copy()

    if rank.empty or not bool(rank["stable_strict_pass"].any()):
        tier_used = "tier2"
        prepost_t2, added = _augment_tier2_interactions(prepost)
        metrics_t2 = [*metrics, *added]
        rank = rank_strategies_strict(
            prepost_t2,
            group_a=base_cfg.group_a_name,
            group_b=base_cfg.group_b_name,
            metrics=metrics_t2,
            n_perm=int(config.n_perm),
            n_boot=int(config.n_boot),
            seed=int(config.seed) + 100,
            strict_q=float(config.strict_q),
            strict_cliff=float(config.strict_cliff),
            strict_gap_reduction=float(config.strict_gap_reduction),
        )
        nested = fit_nested_reward_models(prepost_t2, group_a=base_cfg.group_a_name, block_definitions=blocks)
        stab_summary, stab_runs = evaluate_stability(
            windowed,
            t_break=t_break,
            group_a=base_cfg.group_a_name,
            group_b=base_cfg.group_b_name,
            metrics=metrics,
            config=config,
            include_tier2=True,
        )
        if not rank.empty and not stab_summary.empty:
            rank = rank.merge(stab_summary, on="metric", how="left")
        rank["stability_fraction"] = pd.to_numeric(rank.get("stability_fraction", np.nan), errors="coerce")
        rank["stable_strict_pass"] = rank["strict_pass"].astype(bool) & (
            rank["stability_fraction"] >= float(config.strict_stability_frac)
        )
        mark("tier2_stability")

    leadlag = pd.DataFrame()
    if rank.empty or not bool(rank["stable_strict_pass"].any()):
        tier_used = "tier3"
        leadlag = compute_lead_lag_table(
            windowed,
            group_a=base_cfg.group_a_name,
            group_b=base_cfg.group_b_name,
            metrics=metrics,
            t_break=t_break,
            n_perm=int(config.n_perm),
            seed=int(config.seed),
        )
        mark("tier3_leadlag")
    else:
        leadlag = compute_lead_lag_table(
            windowed,
            group_a=base_cfg.group_a_name,
            group_b=base_cfg.group_b_name,
            metrics=metrics,
            t_break=t_break,
            n_perm=max(500, int(config.n_perm) // 2),
            seed=int(config.seed),
        )

    strict = rank.copy()
    strict_pass_any = bool(strict.get("stable_strict_pass", pd.Series(dtype=bool)).any()) if not strict.empty else False
    strict_summary = pd.DataFrame(
        [
            {
                "strict_pass_any": bool(strict_pass_any),
                "tier_used": str(tier_used),
                "t_break": float(t_break),
                "equivalence_reward_early": bool(bp.get("equivalence_reward_early", False)),
                "equivalence_long_early": bool(bp.get("equivalence_long_early", False)),
                "n_metrics_tested": int(len(strict)),
                "memory_gb_final": _memory_gb(),
            }
        ]
    )

    mark("done")
    memory_table = pd.DataFrame(mem_log)
    return {
        "config": config,
        "compare_config": base_cfg,
        "base_result": base,
        "breakpoint_report": pd.DataFrame(
            [
                {
                    "t_break": float(bp["t_break"]),
                    "found": bool(bp["found"]),
                    "fallback_used": bool(bp["fallback_used"]),
                    "fallback_reason": str(bp["fallback_reason"]),
                    "equivalence_reward_early": bool(bp["equivalence_reward_early"]),
                    "equivalence_long_early": bool(bp["equivalence_long_early"]),
                }
            ]
        ),
        "curve_group_dt10": bp["curve_group_dt10"],
        "curve_session_dt10": bp["curve_session_dt10"],
        "gap_reward_dt10": bp["gap_reward_dt10"],
        "gap_long_dt10": bp["gap_long_dt10"],
        "windowed_behavior_table": windowed,
        "session_prepost_table": prepost,
        "strategy_rank_table": rank,
        "strategy_rank_tier1": rank_tier1,
        "nested_model_table": nested,
        "stability_table": stab_summary,
        "stability_runs": stab_runs,
        "leadlag_table": leadlag,
        "strict_pass_table": strict,
        "strict_summary": strict_summary,
        "memory_table": memory_table,
    }


def export_stage2_outputs(
    result: dict[str, Any],
    output_dir: str | Path,
    fig_dir: str | Path,
) -> dict[str, str]:
    out = Path(output_dir)
    fig = Path(fig_dir)
    out.mkdir(parents=True, exist_ok=True)
    fig.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, str] = {}

    table_keys = [
        "breakpoint_report",
        "curve_group_dt10",
        "curve_session_dt10",
        "gap_reward_dt10",
        "gap_long_dt10",
        "windowed_behavior_table",
        "session_prepost_table",
        "strategy_rank_table",
        "strategy_rank_tier1",
        "nested_model_table",
        "stability_table",
        "stability_runs",
        "leadlag_table",
        "strict_pass_table",
        "strict_summary",
        "memory_table",
    ]
    for k in table_keys:
        df = result.get(k, None)
        if isinstance(df, pd.DataFrame):
            p = out / f"{k}.csv"
            df.to_csv(p, index=False)
            manifest[k] = str(p)

    bp_df = result.get("breakpoint_report", pd.DataFrame())
    if isinstance(bp_df, pd.DataFrame) and not bp_df.empty:
        t_break = float(pd.to_numeric(bp_df["t_break"], errors="coerce").iloc[0])
    else:
        t_break = np.nan

    manifest["fig11_reward_gap_dt10_breakpoint"] = _plot_gap(
        result.get("gap_reward_dt10", pd.DataFrame()),
        t_break,
        fig / "fig11_reward_gap_dt10_breakpoint.png",
        "Reward cumulative gap with breakpoint",
    )
    manifest["fig12_longpath_gap_dt10_breakpoint"] = _plot_gap(
        result.get("gap_long_dt10", pd.DataFrame()),
        t_break,
        fig / "fig12_longpath_gap_dt10_breakpoint.png",
        "Long-path cumulative gap with breakpoint",
    )
    manifest["fig13_strategy_timecourses_postbreak"] = _plot_strategy_timecourses(
        result.get("windowed_behavior_table", pd.DataFrame()),
        result.get("strategy_rank_table", pd.DataFrame()),
        fig / "fig13_strategy_timecourses_postbreak.png",
    )
    manifest["fig14_conversion_latency_panels"] = _plot_conversion_latency(
        result.get("windowed_behavior_table", pd.DataFrame()),
        fig / "fig14_conversion_latency_panels.png",
    )
    manifest["fig15_nested_model_group_coef_drop"] = _plot_nested_models(
        result.get("nested_model_table", pd.DataFrame()),
        fig / "fig15_nested_model_group_coef_drop.png",
    )
    manifest["fig16_strategy_forest_q_effect"] = _plot_strategy_forest(
        result.get("strategy_rank_table", pd.DataFrame()),
        fig / "fig16_strategy_forest_q_effect.png",
    )
    manifest["fig17_stability_matrix_seed_breakshift"] = _plot_stability_matrix(
        result.get("stability_runs", pd.DataFrame()),
        fig / "fig17_stability_matrix_seed_breakshift.png",
    )
    manifest["fig18_leadlag_strategy_reward"] = _plot_leadlag(
        result.get("leadlag_table", pd.DataFrame()),
        fig / "fig18_leadlag_strategy_reward.png",
    )

    run_manifest = {
        "mechanism_config": asdict(result.get("config")),
        "comparison_config": asdict(result.get("compare_config")),
        "strict_pass_any": bool(
            result.get("strict_pass_table", pd.DataFrame()).get("stable_strict_pass", pd.Series(dtype=bool)).any()
            if isinstance(result.get("strict_pass_table", None), pd.DataFrame)
            else False
        ),
        "manifest": manifest,
    }
    mp = out / "mechanism_stage2_manifest.json"
    mp.write_text(json.dumps(run_manifest, indent=2), encoding="utf-8")
    manifest["mechanism_stage2_manifest"] = str(mp)
    return manifest


__all__ = [
    "MechanismConfig",
    "BASE_METRICS",
    "EXTRA_METRICS",
    "TIER2_INTERACTIONS",
    "bh_fdr",
    "estimate_breakpoint_gap_ci_dt10",
    "build_windowed_behavior_table",
    "build_session_prepost_table",
    "rank_strategies_strict",
    "fit_nested_reward_models",
    "compute_lead_lag_table",
    "run_strict_attribution",
    "export_stage2_outputs",
]
