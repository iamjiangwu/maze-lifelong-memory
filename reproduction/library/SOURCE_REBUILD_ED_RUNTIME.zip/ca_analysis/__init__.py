from __future__ import annotations

from importlib import import_module

_SUBMODULES = {
    'io',
    'behavior',
    'spatial',
    'similarity',
    'stats',
    'plotting',
    'alignment',
    'quality',
    'compat',
    'config',
    'mm',
    'decoding',
    'glm',
    'maze',
    'trajectory',
    'maze_behavior',
    'mode_analysis',
    'behavior_models',
    'rotation',
    'symmetry_permutation',
    'exploration',
    'mm_maze_utils',
    'mm_plot_utils',
    'data_loader_utils',
    'query_data_utils',
    'meta_data_loader_utils',
    'group_series_plotting_utils',
    'nmlfunc_utils',
    'decoding_utils_lib',
    'decoding_solutions_lib',
    'sparsity_utils_lib',
    'mm_traj',
    'jw_utils',
    'chemo_day2_compare',
    'chemo_day2_plotting',
    'population_sparsity_controls',
    'figure_panels',
    'figure_supplement_panels',
    'reward_reorganization',
    'session_loader_tools',
    'neural_gui_app',
    'notebook_utils',
    'simulation',
    'rapid_learning_dynamics',
    'rapid_learning_arcrit',
    'rapid_learning_neural_codes',
    'rapid_learning_phase0',
    'rapid_learning_phase3',
    'rapid_learning_policy',
    'rapid_learning_reward',
    'rapid_learning_reporting',
    'rapid_learning_stats',
}

__all__ = sorted(_SUBMODULES)


def __getattr__(name: str):
    if name in _SUBMODULES:
        module = import_module(f'.{name}', __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__():
    return sorted(set(globals().keys()) | _SUBMODULES)
